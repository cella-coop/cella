--
-- PostgreSQL database dump
--

\restrict qk5MaGWnnMZyLzOwz0jTpc6RtuKCGdHGp6NRzhitNDPBc5iDHI5Eg8Kd1QH320a

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: account; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account;


--
-- Name: account_decision; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_decision;


--
-- Name: account_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_membership;


--
-- Name: account_membership_patronage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_membership_patronage;


--
-- Name: account_membership_patronage_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_membership_patronage_transaction;


--
-- Name: account_membership_payslip_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_membership_payslip_transaction;


--
-- Name: account_membership_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_membership_transaction;


--
-- Name: account_patronage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_patronage;


--
-- Name: account_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA account_transaction;


--
-- Name: cella; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA cella;


--
-- Name: circle; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle;


--
-- Name: circle_decision; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_decision;


--
-- Name: circle_decision_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_decision_membership;


--
-- Name: circle_expense_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_expense_membership;


--
-- Name: circle_file_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_file_membership;


--
-- Name: circle_meeting; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_meeting;


--
-- Name: circle_meeting_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_meeting_membership;


--
-- Name: circle_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_membership;


--
-- Name: circle_membership_project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_membership_project;


--
-- Name: circle_membership_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA circle_membership_timesheet;


--
-- Name: client; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA client;


--
-- Name: client_invoice; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA client_invoice;


--
-- Name: client_project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA client_project;


--
-- Name: decision; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision;


--
-- Name: decision_document; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision_document;


--
-- Name: decision_employment_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision_employment_membership;


--
-- Name: decision_meeting; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision_meeting;


--
-- Name: decision_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision_membership;


--
-- Name: decision_patronage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA decision_patronage;


--
-- Name: document; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA document;


--
-- Name: document_meeting; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA document_meeting;


--
-- Name: document_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA document_membership;


--
-- Name: employment; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment;


--
-- Name: employment_file; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment_file;


--
-- Name: employment_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment_membership;


--
-- Name: employment_payslip; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment_payslip;


--
-- Name: employment_project_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment_project_timesheet;


--
-- Name: employment_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA employment_timesheet;


--
-- Name: expense; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense;


--
-- Name: expense_file; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense_file;


--
-- Name: expense_invoice_project_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense_invoice_project_timesheet;


--
-- Name: expense_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense_membership;


--
-- Name: expense_project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense_project;


--
-- Name: expense_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA expense_transaction;


--
-- Name: file; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA file;


--
-- Name: file_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA file_membership;


--
-- Name: import; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA import;


--
-- Name: invoice; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA invoice;


--
-- Name: invoice_project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA invoice_project;


--
-- Name: invoice_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA invoice_transaction;


--
-- Name: meeting; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA meeting;


--
-- Name: meeting_membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA meeting_membership;


--
-- Name: membership; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA membership;


--
-- Name: membership_project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA membership_project;


--
-- Name: membership_task; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA membership_task;


--
-- Name: membership_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA membership_timesheet;


--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA migration;


--
-- Name: patronage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA patronage;


--
-- Name: patronage_payslip; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA patronage_payslip;


--
-- Name: patronage_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA patronage_timesheet;


--
-- Name: patronage_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA patronage_transaction;


--
-- Name: payslip; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA payslip;


--
-- Name: payslip_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA payslip_timesheet;


--
-- Name: payslip_transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA payslip_transaction;


--
-- Name: person; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA person;


--
-- Name: project; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA project;


--
-- Name: project_task; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA project_task;


--
-- Name: project_timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA project_timesheet;


--
-- Name: task; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA task;


--
-- Name: timesheet; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA timesheet;


--
-- Name: transaction; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA transaction;


--
-- Name: cella; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS cella WITH SCHEMA cella VERSION '0.1.0-alpha';


--
-- Name: EXTENSION cella; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION cella IS 'cella: the notary and the rule primitives';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: terms; Type: TABLE; Schema: account; Owner: -
--

CREATE TABLE account.terms (
    id text NOT NULL,
    "from" integer NOT NULL,
    share cella.amount NOT NULL,
    minimum integer NOT NULL,
    instalments integer NOT NULL,
    delay integer NOT NULL,
    repayments integer NOT NULL,
    adopted date,
    CONSTRAINT terms_delay_check CHECK ((delay >= 0)),
    CONSTRAINT terms_from_check CHECK ((("from" >= 1900) AND ("from" <= 9999))),
    CONSTRAINT terms_instalments_check CHECK ((instalments > 0)),
    CONSTRAINT terms_minimum_check CHECK ((minimum > 0)),
    CONSTRAINT terms_repayments_check CHECK ((repayments > 0))
);


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (t.id IS NULL) THEN ('no terms '::text || COALESCE(x.terms, 'are named'::text))
             WHEN (t.adopted IS DISTINCT FROM cella.verdict_date()) THEN (t.id || ' were not adopted by this write'::text)
             WHEN ((t.delay + (12 * (t.repayments - 1))) > 60) THEN (((t.id || ' repay a departing associate '::text) || (t.delay + (12 * (t.repayments - 1)))) || ' months after the exit: a SCOP repays within five years'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (adopts.payload ->> 'terms'::text) AS terms) x
      LEFT JOIN account.terms t ON ((t.id = x.terms)));
END;


--
-- Name: capital_for(date); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.capital_for(day date) RETURNS text
    LANGUAGE sql STABLE
    RETURN (SELECT t.id FROM account.terms t WHERE ((t.adopted IS NOT NULL) AND ((t."from")::numeric <= EXTRACT(year FROM capital_for.day))) ORDER BY t."from" DESC, t.adopted DESC, t.id DESC LIMIT 1);


--
-- Name: period_end(text); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.period_end(month text) RETURNS date
    LANGUAGE sql IMMUTABLE
    RETURN ((to_date(month, 'YYYY-MM'::text) + '1 mon'::interval))::date;


--
-- Name: period; Type: TABLE; Schema: account; Owner: -
--

CREATE TABLE account.period (
    month text NOT NULL,
    closed date,
    CONSTRAINT period_month_check CHECK ((month ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'::text))
);


--
-- Name: closes(jsonb); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.closes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.month IS NULL) THEN ('no period '::text || COALESCE(x.month, 'is named'::text))
             WHEN (p.closed IS DISTINCT FROM cella.verdict_date()) THEN (p.month || ' was not closed by this write'::text)
             WHEN (p.closed < account.period_end(p.month)) THEN ((p.month || ' runs until '::text) || to_char(((account.period_end(p.month) - 1))::timestamp with time zone, 'YYYY-MM-DD'::text))
             WHEN (EXISTS ( SELECT
                FROM account.period q
               WHERE ((q.month < p.month) AND (q.closed IS NULL)))) THEN ((p.month || ' closes after '::text) || ( SELECT min(q.month) AS min
                FROM account.period q
               WHERE ((q.month < p.month) AND (q.closed IS NULL))))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (closes.payload ->> 'month'::text) AS month) x
      LEFT JOIN account.period p ON ((p.month = x.month)));
END;


--
-- Name: kind_of(text); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.kind_of(code text) RETURNS text
    LANGUAGE sql IMMUTABLE
    RETURN CASE WHEN (code ~ '^1[0-4]'::text) THEN 'equity'::text WHEN (code ~ '^1'::text) THEN 'liability'::text WHEN (code ~ '^[235]'::text) THEN 'asset'::text WHEN (code ~ '^(409|41|4456|4562)'::text) THEN 'asset'::text WHEN (code ~ '^4'::text) THEN 'liability'::text WHEN (code ~ '^6'::text) THEN 'expense'::text WHEN (code ~ '^7'::text) THEN 'income'::text ELSE NULL::text END;


--
-- Name: repayments(text, date); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.repayments(terms text, exited date) RETURNS TABLE(n integer, due date)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT k.n,
     ((repayments.exited + make_interval(months => (t.delay + (12 * (k.n - 1))))))::date AS date
    FROM (account.terms t
      CROSS JOIN LATERAL generate_series(1, t.repayments) k(n))
   WHERE (t.id = repayments.terms)
   ORDER BY k.n;
END;


--
-- Name: rubric; Type: TABLE; Schema: account; Owner: -
--

CREATE TABLE account.rubric (
    id text NOT NULL,
    sheet text NOT NULL,
    n integer NOT NULL,
    kind text NOT NULL,
    label text NOT NULL,
    side text,
    prefixes text[] DEFAULT '{}'::text[] NOT NULL,
    adds text[] DEFAULT '{}'::text[] NOT NULL,
    subtracts text[] DEFAULT '{}'::text[] NOT NULL,
    CONSTRAINT rubric_check CHECK (((kind = 'line'::text) = (side IS NOT NULL))),
    CONSTRAINT rubric_check1 CHECK (((kind = 'line'::text) OR (prefixes = '{}'::text[]))),
    CONSTRAINT rubric_check2 CHECK (((kind = 'total'::text) OR ((adds = '{}'::text[]) AND (subtracts = '{}'::text[])))),
    CONSTRAINT rubric_id_check CHECK ((id ~ '^[a-z]+(-[a-z]+)*$'::text)),
    CONSTRAINT rubric_kind_check CHECK ((kind = ANY (ARRAY['heading'::text, 'line'::text, 'total'::text]))),
    CONSTRAINT rubric_label_check CHECK ((label <> ''::text)),
    CONSTRAINT rubric_n_check CHECK ((n > 0)),
    CONSTRAINT rubric_sheet_check CHECK ((sheet = ANY (ARRAY['balance'::text, 'income'::text]))),
    CONSTRAINT rubric_side_check CHECK ((side = ANY (ARRAY['debit'::text, 'credit'::text])))
);


--
-- Name: rubric_of(text, text); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.rubric_of(sheet text, code text) RETURNS text
    LANGUAGE sql STABLE
    RETURN (SELECT r.id FROM account.rubric r, LATERAL unnest(r.prefixes) p(p) WHERE ((r.sheet = rubric_of.sheet) AND (r.kind = 'line'::text) AND (rubric_of.code ~~ (p.p || '%'::text))) ORDER BY (length(p.p)) DESC LIMIT 1);


--
-- Name: stays_adopted(); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.stays_adopted() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.adopted IS NOT NULL THEN
    RAISE EXCEPTION '% were adopted on %', OLD.id, OLD.adopted
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: stays_closed(); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.stays_closed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.closed IS NOT NULL THEN
    RAISE EXCEPTION '% closed on %', OLD.month, OLD.closed
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: stays_frozen(); Type: FUNCTION; Schema: account; Owner: -
--

CREATE FUNCTION account.stays_frozen() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.frozen AND NOT NEW.frozen THEN
    RAISE EXCEPTION '% is frozen until it is repaid', OLD.code
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: adoption; Type: TABLE; Schema: account_decision; Owner: -
--

CREATE TABLE account_decision.adoption (
    terms text NOT NULL,
    decision text NOT NULL
);


--
-- Name: decision; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.decision (
    id text NOT NULL,
    circle text NOT NULL,
    title text NOT NULL,
    rule text NOT NULL,
    proposed date NOT NULL,
    deadline date NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    closed date,
    cutoff bigint,
    procedure text NOT NULL,
    CONSTRAINT decision_check CHECK (((closed IS NULL) = (cutoff IS NULL))),
    CONSTRAINT decision_rule_check CHECK ((rule = ANY (ARRAY['consent'::text, 'majority'::text])))
);


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: account_decision; Owner: -
--

CREATE FUNCTION account_decision.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM account_decision.adoption a
               WHERE ((a.terms = p.terms) AND (a.decision = d.id))))) THEN ((d.id || ' does not adopt '::text) || COALESCE(p.terms, 'these terms'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (adopts.payload ->> 'decision'::text) AS decision,
             (adopts.payload ->> 'terms'::text) AS terms) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: motion; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.motion (
    decision text NOT NULL,
    n integer NOT NULL,
    kind text NOT NULL,
    args jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT motion_args_check CHECK ((jsonb_typeof(args) = 'object'::text)),
    CONSTRAINT motion_n_check CHECK ((n > 0))
);


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: account_decision; Owner: -
--

CREATE FUNCTION account_decision.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (t.id IS NULL) THEN (('no terms '::text || COALESCE((m.args ->> 'terms'::text), 'are named'::text)) || ' to adopt'::text)
                     WHEN (t.adopted IS NOT NULL) THEN ((t.id || ' were adopted on '::text) || to_char((t.adopted)::timestamp with time zone, 'YYYY-MM-DD'::text))
                     WHEN (a.decision IS NULL) THEN ((m.decision || ' does not ask to adopt '::text) || t.id)
                     ELSE NULL::text
                 END AS r
            FROM ((decision.motion m
              LEFT JOIN account.terms t ON ((t.id = (m.args ->> 'terms'::text))))
              LEFT JOIN account_decision.adoption a ON (((a.decision = m.decision) AND (a.terms = t.id))))
           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'terms'::text))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: moved(); Type: FUNCTION; Schema: account_decision; Owner: -
--

CREATE FUNCTION account_decision.moved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind <> 'terms' THEN
    RETURN NEW;
  END IF;
  INSERT INTO account_decision.adoption (terms, decision)
  SELECT t.id, NEW.decision FROM account.terms t WHERE t.id = NEW.args ->> 'terms' AND t.adopted IS NULL;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no terms % to adopt', coalesce(NEW.args ->> 'terms', 'are named')
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: freezes(); Type: FUNCTION; Schema: account_membership; Owner: -
--

CREATE FUNCTION account_membership.freezes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status = 'exited' AND OLD.status <> 'exited' THEN
    UPDATE account.account SET frozen = true WHERE holder = NEW.address AND NOT frozen;
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: held(); Type: FUNCTION; Schema: account_membership; Owner: -
--

CREATE FUNCTION account_membership.held() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.holder IS NOT NULL AND NOT EXISTS (SELECT FROM membership.member m WHERE m.address = NEW.holder) THEN
    RAISE EXCEPTION '% is held by %, who is no member', NEW.code, NEW.holder
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: value(date); Type: FUNCTION; Schema: account_membership; Owner: -
--

CREATE FUNCTION account_membership.value(day date) RETURNS bigint
    LANGUAGE sql STABLE
    RETURN (SELECT cella.cents(t.share) AS cents FROM account.terms t WHERE (t.id = account.capital_for(value.day)));


--
-- Name: credit; Type: TABLE; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE TABLE account_membership_patronage_transaction.credit (
    distribution text NOT NULL,
    member text NOT NULL,
    account text NOT NULL,
    shares integer NOT NULL,
    amount cella.amount NOT NULL,
    until date NOT NULL,
    entry text NOT NULL,
    CONSTRAINT credit_shares_check CHECK ((shares > 0))
);


--
-- Name: employing(text); Type: FUNCTION; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE FUNCTION account_membership_patronage_transaction.employing(ref text) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT '424'::text,
     'debit'::text,
     (sum(cella.cents(c.amount)))::bigint AS sum
    FROM account_membership_patronage_transaction.credit c
   WHERE (c.distribution = employing.ref)
  HAVING (count(*) > 0)
 UNION ALL
  SELECT c.account,
     'credit'::text,
     cella.cents(c.amount) AS cents
    FROM account_membership_patronage_transaction.credit c
   WHERE (c.distribution = employing.ref);
END;


--
-- Name: terms; Type: TABLE; Schema: patronage; Owner: -
--

CREATE TABLE patronage.terms (
    id text NOT NULL,
    "from" integer NOT NULL,
    salary numeric(5,2) DEFAULT 0 NOT NULL,
    hours numeric(5,2) DEFAULT 0 NOT NULL,
    equal numeric(5,2) DEFAULT 0 NOT NULL,
    capital numeric(5,2) DEFAULT 0 NOT NULL,
    adopted date,
    CONSTRAINT terms_capital_check CHECK (((capital >= (0)::numeric) AND (capital <= (100)::numeric))),
    CONSTRAINT terms_equal_check CHECK (((equal >= (0)::numeric) AND (equal <= (100)::numeric))),
    CONSTRAINT terms_from_check CHECK ((("from" >= 1900) AND ("from" <= 9999))),
    CONSTRAINT terms_hours_check CHECK (((hours >= (0)::numeric) AND (hours <= (100)::numeric))),
    CONSTRAINT terms_salary_check CHECK (((salary >= (0)::numeric) AND (salary <= (100)::numeric)))
);


--
-- Name: COLUMN terms.salary; Type: COMMENT; Schema: patronage; Owner: -
--

COMMENT ON COLUMN patronage.terms.salary IS 'not personal: the weight the statutes give pay, a percent';


--
-- Name: terms_for(integer); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.terms_for(year integer) RETURNS text
    LANGUAGE sql STABLE
    RETURN (SELECT t.id FROM patronage.terms t WHERE ((t.adopted IS NOT NULL) AND (t."from" <= terms_for.year)) ORDER BY t."from" DESC, t.adopted DESC, t.id DESC LIMIT 1);


--
-- Name: distribution; Type: TABLE; Schema: patronage; Owner: -
--

CREATE TABLE patronage.distribution (
    id text NOT NULL,
    year integer NOT NULL,
    surplus cella.amount NOT NULL,
    basis text NOT NULL,
    approved date,
    distributed date,
    CONSTRAINT distribution_basis_check CHECK ((basis = ANY (ARRAY['salary'::text, 'hours'::text, 'equal'::text, 'mix'::text]))),
    CONSTRAINT distribution_check CHECK (((distributed IS NULL) OR ((approved IS NOT NULL) AND (distributed >= approved)))),
    CONSTRAINT distribution_year_check CHECK (((year >= 1900) AND (year <= 9999)))
);


--
-- Name: share; Type: TABLE; Schema: patronage; Owner: -
--

CREATE TABLE patronage.share (
    distribution text NOT NULL,
    kind text NOT NULL,
    percent numeric(5,2) NOT NULL,
    amount cella.amount NOT NULL,
    CONSTRAINT share_kind_check CHECK ((kind = ANY (ARRAY['work'::text, 'legal'::text, 'development'::text, 'interest'::text]))),
    CONSTRAINT share_percent_check CHECK (((percent > (0)::numeric) AND (percent <= (100)::numeric)))
);


--
-- Name: lines(text); Type: FUNCTION; Schema: patronage_transaction; Owner: -
--

CREATE FUNCTION patronage_transaction.lines(ref text) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT '120'::text,
     'debit'::text,
     cella.cents(d.surplus) AS cents
    FROM patronage.distribution d
   WHERE (d.id = lines.ref)
 UNION ALL
  SELECT
         CASE s.kind
             WHEN 'work'::text THEN '424'::text
             WHEN 'legal'::text THEN '1061'::text
             WHEN 'development'::text THEN '1068'::text
             ELSE '457'::text
         END AS "case",
     'credit'::text,
     cella.cents(s.amount) AS cents
    FROM patronage.share s
   WHERE (s.distribution = lines.ref);
END;


--
-- Name: account; Type: TABLE; Schema: account; Owner: -
--

CREATE TABLE account.account (
    code text NOT NULL,
    label text NOT NULL,
    kind text NOT NULL,
    parent text,
    holder text,
    frozen boolean DEFAULT false NOT NULL,
    cash boolean DEFAULT false NOT NULL,
    CONSTRAINT account_code_check CHECK ((code ~ '^[0-9]+$'::text)),
    CONSTRAINT account_kind_check CHECK ((kind = ANY (ARRAY['asset'::text, 'liability'::text, 'equity'::text, 'income'::text, 'expense'::text])))
);


--
-- Name: COLUMN account.holder; Type: COMMENT; Schema: account; Owner: -
--

COMMENT ON COLUMN account.account.holder IS 'not personal: the holder''s pseudonymous address';


--
-- Name: member; Type: TABLE; Schema: membership; Owner: -
--

CREATE TABLE membership.member (
    address text NOT NULL,
    status text NOT NULL,
    since date,
    shares integer DEFAULT 0 NOT NULL,
    invited date,
    suspended date,
    exited date,
    CONSTRAINT member_shares_check CHECK ((shares >= 0)),
    CONSTRAINT member_status_check CHECK ((status = ANY (ARRAY['invited'::text, 'active'::text, 'suspended'::text, 'exited'::text])))
);


--
-- Name: COLUMN member.address; Type: COMMENT; Schema: membership; Owner: -
--

COMMENT ON COLUMN membership.member.address IS 'not personal: the pseudonymous address every log entry names the member by';


--
-- Name: part; Type: TABLE; Schema: patronage; Owner: -
--

CREATE TABLE patronage.part (
    distribution text NOT NULL,
    worker text NOT NULL,
    basis text NOT NULL,
    quantity bigint,
    amount cella.amount,
    CONSTRAINT part_basis_check CHECK ((basis = ANY (ARRAY['salary'::text, 'hours'::text, 'equal'::text]))),
    CONSTRAINT part_quantity_check CHECK ((quantity > 0))
);


--
-- Name: COLUMN part.worker; Type: COMMENT; Schema: patronage; Owner: -
--

COMMENT ON COLUMN patronage.part.worker IS 'not personal: the worker''s pseudonymous address';


--
-- Name: statement; Type: VIEW; Schema: patronage; Owner: -
--

CREATE VIEW patronage.statement WITH (security_invoker='true') AS
 SELECT ((p.distribution || ':'::text) || p.worker) AS id,
    p.distribution,
    d.year,
    p.worker,
    (sum(cella.cents(p.amount)))::bigint AS amount,
    (COALESCE(sum(cella.cents(p.amount)) FILTER (WHERE (p.basis = 'salary'::text)), (0)::numeric))::bigint AS salary,
    (COALESCE(sum(cella.cents(p.amount)) FILTER (WHERE (p.basis = 'hours'::text)), (0)::numeric))::bigint AS hours,
    (COALESCE(sum(cella.cents(p.amount)) FILTER (WHERE (p.basis = 'equal'::text)), (0)::numeric))::bigint AS equal
   FROM (patronage.part p
     JOIN patronage.distribution d ON ((d.id = p.distribution)))
  GROUP BY p.distribution, d.year, p.worker;


--
-- Name: split; Type: VIEW; Schema: account_membership_patronage; Owner: -
--

CREATE VIEW account_membership_patronage.split WITH (security_invoker='true') AS
 SELECT s.distribution,
    s.year,
    s.worker,
    s.amount AS part,
    t.capital AS percent,
    v.value,
    x.associate,
    k.shares,
    (k.shares * v.value) AS capital,
    (s.amount - (k.shares * v.value)) AS cash,
    ((make_date((s.year + 1), 6, 1) + '5 years'::interval))::date AS until
   FROM ((((patronage.statement s
     JOIN patronage.terms t ON ((t.id = patronage.terms_for(s.year))))
     JOIN LATERAL ( SELECT account_membership.value(cella.verdict_date()) AS value) v ON ((v.value IS NOT NULL)))
     CROSS JOIN LATERAL ( SELECT (EXISTS ( SELECT
                   FROM (membership.member m
                     JOIN account.account a ON (((a.holder = m.address) AND (a.parent = '1013'::text) AND (NOT a.frozen))))
                  WHERE ((m.address = s.worker) AND (m.status = 'active'::text)))) AS associate) x)
     CROSS JOIN LATERAL ( SELECT
                CASE
                    WHEN (x.associate AND (v.value > 0)) THEN (floor((((s.amount)::numeric * t.capital) / ((100 * v.value))::numeric)))::integer
                    ELSE 0
                END AS shares) k);


--
-- Name: distribution; Type: TABLE; Schema: patronage_transaction; Owner: -
--

CREATE TABLE patronage_transaction.distribution (
    distribution text NOT NULL,
    entry text NOT NULL
);


--
-- Name: line; Type: TABLE; Schema: transaction; Owner: -
--

CREATE TABLE transaction.line (
    entry text NOT NULL,
    n integer NOT NULL,
    account text NOT NULL,
    side text NOT NULL,
    amount cella.amount NOT NULL,
    CONSTRAINT line_n_check CHECK ((n > 0)),
    CONSTRAINT line_side_check CHECK ((side = ANY (ARRAY['debit'::text, 'credit'::text])))
);


--
-- Name: credited(jsonb); Type: FUNCTION; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE FUNCTION account_membership_patronage_transaction.credited(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((EXISTS ( SELECT p.worker,
                 p.shares,
                 p.capital,
                 p.until
                FROM account_membership_patronage.split p
               WHERE ((p.distribution = x.distribution) AND (p.shares > 0))
             EXCEPT ALL
              SELECT c.member,
                 c.shares,
                 cella.cents(c.amount) AS cents,
                 c.until
                FROM account_membership_patronage_transaction.credit c
               WHERE (c.distribution = x.distribution))) OR (EXISTS ( SELECT c.member,
                 c.shares,
                 cella.cents(c.amount) AS cents,
                 c.until
                FROM account_membership_patronage_transaction.credit c
               WHERE (c.distribution = x.distribution)
             EXCEPT ALL
              SELECT p.worker,
                 p.shares,
                 p.capital,
                 p.until
                FROM account_membership_patronage.split p
               WHERE ((p.distribution = x.distribution) AND (p.shares > 0))))) THEN (x.distribution || ' does not employ in shares what its terms give each associate'::text)
             WHEN ((EXISTS ( SELECT
                FROM account_membership_patronage_transaction.credit c
               WHERE ((c.distribution = x.distribution) AND (c.entry IS DISTINCT FROM t.entry)))) OR (EXISTS ((
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM patronage_transaction.lines(x.distribution) l(account, side, cents)
                     UNION ALL
                      SELECT e.account,
                         e.side,
                         e.cents
                        FROM account_membership_patronage_transaction.employing(x.distribution) e(account, side, cents)
             ) EXCEPT ALL
              SELECT l.account,
                 l.side,
                 cella.cents(l.amount) AS cents
                FROM transaction.line l
               WHERE (l.entry = t.entry))) OR (EXISTS ( SELECT l.account,
                 l.side,
                 cella.cents(l.amount) AS cents
                FROM transaction.line l
               WHERE (l.entry = t.entry)
             EXCEPT ALL (
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM patronage_transaction.lines(x.distribution) l(account, side, cents)
                     UNION ALL
                      SELECT e.account,
                         e.side,
                         e.cents
                        FROM account_membership_patronage_transaction.employing(x.distribution) e(account, side, cents)
             )))) THEN (((COALESCE(t.entry, 'the distribution''s entry'::text) || ' does not post exactly the split of '::text) || x.distribution) || ' and the shares it employs: 424 debited by the whole, each capital account credited by its own'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (credited.payload ->> 'distribution'::text) AS distribution) x
      LEFT JOIN patronage_transaction.distribution t ON ((t.distribution = x.distribution)));
END;


--
-- Name: employs(); Type: FUNCTION; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE FUNCTION account_membership_patronage_transaction.employs() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  total bigint;
  last integer;
BEGIN
  SELECT sum(p.capital) INTO total FROM account_membership_patronage.split p WHERE p.distribution = NEW.distribution AND p.shares > 0;
  IF coalesce(total, 0) = 0 THEN
    RETURN NULL;
  END IF;
  SELECT max(l.n) INTO last FROM transaction.line l WHERE l.entry = NEW.entry;
  INSERT INTO transaction.line (entry, n, account, side, amount)
  SELECT NEW.entry, last + 1, '424', 'debit', cella.amount(total)
  UNION ALL
  SELECT NEW.entry, last + 1 + row_number() OVER (ORDER BY a.code), a.code, 'credit', cella.amount(p.capital)
  FROM account_membership_patronage.split p
  JOIN account.account a ON a.holder = p.worker AND a.parent = '1013' AND NOT a.frozen
  WHERE p.distribution = NEW.distribution AND p.shares > 0;
  INSERT INTO account_membership_patronage_transaction.credit (distribution, member, account, shares, amount, until, entry)
  SELECT NEW.distribution, p.worker, a.code, p.shares, cella.amount(p.capital), p.until, NEW.entry
  FROM account_membership_patronage.split p
  JOIN account.account a ON a.holder = p.worker AND a.parent = '1013' AND NOT a.frozen
  WHERE p.distribution = NEW.distribution AND p.shares > 0;
  UPDATE membership.member m SET shares = m.shares + c.shares
  FROM account_membership_patronage_transaction.credit c
  WHERE c.distribution = NEW.distribution AND c.member = m.address;
  RETURN NULL;
END
$$;


--
-- Name: may(text); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.may(power text) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
  f regprocedure;
  ok boolean;
BEGIN
  SELECT a.fn INTO f FROM cella.authority a;
  IF f IS NULL OR power IS NULL OR cella.reader() IS NULL THEN
    RETURN false;
  END IF;
  EXECUTE format('SELECT %s($1, $2, NULL::bigint, $3)', f::oid::regproc)
    INTO ok USING cella.reader(), may.power, cella.verdict_date();
  RETURN coalesce(ok, false);
END
$_$;


--
-- Name: reaches(text, text); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.reaches(what text, key text) RETURNS boolean
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
  f regprocedure;
  ok boolean;
BEGIN
  IF cella.reader() IS NULL THEN
    RETURN false;
  END IF;
  IF EXISTS (SELECT FROM cella.reading g WHERE g.what = reaches.what AND g.key = reaches.key AND cella.may(g.power)) THEN
    RETURN true;
  END IF;
  FOR f IN SELECT x.fn FROM cella.reach x WHERE x.what = reaches.what ORDER BY x.owner LOOP
    EXECUTE format('SELECT %s($1, $2)', f::oid::regproc) INTO ok USING reaches.key, cella.reader();
    IF ok THEN
      RETURN true;
    END IF;
  END LOOP;
  RETURN false;
END
$_$;


--
-- Name: reader(); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.reader() RETURNS text
    LANGUAGE sql STABLE
    RETURN NULLIF(current_setting('cella.actor'::text, true), ''::text);


--
-- Name: reading; Type: TABLE; Schema: cella; Owner: -
--

CREATE TABLE cella.reading (
    what text NOT NULL,
    key text,
    power text NOT NULL,
    owner text NOT NULL
);


--
-- Name: reads_all(text); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.reads_all(what text) RETURNS boolean
    LANGUAGE sql STABLE
    RETURN ((cella.reader() IS NOT NULL) AND (EXISTS (SELECT FROM cella.reading g WHERE ((g.what = reads_all.what) AND (g.key IS NULL) AND cella.may(g.power)))));


--
-- Name: writing(); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.writing() RETURNS boolean
    LANGUAGE sql STABLE
    RETURN (COALESCE(current_setting('cella.writing'::text, true), ''::text) = 'on'::text);


--
-- Name: sees(text); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.sees(what text) RETURNS boolean
    LANGUAGE sql STABLE
    RETURN (cella.writing() OR (SELECT (r.rolsuper OR r.rolbypassrls) FROM pg_roles r WHERE (r.rolname = CURRENT_USER)) OR cella.reads_all(what));


--
-- Name: share_of(text, text); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.share_of(ref text, of text) RETURNS bigint
    LANGUAGE sql STABLE
    RETURN COALESCE((SELECT cella.cents(s.amount) AS cents FROM patronage.share s WHERE ((s.distribution = share_of.ref) AND (s.kind = share_of.of))), (0)::bigint);


--
-- Name: entry; Type: TABLE; Schema: transaction; Owner: -
--

CREATE TABLE transaction.entry (
    id text NOT NULL,
    date date NOT NULL,
    label text NOT NULL,
    corrects text,
    receipt bigint
);


--
-- Name: capital(date); Type: FUNCTION; Schema: patronage_transaction; Owner: -
--

CREATE FUNCTION patronage_transaction.capital(day date) RETURNS bigint
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(sum(
         CASE l.side
             WHEN 'credit'::text THEN cella.cents(l.amount)
             ELSE (- cella.cents(l.amount))
         END), (0)::numeric) AS "coalesce"
    FROM (transaction.line l
      JOIN transaction.entry e ON ((e.id = l.entry)))
   WHERE ((l.account ~~ '101%'::text) AND (e.date <= capital.day));
END;


--
-- Name: highest(); Type: FUNCTION; Schema: patronage_transaction; Owner: -
--

CREATE FUNCTION patronage_transaction.highest() RETURNS bigint
    LANGUAGE sql STABLE
    RETURN COALESCE((SELECT max(patronage_transaction.capital(e.date)) AS max FROM transaction.entry e WHERE (EXISTS (SELECT FROM transaction.line l WHERE ((l.entry = e.id) AND (l.account ~~ '101%'::text))))), (0)::bigint);


--
-- Name: allowance; Type: TABLE; Schema: account_membership; Owner: -
--

CREATE TABLE account_membership.allowance (
    member text NOT NULL,
    amount cella.amount NOT NULL
);


--
-- Name: person; Type: TABLE; Schema: person; Owner: -
--

CREATE TABLE person.person (
    address text NOT NULL,
    name text NOT NULL,
    email text,
    phone text
);


--
-- Name: COLUMN person.address; Type: COMMENT; Schema: person; Owner: -
--

COMMENT ON COLUMN person.person.address IS 'not personal: the pseudonymous address every log entry names the person by';


--
-- Name: capital; Type: VIEW; Schema: account_membership; Owner: -
--

CREATE VIEW account_membership.capital AS
 SELECT m.address AS member,
    mp.name,
    m.status,
    m.shares,
    v.value,
    (m.shares * v.value) AS subscribed,
    a.code AS account,
    COALESCE(a.frozen, false) AS frozen,
    cella.cents(w.amount) AS allowance
   FROM ((((membership.member m
     JOIN person.person mp ON ((mp.address = m.address)))
     JOIN LATERAL ( SELECT account_membership.value(cella.verdict_date()) AS value) v ON ((v.value IS NOT NULL)))
     LEFT JOIN account.account a ON (((a.holder = m.address) AND (a.parent = '1013'::text))))
     LEFT JOIN account_membership.allowance w ON ((w.member = m.address)))
  WHERE (( SELECT cella.sees('account'::text) AS sees) OR (m.address = cella.reader()) OR cella.reaches('account'::text, m.address));


--
-- Name: balance; Type: VIEW; Schema: account_transaction; Owner: -
--

CREATE VIEW account_transaction.balance WITH (security_invoker='true') AS
 SELECT a.code,
    a.label,
    a.kind,
    COALESCE(sum(cella.cents(l.amount)) FILTER (WHERE (l.side = 'debit'::text)), (0)::numeric) AS debit,
    COALESCE(sum(cella.cents(l.amount)) FILTER (WHERE (l.side = 'credit'::text)), (0)::numeric) AS credit,
    COALESCE(sum(
        CASE l.side
            WHEN 'debit'::text THEN cella.cents(l.amount)
            ELSE (- cella.cents(l.amount))
        END), (0)::numeric) AS balance
   FROM (account.account a
     LEFT JOIN transaction.line l ON ((l.account = a.code)))
  GROUP BY a.code, a.label, a.kind;


--
-- Name: federation(text); Type: FUNCTION; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE FUNCTION account_membership_patronage_transaction.federation(ref text) RETURNS TABLE(year integer, distributed text, surplus numeric, legal numeric, development numeric, work numeric, interest numeric, workers numeric, associates_sharing numeric, employed numeric, shares numeric, until text, associates numeric, capital numeric, employee_capital numeric, reserve numeric, highest numeric)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    BEGIN ATOMIC
 SELECT a.year,
     to_char((a.distributed)::timestamp with time zone, 'YYYY-MM-DD'::text) AS to_char,
     (cella.cents(a.surplus))::numeric AS cents,
     (patronage.share_of(a.id, 'legal'::text))::numeric AS share_of,
     (patronage.share_of(a.id, 'development'::text))::numeric AS share_of,
     (patronage.share_of(a.id, 'work'::text))::numeric AS share_of,
     (patronage.share_of(a.id, 'interest'::text))::numeric AS share_of,
     (( SELECT count(*) AS count
            FROM patronage.statement s
           WHERE (s.distribution = a.id)))::numeric AS count,
     (( SELECT count(*) AS count
            FROM (patronage.statement s
              JOIN membership.member m ON ((m.address = s.worker)))
           WHERE ((s.distribution = a.id) AND (m.status = 'active'::text))))::numeric AS count,
     ( SELECT COALESCE(sum(cella.cents(c.amount)), (0)::numeric) AS "coalesce"
            FROM account_membership_patronage_transaction.credit c
           WHERE (c.distribution = a.id)) AS "coalesce",
     (( SELECT COALESCE(sum(c.shares), (0)::bigint) AS "coalesce"
            FROM account_membership_patronage_transaction.credit c
           WHERE (c.distribution = a.id)))::numeric AS "coalesce",
     ( SELECT to_char((max(c.until))::timestamp with time zone, 'YYYY-MM-DD'::text) AS to_char
            FROM account_membership_patronage_transaction.credit c
           WHERE (c.distribution = a.id)) AS to_char,
     (( SELECT count(*) AS count
            FROM membership.member m
           WHERE (m.status = 'active'::text)))::numeric AS count,
     ( SELECT COALESCE(sum(c.subscribed), (0)::numeric) AS "coalesce"
            FROM account_membership.capital c
           WHERE (c.status = 'active'::text)) AS "coalesce",
     ( SELECT COALESCE(sum(c.subscribed), (0)::numeric) AS "coalesce"
            FROM account_membership.capital c
           WHERE ((c.status = 'active'::text) AND (EXISTS ( SELECT
                    FROM patronage.statement s
                   WHERE ((s.distribution = a.id) AND (s.worker = c.member)))))) AS "coalesce",
     COALESCE(( SELECT (- b.balance)
            FROM account_transaction.balance b
           WHERE (b.code = '1061'::text)), (0)::numeric) AS "coalesce",
     (patronage_transaction.highest())::numeric AS highest
    FROM patronage.distribution a
   WHERE ((a.id = federation.ref) AND (a.distributed IS NOT NULL));
END;


--
-- Name: plan; Type: TABLE; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE TABLE account_membership_payslip_transaction.plan (
    member text NOT NULL,
    instalments integer NOT NULL,
    each cella.amount NOT NULL,
    since date NOT NULL,
    CONSTRAINT plan_instalments_check CHECK ((instalments > 0))
);


--
-- Name: withheld; Type: TABLE; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE TABLE account_membership_payslip_transaction.withheld (
    month text NOT NULL,
    member text NOT NULL,
    amount cella.amount NOT NULL,
    entry text NOT NULL
);


--
-- Name: paid; Type: TABLE; Schema: account_membership_transaction; Owner: -
--

CREATE TABLE account_membership_transaction.paid (
    entry text NOT NULL,
    member text NOT NULL,
    amount cella.amount NOT NULL,
    via text NOT NULL,
    CONSTRAINT paid_via_check CHECK ((via = ANY (ARRAY['bank'::text, 'pay'::text])))
);


--
-- Name: subscription; Type: TABLE; Schema: account_membership_transaction; Owner: -
--

CREATE TABLE account_membership_transaction.subscription (
    member text NOT NULL,
    account text NOT NULL,
    shares integer NOT NULL,
    entry text NOT NULL,
    amount cella.amount,
    cancelled cella.amount,
    CONSTRAINT subscription_shares_check CHECK ((shares > 0))
);


--
-- Name: called; Type: VIEW; Schema: account_membership_transaction; Owner: -
--

CREATE VIEW account_membership_transaction.called WITH (security_invoker='true') AS
 SELECT s.member,
    s.account,
    s.shares,
    cella.cents(s.amount) AS amount,
    COALESCE(p.paid, (0)::bigint) AS paid,
    COALESCE(cella.cents(s.cancelled), (0)::bigint) AS cancelled,
    ((cella.cents(s.amount) - COALESCE(p.paid, (0)::bigint)) - COALESCE(cella.cents(s.cancelled), (0)::bigint)) AS unpaid
   FROM (account_membership_transaction.subscription s
     LEFT JOIN ( SELECT d.member,
            (sum(cella.cents(d.amount)))::bigint AS paid
           FROM account_membership_transaction.paid d
          GROUP BY d.member) p ON ((p.member = s.member)))
  WHERE (s.amount IS NOT NULL);


--
-- Name: payslip; Type: TABLE; Schema: payslip; Owner: -
--

CREATE TABLE payslip.payslip (
    month text NOT NULL,
    member text NOT NULL,
    minutes integer,
    gross cella.amount,
    employee cella.amount,
    employer cella.amount,
    net cella.amount,
    CONSTRAINT payslip_check CHECK ((cella.cents(gross) = (cella.cents(employee) + cella.cents(net)))),
    CONSTRAINT payslip_minutes_check CHECK ((minutes >= 0))
);


--
-- Name: due(text); Type: FUNCTION; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE FUNCTION account_membership_payslip_transaction.due(month text) RETURNS TABLE(member text, account text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT p.member,
     c.account,
     LEAST(cella.cents(p.each), (c.unpaid + COALESCE(cella.cents(w.amount), (0)::bigint)), cella.cents(s.net)) AS "least"
    FROM (((account_membership_payslip_transaction.plan p
      JOIN account_membership_transaction.called c ON ((c.member = p.member)))
      JOIN payslip.payslip s ON (((s.member = p.member) AND (s.month = due.month))))
      LEFT JOIN account_membership_payslip_transaction.withheld w ON (((w.member = p.member) AND (w.month = due.month))))
   WHERE (((c.unpaid + COALESCE(cella.cents(w.amount), (0)::bigint)) > 0) AND (s.net IS NOT NULL))
   ORDER BY c.account;
END;


--
-- Name: paying(text, bigint); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.paying(capital text, paid bigint) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql IMMUTABLE
    BEGIN ATOMIC
 SELECT x.code,
     x.side,
     paying.paid AS paid
    FROM ( VALUES ('512'::text,'debit'::text,1), ('4562'::text,'credit'::text,2), ('1012'::text,'debit'::text,3), (paying.capital,'credit'::text,4)) x(code, side, n)
   ORDER BY x.n;
END;


--
-- Name: lines(text, text); Type: FUNCTION; Schema: payslip_transaction; Owner: -
--

CREATE FUNCTION payslip_transaction.lines(ref text, event text) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.account,
     x.side,
     x.cents
    FROM (( SELECT sum(cella.cents(p.gross)) AS gross,
             sum(cella.cents(p.employee)) AS employee,
             sum(cella.cents(p.employer)) AS employer,
             sum(cella.cents(p.net)) AS net
            FROM payslip.payslip p
           WHERE (p.month = lines.ref)) t
      CROSS JOIN LATERAL ( VALUES ('accrual'::text,'641'::text,'debit'::text,t.gross), ('accrual'::text,'645'::text,'debit'::text,t.employer), ('accrual'::text,'421'::text,'credit'::text,t.net), ('accrual'::text,'431'::text,'credit'::text,(t.employee + t.employer)), ('payment'::text,'421'::text,'debit'::text,t.net), ('payment'::text,'431'::text,'debit'::text,(t.employee + t.employer)), ('payment'::text,'512'::text,'credit'::text,((t.net + t.employee) + t.employer))) x(event, account, side, cents))
   WHERE ((x.event = lines.event) AND (x.cents > (0)::numeric));
END;


--
-- Name: posting; Type: TABLE; Schema: payslip_transaction; Owner: -
--

CREATE TABLE payslip_transaction.posting (
    entry text NOT NULL,
    month text NOT NULL,
    event text NOT NULL,
    CONSTRAINT posting_event_check CHECK ((event = ANY (ARRAY['accrual'::text, 'payment'::text, 'carried'::text])))
);


--
-- Name: deducted(jsonb); Type: FUNCTION; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE FUNCTION account_membership_payslip_transaction.deducted(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((EXISTS ( SELECT d.member,
                 d.cents
                FROM account_membership_payslip_transaction.due(x.month) d(member, account, cents)
               WHERE (d.cents > 0)
             EXCEPT
              SELECT w.member,
                 cella.cents(w.amount) AS cents
                FROM account_membership_payslip_transaction.withheld w
               WHERE (w.month = x.month))) OR (EXISTS ( SELECT w.member,
                 cella.cents(w.amount) AS cents
                FROM account_membership_payslip_transaction.withheld w
               WHERE (w.month = x.month)
             EXCEPT
              SELECT d.member,
                 d.cents
                FROM account_membership_payslip_transaction.due(x.month) d(member, account, cents)
               WHERE (d.cents > 0)))) THEN (COALESCE(x.month, 'the month'::text) || '''s pay does not withhold the instalments its associates owe'::text)
             WHEN ((EXISTS ( SELECT
                FROM account_membership_payslip_transaction.withheld w
               WHERE ((w.month = x.month) AND ((w.entry IS DISTINCT FROM p.entry) OR (NOT (EXISTS ( SELECT
                        FROM account_membership_transaction.paid d
                       WHERE ((d.entry = w.entry) AND (d.member = w.member) AND (d.via = 'pay'::text) AND (cella.cents(d.amount) = cella.cents(w.amount)))))))))) OR (EXISTS ( SELECT y.account,
                 y.side,
                 y.cents
                FROM ((account_membership_payslip_transaction.withheld w
                  JOIN account_membership_transaction.called c ON ((c.member = w.member)))
                  CROSS JOIN LATERAL account_membership_transaction.paying(c.account, cella.cents(w.amount)) y(account, side, cents))
               WHERE (w.month = x.month)
             EXCEPT ALL (
                      SELECT l.account,
                         l.side,
                         cella.cents(l.amount) AS cents
                        FROM transaction.line l
                       WHERE (l.entry = p.entry)
                     EXCEPT ALL
                      SELECT o.account,
                         o.side,
                         o.cents
                        FROM payslip_transaction.lines(x.month, 'payment'::text) o(account, side, cents)
             ))) OR (EXISTS ( SELECT l.account,
                 l.side,
                 cella.cents(l.amount) AS cents
                FROM transaction.line l
               WHERE (l.entry = p.entry)
             EXCEPT ALL
              SELECT o.account,
                 o.side,
                 o.cents
                FROM payslip_transaction.lines(x.month, 'payment'::text) o(account, side, cents)
             EXCEPT ALL
              SELECT y.account,
                 y.side,
                 y.cents
                FROM ((account_membership_payslip_transaction.withheld w
                  JOIN account_membership_transaction.called c ON ((c.member = w.member)))
                  CROSS JOIN LATERAL account_membership_transaction.paying(c.account, cella.cents(w.amount)) y(account, side, cents))
               WHERE (w.month = x.month)))) THEN (((COALESCE(p.entry, 'the payment'::text) || ' does not post what '::text) || x.month) || '''s pay withheld: for each, 512 debited and 4562 credited, 1012 debited and the capital account credited'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (deducted.payload ->> 'month'::text) AS month) x
      LEFT JOIN payslip_transaction.posting p ON (((p.month = x.month) AND (p.event = 'payment'::text))));
END;


--
-- Name: spreads(jsonb); Type: FUNCTION; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE FUNCTION account_membership_payslip_transaction.spreads(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((c.member IS NULL) OR (c.unpaid <= 0)) THEN (COALESCE(x.member, 'no one'::text) || ' owes nothing on a subscription'::text)
             WHEN ((t.instalments IS NULL) OR (x.instalments > t.instalments)) THEN ((((x.member || ' spreads their subscription over '::text) || x.instalments) || ' instalments: '::text) || COALESCE(((t.id || ' allow at most '::text) || t.instalments), 'no adopted terms allow any'::text))
             WHEN ((p.member IS NULL) OR (p.since IS DISTINCT FROM cella.verdict_date()) OR (p.instalments <> x.instalments) OR (cella.cents(p.each) <> (((c.unpaid + x.instalments) - 1) / x.instalments))) THEN (((x.member || '''s plan was not set by this write: '::text) || x.instalments) || ' instalments of what they owe, rounded up to the cent'::text)
             WHEN (x.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may spread only their own subscription, not '::text) || COALESCE(x.member, 'no one'::text)) || '''s'::text)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT (spreads.payload ->> 'member'::text) AS member,
             ((spreads.payload ->> 'instalments'::text))::integer AS instalments) x
      LEFT JOIN account_membership_transaction.called c ON ((c.member = x.member)))
      LEFT JOIN account.terms t ON ((t.id = account.capital_for(cella.verdict_date()))))
      LEFT JOIN account_membership_payslip_transaction.plan p ON ((p.member = x.member)));
END;


--
-- Name: withholds(); Type: FUNCTION; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE FUNCTION account_membership_payslip_transaction.withholds() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  last integer;
BEGIN
  IF NEW.event <> 'payment' THEN
    RETURN NULL;
  END IF;
  INSERT INTO account_membership_payslip_transaction.withheld (month, member, amount, entry)
  SELECT NEW.month, d.member, cella.amount(d.cents), NEW.entry
  FROM account_membership_payslip_transaction.due(NEW.month) d WHERE d.cents > 0;
  SELECT max(l.n) INTO last FROM transaction.line l WHERE l.entry = NEW.entry;
  INSERT INTO transaction.line (entry, n, account, side, amount)
  SELECT NEW.entry, last + row_number() OVER (ORDER BY c.account, x.n), x.account, x.side, cella.amount(x.cents)
  FROM account_membership_payslip_transaction.withheld w
  JOIN account_membership_transaction.called c ON c.member = w.member
  CROSS JOIN LATERAL (
    SELECT p.account, p.side, p.cents, row_number() OVER () AS n
    FROM account_membership_transaction.paying(c.account, cella.cents(w.amount)) p
  ) x
  WHERE w.month = NEW.month;
  INSERT INTO account_membership_transaction.paid (entry, member, amount, via)
  SELECT NEW.entry, w.member, w.amount, 'pay'
  FROM account_membership_payslip_transaction.withheld w WHERE w.month = NEW.month;
  RETURN NULL;
END
$$;


--
-- Name: draw; Type: TABLE; Schema: account_membership_transaction; Owner: -
--

CREATE TABLE account_membership_transaction.draw (
    entry text NOT NULL,
    member text NOT NULL,
    amount cella.amount NOT NULL
);


--
-- Name: drawn; Type: VIEW; Schema: account_membership_transaction; Owner: -
--

CREATE VIEW account_membership_transaction.drawn WITH (security_invoker='true') AS
 SELECT member,
    account,
    frozen,
    allowance,
    COALESCE(( SELECT sum(cella.cents(d.amount)) AS sum
           FROM account_membership_transaction.draw d
          WHERE (d.member = c.member)), (0)::numeric) AS drawn
   FROM account_membership.capital c;


--
-- Name: draws(jsonb); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.draws(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (x.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may draw only on their own account, not '::text) || COALESCE(x.member, 'no one'::text)) || '''s'::text)
             WHEN (m.status IS DISTINCT FROM 'active'::text) THEN (((x.member || ' is '::text) || COALESCE(m.status, 'no member'::text)) || ': only an active member draws'::text)
             WHEN (w.account IS NULL) THEN (x.member || ' holds no capital account'::text)
             WHEN w.frozen THEN (((w.account || ' is frozen: '::text) || x.member) || ' left, and draws nothing until it is repaid'::text)
             WHEN ((w.allowance IS NULL) OR (w.drawn > (w.allowance)::numeric)) THEN (((((((('a draw of '::text || x.amount) || ' cents exceeds what is left of '::text) || x.member) || '''s draw limit, '::text) || GREATEST((((COALESCE(w.allowance, (0)::bigint))::numeric - w.drawn) + (x.amount)::numeric), (0)::numeric)) || ' of '::text) || COALESCE(w.allowance, (0)::bigint)) || ' cents'::text)
             WHEN (( SELECT ((count(*) FILTER (WHERE (NOT (((l.account = '455'::text) AND (l.side = 'debit'::text)) OR ((l.account = '512'::text) AND (l.side = 'credit'::text))))) <> 0) OR (count(*) <> 2) OR (count(DISTINCT l.account) <> 2) OR bool_or((cella.cents(l.amount) <> x.amount)))
                FROM transaction.line l
               WHERE (l.entry = x.entry)) OR (NOT (EXISTS ( SELECT
                FROM account_membership_transaction.draw d
               WHERE ((d.entry = x.entry) AND (d.member = x.member)))))) THEN (((COALESCE(x.entry, 'the entry'::text) || ' is not a draw of '::text) || x.amount) || ' cents: 455 debited and 512 credited by it, nothing else'::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (draws.payload ->> 'member'::text) AS member,
             ((draws.payload ->> 'amount'::text))::bigint AS amount,
             (draws.payload ->> 'entry'::text) AS entry) x
      LEFT JOIN membership.member m ON ((m.address = x.member)))
      LEFT JOIN account_membership_transaction.drawn w ON ((w.member = x.member)));
END;


--
-- Name: pays(jsonb); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.pays(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (c.member IS NULL) THEN (COALESCE(x.member, 'no one'::text) || ' has no subscription to pay'::text)
             WHEN (c.unpaid < 0) THEN (((((('a payment of '::text || x.amount) || ' cents exceeds what '::text) || x.member) || ' owes on their subscription, '::text) || (c.unpaid + x.amount)) || ' cents'::text)
             WHEN ((NOT (EXISTS ( SELECT
                FROM account_membership_transaction.paid d
               WHERE ((d.entry = x.entry) AND (d.member = x.member) AND (d.via = 'bank'::text) AND (cella.cents(d.amount) = x.amount))))) OR (EXISTS ( SELECT p.account,
                 p.side,
                 p.cents
                FROM account_membership_transaction.paying(c.account, x.amount) p(account, side, cents)
             EXCEPT ALL
              SELECT l.account,
                 l.side,
                 cella.cents(l.amount) AS cents
                FROM transaction.line l
               WHERE (l.entry = x.entry))) OR (EXISTS ( SELECT l.account,
                 l.side,
                 cella.cents(l.amount) AS cents
                FROM transaction.line l
               WHERE (l.entry = x.entry)
             EXCEPT ALL
              SELECT p.account,
                 p.side,
                 p.cents
                FROM account_membership_transaction.paying(c.account, x.amount) p(account, side, cents)))) THEN (((((((COALESCE(x.entry, 'the entry'::text) || ' is not a payment of '::text) || x.amount) || ' cents on '::text) || x.member) || '''s subscription: 512 debited and 4562 credited, 1012 debited and '::text) || c.account) || ' credited, nothing else'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (pays.payload ->> 'member'::text) AS member,
             ((pays.payload ->> 'amount'::text))::bigint AS amount,
             (pays.payload ->> 'entry'::text) AS entry) x
      LEFT JOIN account_membership_transaction.called c ON ((c.member = x.member)));
END;


--
-- Name: repayment; Type: TABLE; Schema: account_membership_transaction; Owner: -
--

CREATE TABLE account_membership_transaction.repayment (
    member text NOT NULL,
    n integer NOT NULL,
    due date NOT NULL,
    amount cella.amount NOT NULL,
    entry text,
    paid date,
    CONSTRAINT repayment_check CHECK (((entry IS NULL) = (paid IS NULL))),
    CONSTRAINT repayment_n_check CHECK ((n > 0))
);


--
-- Name: repays(jsonb); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.repays(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (r.member IS NULL) THEN ((COALESCE(x.member, 'no one'::text) || ' has no repayment '::text) || COALESCE((x.n)::text, ''::text))
             WHEN (r.entry IS DISTINCT FROM x.entry) THEN ((((((x.member || '''s repayment '::text) || x.n) || ' was paid on '::text) || COALESCE((r.paid)::text, 'another day'::text)) || ' by '::text) || COALESCE(r.entry, 'another write'::text))
             WHEN (r.due > cella.verdict_date()) THEN ((((x.member || '''s repayment '::text) || x.n) || ' falls due on '::text) || r.due)
             WHEN (EXISTS ( SELECT
                FROM account_membership_transaction.repayment e
               WHERE ((e.member = x.member) AND (e.n < x.n) AND (e.paid IS NULL)))) THEN (((x.member || '''s repayment '::text) || ( SELECT min(e.n) AS min
                FROM account_membership_transaction.repayment e
               WHERE ((e.member = x.member) AND (e.paid IS NULL)))) || ' comes first'::text)
             WHEN ( SELECT ((count(*) FILTER (WHERE (NOT (((l.account = '4567'::text) AND (l.side = 'debit'::text)) OR ((l.account = '512'::text) AND (l.side = 'credit'::text))))) <> 0) OR (count(*) <> 2) OR (count(DISTINCT l.account) <> 2) OR bool_or((cella.cents(l.amount) <> cella.cents(r.amount))))
                FROM transaction.line l
               WHERE (l.entry = x.entry)) THEN (((((((COALESCE(x.entry, 'the entry'::text) || ' is not '::text) || x.member) || '''s repayment '::text) || x.n) || ' of '::text) || cella.cents(r.amount)) || ' cents: 4567 debited and 512 credited by it, nothing else'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (repays.payload ->> 'member'::text) AS member,
             ((repays.payload ->> 'n'::text))::integer AS n,
             (repays.payload ->> 'entry'::text) AS entry) x
      LEFT JOIN account_membership_transaction.repayment r ON (((r.member = x.member) AND (r.n = x.n))));
END;


--
-- Name: stays_repaid(); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.stays_repaid() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.paid IS NOT NULL THEN
    RAISE EXCEPTION '%''s repayment % was paid on %', OLD.member, OLD.n, OLD.paid
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: subscribes(); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.subscribes() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
  terms text;
  code text;
  cents bigint;
  fewest integer;
  entry text;
BEGIN
  IF NOT (OLD.status = 'invited' AND NEW.status = 'active') OR NEW.shares = 0 THEN
    RETURN NULL;
  END IF;
  terms := account.capital_for(cella.verdict_date());
  SELECT NEW.shares * cella.cents(t.share), t.minimum INTO cents, fewest FROM account.terms t WHERE t.id = terms;
  IF cents IS NULL OR NOT EXISTS (
    SELECT FROM account.period p WHERE p.month = to_char(cella.verdict_date(), 'YYYY-MM') AND p.closed IS NULL
  ) OR NOT EXISTS (SELECT FROM account.account a WHERE a.code = '1013')
    OR NOT EXISTS (SELECT FROM account.account a WHERE a.code = '1012')
    OR NOT EXISTS (SELECT FROM account.account a WHERE a.code = '4562') THEN
    RETURN NULL;
  END IF;
  IF NEW.shares < fewest THEN
    RAISE EXCEPTION '% subscribes % shares: % ask at least %', NEW.address, NEW.shares, terms, fewest
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT '1013' || lpad((coalesce(max(substr(a.code, 5)::integer), 0) + 1)::text, 2, '0') INTO code
  FROM account.account a WHERE a.parent = '1013' AND a.code ~ '^1013[0-9]{2}$';
  INSERT INTO account.account (code, label, kind, parent, holder)
  VALUES (code, 'Capital — ' || (SELECT p.name FROM person.person p WHERE p.address = NEW.address), 'equity', '1013', NEW.address);
  INSERT INTO transaction.entry (date, label, receipt)
  VALUES (cella.verdict_date(), 'Capital subscribed and called, ' || code, cella.receipt())
  RETURNING id INTO entry;
  INSERT INTO transaction.line (entry, n, account, side, amount) VALUES
    (entry, 1, '4562', 'debit', cella.amount(cents)),
    (entry, 2, '1012', 'credit', cella.amount(cents));
  INSERT INTO account_membership_transaction.subscription (member, account, shares, entry, amount)
  VALUES (NEW.address, code, NEW.shares, entry, cella.amount(cents));
  RETURN NULL;
END
$_$;


--
-- Name: withdraws(); Type: FUNCTION; Schema: account_membership_transaction; Owner: -
--

CREATE FUNCTION account_membership_transaction.withdraws() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  terms text;
  held bigint;
  owed bigint;
  entry text;
BEGIN
  IF NOT (NEW.status = 'exited' AND OLD.status <> 'exited') THEN
    RETURN NULL;
  END IF;
  terms := account.capital_for(cella.verdict_date());
  SELECT coalesce(sum(CASE l.side WHEN 'credit' THEN cella.cents(l.amount) ELSE -cella.cents(l.amount) END), 0)
  INTO held
  FROM transaction.line l JOIN account.account a ON a.code = l.account
  WHERE a.holder = NEW.address AND a.parent = '1013';
  SELECT greatest(c.unpaid, 0) INTO owed FROM account_membership_transaction.called c WHERE c.member = NEW.address;
  owed := coalesce(owed, 0);
  IF terms IS NULL OR (held <= 0 AND owed = 0) OR NOT EXISTS (
    SELECT FROM account.period p WHERE p.month = to_char(cella.verdict_date(), 'YYYY-MM') AND p.closed IS NULL
  ) OR NOT EXISTS (SELECT FROM account.account a WHERE a.code = '4567') THEN
    RETURN NULL;
  END IF;
  INSERT INTO transaction.entry (date, label, receipt)
  VALUES (cella.verdict_date(), 'Capital to repay, ' || NEW.address, cella.receipt())
  RETURNING id INTO entry;
  INSERT INTO transaction.line (entry, n, account, side, amount)
  SELECT entry, row_number() OVER (ORDER BY y.n), y.account, y.side, cella.amount(y.cents)
  FROM (
    SELECT 1 AS n, a.code AS account, 'debit' AS side, b.cents
    FROM account.account a
    JOIN LATERAL (
      SELECT coalesce(sum(CASE l.side WHEN 'credit' THEN cella.cents(l.amount) ELSE -cella.cents(l.amount) END), 0)::bigint AS cents
      FROM transaction.line l WHERE l.account = a.code
    ) b ON b.cents > 0
    WHERE a.holder = NEW.address AND a.parent = '1013' AND held > 0
    UNION ALL SELECT 2, '4567', 'credit', held WHERE held > 0
    UNION ALL SELECT 3, '1012', 'debit', owed WHERE owed > 0
    UNION ALL SELECT 4, '4562', 'credit', owed WHERE owed > 0
  ) y;
  IF owed > 0 THEN
    UPDATE account_membership_transaction.subscription SET cancelled = cella.amount(owed) WHERE member = NEW.address;
  END IF;
  IF held > 0 THEN
    INSERT INTO account_membership_transaction.repayment (member, n, due, amount)
    SELECT NEW.address, r.n, r.due, cella.amount((cella.allocate(cella.amount(held), array_fill(1::bigint, ARRAY[t.repayments])))[r.n])
    FROM account.repayments(terms, cella.verdict_date()) r
    CROSS JOIN account.terms t WHERE t.id = terms;
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: closed(jsonb); Type: FUNCTION; Schema: account_patronage; Owner: -
--

CREATE FUNCTION account_patronage.closed(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT ((d.year || ' has a period still open: '::text) || min(p.month))
    FROM ((( SELECT (closed.payload ->> 'distribution'::text) AS distribution) x
      JOIN patronage.distribution d ON ((d.id = x.distribution)))
      JOIN account.period p ON (((p.month ~~ (d.year || '-%'::text)) AND (p.closed IS NULL))))
   GROUP BY d.year;
END;


--
-- Name: agrees(); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.agrees() RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    RETURN (SELECT (COALESCE(sum(b.debit), (0)::numeric) = COALESCE(sum(b.credit), (0)::numeric)) FROM account_transaction.balance b);


--
-- Name: carries(jsonb); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.carries(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(
         CASE
             WHEN (e.id IS NULL) THEN ('no entry '::text || COALESCE(x.entry, 'is named'::text))
             WHEN ((e.date IS DISTINCT FROM x.date) OR (( SELECT count(*) AS count
                FROM transaction.line l
               WHERE (l.entry = e.id)) IS DISTINCT FROM (jsonb_array_length(COALESCE((carries.payload -> 'lines'::text), '[]'::jsonb)))::bigint) OR (( SELECT sum(cella.cents(l.amount)) AS sum
                FROM transaction.line l
               WHERE ((l.entry = e.id) AND (l.side = 'debit'::text))) IS DISTINCT FROM ( SELECT sum(((p.value ->> 'cents'::text))::bigint) AS sum
                FROM jsonb_array_elements((carries.payload -> 'lines'::text)) p(value)
               WHERE ((p.value ->> 'side'::text) = 'debit'::text)))) THEN (e.id || ' is not the entry the write carried over'::text)
             ELSE NULL::text
         END, ( SELECT string_agg((o.code || ' was not opened as the write names'::text), '; '::text ORDER BY o.code) AS string_agg
            FROM (jsonb_array_elements_text(COALESCE((carries.payload -> 'opened'::text), '[]'::jsonb)) o(code)
              LEFT JOIN account.account a ON ((a.code = o.code)))
           WHERE ((a.code IS NULL) OR (a.kind IS DISTINCT FROM account.kind_of(o.code))))) AS "coalesce"
    FROM (( SELECT (carries.payload ->> 'entry'::text) AS entry,
             ((carries.payload ->> 'date'::text))::date AS date) x
      LEFT JOIN transaction.entry e ON ((e.id = x.entry)));
END;


--
-- Name: cashless(jsonb); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.cashless(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (c.account IS NOT NULL) THEN (((x.entry || ' posts to '::text) || c.account) || ', a cash account: money moves through pay or payroll'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (cashless.payload ->> 'entry'::text) AS entry) x
      LEFT JOIN LATERAL ( SELECT min(l.account) AS account
            FROM (transaction.line l
              JOIN account.account a ON (((a.code = l.account) AND a.cash)))
           WHERE (l.entry = x.entry)) c ON (true));
END;


--
-- Name: figures(text, date, date); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.figures(sheet text, since date, until date) RETURNS TABLE(rubric text, code text, label text, amount bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT r.id,
     a.code,
     a.label,
     (sum(
         CASE
             WHEN (l.side = r.side) THEN cella.cents(l.amount)
             ELSE (- cella.cents(l.amount))
         END))::bigint AS sum
    FROM (((transaction.line l
      JOIN transaction.entry e ON ((e.id = l.entry)))
      JOIN account.account a ON ((a.code = l.account)))
      JOIN account.rubric r ON ((r.id = account.rubric_of(figures.sheet, a.code))))
   WHERE ((e.date <= figures.until) AND ((figures.since IS NULL) OR (e.date >= figures.since)))
   GROUP BY r.id, a.code, a.label;
END;


--
-- Name: holds(text, text); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.holds(code text, reader text) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    BEGIN ATOMIC
 SELECT COALESCE(bool_and(((a.holder IS NULL) OR (a.holder = holds.reader) OR cella.reads_all('account'::text) OR cella.reaches('account'::text, a.holder))), false) AS "coalesce"
    FROM account.account a
   WHERE ((a.code = holds.code) AND (holds.reader = cella.reader()));
END;


--
-- Name: posts(); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.posts() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  day date;
  period text;
  closed date;
BEGIN
  IF NOT EXISTS (SELECT FROM account.account a WHERE a.code = NEW.account) THEN
    RAISE EXCEPTION '% posts to %, which is no account', NEW.entry, NEW.account
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT e.date INTO day FROM transaction.entry e WHERE e.id = NEW.entry;
  period := to_char(day, 'YYYY-MM');
  SELECT p.closed INTO closed FROM account.period p WHERE p.month = period FOR SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION '% is dated %, in no period of the books', NEW.entry, day
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF closed IS NOT NULL THEN
    RAISE EXCEPTION '% is closed: % cannot post into it', period, NEW.entry
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: restores(jsonb); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.restores(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (o.account IS NOT NULL) THEN (((((x.entry || ' credits '::text) || o.account) || ' beyond what '::text) || COALESCE(x.corrects, 'no entry'::text)) || ' debited it: a correction returns cash, it never pays it out'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (restores.payload ->> 'entry'::text) AS entry,
             (restores.payload ->> 'corrects'::text) AS corrects) x
      LEFT JOIN LATERAL ( SELECT min(c.account) AS account
            FROM ( SELECT l.account,
                     sum(cella.cents(l.amount)) AS cents
                    FROM (transaction.line l
                      JOIN account.account a ON (((a.code = l.account) AND a.cash)))
                   WHERE ((l.entry = x.entry) AND (l.side = 'credit'::text))
                   GROUP BY l.account) c
           WHERE (c.cents > COALESCE(( SELECT sum(cella.cents(k.amount)) AS sum
                    FROM transaction.line k
                   WHERE ((k.entry = x.corrects) AND (k.account = c.account) AND (k.side = 'debit'::text))), (0)::numeric))) o ON (true));
END;


--
-- Name: statement(text, date, date); Type: FUNCTION; Schema: account_transaction; Owner: -
--

CREATE FUNCTION account_transaction.statement(sheet text, since date, until date) RETURNS TABLE(id text, n integer, kind text, label text, amount bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    BEGIN ATOMIC
 WITH RECURSIVE lines AS (
          SELECT f.rubric,
             (sum(f.amount))::bigint AS amount
            FROM account_transaction.figures(statement.sheet, statement.since, statement.until) f(rubric, code, label, amount)
           GROUP BY f.rubric
         ), terms AS (
          SELECT r_1.id AS total,
             x.part,
             1 AS sign
            FROM account.rubric r_1,
             LATERAL unnest(r_1.adds) x(part)
           WHERE (r_1.sheet = statement.sheet)
         UNION ALL
          SELECT r_1.id,
             x.part,
             '-1'::integer
            FROM account.rubric r_1,
             LATERAL unnest(r_1.subtracts) x(part)
           WHERE (r_1.sheet = statement.sheet)
         ), expanded AS (
          SELECT t_1.total,
             t_1.part,
             t_1.sign
            FROM terms t_1
         UNION ALL
          SELECT e.total,
             t_1.part,
             (e.sign * t_1.sign)
            FROM (expanded e
              JOIN terms t_1 ON ((t_1.total = e.part)))
         ), totals AS (
          SELECT e.total,
             (COALESCE(sum((e.sign * l_1.amount)), (0)::numeric))::bigint AS amount
            FROM ((expanded e
              JOIN account.rubric r_1 ON (((r_1.id = e.part) AND (r_1.kind = 'line'::text))))
              LEFT JOIN lines l_1 ON ((l_1.rubric = e.part)))
           GROUP BY e.total
         )
  SELECT r.id,
     r.n,
     r.kind,
     r.label,
         CASE r.kind
             WHEN 'line'::text THEN COALESCE(l.amount, (0)::bigint)
             WHEN 'total'::text THEN COALESCE(t.amount, (0)::bigint)
             ELSE NULL::bigint
         END AS "case"
    FROM ((account.rubric r
      LEFT JOIN lines l ON ((l.rubric = r.id)))
      LEFT JOIN totals t ON ((t.total = r.id)))
   WHERE (r.sheet = statement.sheet)
   ORDER BY r.n;
END;


--
-- Name: disclosed(bigint); Type: FUNCTION; Schema: cella; Owner: -
--

CREATE FUNCTION cella.disclosed(n bigint) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
DECLARE
  e record;
BEGIN
  SELECT l.op, l.actor, l.receipt INTO e FROM cella.log l WHERE l.n = disclosed.n;
  IF NOT FOUND OR cella.reader() IS NULL THEN
    RETURN NULL;
  END IF;
  IF e.actor = cella.reader()
    OR NOT EXISTS (SELECT FROM vault.secret s WHERE s.receipt = e.receipt AND s.subject <> cella.reader())
    OR cella.may((SELECT p.power FROM cella.power p WHERE p.op = e.op)) THEN
    RETURN cella.opened(disclosed.n);
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: circle; Type: TABLE; Schema: circle; Owner: -
--

CREATE TABLE circle.circle (
    id text NOT NULL,
    name text NOT NULL,
    parent text,
    purpose text DEFAULT ''::text NOT NULL,
    procedure text DEFAULT 'consent'::text NOT NULL,
    path text[] NOT NULL,
    CONSTRAINT circle_procedure_check CHECK ((procedure ~ '^[a-z][a-z-]*$'::text))
);


--
-- Name: COLUMN circle.name; Type: COMMENT; Schema: circle; Owner: -
--

COMMENT ON COLUMN circle.circle.name IS 'not personal: a circle''s name';


--
-- Name: mandate; Type: TABLE; Schema: circle; Owner: -
--

CREATE TABLE circle.mandate (
    id bigint NOT NULL,
    role text NOT NULL,
    power text NOT NULL,
    text text NOT NULL,
    "limit" cella.amount,
    budget cella.amount,
    per text,
    "from" date,
    until date,
    revoked date,
    CONSTRAINT mandate_check CHECK ((("limit" IS NULL) OR (budget IS NULL))),
    CONSTRAINT mandate_check1 CHECK (((budget IS NULL) = (per IS NULL))),
    CONSTRAINT mandate_check2 CHECK (((until IS NULL) OR ("from" IS NULL) OR ("from" < until))),
    CONSTRAINT mandate_per_check CHECK ((per = ANY (ARRAY['month'::text, 'year'::text]))),
    CONSTRAINT mandate_power_check CHECK ((power ~ '^[a-z][a-z-]*$'::text))
);


--
-- Name: role; Type: TABLE; Schema: circle; Owner: -
--

CREATE TABLE circle.role (
    id text NOT NULL,
    circle text NOT NULL,
    name text NOT NULL,
    duty text DEFAULT ''::text NOT NULL
);


--
-- Name: COLUMN role.name; Type: COMMENT; Schema: circle; Owner: -
--

COMMENT ON COLUMN circle.role.name IS 'not personal: a role''s name';


--
-- Name: beyond(date); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.beyond(day date) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (((((((('mandate '::text || m.id) || ' grants '::text) || m.power) || ' to '::text) || m.role) || ' beyond what '::text) || s.circle) || ' holds of it'::text)
    FROM (((circle.mandate m
      JOIN circle.role r ON ((r.id = m.role)))
      JOIN circle.circle c ON ((c.id = r.circle)))
      JOIN LATERAL ( SELECT r2.circle
            FROM (circle.mandate x
              JOIN circle.role r2 ON ((r2.id = x.role)))
           WHERE ((x.power = m.power) AND (x.revoked IS NULL) AND ((x."from" IS NULL) OR (x."from" <= beyond.day)) AND ((x.until IS NULL) OR (x.until > beyond.day)) AND (r2.circle = ANY (c.path)) AND (r2.circle <> c.id))
           ORDER BY (array_position(c.path, r2.circle)) DESC
          LIMIT 1) s ON (true))
   WHERE ((m.revoked IS NULL) AND ((m."from" IS NULL) OR (m."from" <= beyond.day)) AND ((m.until IS NULL) OR (m.until > beyond.day)) AND (NOT (EXISTS ( SELECT
            FROM (circle.mandate y
              JOIN circle.role r3 ON ((r3.id = y.role)))
           WHERE ((r3.circle = s.circle) AND (y.power = m.power) AND (y.revoked IS NULL) AND ((y."from" IS NULL) OR (y."from" <= beyond.day)) AND ((y.until IS NULL) OR (y.until > beyond.day)) AND (((y."limit" IS NULL) AND (y.budget IS NULL)) OR (cella.cents(m."limit") <= cella.cents(y."limit")) OR ((m.per = y.per) AND (cella.cents(m.budget) <= cella.cents(y.budget)))))))))
   ORDER BY m.id
  LIMIT 1;
END;


--
-- Name: carried(); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.carried() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE circle.circle c SET path = NEW.path || c.path[array_position(c.path, NEW.id) + 1:]
  WHERE NEW.id = ANY(c.path) AND c.id <> NEW.id;
  RETURN NULL;
END
$$;


--
-- Name: carves(jsonb); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.carves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT circle.beyond(cella.verdict_date()) AS beyond;
END;


--
-- Name: grants(jsonb); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.grants(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no mandate '::text || COALESCE((p.mandate)::text, 'is named'::text))
             WHEN ((m."from" IS DISTINCT FROM cella.verdict_date()) OR (m.role IS DISTINCT FROM p.role) OR (m.power IS DISTINCT FROM p.power)) THEN (('mandate '::text || m.id) || ' was not granted by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT ((grants.payload ->> 'mandate'::text))::bigint AS mandate,
             (grants.payload ->> 'role'::text) AS role,
             (grants.payload ->> 'power'::text) AS power) p
      LEFT JOIN circle.mandate m ON ((m.id = p.mandate)));
END;


--
-- Name: nests(jsonb); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.nests(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (c.id IS NULL) THEN ('no circle '::text || COALESCE(p.circle, 'is named'::text))
             WHEN (up.id IS NULL) THEN (('no circle '::text || COALESCE(p.parent, 'is named'::text)) || ' to nest under'::text)
             WHEN (c.parent IS DISTINCT FROM up.id) THEN (((c.id || ' was not nested under '::text) || up.id) || ' by this write'::text)
             WHEN (c.id = ANY (up.path)) THEN (((up.id || ' is within '::text) || c.id) || ': nesting it there makes a cycle'::text)
             WHEN (c.path IS DISTINCT FROM (up.path || c.id)) THEN (c.id || ' moved under a parent that moved meanwhile'::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (nests.payload ->> 'circle'::text) AS circle,
             (nests.payload ->> 'parent'::text) AS parent) p
      LEFT JOIN circle.circle c ON ((c.id = p.circle)))
      LEFT JOIN circle.circle up ON ((up.id = p.parent)));
END;


--
-- Name: placed(); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.placed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  above text[];
BEGIN
  IF NEW.parent IS NULL THEN
    NEW.path := ARRAY[NEW.id];
    RETURN NEW;
  END IF;
  SELECT p.path INTO above FROM circle.circle p WHERE p.id = NEW.parent;
  IF above IS NULL THEN
    RAISE EXCEPTION 'no circle %', NEW.parent USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NEW.id = ANY(above) THEN
    RAISE EXCEPTION '% is within %: nesting it there makes a cycle', NEW.parent, NEW.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  NEW.path := above || NEW.id;
  RETURN NEW;
END
$$;


--
-- Name: revokes(jsonb); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.revokes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no mandate '::text || COALESCE((p.mandate)::text, 'is named'::text))
             WHEN (m.revoked IS DISTINCT FROM cella.verdict_date()) THEN (('mandate '::text || m.id) || ' was not revoked by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT ((revokes.payload ->> 'mandate'::text))::bigint AS mandate) p
      LEFT JOIN circle.mandate m ON ((m.id = p.mandate)));
END;


--
-- Name: stays_granted(); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.stays_granted() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (NEW.role, NEW.power, cella.cents(NEW."limit"), cella.cents(NEW.budget), NEW.per, NEW."from", NEW.until)
       IS DISTINCT FROM (OLD.role, OLD.power, cella.cents(OLD."limit"), cella.cents(OLD.budget), OLD.per, OLD."from", OLD.until)
    OR (OLD.revoked IS NOT NULL AND NEW.revoked IS DISTINCT FROM OLD.revoked) THEN
    RAISE EXCEPTION 'mandate % of % keeps its grant, and stays revoked', OLD.id, OLD.role
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: within(text, text); Type: FUNCTION; Schema: circle; Owner: -
--

CREATE FUNCTION circle.within(part text, whole text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (EXISTS ( SELECT
            FROM circle.circle c
           WHERE ((c.id = within.part) AND (within.whole = ANY (c.path))))) AS "exists";
END;


--
-- Name: decides(text, text); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.decides(decider text, subject text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT ((EXISTS ( SELECT
            FROM circle.circle b
           WHERE ((b.id = decides.decider) AND (b.parent IS NULL)))) OR ((decider IS DISTINCT FROM subject) AND circle.within(subject, decider)));
END;


--
-- Name: motion; Type: VIEW; Schema: circle_decision; Owner: -
--

CREATE VIEW circle_decision.motion AS
 SELECT decision,
    n,
    kind,
    args,
        CASE kind
            WHEN 'nest'::text THEN (args ->> 'circle'::text)
            WHEN 'grant'::text THEN ( SELECT NULLIF(r.circle, '*'::text) AS "nullif"
               FROM circle.role r
              WHERE (r.id = (m.args ->> 'role'::text)))
            WHEN 'revoke'::text THEN ( SELECT NULLIF(r.circle, '*'::text) AS "nullif"
               FROM (circle.mandate x
                 JOIN circle.role r ON ((r.id = x.role)))
              WHERE (((m.args ->> 'mandate'::text) ~ '^[0-9]{1,18}$'::text) AND (x.id = ((m.args ->> 'mandate'::text))::bigint)))
            ELSE NULL::text
        END AS circle
   FROM decision.motion m
  WHERE (kind = ANY (ARRAY['nest'::text, 'grant'::text, 'revoke'::text]));


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN ((m.kind = 'nest'::text) AND (NOT (EXISTS ( SELECT
                        FROM circle.circle c
                       WHERE (c.id = (m.args ->> 'circle'::text)))))) THEN (('no circle '::text || COALESCE((m.args ->> 'circle'::text), 'is named'::text)) || ' to nest'::text)
                     WHEN ((m.kind = 'nest'::text) AND (NOT (EXISTS ( SELECT
                        FROM circle.circle c
                       WHERE (c.id = (m.args ->> 'parent'::text)))))) THEN (('no circle '::text || COALESCE((m.args ->> 'parent'::text), 'is named'::text)) || ' to nest under'::text)
                     WHEN ((m.kind = 'grant'::text) AND (NOT (EXISTS ( SELECT
                        FROM circle.role r
                       WHERE (r.id = (m.args ->> 'role'::text)))))) THEN ('no role '::text || COALESCE((m.args ->> 'role'::text), 'is named'::text))
                     WHEN ((m.kind = 'grant'::text) AND (COALESCE((m.args ->> 'power'::text), ''::text) !~ '^[a-z][a-z-]*$'::text)) THEN 'a power is named in lower case, such as approve-time'::text
                     WHEN ((m.kind = 'grant'::text) AND (m.args ? 'limit'::text) AND (m.args ? 'budget'::text)) THEN 'a mandate caps by a limit per write or by a budget, not both'::text
                     WHEN ((m.kind = 'grant'::text) AND (m.args ? 'budget'::text) AND (COALESCE((m.args ->> 'per'::text), ''::text) <> ALL (ARRAY['month'::text, 'year'::text]))) THEN 'a budget runs per month or per year'::text
                     WHEN ((m.kind = 'revoke'::text) AND (NOT (EXISTS ( SELECT
                        FROM circle.mandate x_1
                       WHERE (((m.args ->> 'mandate'::text) ~ '^[0-9]{1,18}$'::text) AND (x_1.id = ((m.args ->> 'mandate'::text))::bigint) AND (x_1.revoked IS NULL)))))) THEN ('no mandate in force '::text || COALESCE((m.args ->> 'mandate'::text), 'is named'::text))
                     WHEN ((NOT circle_decision.decides(d.circle, COALESCE(m.circle, '*'::text))) OR ((m.kind = 'nest'::text) AND (NOT circle_decision.decides(d.circle, (m.args ->> 'parent'::text))) AND (d.circle IS DISTINCT FROM (m.args ->> 'parent'::text)))) THEN ((((d.circle || ' may not decide to '::text) || m.kind) || ' in '::text) || COALESCE(m.circle, 'every working circle'::text))
                     ELSE NULL::text
                 END AS r
            FROM (circle_decision.motion m
              JOIN decision.decision d ON ((d.id = m.decision)))
           WHERE (m.decision = (asks.payload ->> 'decision'::text))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: decides_by(); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.decides_by() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM decision.procedure p WHERE p.id = NEW.procedure) THEN
    RAISE EXCEPTION '% decides by %, which is no procedure', NEW.id, NEW.procedure
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: grants(jsonb); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.grants(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision.motion m
               WHERE ((m.decision = d.id) AND (m.kind = 'grant'::text) AND ((m.args ->> 'role'::text) = p.role) AND ((m.args ->> 'power'::text) = p.power) AND (NOT (round((((m.args ->> 'limit'::text))::numeric * (100)::numeric)) IS DISTINCT FROM p."limit")) AND (NOT (round((((m.args ->> 'budget'::text))::numeric * (100)::numeric)) IS DISTINCT FROM p.budget)) AND (NOT ((m.args ->> 'per'::text) IS DISTINCT FROM p.per)))))) THEN (((((d.id || ' does not grant '::text) || COALESCE(p.power, 'this power'::text)) || ' to '::text) || COALESCE(p.role, 'this role'::text)) || ' so capped'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (grants.payload ->> 'decision'::text) AS decision,
             (grants.payload ->> 'role'::text) AS role,
             (grants.payload ->> 'power'::text) AS power,
             ((grants.payload ->> 'limit'::text))::numeric AS "limit",
             ((grants.payload ->> 'budget'::text))::numeric AS budget,
             (grants.payload ->> 'per'::text) AS per) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: nests(jsonb); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.nests(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision.motion m
               WHERE ((m.decision = d.id) AND (m.kind = 'nest'::text) AND ((m.args ->> 'circle'::text) = p.circle) AND ((m.args ->> 'parent'::text) = p.parent))))) THEN ((((d.id || ' does not nest '::text) || COALESCE(p.circle, 'a circle'::text)) || ' under '::text) || COALESCE(p.parent, 'another'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (nests.payload ->> 'decision'::text) AS decision,
             (nests.payload ->> 'circle'::text) AS circle,
             (nests.payload ->> 'parent'::text) AS parent) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: revokes(jsonb); Type: FUNCTION; Schema: circle_decision; Owner: -
--

CREATE FUNCTION circle_decision.revokes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision.motion m
               WHERE ((m.decision = d.id) AND (m.kind = 'revoke'::text) AND ((m.args ->> 'mandate'::text) = p.mandate))))) THEN ((d.id || ' does not revoke mandate '::text) || COALESCE(p.mandate, '?'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (revokes.payload ->> 'decision'::text) AS decision,
             (revokes.payload ->> 'mandate'::text) AS mandate) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: position; Type: TABLE; Schema: circle_membership; Owner: -
--

CREATE TABLE circle_membership."position" (
    id bigint NOT NULL,
    circle text NOT NULL,
    member text NOT NULL,
    role text,
    since date,
    until date,
    CONSTRAINT position_check CHECK (((until IS NULL) OR (since IS NULL) OR (since < until)))
);


--
-- Name: motion; Type: VIEW; Schema: decision_membership; Owner: -
--

CREATE VIEW decision_membership.motion AS
 SELECT decision,
    n,
    kind,
    (args ->> 'member'::text) AS member,
        CASE
            WHEN ((args ->> 'shares'::text) ~ '^[0-9]{1,9}$'::text) THEN ((args ->> 'shares'::text))::integer
            ELSE NULL::integer
        END AS shares
   FROM decision.motion m
  WHERE (kind = ANY (ARRAY['admit'::text, 'suspend'::text, 'exit'::text, 'erase'::text]));


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (NOT (EXISTS ( SELECT
                        FROM circle.circle c
                       WHERE ((c.id = d.circle) AND (c.parent IS NULL))))) THEN ((('only the assembly decides to '::text || a.kind) || ' a member, not '::text) || d.circle)
                     ELSE NULL::text
                 END AS r
            FROM (decision_membership.motion a
              JOIN decision.decision d ON ((d.id = a.decision)))
           WHERE (a.decision = (asks.payload ->> 'decision'::text))
         UNION ALL
          SELECT
                 CASE
                     WHEN (NOT (EXISTS ( SELECT
                        FROM circle.circle c
                       WHERE (c.id = g.circle)))) THEN ('no circle '::text || COALESCE(g.circle, 'is named'::text))
                     WHEN ((g.kind = 'seat'::text) AND (NOT (EXISTS ( SELECT
                        FROM membership.member m
                       WHERE ((m.address = g.member) AND (m.status = 'active'::text)))))) THEN (COALESCE(g.member, 'no one'::text) || ' is not an active member'::text)
                     WHEN ((g.kind = 'seat'::text) AND (g.role IS NOT NULL) AND (NOT (EXISTS ( SELECT
                        FROM circle.role x_1
                       WHERE ((x_1.id = g.role) AND (x_1.circle = ANY (ARRAY[g.circle, '*'::text]))))))) THEN ((('no role '::text || g.role) || ' in '::text) || g.circle)
                     WHEN ((g.kind = 'unseat'::text) AND (NOT (EXISTS ( SELECT
                        FROM circle_membership."position" o
                       WHERE ((o.circle = g.circle) AND (o.member = g.member) AND (NOT (o.role IS DISTINCT FROM g.role)) AND (o.until IS NULL)))))) THEN ((COALESCE(g.member, 'no one'::text) || ' holds no such seat in '::text) || g.circle)
                     WHEN (NOT circle_decision.decides(d.circle, g.circle)) THEN ((d.circle || ' may not decide who sits in '::text) || g.circle)
                     ELSE NULL::text
                 END AS "case"
            FROM (( SELECT m.decision,
                     m.kind,
                     (m.args ->> 'circle'::text) AS circle,
                     (m.args ->> 'member'::text) AS member,
                     (m.args ->> 'role'::text) AS role
                    FROM decision.motion m
                   WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = ANY (ARRAY['seat'::text, 'unseat'::text])))) g
              JOIN decision.decision d ON ((d.id = g.decision)))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: attach(); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.attach() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO cella.rule (op, fn, owner)
  VALUES (NEW.op, 'circle_decision_membership.carried(jsonb)', 'circle-decision-membership');
  RETURN NULL;
END
$$;


--
-- Name: counted; Type: TABLE; Schema: circle_decision_membership; Owner: -
--

CREATE TABLE circle_decision_membership.counted (
    decision text NOT NULL,
    member text NOT NULL
);


--
-- Name: roll; Type: TABLE; Schema: circle_decision_membership; Owner: -
--

CREATE TABLE circle_decision_membership.roll (
    decision text NOT NULL,
    member text NOT NULL
);


--
-- Name: electorate(text); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.electorate(ref text) RETURNS SETOF text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT c.member
    FROM (circle_decision_membership.counted c
      JOIN decision.decision d ON (((d.id = c.decision) AND (d.closed IS NOT NULL))))
   WHERE (c.decision = electorate.ref)
 UNION
  SELECT r.member
    FROM ((circle_decision_membership.roll r
      JOIN decision.decision d ON (((d.id = r.decision) AND (d.closed IS NULL))))
      JOIN membership.member m ON (((m.address = r.member) AND (m.status = 'active'::text))))
   WHERE (r.decision = electorate.ref);
END;


--
-- Name: vote; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.vote (
    receipt bigint NOT NULL,
    decision text NOT NULL,
    member text NOT NULL,
    stance text NOT NULL,
    at date NOT NULL,
    CONSTRAINT vote_stance_check CHECK ((stance = ANY (ARRAY['for'::text, 'against'::text, 'abstain'::text, 'consent'::text, 'object'::text])))
);


--
-- Name: stances(text); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.stances(ref text) RETURNS SETOF decision.vote
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT v.receipt,
     v.decision,
     v.member,
     v.stance,
     v.at
    FROM (decision.vote v
      JOIN decision.decision d ON ((d.id = v.decision)))
   WHERE ((v.decision = stances.ref) AND (v.receipt < COALESCE(d.cutoff, '9223372036854775807'::bigint)) AND (v.member IN ( SELECT circle_decision_membership.electorate(stances.ref) AS electorate)));
END;


--
-- Name: procedure; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.procedure (
    id text NOT NULL,
    label text NOT NULL,
    rule text NOT NULL,
    share_num integer,
    share_den integer,
    quorum_num integer DEFAULT 0 NOT NULL,
    quorum_den integer DEFAULT 1 NOT NULL,
    CONSTRAINT procedure_check CHECK (((share_num IS NULL) = (share_den IS NULL))),
    CONSTRAINT procedure_check1 CHECK (((share_num IS NULL) OR ((rule = 'majority'::text) AND (0 < share_num) AND (share_num <= share_den)))),
    CONSTRAINT procedure_check2 CHECK (((0 <= quorum_num) AND (quorum_num <= quorum_den))),
    CONSTRAINT procedure_id_check CHECK ((id ~ '^[a-z][a-z-]*$'::text)),
    CONSTRAINT procedure_rule_check CHECK ((rule = ANY (ARRAY['consent'::text, 'majority'::text])))
);


--
-- Name: turnout(text); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.turnout(ref text, OUT counted integer, OUT given integer, OUT quorate boolean) RETURNS record
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT e.n,
     s.n,
     ((s.n * p.quorum_den) >= (p.quorum_num * e.n))
    FROM (((decision.decision d
      JOIN decision.procedure p ON ((p.id = d.procedure)))
      CROSS JOIN LATERAL ( SELECT (count(*))::integer AS n
            FROM circle_decision_membership.electorate(d.id) electorate(electorate)) e)
      CROSS JOIN LATERAL ( SELECT (count(DISTINCT x.member))::integer AS n
            FROM circle_decision_membership.stances(d.id) x(receipt, decision, member, stance, at)) s)
   WHERE (d.id = turnout.ref);
END;


--
-- Name: passes(text); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.passes(ref text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (( SELECT t.quorate
            FROM circle_decision_membership.turnout(d.id) t(counted, given, quorate)) AND
         CASE
             WHEN (d.rule = 'consent'::text) THEN ( SELECT cella.consent(s.member, s.stance, s.receipt) AS consent
                FROM circle_decision_membership.stances(d.id) s(receipt, decision, member, stance, at))
             WHEN (p.share_num IS NULL) THEN ( SELECT cella.majority(s.member, s.stance, s.receipt) AS majority
                FROM circle_decision_membership.stances(d.id) s(receipt, decision, member, stance, at))
             ELSE ( SELECT cella.share(s.member, s.stance, s.receipt, (p.share_num)::bigint, (p.share_den)::bigint) AS share
                FROM circle_decision_membership.stances(d.id) s(receipt, decision, member, stance, at))
         END)
    FROM (decision.decision d
      JOIN decision.procedure p ON ((p.id = d.procedure)))
   WHERE (d.id = passes.ref);
END;


--
-- Name: carried(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.carried(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (d.closed IS NULL) THEN (d.id || ' is not closed'::text)
             WHEN (NOT circle_decision_membership.passes(d.id)) THEN ((d.id || ' does not pass by '::text) || d.rule)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (carried.payload ->> 'decision'::text) AS decision) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: count_roll(); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.count_roll() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO circle_decision_membership.counted (decision, member)
  SELECT r.decision, r.member
  FROM circle_decision_membership.roll r
  JOIN membership.member m ON m.address = r.member AND m.status = 'active'
  WHERE r.decision = NEW.id;
  RETURN NULL;
END
$$;


--
-- Name: fix_roll(); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.fix_roll() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
BEGIN
  INSERT INTO circle_decision_membership.roll (decision, member)
  SELECT NEW.id, s FROM circle_membership.seated(NEW.circle, NEW.proposed) s;
  RETURN NULL;
END
$$;


--
-- Name: on_roll(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.on_roll(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision_membership.roll r
               WHERE ((r.decision = p.decision) AND (r.member = p.member))))) THEN ((COALESCE(p.member, 'no one'::text) || ' is not on the roll of '::text) || COALESCE(p.decision, 'no decision'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM membership.member m
               WHERE ((m.address = p.member) AND (m.status = 'active'::text))))) THEN (p.member || ' is not an active member'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (on_roll.payload ->> 'decision'::text) AS decision,
             (on_roll.payload ->> 'member'::text) AS member) p;
END;


--
-- Name: seating; Type: VIEW; Schema: circle_decision_membership; Owner: -
--

CREATE VIEW circle_decision_membership.seating AS
 SELECT m.decision,
    m.n,
    m.kind,
    (m.args ->> 'circle'::text) AS circle,
    (m.args ->> 'member'::text) AS member,
    (m.args ->> 'role'::text) AS role
   FROM decision.motion m
  WHERE (m.kind = ANY (ARRAY['seat'::text, 'unseat'::text]))
UNION ALL
 SELECT a.decision,
    a.n,
    'seat'::text AS kind,
    d.circle,
    a.member,
    'member'::text AS role
   FROM (decision_membership.motion a
     JOIN decision.decision d ON ((d.id = a.decision)))
  WHERE (a.kind = 'admit'::text);


--
-- Name: seats(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.seats(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (s.id IS NULL) THEN ('no position '::text || COALESCE((p."position")::text, 'is named'::text))
             WHEN ((s.since IS DISTINCT FROM cella.verdict_date()) OR (s.until IS NOT NULL)) THEN (('position '::text || s.id) || ' was not added by this write'::text)
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision_membership.seating g
               WHERE ((g.decision = d.id) AND (g.kind = 'seat'::text) AND (g.circle = s.circle) AND (g.member = s.member) AND (NOT (g.role IS DISTINCT FROM s.role)))))) THEN (((((d.id || ' does not seat '::text) || s.member) || ' in '::text) || s.circle) || COALESCE((' as '::text || s.role), ''::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM membership.member m
               WHERE ((m.address = s.member) AND (m.status = 'active'::text))))) THEN (s.member || ' is not an active member'::text)
             WHEN (EXISTS ( SELECT
                FROM circle_membership."position" o
               WHERE ((o.id <> s.id) AND (o.circle = s.circle) AND (o.member = s.member) AND (NOT (o.role IS DISTINCT FROM s.role)) AND ((o.until IS NULL) OR (o.until > cella.verdict_date()))))) THEN (((s.member || ' already sits in '::text) || s.circle) || COALESCE((' as '::text || s.role), ''::text))
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT ((seats.payload ->> 'position'::text))::bigint AS "position",
             (seats.payload ->> 'decision'::text) AS decision) p
      LEFT JOIN circle_membership."position" s ON ((s.id = p."position")))
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: settles(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.settles(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((d.id IS NULL) OR (d.closed IS NULL)) THEN NULL::text
             WHEN COALESCE(circle_decision_membership.passes(d.id), false) THEN ( SELECT x.r
                FROM ( SELECT
                             CASE
                                 WHEN (a.member IS NULL) THEN ((d.id || ' passes, and its close does not admit '::text) || m.member)
                                 ELSE circle_decision_membership.seats(jsonb_build_object('position', a."position", 'decision', d.id))
                             END AS r
                        FROM (decision_membership.motion m
                          LEFT JOIN jsonb_to_recordset(COALESCE((settles.payload -> 'admitted'::text), '[]'::jsonb)) a(member text, "position" bigint) ON ((a.member = m.member)))
                       WHERE ((m.decision = d.id) AND (m.kind = 'admit'::text))) x
               WHERE (x.r IS NOT NULL)
              LIMIT 1)
             WHEN (jsonb_array_length(COALESCE((settles.payload -> 'admitted'::text), '[]'::jsonb)) > 0) THEN (d.id || ' does not pass, so its close admits no one'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (settles.payload ->> 'decision'::text) AS id) p
      LEFT JOIN decision.decision d ON ((d.id = p.id)));
END;


--
-- Name: seated(text, date); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.seated(circle text, day date) RETURNS SETOF text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT DISTINCT p.member
    FROM circle_membership."position" p
   WHERE ((p.circle = seated.circle) AND ((p.since IS NULL) OR (p.since <= seated.day)) AND ((p.until IS NULL) OR (p.until > seated.day)));
END;


--
-- Name: sits(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.sits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is named'::text))
             WHEN ((NOT (EXISTS ( SELECT
                FROM circle_membership.seated(d.circle, cella.verdict_date()) s(s)
               WHERE (s.s = cella.actor())))) OR (NOT (EXISTS ( SELECT
                FROM membership.member m
               WHERE ((m.address = cella.actor()) AND (m.status = 'active'::text)))))) THEN ((((((cella.actor() || ' holds no seat in '::text) || d.circle) || ', so may not '::text) || split_part(cella.op(), ':'::text, 3)) || ' '::text) || d.id)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (sits.payload ->> 'decision'::text) AS decision) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: unseats(jsonb); Type: FUNCTION; Schema: circle_decision_membership; Owner: -
--

CREATE FUNCTION circle_decision_membership.unseats(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (s.id IS NULL) THEN ((('no seat '::text || COALESCE(p.member, 'of no one'::text)) || ' holds in '::text) || COALESCE(p.circle, 'no circle'::text))
             WHEN (s.until IS DISTINCT FROM cella.verdict_date()) THEN (('position '::text || s.id) || ' was not ended by this write'::text)
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_decision_membership.seating g
               WHERE ((g.decision = d.id) AND (g.kind = 'unseat'::text) AND (g.circle = s.circle) AND (g.member = s.member) AND (NOT (g.role IS DISTINCT FROM s.role)))))) THEN ((((d.id || ' does not end '::text) || s.member) || '''s seat in '::text) || s.circle)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT ((unseats.payload ->> 'position'::text))::bigint AS "position",
             (unseats.payload ->> 'circle'::text) AS circle,
             (unseats.payload ->> 'member'::text) AS member,
             (unseats.payload ->> 'decision'::text) AS decision) p
      LEFT JOIN circle_membership."position" s ON ((s.id = p."position")))
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: number; Type: SEQUENCE; Schema: expense; Owner: -
--

CREATE SEQUENCE expense.number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: expense; Type: TABLE; Schema: expense; Owner: -
--

CREATE TABLE expense.expense (
    id text DEFAULT ('ex-'::text || lpad((nextval('expense.number'::regclass))::text, 4, '0'::text)) NOT NULL,
    member text NOT NULL,
    day date NOT NULL,
    label text NOT NULL,
    category text NOT NULL,
    net cella.amount NOT NULL,
    vat cella.amount,
    receipt text,
    status text DEFAULT 'draft'::text NOT NULL,
    submitted date,
    decided date,
    decider text,
    reimbursed date,
    CONSTRAINT expense_category_check CHECK ((category ~ '^6[0-9]+$'::text)),
    CONSTRAINT expense_check CHECK (((decided IS NULL) = (decider IS NULL))),
    CONSTRAINT expense_check1 CHECK (((status = ANY (ARRAY['approved'::text, 'refused'::text, 'reimbursed'::text])) = (decided IS NOT NULL))),
    CONSTRAINT expense_check2 CHECK (((status = 'reimbursed'::text) = (reimbursed IS NOT NULL))),
    CONSTRAINT expense_label_check CHECK ((label <> ''::text)),
    CONSTRAINT expense_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'submitted'::text, 'approved'::text, 'refused'::text, 'reimbursed'::text])))
);


--
-- Name: COLUMN expense.net; Type: COMMENT; Schema: expense; Owner: -
--

COMMENT ON COLUMN expense.expense.net IS 'not personal: an amount of the books';


--
-- Name: COLUMN expense.decider; Type: COMMENT; Schema: expense; Owner: -
--

COMMENT ON COLUMN expense.expense.decider IS 'not personal: the decider''s pseudonymous address';


--
-- Name: total(expense.expense); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.total(e expense.expense) RETURNS bigint
    LANGUAGE sql IMMUTABLE
    RETURN (cella.cents((e).net) + COALESCE(cella.cents((e).vat), (0)::bigint));


--
-- Name: approved(text, date, text); Type: FUNCTION; Schema: circle_expense_membership; Owner: -
--

CREATE FUNCTION circle_expense_membership.approved(member text, day date, per text) RETURNS bigint
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(sum(expense.total(e.*)), (0)::numeric) AS "coalesce"
    FROM expense.expense e
   WHERE ((e.decider = approved.member) AND (e.status = ANY (ARRAY['approved'::text, 'reimbursed'::text])) AND (date_trunc(approved.per, (e.decided)::timestamp with time zone) = date_trunc(approved.per, (approved.day)::timestamp with time zone)));
END;


--
-- Name: within(jsonb); Type: FUNCTION; Schema: circle_expense_membership; Owner: -
--

CREATE FUNCTION circle_expense_membership.within(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 WITH held AS (
          SELECT cella.cents(m.budget) AS budget,
             m.per,
             circle_expense_membership.approved(cella.actor(), cella.verdict_date(), COALESCE(m.per, 'month'::text)) AS spent
            FROM (circle_membership."position" p
              JOIN circle.mandate m ON ((m.role = p.role)))
           WHERE ((p.member = cella.actor()) AND (m.power = 'approve-expense'::text) AND ((p.since IS NULL) OR (p.since <= cella.verdict_date())) AND ((p.until IS NULL) OR (p.until > cella.verdict_date())) AND ((m."from" IS NULL) OR (m."from" <= cella.verdict_date())) AND ((m.until IS NULL) OR (m.until > cella.verdict_date())) AND (m.revoked IS NULL))
         )
  SELECT
         CASE
             WHEN ((EXISTS ( SELECT
                FROM held h
               WHERE (h.budget IS NOT NULL))) AND (NOT (EXISTS ( SELECT
                FROM held h
               WHERE ((h.budget IS NULL) OR (h.spent <= h.budget)))))) THEN (((((((cella.actor() || '''s approvals this '::text) || ( SELECT min(h.per) AS min
                FROM held h
               WHERE (h.budget IS NOT NULL))) || ' come to '::text) || ( SELECT min(h.spent) AS min
                FROM held h
               WHERE (h.budget IS NOT NULL))) || ' cents, beyond their approve-expense budget of '::text) || ( SELECT max(h.budget) AS max
                FROM held h)) || ' cents'::text)
             ELSE NULL::text
         END AS "case";
END;


--
-- Name: may(text, text, bigint, date); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.may(actor text, power text, cents bigint, day date) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (EXISTS ( SELECT
            FROM ((circle_membership."position" p
              JOIN circle.mandate m ON ((m.role = p.role)))
              JOIN membership.member mm ON ((mm.address = p.member)))
           WHERE ((p.member = may.actor) AND (mm.status = 'active'::text) AND (m.power = may.power) AND ((p.since IS NULL) OR (p.since <= may.day)) AND ((p.until IS NULL) OR (p.until > may.day)) AND ((m."from" IS NULL) OR (m."from" <= may.day)) AND ((m.until IS NULL) OR (m.until > may.day)) AND (m.revoked IS NULL) AND ((m."limit" IS NULL) OR (may.cents IS NULL) OR (may.cents <= cella.cents(m."limit")))))) AS "exists";
END;


--
-- Name: largest(); Type: FUNCTION; Schema: file; Owner: -
--

CREATE FUNCTION file.largest() RETURNS integer
    LANGUAGE sql IMMUTABLE
    RETURN 10485760;


--
-- Name: opener; Type: TABLE; Schema: circle_file_membership; Owner: -
--

CREATE TABLE circle_file_membership.opener (
    class text NOT NULL,
    power text NOT NULL
);


--
-- Name: number; Type: SEQUENCE; Schema: file; Owner: -
--

CREATE SEQUENCE file.number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file; Type: TABLE; Schema: file; Owner: -
--

CREATE TABLE file.file (
    id text DEFAULT ('fi-'::text || lpad((nextval('file.number'::regclass))::text, 4, '0'::text)) NOT NULL,
    class text NOT NULL,
    subject text,
    name text NOT NULL,
    type text NOT NULL,
    size integer NOT NULL,
    bytes bytea,
    hash bytea GENERATED ALWAYS AS (cella.digest(bytes)) STORED,
    uploader text NOT NULL,
    uploaded date NOT NULL,
    CONSTRAINT file_check CHECK (((class = 'none'::text) = (subject IS NULL))),
    CONSTRAINT file_check1 CHECK (((bytes IS NULL) OR (octet_length(bytes) = size))),
    CONSTRAINT file_class_check CHECK ((class = ANY (ARRAY['none'::text, 'expense-receipt'::text, 'payroll'::text, 'profile'::text]))),
    CONSTRAINT file_name_check CHECK ((name <> ''::text)),
    CONSTRAINT file_size_check CHECK (((size > 0) AND (size <= file.largest()))),
    CONSTRAINT file_type_check CHECK ((type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))
)
PARTITION BY LIST (class);


--
-- Name: COLUMN file.name; Type: COMMENT; Schema: file; Owner: -
--

COMMENT ON COLUMN file.file.name IS 'not personal: the co-op''s own files'' names; each personal class''s part, file.receipt, file.contract and file.record, registers its own';


--
-- Name: opens(text, text); Type: FUNCTION; Schema: circle_file_membership; Owner: -
--

CREATE FUNCTION circle_file_membership.opens(id text, actor text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(bool_or(circle_membership.may(opens.actor, o.power, NULL::bigint, cella.verdict_date())), false) AS "coalesce"
    FROM (file.file f
      JOIN circle_file_membership.opener o ON ((o.class = f.class)))
   WHERE (f.id = opens.id);
END;


--
-- Name: meeting; Type: TABLE; Schema: meeting; Owner: -
--

CREATE TABLE meeting.meeting (
    id text NOT NULL,
    circle text NOT NULL,
    title text NOT NULL,
    at timestamp without time zone NOT NULL,
    place text DEFAULT ''::text NOT NULL,
    link text,
    scheduled date,
    status text DEFAULT 'scheduled'::text NOT NULL,
    settled date,
    minuted date,
    CONSTRAINT meeting_check CHECK (((status = 'scheduled'::text) = (settled IS NULL))),
    CONSTRAINT meeting_id_check CHECK ((id ~ '^[a-z0-9]+(-[a-z0-9]+)*$'::text)),
    CONSTRAINT meeting_link_check CHECK (((link IS NULL) OR (link ~ '^https://'::text))),
    CONSTRAINT meeting_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'held'::text, 'cancelled'::text]))),
    CONSTRAINT meeting_title_check CHECK ((title <> ''::text))
);


--
-- Name: meets(jsonb); Type: FUNCTION; Schema: circle_meeting; Owner: -
--

CREATE FUNCTION circle_meeting.meets(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (c.id IS NULL) THEN (('no circle '::text || COALESCE(m.circle, w.circle, 'is named'::text)) || ' to meet'::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (meets.payload ->> 'meeting'::text) AS meeting,
             (meets.payload ->> 'circle'::text) AS circle) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.meeting)))
      LEFT JOIN circle.circle c ON ((c.id = COALESCE(m.circle, w.circle))));
END;


--
-- Name: resolves(); Type: FUNCTION; Schema: circle_meeting; Owner: -
--

CREATE FUNCTION circle_meeting.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM circle.circle c WHERE c.id = NEW.circle) THEN
    RAISE EXCEPTION 'no circle %', NEW.circle USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: over(text, text, text, date); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.over(actor text, power text, about text, day date) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (EXISTS ( SELECT
            FROM (circle_membership."position" a
              JOIN circle.mandate md ON ((md.role = a.role)))
           WHERE ((a.member = over.actor) AND (md.power = over.power) AND (md.revoked IS NULL) AND ((md."from" IS NULL) OR (md."from" <= over.day)) AND ((md.until IS NULL) OR (md.until > over.day)) AND ((a.since IS NULL) OR (a.since <= over.day)) AND ((a.until IS NULL) OR (a.until > over.day)) AND circle.within(over.about, a.circle)))) AS "exists";
END;


--
-- Name: reaches(jsonb); Type: FUNCTION; Schema: circle_meeting_membership; Owner: -
--

CREATE FUNCTION circle_meeting_membership.reaches(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN NULL::text
             WHEN (NOT circle_membership.over(cella.actor(), w.power, m.circle, cella.verdict_date())) THEN ((((COALESCE(cella.actor(), 'no one'::text) || ' holds '::text) || COALESCE(w.power, 'no power'::text)) || ' over no circle that holds '::text) || m.id)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (reaches.payload ->> 'meeting'::text) AS meeting,
             ( SELECT p.power
                    FROM cella.power p
                   WHERE (p.op = cella.op())) AS power) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.meeting)));
END;


--
-- Name: records(jsonb); Type: FUNCTION; Schema: circle_meeting_membership; Owner: -
--

CREATE FUNCTION circle_meeting_membership.records(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no meeting '::text || COALESCE(w.meeting, 'is named'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM circle_membership.seated(m.circle, (m.at)::date) s(s)
               WHERE (s.s = w.member)))) THEN (((((COALESCE(w.member, 'no one'::text) || ' holds no seat in '::text) || m.circle) || ' on '::text) || to_char(m.at, 'YYYY-MM-DD'::text)) || ': only they may mark themselves, as a guest'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (records.payload ->> 'meeting'::text) AS meeting,
             (records.payload ->> 'member'::text) AS member) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.meeting)));
END;


--
-- Name: sits(jsonb); Type: FUNCTION; Schema: circle_meeting_membership; Owner: -
--

CREATE FUNCTION circle_meeting_membership.sits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no meeting '::text || COALESCE(w.meeting, 'is named'::text))
             WHEN (cella.actor() IS NULL) THEN 'an agenda is drawn up by a member of its circle, and this write has no actor'::text
             WHEN ((NOT (EXISTS ( SELECT
                FROM circle_membership.seated(m.circle, cella.verdict_date()) s(s)
               WHERE (s.s = cella.actor())))) OR (NOT (EXISTS ( SELECT
                FROM membership.member mm
               WHERE ((mm.address = cella.actor()) AND (mm.status = 'active'::text)))))) THEN (((cella.actor() || ' holds no seat in '::text) || m.circle) || ': its agenda is its members'''::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (sits.payload ->> 'meeting'::text) AS meeting) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.meeting)));
END;


--
-- Name: attach(); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.attach() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO cella.rule (op, fn, owner)
  VALUES (NEW.op, 'circle_membership.empowered(jsonb)', 'circle-membership');
  RETURN NULL;
END
$$;


--
-- Name: empowered(jsonb); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.empowered(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((w.amount IS NOT NULL) AND (w.cents IS NULL)) THEN (((w.op || ' names its amount in '::text) || w.amount) || ', which the payload lacks'::text)
             WHEN (NOT circle_membership.may(cella.actor(), w.power, w.cents, cella.verdict_date())) THEN (((cella.actor() || ' holds no mandate for '::text) || w.power) || COALESCE(((' up to '::text || (cella.amount(w.cents))::text) || ' €'::text), ''::text))
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT p.op,
             p.power,
             p.amount,
             ((empowered.payload ->> p.amount))::bigint AS cents
            FROM cella.power p
           WHERE (p.op = cella.op())) w;
END;


--
-- Name: sits(jsonb); Type: FUNCTION; Schema: circle_membership; Owner: -
--

CREATE FUNCTION circle_membership.sits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((NOT (EXISTS ( SELECT
                FROM circle_membership.seated(p.circle, cella.verdict_date()) s(s)
               WHERE (s.s = cella.actor())))) OR (NOT (EXISTS ( SELECT
                FROM membership.member m
               WHERE ((m.address = cella.actor()) AND (m.status = 'active'::text)))))) THEN ((cella.actor() || ' holds no seat in '::text) || COALESCE(p.circle, 'no circle'::text))
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (sits.payload ->> 'circle'::text) AS circle) p;
END;


--
-- Name: project; Type: TABLE; Schema: project; Owner: -
--

CREATE TABLE project.project (
    id text NOT NULL,
    title text NOT NULL,
    circle text,
    summary text DEFAULT ''::text NOT NULL,
    started date NOT NULL,
    due date,
    budget cella.amount,
    archived date,
    CONSTRAINT project_id_check CHECK ((id ~ '^[a-z0-9]+(-[a-z0-9]+)*$'::text)),
    CONSTRAINT project_title_check CHECK ((title <> ''::text))
);


--
-- Name: runs(jsonb); Type: FUNCTION; Schema: circle_membership_project; Owner: -
--

CREATE FUNCTION circle_membership_project.runs(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (pr.id IS NULL) THEN NULL::text
             WHEN (NOT circle_membership.over(cella.actor(), w.power, COALESCE(pr.circle, ( SELECT c.id
                FROM circle.circle c
               WHERE (c.parent IS NULL))), cella.verdict_date())) THEN (((((cella.actor() || ' holds '::text) || COALESCE(w.power, 'no power'::text)) || ' over no circle that runs '::text) || pr.id) || COALESCE(((', '::text || pr.circle) || '''s'::text), ''::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (runs.payload ->> 'project'::text) AS project,
             ( SELECT p.power
                    FROM cella.power p
                   WHERE (p.op = cella.op())) AS power) w
      LEFT JOIN project.project pr ON ((pr.id = w.project)));
END;


--
-- Name: approves(jsonb); Type: FUNCTION; Schema: circle_membership_timesheet; Owner: -
--

CREATE FUNCTION circle_membership_timesheet.approves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((EXISTS ( SELECT
                FROM membership.member m
               WHERE ((m.address = w.member) AND (m.status = 'active'::text)))) AND (NOT (EXISTS ( SELECT
                FROM circle_membership."position" s
               WHERE ((s.member = w.member) AND ((s.since IS NULL) OR (s.since <= cella.verdict_date())) AND ((s.until IS NULL) OR (s.until > cella.verdict_date())) AND circle_membership.over(cella.actor(), w.power, s.circle, cella.verdict_date())))))) THEN (((((cella.actor() || ' holds '::text) || COALESCE(w.power, 'no power'::text)) || ' over no circle '::text) || COALESCE(w.member, 'no one'::text)) || ' sits in'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (approves.payload ->> 'member'::text) AS member,
             ( SELECT p.power
                    FROM cella.power p
                   WHERE (p.op = cella.op())) AS power) w;
END;


--
-- Name: client; Type: TABLE; Schema: client; Owner: -
--

CREATE TABLE client.client (
    id text NOT NULL,
    kind text DEFAULT 'company'::text NOT NULL,
    name text NOT NULL,
    form text,
    email text,
    phone text,
    address jsonb,
    parent text,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    CONSTRAINT client_check CHECK ((parent IS DISTINCT FROM id)),
    CONSTRAINT client_kind_check CHECK ((kind = ANY (ARRAY['company'::text, 'person'::text]))),
    CONSTRAINT client_status_check CHECK ((status = ANY (ARRAY['lead'::text, 'active'::text, 'inactive'::text, 'archived'::text])))
);


--
-- Name: erases(jsonb); Type: FUNCTION; Schema: client; Owner: -
--

CREATE FUNCTION client.erases(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (c.id IS NULL) THEN ('no client '::text || COALESCE(p.client, 'is named'::text))
             WHEN (c.kind <> 'person'::text) THEN (c.id || ' is a company: its data is not personal'::text)
             WHEN ((p.subject IS DISTINCT FROM c.id) OR (p.erased IS DISTINCT FROM '["contact"]'::jsonb)) THEN (('the erasure is not of '::text || c.id) || '''s contact data'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (erases.payload ->> 'client'::text) AS client,
             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,
             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased) p
      LEFT JOIN client.client c ON ((c.id = p.client)));
END;


--
-- Name: parent_is_company(); Type: FUNCTION; Schema: client; Owner: -
--

CREATE FUNCTION client.parent_is_company() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.parent IS NOT NULL AND NOT EXISTS (
    SELECT FROM client.client c WHERE c.id = NEW.parent AND c.kind = 'company'
  ) THEN
    RAISE EXCEPTION '% is no company, so % cannot be under it', NEW.parent, NEW.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: client_invoice; Owner: -
--

CREATE FUNCTION client_invoice.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM invoice.invoice i WHERE i.id = NEW.invoice) THEN
    RAISE EXCEPTION 'no invoice %', NEW.invoice USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM client.client c WHERE c.id = NEW.client) THEN
    RAISE EXCEPTION 'no client %', NEW.client USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: client_project; Owner: -
--

CREATE FUNCTION client_project.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM project.project p WHERE p.id = NEW.project) THEN
    RAISE EXCEPTION 'no project %', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM client.client c WHERE c.id = NEW.client) THEN
    RAISE EXCEPTION 'no client %', NEW.client USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: closes(jsonb); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.closes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || p.id)
             WHEN (d.closed IS DISTINCT FROM cella.verdict_date()) THEN (d.id || ' was not closed by this write'::text)
             WHEN (d.closed < d.deadline) THEN ((d.id || ' is open until '::text) || to_char((d.deadline)::timestamp with time zone, 'YYYY-MM-DD'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (closes.payload ->> 'decision'::text) AS id) p
      LEFT JOIN decision.decision d ON ((d.id = p.id)));
END;


--
-- Name: moved_with_proposal(); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.moved_with_proposal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM decision.decision d WHERE d.id = NEW.decision AND d.closed IS NOT NULL)
    OR EXISTS (SELECT FROM decision.vote v WHERE v.decision = NEW.decision) THEN
    RAISE EXCEPTION '% has stances or is closed: what it decides is fixed', NEW.decision
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: open_for_votes(); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.open_for_votes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM decision.decision d WHERE d.id = NEW.decision AND d.closed IS NOT NULL) THEN
    RAISE EXCEPTION '% is closed', NEW.decision
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: own_stance(jsonb); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.own_stance(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.member IS DISTINCT FROM cella.actor()) THEN ((cella.actor() || ' may not vote for '::text) || COALESCE(p.member, 'no one'::text))
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (own_stance.payload ->> 'member'::text) AS member) p;
END;


--
-- Name: message; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.message (
    receipt bigint NOT NULL,
    decision text NOT NULL,
    member text NOT NULL,
    reply bigint,
    body text NOT NULL,
    mentions text[] DEFAULT '{}'::text[] NOT NULL,
    links text[] DEFAULT '{}'::text[] NOT NULL,
    at date NOT NULL,
    CONSTRAINT message_body_check CHECK ((btrim(body) <> ''::text)),
    CONSTRAINT message_check CHECK ((reply < receipt))
);


--
-- Name: posts(jsonb); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.posts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.receipt IS NULL) THEN ('no message '::text || COALESCE(p.message, 'is named'::text))
             WHEN (m.member IS DISTINCT FROM cella.actor()) THEN ((cella.actor() || ' may not post as '::text) || m.member)
             WHEN ((m.decision IS DISTINCT FROM p.decision) OR (m.reply IS DISTINCT FROM p.reply) OR (m.mentions IS DISTINCT FROM ARRAY( SELECT jsonb_array_elements_text(COALESCE(p.mentions, '[]'::jsonb)) AS jsonb_array_elements_text)) OR (m.links IS DISTINCT FROM ARRAY( SELECT jsonb_array_elements_text(COALESCE(p.links, '[]'::jsonb)) AS jsonb_array_elements_text))) THEN (('message '::text || m.receipt) || ' was posted otherwise than its payload names'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (posts.payload ->> 'message'::text) AS message,
             (posts.payload ->> 'decision'::text) AS decision,
             ((posts.payload ->> 'reply'::text))::bigint AS reply,
             (posts.payload -> 'mentions'::text) AS mentions,
             (posts.payload -> 'links'::text) AS links) p
      LEFT JOIN decision.message m ON (((m.receipt)::text = p.message)));
END;


--
-- Name: procedure_kept(); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.procedure_kept() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM decision.decision d WHERE d.procedure = OLD.id) THEN
    RAISE EXCEPTION 'decisions are taken by %: its terms are fixed', OLD.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: proposes(jsonb); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.proposes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.id, 'is named'::text))
             WHEN ((d.proposed IS DISTINCT FROM cella.verdict_date()) OR (d.closed IS NOT NULL)) THEN (d.id || ' was not proposed by this write'::text)
             WHEN (d.deadline <= d.proposed) THEN ((d.id || '''s deadline must come after '::text) || to_char((d.proposed)::timestamp with time zone, 'YYYY-MM-DD'::text))
             WHEN (( SELECT count(*) AS count
                FROM decision.motion m
               WHERE (m.decision = d.id)) <> jsonb_array_length(COALESCE(p.motions, '[]'::jsonb))) THEN (d.id || ' decides otherwise than its payload names'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (proposes.payload ->> 'decision'::text) AS id,
             (proposes.payload -> 'motions'::text) AS motions) p
      LEFT JOIN decision.decision d ON ((d.id = p.id)));
END;


--
-- Name: stays_closed(); Type: FUNCTION; Schema: decision; Owner: -
--

CREATE FUNCTION decision.stays_closed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.closed IS NOT NULL THEN
    RAISE EXCEPTION '% closed on %', OLD.id, OLD.closed
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: adoption; Type: TABLE; Schema: decision_document; Owner: -
--

CREATE TABLE decision_document.adoption (
    decision text NOT NULL,
    document text NOT NULL,
    version text NOT NULL,
    hash bytea NOT NULL,
    CONSTRAINT adoption_hash_check CHECK ((length(hash) = 32))
);


--
-- Name: version; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.version (
    id text NOT NULL,
    document text NOT NULL,
    n integer NOT NULL,
    saved date NOT NULL,
    snapshot bytea NOT NULL,
    canonical text GENERATED ALWAYS AS (cella.document_canonical(snapshot)) STORED NOT NULL,
    hash bytea GENERATED ALWAYS AS (cella.document_hash(snapshot)) STORED NOT NULL,
    plain text GENERATED ALWAYS AS (cella.document_text(snapshot)) STORED NOT NULL,
    frontier jsonb NOT NULL,
    vv jsonb NOT NULL,
    CONSTRAINT version_check CHECK ((id = ((document || '@'::text) || n))),
    CONSTRAINT version_n_check CHECK ((n > 0))
);


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: decision_document; Owner: -
--

CREATE FUNCTION decision_document.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (a.decision IS NULL) THEN ((d.id || ' does not adopt '::text) || COALESCE(p.document, 'a document'::text))
             WHEN (v.id IS NULL) THEN ((p.document || ' has no version '::text) || COALESCE(p.version, 'named'::text))
             WHEN (v.hash <> a.hash) THEN ((((((((d.id || ' adopts '::text) || a.document) || ' as '::text) || "left"(encode(a.hash, 'hex'::text), 12)) || ', not '::text) || v.id) || ', which hashes '::text) || "left"(encode(v.hash, 'hex'::text), 12))
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT (adopts.payload ->> 'decision'::text) AS decision,
             (adopts.payload ->> 'document'::text) AS document,
             (adopts.payload ->> 'version'::text) AS version) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)))
      LEFT JOIN decision_document.adoption a ON (((a.decision = d.id) AND (a.document = p.document))))
      LEFT JOIN document.version v ON (((v.id = p.version) AND (v.document = p.document))));
END;


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: decision_document; Owner: -
--

CREATE FUNCTION decision_document.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (v.id IS NULL) THEN (('no version '::text || COALESCE((m.args ->> 'version'::text), 'is named'::text)) || ' to adopt'::text)
                     WHEN ((a.decision IS NULL) OR (a.hash <> v.hash)) THEN (((m.decision || ' does not adopt '::text) || v.id) || ' as it hashes'::text)
                     ELSE NULL::text
                 END AS r
            FROM ((decision.motion m
              LEFT JOIN document.version v ON ((v.id = (m.args ->> 'version'::text))))
              LEFT JOIN decision_document.adoption a ON (((a.decision = m.decision) AND (a.document = v.document) AND (a.version = v.id))))
           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'adopt'::text))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: document; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.document (
    id text NOT NULL,
    title text NOT NULL
);


--
-- Name: linked(text); Type: FUNCTION; Schema: decision_document; Owner: -
--

CREATE FUNCTION decision_document.linked(ref text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(( SELECT d.id
            FROM document.document d
           WHERE (d.id = lower(linked.ref))), ( SELECT v.document
            FROM document.version v
           WHERE (v.id = lower(linked.ref)))) AS "coalesce";
END;


--
-- Name: links(jsonb); Type: FUNCTION; Schema: decision_document; Owner: -
--

CREATE FUNCTION decision_document.links(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (('[['::text || l.ref) || ']] names no document'::text)
    FROM jsonb_array_elements_text(COALESCE((links.payload -> 'links'::text), '[]'::jsonb)) l(ref)
   WHERE (decision_document.linked(l.ref) IS NULL)
  LIMIT 1;
END;


--
-- Name: moved(); Type: FUNCTION; Schema: decision_document; Owner: -
--

CREATE FUNCTION decision_document.moved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind <> 'adopt' THEN
    RETURN NEW;
  END IF;
  INSERT INTO decision_document.adoption (decision, document, version, hash)
  SELECT NEW.decision, v.document, v.id, v.hash FROM document.version v WHERE v.id = NEW.args ->> 'version';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no version %', coalesce(NEW.args ->> 'version', 'is named')
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: decision_meeting; Owner: -
--

CREATE FUNCTION decision_meeting.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM meeting.item i WHERE i.id = NEW.item AND i.meeting = NEW.meeting) THEN
    RAISE EXCEPTION '% has no item %', NEW.meeting, NEW.item USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM decision.decision d WHERE d.id = NEW.decision) THEN
    RAISE EXCEPTION 'no decision %', NEW.decision USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: admits(jsonb); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.admits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM decision_membership.motion m
               WHERE ((m.decision = d.id) AND (m.kind = 'admit'::text) AND (m.member = p.member) AND (m.shares = p.shares))))) THEN (((d.id || ' does not admit '::text) || p.member) || COALESCE(((' with '::text || p.shares) || ' shares'::text), ''::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (admits.payload ->> 'decision'::text) AS decision,
             (admits.payload ->> 'member'::text) AS member,
             ((admits.payload ->> 'shares'::text))::integer AS shares) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (m.member IS NULL) THEN ((m.decision || ' names no member to '::text) || m.kind)
                     WHEN (mm.address IS NULL) THEN ('no member '::text || m.member)
                     WHEN ((m.kind = 'admit'::text) AND (mm.status <> 'invited'::text)) THEN (((m.member || ' is '::text) || mm.status) || ', not invited'::text)
                     WHEN ((m.kind = 'admit'::text) AND (COALESCE(m.shares, 0) <= 0)) THEN 'an admission subscribes a whole number of shares'::text
                     WHEN ((m.kind = 'suspend'::text) AND (mm.status <> 'active'::text)) THEN (((m.member || ' is '::text) || mm.status) || ', not active'::text)
                     WHEN ((m.kind = 'exit'::text) AND (mm.status <> ALL (ARRAY['active'::text, 'suspended'::text]))) THEN ((m.member || ' is '::text) || mm.status)
                     WHEN ((m.kind = 'erase'::text) AND (mm.status <> 'exited'::text)) THEN (((m.member || ' is '::text) || mm.status) || ': only a member who has left is erased'::text)
                     ELSE NULL::text
                 END AS r
            FROM (decision_membership.motion m
              LEFT JOIN membership.member mm ON ((mm.address = m.member)))
           WHERE (m.decision = (asks.payload ->> 'decision'::text))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: admitted(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.admitted(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no member '::text || p.address)
             WHEN (m.status <> 'active'::text) THEN ((m.address || ' is '::text) || m.status)
             WHEN (m.since IS DISTINCT FROM cella.verdict_date()) THEN (m.address || ' was not admitted by this write'::text)
             WHEN (m.shares = 0) THEN (m.address || ' holds no shares'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (admitted.payload ->> 'member'::text) AS address) p
      LEFT JOIN membership.member m ON ((m.address = p.address)));
END;


--
-- Name: closes(jsonb); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.closes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (m.member IS NULL) THEN (((closes.payload ->> 'decision'::text) || ' does not admit '::text) || a.member)
                     WHEN (mm.shares IS DISTINCT FROM m.shares) THEN ((((a.member || ' holds '::text) || COALESCE(mm.shares, 0)) || ' shares, not '::text) || m.shares)
                     ELSE membership.admitted(jsonb_build_object('member', a.member))
                 END AS r
            FROM ((jsonb_to_recordset(COALESCE((closes.payload -> 'admitted'::text), '[]'::jsonb)) a(member text)
              LEFT JOIN decision_membership.motion m ON (((m.decision = (closes.payload ->> 'decision'::text)) AND (m.kind = 'admit'::text) AND (m.member = a.member))))
              LEFT JOIN membership.member mm ON ((mm.address = a.member)))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: ends(jsonb); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.ends(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM decision_membership.motion m
               WHERE ((m.decision = d.id) AND (m.kind = split_part(cella.op(), ':'::text, 3)) AND (m.member = p.member))))) THEN ((((d.id || ' does not '::text) || split_part(cella.op(), ':'::text, 3)) || ' '::text) || COALESCE(p.member, 'anyone'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (ends.payload ->> 'decision'::text) AS decision,
             (ends.payload ->> 'member'::text) AS member) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: named(text); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.named(handle text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (count(*) = 1) THEN min(m.address)
             ELSE NULL::text
         END AS "case"
    FROM membership.member m
   WHERE ((m.address = lower(named.handle)) OR ((strpos(named.handle, '@'::text) = 0) AND (split_part(m.address, '@'::text, 1) = lower(named.handle))));
END;


--
-- Name: mentions(jsonb); Type: FUNCTION; Schema: decision_membership; Owner: -
--

CREATE FUNCTION decision_membership.mentions(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (('@'::text || h.handle) || ' names no one member'::text)
    FROM jsonb_array_elements_text(COALESCE((mentions.payload -> 'mentions'::text), '[]'::jsonb)) h(handle)
   WHERE (decision_membership.named(h.handle) IS NULL)
  LIMIT 1;
END;


--
-- Name: adoption; Type: TABLE; Schema: decision_patronage; Owner: -
--

CREATE TABLE decision_patronage.adoption (
    terms text NOT NULL,
    decision text NOT NULL
);


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: decision_patronage; Owner: -
--

CREATE FUNCTION decision_patronage.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM decision_patronage.adoption a
               WHERE ((a.terms = p.terms) AND (a.decision = d.id))))) THEN ((d.id || ' does not adopt '::text) || COALESCE(p.terms, 'these terms'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (adopts.payload ->> 'decision'::text) AS decision,
             (adopts.payload ->> 'terms'::text) AS terms) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)));
END;


--
-- Name: approval; Type: TABLE; Schema: decision_patronage; Owner: -
--

CREATE TABLE decision_patronage.approval (
    distribution text NOT NULL,
    decision text NOT NULL
);


--
-- Name: approves(jsonb); Type: FUNCTION; Schema: decision_patronage; Owner: -
--

CREATE FUNCTION decision_patronage.approves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))
             WHEN (a.decision IS DISTINCT FROM d.id) THEN ((d.id || ' does not approve '::text) || COALESCE(p.distribution, 'a distribution'::text))
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (approves.payload ->> 'decision'::text) AS decision,
             (approves.payload ->> 'distribution'::text) AS distribution) p
      LEFT JOIN decision.decision d ON ((d.id = p.decision)))
      LEFT JOIN decision_patronage.approval a ON ((a.distribution = p.distribution)));
END;


--
-- Name: asks(jsonb); Type: FUNCTION; Schema: decision_patronage; Owner: -
--

CREATE FUNCTION decision_patronage.asks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.r
    FROM ( SELECT
                 CASE
                     WHEN (t.id IS NULL) THEN (('no terms '::text || COALESCE((m.args ->> 'terms'::text), 'are named'::text)) || ' to adopt'::text)
                     WHEN (t.adopted IS NOT NULL) THEN ((t.id || ' were adopted on '::text) || to_char((t.adopted)::timestamp with time zone, 'YYYY-MM-DD'::text))
                     WHEN (a.decision IS NULL) THEN ((m.decision || ' does not ask to adopt '::text) || t.id)
                     ELSE NULL::text
                 END AS r
            FROM ((decision.motion m
              LEFT JOIN patronage.terms t ON ((t.id = (m.args ->> 'terms'::text))))
              LEFT JOIN decision_patronage.adoption a ON (((a.decision = m.decision) AND (a.terms = t.id))))
           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'patronage'::text))) x
   WHERE (x.r IS NOT NULL)
  LIMIT 1;
END;


--
-- Name: moved(); Type: FUNCTION; Schema: decision_patronage; Owner: -
--

CREATE FUNCTION decision_patronage.moved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.kind <> 'patronage' THEN
    RETURN NEW;
  END IF;
  INSERT INTO decision_patronage.adoption (terms, decision)
  SELECT t.id, NEW.decision FROM patronage.terms t WHERE t.id = NEW.args ->> 'terms' AND t.adopted IS NULL;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no terms % to adopt', coalesce(NEW.args ->> 'terms', 'are named')
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: adoption; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.adoption (
    receipt bigint NOT NULL,
    document text NOT NULL,
    version text NOT NULL,
    base text,
    adopted date NOT NULL
);


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: document; Owner: -
--

CREATE FUNCTION document.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (a.receipt IS NULL) THEN ('no adoption at receipt '::text || COALESCE((p.receipt)::text, 'none'::text))
             WHEN ((a.document IS DISTINCT FROM p.document) OR (a.version IS DISTINCT FROM p.version)) THEN (('the adoption at receipt '::text || a.receipt) || ' is not this write''s'::text)
             WHEN (v.id IS NULL) THEN ((a.document || ' has no version '::text) || a.version)
             WHEN (latest.version IS DISTINCT FROM a.base) THEN ((((a.document || ' moved: its adopted version is '::text) || COALESCE(latest.version, 'none'::text)) || ', not '::text) || COALESCE(a.base, 'none'::text))
             WHEN (v.n <= latest.n) THEN ((a.version || ' is not later than '::text) || latest.version)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT ((adopts.payload ->> 'receipt'::text))::bigint AS receipt,
             (adopts.payload ->> 'document'::text) AS document,
             (adopts.payload ->> 'version'::text) AS version) p
      LEFT JOIN document.adoption a ON ((a.receipt = p.receipt)))
      LEFT JOIN document.version v ON (((v.id = a.version) AND (v.document = a.document))))
      LEFT JOIN LATERAL ( SELECT b.version,
             bv.n
            FROM (document.adoption b
              JOIN document.version bv ON ((bv.id = b.version)))
           WHERE ((b.document = a.document) AND (b.receipt < a.receipt))
           ORDER BY b.receipt DESC
          LIMIT 1) latest ON (true));
END;


--
-- Name: numbers(); Type: FUNCTION; Schema: document; Owner: -
--

CREATE FUNCTION document.numbers() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
BEGIN
  PERFORM FROM document.document d WHERE d.id = NEW.document FOR UPDATE;
  IF NEW.n IS NULL THEN
    SELECT coalesce(max(v.n), 0) + 1 INTO NEW.n FROM document.version v WHERE v.document = NEW.document;
  END IF;
  NEW.id := NEW.document || '@' || NEW.n;
  RETURN NEW;
END
$$;


--
-- Name: permanent(); Type: FUNCTION; Schema: document; Owner: -
--

CREATE FUNCTION document.permanent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'a document''s % never changes', TG_TABLE_NAME
    USING ERRCODE = 'triggered_action_exception';
END
$$;


--
-- Name: quotes(); Type: FUNCTION; Schema: document; Owner: -
--

CREATE FUNCTION document.quotes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM document.version v WHERE v.id = NEW.version AND strpos(v.plain, NEW.quote) > 0) THEN
    RAISE EXCEPTION '% does not hold the quoted text', NEW.version
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: minutes; Type: TABLE; Schema: document_meeting; Owner: -
--

CREATE TABLE document_meeting.minutes (
    meeting text NOT NULL,
    document text NOT NULL
);


--
-- Name: keeps(jsonb); Type: FUNCTION; Schema: document_meeting; Owner: -
--

CREATE FUNCTION document_meeting.keeps(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((w.document IS NOT NULL) AND (n.document IS DISTINCT FROM w.document)) THEN ((COALESCE(w.meeting, 'no meeting'::text) || '''s minutes are not '::text) || w.document)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (keeps.payload ->> 'meeting'::text) AS meeting,
             (keeps.payload ->> 'document'::text) AS document) w
      LEFT JOIN document_meeting.minutes n ON ((n.meeting = w.meeting)));
END;


--
-- Name: resolves(); Type: FUNCTION; Schema: document_meeting; Owner: -
--

CREATE FUNCTION document_meeting.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM meeting.meeting m WHERE m.id = NEW.meeting) THEN
    RAISE EXCEPTION 'no meeting %', NEW.meeting USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM document.document d WHERE d.id = NEW.document) THEN
    RAISE EXCEPTION 'no document %', NEW.document USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: reading; Type: TABLE; Schema: document_membership; Owner: -
--

CREATE TABLE document_membership.reading (
    version text NOT NULL,
    member text NOT NULL,
    read date NOT NULL
);


--
-- Name: reads(jsonb); Type: FUNCTION; Schema: document_membership; Owner: -
--

CREATE FUNCTION document_membership.reads(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.member IS DISTINCT FROM cella.actor()) THEN (COALESCE(cella.actor(), 'no one'::text) || ' may mark only their own reading'::text)
             WHEN (NOT (EXISTS ( SELECT
                FROM document.version v
               WHERE (v.id = p.version)))) THEN ('no version '::text || COALESCE(p.version, 'is named'::text))
             WHEN (NOT (EXISTS ( SELECT
                FROM document_membership.reading r
               WHERE ((r.version = p.version) AND (r.member = p.member) AND (r.read = cella.verdict_date()))))) THEN (((p.member || '''s reading of '::text) || p.version) || ' was not marked by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (reads.payload ->> 'member'::text) AS member,
             (reads.payload ->> 'version'::text) AS version) p;
END;


--
-- Name: device; Type: TABLE; Schema: person; Owner: -
--

CREATE TABLE person.device (
    key bytea NOT NULL,
    address text NOT NULL,
    label text NOT NULL,
    enrolled date NOT NULL,
    enrolled_by bytea,
    revoked date,
    CONSTRAINT device_check CHECK (((revoked IS NULL) OR (revoked >= enrolled))),
    CONSTRAINT device_key_check CHECK ((length(key) = 32))
);


--
-- Name: COLUMN device.address; Type: COMMENT; Schema: person; Owner: -
--

COMMENT ON COLUMN person.device.address IS 'not personal: the holder''s pseudonymous address';


--
-- Name: carries(jsonb); Type: FUNCTION; Schema: employment; Owner: -
--

CREATE FUNCTION employment.carries(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.key IS NULL) THEN (COALESCE(p.worker, 'no one'::text) || ' is hired with no first device'::text)
             WHEN (NOT (EXISTS ( SELECT
                FROM person.device d
               WHERE ((encode(d.key, 'hex'::text) = p.key) AND (d.address = p.worker) AND (d.enrolled = cella.verdict_date()) AND (d.enrolled_by IS NULL))))) THEN (p.worker || '''s first device was not enrolled by this hire'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (carries.payload ->> 'worker'::text) AS worker,
             (carries.payload ->> 'key'::text) AS key) p;
END;


--
-- Name: worker; Type: TABLE; Schema: employment; Owner: -
--

CREATE TABLE employment.worker (
    address text NOT NULL,
    name text,
    job text NOT NULL,
    contract text NOT NULL,
    start date NOT NULL,
    until date,
    minutes integer NOT NULL,
    hired date NOT NULL,
    CONSTRAINT worker_check CHECK (((until IS NULL) OR (until >= start))),
    CONSTRAINT worker_check1 CHECK (((contract = 'permanent'::text) OR (until IS NOT NULL))),
    CONSTRAINT worker_contract_check CHECK ((contract = ANY (ARRAY['permanent'::text, 'fixed-term'::text, 'apprenticeship'::text]))),
    CONSTRAINT worker_job_check CHECK ((job <> ''::text)),
    CONSTRAINT worker_minutes_check CHECK (((minutes > 0) AND (minutes <= (48 * 60))))
);


--
-- Name: COLUMN worker.address; Type: COMMENT; Schema: employment; Owner: -
--

COMMENT ON COLUMN employment.worker.address IS 'not personal: the pseudonymous address every log entry names the worker by';


--
-- Name: employed(text, date); Type: FUNCTION; Schema: employment; Owner: -
--

CREATE FUNCTION employment.employed(address text, day date) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (EXISTS ( SELECT
            FROM employment.worker w
           WHERE ((w.address = employed.address) AND (w.start <= employed.day) AND ((w.until IS NULL) OR (w.until >= employed.day))))) AS "exists";
END;


--
-- Name: employed_in(text, text); Type: FUNCTION; Schema: employment; Owner: -
--

CREATE FUNCTION employment.employed_in(address text, month text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT (EXISTS ( SELECT
            FROM employment.worker w
           WHERE ((w.address = employed_in.address) AND (w.start < ((to_date((employed_in.month || '-01'::text), 'YYYY-MM-DD'::text) + '1 mon'::interval))::date) AND ((w.until IS NULL) OR (w.until >= to_date((employed_in.month || '-01'::text), 'YYYY-MM-DD'::text)))))) AS "exists";
END;


--
-- Name: hires(jsonb); Type: FUNCTION; Schema: employment; Owner: -
--

CREATE FUNCTION employment.hires(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((w.address IS NULL) OR (w.hired IS DISTINCT FROM cella.verdict_date())) THEN (COALESCE(p.worker, 'no one'::text) || ' was not hired by this write'::text)
             WHEN ((((w.contract IS DISTINCT FROM p.contract) OR (w.start IS DISTINCT FROM p.start)) OR (w.until IS DISTINCT FROM p.until)) OR (w.minutes IS DISTINCT FROM p.minutes)) THEN (w.address || '''s contract is not what the write names'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (hires.payload ->> 'worker'::text) AS worker,
             (hires.payload ->> 'contract'::text) AS contract,
             ((hires.payload ->> 'start'::text))::date AS start,
             ((hires.payload ->> 'until'::text))::date AS until,
             ((hires.payload ->> 'minutes'::text))::integer AS minutes) p
      LEFT JOIN employment.worker w ON ((w.address = p.worker)));
END;


--
-- Name: stored(text, text, text); Type: FUNCTION; Schema: file; Owner: -
--

CREATE FUNCTION file.stored(id text, class text, subject text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (f.id IS NULL) THEN ('no file '::text || COALESCE(x.id, 'is named'::text))
             WHEN ((f.uploader IS DISTINCT FROM cella.actor()) OR (f.uploaded IS DISTINCT FROM cella.verdict_date())) THEN (f.id || ' was not uploaded by this write'::text)
             WHEN (f.class IS DISTINCT FROM x.class) THEN ((((f.id || ' is of class '::text) || f.class) || ', not '::text) || COALESCE(x.class, 'none named'::text))
             WHEN (f.subject IS DISTINCT FROM x.subject) THEN ((((f.id || ' concerns '::text) || COALESCE(f.subject, 'no one'::text)) || ', not '::text) || COALESCE(x.subject, 'no one'::text))
             WHEN (f.bytes IS NULL) THEN (f.id || ' holds nothing'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT stored.id AS id,
             stored.class AS class,
             stored.subject AS subject) x
      LEFT JOIN file.file f ON ((f.id = x.id)));
END;


--
-- Name: record; Type: TABLE; Schema: employment_file; Owner: -
--

CREATE TABLE employment_file.record (
    worker text NOT NULL,
    file text NOT NULL
);


--
-- Name: files(jsonb); Type: FUNCTION; Schema: employment_file; Owner: -
--

CREATE FUNCTION employment_file.files(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (w.address IS NULL) THEN ('no worker '::text || COALESCE(x.worker, 'is named'::text))
             WHEN (r.file IS NULL) THEN (((COALESCE(x.file, 'no file'::text) || ' is not on '::text) || w.address) || '''s file'::text)
             ELSE file.stored(x.file, 'payroll'::text, w.address)
         END AS stored
    FROM ((( SELECT (files.payload ->> 'worker'::text) AS worker,
             (files.payload ->> 'file'::text) AS file) x
      LEFT JOIN employment.worker w ON ((w.address = x.worker)))
      LEFT JOIN employment_file.record r ON (((r.worker = x.worker) AND (r.file = x.file))));
END;


--
-- Name: candidacy; Type: TABLE; Schema: employment_membership; Owner: -
--

CREATE TABLE employment_membership.candidacy (
    worker text NOT NULL,
    "from" date NOT NULL,
    "to" date NOT NULL,
    shares integer NOT NULL,
    opened date NOT NULL,
    CONSTRAINT candidacy_check CHECK (("to" >= "from")),
    CONSTRAINT candidacy_shares_check CHECK ((shares > 0))
);


--
-- Name: opens(jsonb); Type: FUNCTION; Schema: employment_membership; Owner: -
--

CREATE FUNCTION employment_membership.opens(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (w.address IS NULL) THEN (COALESCE(p.worker, 'no one'::text) || ' is no worker: a candidate is one'::text)
             WHEN (m.status = ANY (ARRAY['active'::text, 'suspended'::text, 'exited'::text])) THEN (((w.address || ' is '::text) || m.status) || ' as a member: a candidate is not yet one'::text)
             WHEN ((c.worker IS NULL) OR (c.opened IS DISTINCT FROM cella.verdict_date())) THEN (w.address || '''s candidacy was not opened by this write'::text)
             WHEN (((c."from" IS DISTINCT FROM p."from") OR (c."to" IS DISTINCT FROM p."to")) OR (c.shares IS DISTINCT FROM p.shares)) THEN (w.address || '''s candidacy is not what the write names'::text)
             WHEN (c."from" < w.start) THEN ((((w.address || '''s probation starts on '::text) || (c."from")::text) || ', before their hire on '::text) || (w.start)::text)
             WHEN ((w.until IS NOT NULL) AND (c."to" > w.until)) THEN ((((w.address || '''s probation ends on '::text) || (c."to")::text) || ', after their contract does on '::text) || (w.until)::text)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT (opens.payload ->> 'worker'::text) AS worker,
             ((opens.payload ->> 'from'::text))::date AS "from",
             ((opens.payload ->> 'to'::text))::date AS "to",
             ((opens.payload ->> 'shares'::text))::integer AS shares) p
      LEFT JOIN employment.worker w ON ((w.address = p.worker)))
      LEFT JOIN membership.member m ON ((m.address = p.worker)))
      LEFT JOIN employment_membership.candidacy c ON ((c.worker = p.worker)));
END;


--
-- Name: whose(); Type: FUNCTION; Schema: employment_payslip; Owner: -
--

CREATE FUNCTION employment_payslip.whose() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'salary' THEN
    IF NOT EXISTS (SELECT FROM employment.worker w WHERE w.address = NEW.member) THEN
      RAISE EXCEPTION '% is no worker: a salary is one''s', NEW.member
        USING ERRCODE = 'triggered_action_exception';
    END IF;
  ELSIF NOT employment.employed_in(NEW.member, NEW.month) THEN
    RAISE EXCEPTION '% is employed in no day of %: a payslip is a worker''s for a month they worked', NEW.member, NEW.month
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: whose(); Type: FUNCTION; Schema: employment_timesheet; Owner: -
--

CREATE FUNCTION employment_timesheet.whose() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM employment.worker w WHERE w.address = NEW.member) AND NOT employment.employed(NEW.member, NEW.day) THEN
    RAISE EXCEPTION '% is not employed on %: a worker logs time while employed', NEW.member, NEW.day
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: works(jsonb); Type: FUNCTION; Schema: employment_timesheet; Owner: -
--

CREATE FUNCTION employment_timesheet.works(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (NOT (EXISTS ( SELECT
                FROM employment.worker w
               WHERE (w.address = cella.actor())))) THEN (COALESCE(cella.actor(), 'no one'::text) || ' is no worker: a worker logs their time by their employment'::text)
             WHEN ((p.day IS NOT NULL) AND (NOT employment.employed(cella.actor(), p.day))) THEN ((cella.actor() || ' is not employed on '::text) || (p.day)::text)
             WHEN ((p.month IS NOT NULL) AND (NOT employment.employed_in(cella.actor(), p.month))) THEN ((cella.actor() || ' is employed in no day of '::text) || p.month)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT ((works.payload ->> 'day'::text))::date AS day,
             (works.payload ->> 'month'::text) AS month) p;
END;


--
-- Name: captures(jsonb); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.captures(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN ((COALESCE(cella.actor(), 'no one'::text) || ' may not claim an expense for '::text) || e.member)
             WHEN (e.day > cella.verdict_date()) THEN (('an expense on '::text || (e.day)::text) || ' is in the future'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (captures.payload ->> 'expense'::text) AS expense) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)));
END;


--
-- Name: decides(jsonb); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.decides(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN ((e.status <> x.status) OR (e.decided IS DISTINCT FROM cella.verdict_date()) OR (e.decider IS DISTINCT FROM cella.actor())) THEN (((e.id || ' was not '::text) || x.status) || ' by this write'::text)
             WHEN (e.decider = e.member) THEN (e.member || ' may not decide their own expense'::text)
             WHEN (x.amount IS DISTINCT FROM expense.total(e.*)) THEN ((((e.id || ' comes to '::text) || expense.total(e.*)) || ' cents, not '::text) || COALESCE((x.amount)::text, 'no amount'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (decides.payload ->> 'expense'::text) AS expense,
             ((decides.payload ->> 'amount'::text))::bigint AS amount,
                 CASE cella.op()
                     WHEN 'expense:expense:refuse'::text THEN 'refused'::text
                     ELSE 'approved'::text
                 END AS status) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)));
END;


--
-- Name: moves(); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.moves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF cella.redacting() THEN
    RETURN NEW;
  END IF;
  IF NEW.status <> OLD.status AND (OLD.status, NEW.status) NOT IN (
    ('draft', 'submitted'), ('submitted', 'approved'), ('submitted', 'refused'), ('approved', 'reimbursed')
  ) THEN
    RAISE EXCEPTION '% is %, and cannot become %', OLD.id, OLD.status, NEW.status
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.status <> 'draft' AND (expense.total(NEW), cella.cents(NEW.vat), NEW.category, NEW.day, NEW.member)
    IS DISTINCT FROM (expense.total(OLD), cella.cents(OLD.vat), OLD.category, OLD.day, OLD.member) THEN
    RAISE EXCEPTION '% was submitted: its figures never change', OLD.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  -- Each step is taken once: a second approval, refusal or reimbursement
  -- of the same expense is refused.
  IF NEW.status = OLD.status AND OLD.status <> 'draft' THEN
    RAISE EXCEPTION '% is % already', OLD.id, OLD.status
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: reimburses(jsonb); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.reimburses(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN ((e.status <> 'reimbursed'::text) OR (e.reimbursed IS DISTINCT FROM cella.verdict_date())) THEN (e.id || ' was not reimbursed by this write'::text)
             WHEN (x.amount IS DISTINCT FROM expense.total(e.*)) THEN ((((e.id || ' comes to '::text) || expense.total(e.*)) || ' cents, not '::text) || COALESCE((x.amount)::text, 'no amount'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (reimburses.payload ->> 'expense'::text) AS expense,
             ((reimburses.payload ->> 'amount'::text))::bigint AS amount) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)));
END;


--
-- Name: submits(jsonb); Type: FUNCTION; Schema: expense; Owner: -
--

CREATE FUNCTION expense.submits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may not submit '::text) || e.member) || '''s expense'::text)
             WHEN ((e.status <> 'submitted'::text) OR (e.submitted IS DISTINCT FROM cella.verdict_date())) THEN (e.id || ' was not submitted by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (submits.payload ->> 'expense'::text) AS expense) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)));
END;


--
-- Name: receipt; Type: TABLE; Schema: expense_file; Owner: -
--

CREATE TABLE expense_file.receipt (
    expense text NOT NULL,
    file text NOT NULL
);


--
-- Name: attaches(jsonb); Type: FUNCTION; Schema: expense_file; Owner: -
--

CREATE FUNCTION expense_file.attaches(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((x.file IS NULL) AND (cella.op() = 'expense:expense:capture'::text)) THEN NULL::text
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may not attach a receipt to '::text) || e.member) || '''s expense'::text)
             WHEN (e.status = ANY (ARRAY['refused'::text, 'reimbursed'::text])) THEN ((e.id || ' is '::text) || e.status)
             WHEN (r.file IS NULL) THEN ((COALESCE(x.file, 'no file'::text) || ' is not attached to '::text) || e.id)
             ELSE file.stored(x.file, 'expense-receipt'::text, e.member)
         END AS stored
    FROM ((( SELECT (attaches.payload ->> 'expense'::text) AS expense,
             (attaches.payload ->> 'file'::text) AS file) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)))
      LEFT JOIN expense_file.receipt r ON (((r.expense = x.expense) AND (r.file = x.file))));
END;


--
-- Name: elapsed(date, date, date, boolean, date); Type: FUNCTION; Schema: project_timesheet; Owner: -
--

CREATE FUNCTION project_timesheet.elapsed(started date, due date, archived date, done boolean, day date) RETURNS numeric
    LANGUAGE sql IMMUTABLE
    RETURN CASE WHEN ((archived IS NOT NULL) OR done) THEN (1)::numeric WHEN (due IS NULL) THEN NULL::numeric WHEN (day >= due) THEN (1)::numeric WHEN (day <= started) THEN (0)::numeric ELSE round((((day - started))::numeric / (GREATEST((due - started), 1))::numeric), 4) END;


--
-- Name: milestone; Type: TABLE; Schema: project; Owner: -
--

CREATE TABLE project.milestone (
    project text NOT NULL,
    n integer NOT NULL,
    title text NOT NULL,
    due date,
    completed date,
    CONSTRAINT milestone_n_check CHECK ((n > 0)),
    CONSTRAINT milestone_title_check CHECK ((title <> ''::text))
);


--
-- Name: progress; Type: VIEW; Schema: project; Owner: -
--

CREATE VIEW project.progress AS
 SELECT p.id,
    (count(m.n))::integer AS milestones,
    (count(m.n) FILTER (WHERE (m.completed IS NOT NULL)))::integer AS completed,
    ( SELECT m2.title
           FROM project.milestone m2
          WHERE ((m2.project = p.id) AND (m2.completed IS NULL))
          ORDER BY m2.n
         LIMIT 1) AS next
   FROM (project.project p
     LEFT JOIN project.milestone m ON ((m.project = p.id)))
  GROUP BY p.id;


--
-- Name: booking; Type: TABLE; Schema: project_timesheet; Owner: -
--

CREATE TABLE project_timesheet.booking (
    entry bigint NOT NULL,
    project text NOT NULL
);


--
-- Name: cost; Type: TABLE; Schema: project_timesheet; Owner: -
--

CREATE TABLE project_timesheet.cost (
    since date NOT NULL,
    hourly cella.amount NOT NULL
);


--
-- Name: rate; Type: TABLE; Schema: project_timesheet; Owner: -
--

CREATE TABLE project_timesheet.rate (
    since date NOT NULL,
    hourly cella.amount NOT NULL
);


--
-- Name: entry; Type: TABLE; Schema: timesheet; Owner: -
--

CREATE TABLE timesheet.entry (
    id bigint NOT NULL,
    member text NOT NULL,
    day date NOT NULL,
    minutes integer NOT NULL,
    billable boolean DEFAULT true NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    CONSTRAINT entry_minutes_check CHECK (((minutes > 0) AND (minutes <= 1440)))
);


--
-- Name: COLUMN entry.note; Type: COMMENT; Schema: timesheet; Owner: -
--

COMMENT ON COLUMN timesheet.entry.note IS 'not personal: what the time was spent on, a work record';


--
-- Name: costed; Type: VIEW; Schema: project_timesheet; Owner: -
--

CREATE VIEW project_timesheet.costed WITH (security_invoker='true') AS
 SELECT b.project,
    e.id AS entry,
    e.member,
    e.day,
    ((e.minutes)::numeric / 60.0) AS hours,
    e.billable,
    ( SELECT cella.cents(r.hourly) AS cents
           FROM project_timesheet.rate r
          WHERE (r.since <= e.day)
          ORDER BY r.since DESC
         LIMIT 1) AS hourly,
    ( SELECT cella.cents(c.hourly) AS cents
           FROM project_timesheet.cost c
          WHERE (c.since <= e.day)
          ORDER BY c.since DESC
         LIMIT 1) AS cost
   FROM (project_timesheet.booking b
     JOIN timesheet.entry e ON ((e.id = b.entry)));


--
-- Name: burn; Type: VIEW; Schema: project_timesheet; Owner: -
--

CREATE VIEW project_timesheet.burn AS
 SELECT project,
    (sum(hours))::numeric(8,2) AS hours,
    (COALESCE(sum(hours) FILTER (WHERE billable), (0)::numeric))::numeric(8,2) AS billable,
    (COALESCE(round(sum((hours * (hourly)::numeric)) FILTER (WHERE billable)), (0)::numeric))::bigint AS spent,
    (COALESCE(round(sum((hours * (cost)::numeric))), (0)::numeric))::bigint AS cost
   FROM project_timesheet.costed
  GROUP BY project;


--
-- Name: forecast(date); Type: FUNCTION; Schema: project_timesheet; Owner: -
--

CREATE FUNCTION project_timesheet.forecast(day date) RETURNS TABLE(project text, budget bigint, spent bigint, burn numeric, elapsed numeric, forecast bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT p.id,
     cella.cents(p.budget) AS cents,
     COALESCE(b.spent, (0)::bigint) AS "coalesce",
         CASE
             WHEN ((p.budget IS NOT NULL) AND (cella.cents(p.budget) > 0)) THEN round(((100.0 * (COALESCE(b.spent, (0)::bigint))::numeric) / (cella.cents(p.budget))::numeric), 1)
             ELSE NULL::numeric
         END AS "case",
     x.elapsed,
         CASE
             WHEN (x.elapsed > (0)::numeric) THEN (round(((COALESCE(b.spent, (0)::bigint))::numeric / x.elapsed)))::bigint
             ELSE NULL::bigint
         END AS "case"
    FROM (((project.project p
      JOIN project.progress g ON ((g.id = p.id)))
      LEFT JOIN project_timesheet.burn b ON ((b.project = p.id)))
      CROSS JOIN LATERAL ( SELECT project_timesheet.elapsed(p.started, p.due, p.archived, ((g.milestones > 0) AND (g.completed = g.milestones)), forecast.day) AS elapsed) x);
END;


--
-- Name: threshold; Type: TABLE; Schema: expense_invoice_project_timesheet; Owner: -
--

CREATE TABLE expense_invoice_project_timesheet.threshold (
    since date NOT NULL,
    burn numeric NOT NULL,
    margin numeric NOT NULL,
    CONSTRAINT threshold_burn_check CHECK ((burn > (0)::numeric)),
    CONSTRAINT threshold_margin_check CHECK ((margin < (100)::numeric))
);


--
-- Name: rebill; Type: TABLE; Schema: expense_project; Owner: -
--

CREATE TABLE expense_project.rebill (
    expense text NOT NULL,
    project text NOT NULL
);


--
-- Name: spent; Type: VIEW; Schema: expense_project; Owner: -
--

CREATE VIEW expense_project.spent AS
 SELECT r.project,
    (count(*))::integer AS expenses,
    COALESCE(sum(expense.total(e.*)) FILTER (WHERE (e.status = ANY (ARRAY['approved'::text, 'reimbursed'::text]))), (0)::numeric) AS approved,
    COALESCE(sum(expense.total(e.*)) FILTER (WHERE (e.status = ANY (ARRAY['draft'::text, 'submitted'::text]))), (0)::numeric) AS pending
   FROM (expense_project.rebill r
     JOIN expense.expense e ON ((e.id = r.expense)))
  GROUP BY r.project;


--
-- Name: invoice; Type: TABLE; Schema: invoice; Owner: -
--

CREATE TABLE invoice.invoice (
    id text NOT NULL,
    series text NOT NULL,
    number integer NOT NULL,
    issued date NOT NULL,
    due date NOT NULL,
    bill_to text NOT NULL,
    label text NOT NULL,
    net cella.amount NOT NULL,
    vat cella.amount,
    total cella.amount NOT NULL,
    sent date,
    voided date,
    reason text,
    CONSTRAINT invoice_check CHECK ((cella.cents(total) = (cella.cents(net) + COALESCE(cella.cents(vat), (0)::bigint)))),
    CONSTRAINT invoice_check1 CHECK (((voided IS NULL) = (reason IS NULL))),
    CONSTRAINT invoice_check2 CHECK ((due >= issued)),
    CONSTRAINT invoice_number_check CHECK ((number > 0))
);


--
-- Name: COLUMN invoice.net; Type: COMMENT; Schema: invoice; Owner: -
--

COMMENT ON COLUMN invoice.invoice.net IS 'not personal: an amount of the books';


--
-- Name: charge; Type: TABLE; Schema: invoice_project; Owner: -
--

CREATE TABLE invoice_project.charge (
    invoice text NOT NULL,
    project text NOT NULL
);


--
-- Name: invoiced; Type: VIEW; Schema: invoice_project; Owner: -
--

CREATE VIEW invoice_project.invoiced AS
 SELECT c.project,
    (COALESCE(sum(cella.cents(i.net)) FILTER (WHERE (i.voided IS NULL)), (0)::numeric))::bigint AS net
   FROM (invoice_project.charge c
     JOIN invoice.invoice i ON ((i.id = c.invoice)))
  GROUP BY c.project;


--
-- Name: margin(date); Type: FUNCTION; Schema: expense_invoice_project_timesheet; Owner: -
--

CREATE FUNCTION expense_invoice_project_timesheet.margin(day date) RETURNS TABLE(project text, invoiced bigint, cost bigint, expenses bigint, margin bigint, percent numeric, budget bigint, spent bigint, burn numeric, forecast bigint, landing bigint, watch text)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT p.id,
     m.invoiced,
     m.cost,
     m.expenses,
     ((m.invoiced - m.cost) - m.expenses),
         CASE
             WHEN (m.invoiced > 0) THEN round(((100.0 * (((m.invoiced - m.cost) - m.expenses))::numeric) / (m.invoiced)::numeric), 1)
             ELSE NULL::numeric
         END AS "case",
     f.budget,
     f.spent,
     f.burn,
     f.forecast,
         CASE
             WHEN (f.elapsed > (0)::numeric) THEN (((COALESCE(f.budget, m.invoiced))::numeric - round((((m.cost + m.expenses))::numeric / f.elapsed))))::bigint
             ELSE NULL::bigint
         END AS "case",
         CASE
             WHEN (p.archived IS NOT NULL) THEN NULL::text
             WHEN ((f.burn >= t.burn) AND (COALESCE(f.elapsed, (0)::numeric) < (1)::numeric)) THEN 'budget spent'::text
             WHEN (f.forecast > f.budget) THEN 'over budget'::text
             WHEN ((m.invoiced > 0) AND (((100.0 * (((m.invoiced - m.cost) - m.expenses))::numeric) / (m.invoiced)::numeric) < t.margin)) THEN 'thin margin'::text
             ELSE 'on track'::text
         END AS "case"
    FROM ((((((project.project p
      JOIN project_timesheet.forecast(margin.day) f(project, budget, spent, burn, elapsed, forecast) ON ((f.project = p.id)))
      LEFT JOIN project_timesheet.burn b ON ((b.project = p.id)))
      LEFT JOIN invoice_project.invoiced i ON ((i.project = p.id)))
      LEFT JOIN expense_project.spent s ON ((s.project = p.id)))
      CROSS JOIN LATERAL ( SELECT COALESCE(i.net, (0)::bigint) AS invoiced,
             COALESCE(b.cost, (0)::bigint) AS cost,
             (COALESCE(s.approved, (0)::numeric))::bigint AS expenses) m)
      LEFT JOIN LATERAL ( SELECT h.burn,
             h.margin
            FROM expense_invoice_project_timesheet.threshold h
           WHERE (h.since <= margin.day)
           ORDER BY h.since DESC
          LIMIT 1) t ON (true));
END;


--
-- Name: whose(); Type: FUNCTION; Schema: expense_membership; Owner: -
--

CREATE FUNCTION expense_membership.whose() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM membership.member m WHERE m.address = NEW.member AND m.status = 'active') THEN
    RAISE EXCEPTION '% is no active member: an expense is claimed by one', NEW.member
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: files(jsonb); Type: FUNCTION; Schema: expense_project; Owner: -
--

CREATE FUNCTION expense_project.files(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))
             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may not file '::text) || e.member) || '''s expense'::text)
             WHEN (e.status = ANY (ARRAY['refused'::text, 'reimbursed'::text])) THEN ((e.id || ' is '::text) || e.status)
             WHEN (p.id IS NULL) THEN ('no project '::text || COALESCE(x.project, 'is named'::text))
             WHEN (p.archived IS NOT NULL) THEN ((p.id || ' was archived on '::text) || (p.archived)::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (files.payload ->> 'expense'::text) AS expense,
             (files.payload ->> 'project'::text) AS project) x
      LEFT JOIN expense.expense e ON ((e.id = x.expense)))
      LEFT JOIN project.project p ON ((p.id = x.project)));
END;


--
-- Name: lines(text, text); Type: FUNCTION; Schema: expense_transaction; Owner: -
--

CREATE FUNCTION expense_transaction.lines(ref text, event text) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.account,
     x.side,
     x.cents
    FROM (expense.expense e
      CROSS JOIN LATERAL ( VALUES ('charge'::text,e.category,'debit'::text,cella.cents(e.net)), ('charge'::text,'44566'::text,'debit'::text,cella.cents(e.vat)), ('charge'::text,'421'::text,'credit'::text,expense.total(e.*)), ('payment'::text,'421'::text,'debit'::text,expense.total(e.*)), ('payment'::text,'512'::text,'credit'::text,expense.total(e.*))) x(event, account, side, cents))
   WHERE ((e.id = lines.ref) AND (x.event = lines.event) AND (x.cents IS NOT NULL));
END;


--
-- Name: posting; Type: TABLE; Schema: expense_transaction; Owner: -
--

CREATE TABLE expense_transaction.posting (
    entry text NOT NULL,
    expense text NOT NULL,
    event text NOT NULL,
    CONSTRAINT posting_event_check CHECK ((event = ANY (ARRAY['charge'::text, 'payment'::text])))
);


--
-- Name: unposted(text, text); Type: FUNCTION; Schema: expense_transaction; Owner: -
--

CREATE FUNCTION expense_transaction.unposted(ref text, event text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(unposted.ref, 'is named'::text))
             WHEN (p.entry IS NULL) THEN ((unposted.ref || ' posted no '::text) || unposted.event)
             WHEN (t.date IS DISTINCT FROM
             CASE unposted.event
                 WHEN 'charge'::text THEN e.decided
                 ELSE e.reimbursed
             END) THEN ((((p.entry || ' is not dated on '::text) || unposted.ref) || '''s '::text) || unposted.event)
             WHEN ((EXISTS ( SELECT l.account,
                 l.side,
                 l.cents
                FROM expense_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)
             EXCEPT ALL
              SELECT x.account,
                 x.side,
                 cella.cents(x.amount) AS cents
                FROM transaction.line x
               WHERE (x.entry = p.entry))) OR (EXISTS ( SELECT x.account,
                 x.side,
                 cella.cents(x.amount) AS cents
                FROM transaction.line x
               WHERE (x.entry = p.entry)
             EXCEPT ALL
              SELECT l.account,
                 l.side,
                 l.cents
                FROM expense_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)))) THEN ((((p.entry || ' does not post '::text) || unposted.ref) || '''s '::text) || unposted.event)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT 1 AS "?column?") one
      LEFT JOIN expense.expense e ON ((e.id = unposted.ref)))
      LEFT JOIN expense_transaction.posting p ON (((p.expense = unposted.ref) AND (p.event = unposted.event))))
      LEFT JOIN transaction.entry t ON ((t.id = p.entry)));
END;


--
-- Name: charged(jsonb); Type: FUNCTION; Schema: expense_transaction; Owner: -
--

CREATE FUNCTION expense_transaction.charged(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN expense_transaction.unposted((payload ->> 'expense'::text), 'charge'::text);


--
-- Name: paid(jsonb); Type: FUNCTION; Schema: expense_transaction; Owner: -
--

CREATE FUNCTION expense_transaction.paid(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN expense_transaction.unposted((payload ->> 'expense'::text), 'payment'::text);


--
-- Name: fixed(); Type: FUNCTION; Schema: file; Owner: -
--

CREATE FUNCTION file.fixed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT cella.redacting() THEN
    RAISE EXCEPTION '% never changes once uploaded', OLD.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: opens(text, text); Type: FUNCTION; Schema: file; Owner: -
--

CREATE FUNCTION file.opens(id text, actor text) RETURNS boolean
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT COALESCE(bool_or(((f.class = 'none'::text) OR ((opens.actor = f.subject) OR (opens.actor = f.uploader)))), false) AS "coalesce"
    FROM file.file f
   WHERE (f.id = opens.id);
END;


--
-- Name: uploads(jsonb); Type: FUNCTION; Schema: file; Owner: -
--

CREATE FUNCTION file.uploads(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN file.stored((payload ->> 'file'::text), 'none'::text, NULL::text);


--
-- Name: record; Type: TABLE; Schema: file_membership; Owner: -
--

CREATE TABLE file_membership.record (
    member text NOT NULL,
    file text NOT NULL
);


--
-- Name: files(jsonb); Type: FUNCTION; Schema: file_membership; Owner: -
--

CREATE FUNCTION file_membership.files(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(x.member, 'is named'::text))
             WHEN (m.address IS DISTINCT FROM cella.actor()) THEN ((COALESCE(cella.actor(), 'no one'::text) || ' may not file a record of '::text) || m.address)
             WHEN (m.status = 'exited'::text) THEN (m.address || ' has left'::text)
             WHEN (r.file IS NULL) THEN (((COALESCE(x.file, 'no file'::text) || ' is not on '::text) || m.address) || '''s file'::text)
             ELSE file.stored(x.file, 'profile'::text, m.address)
         END AS stored
    FROM ((( SELECT (files.payload ->> 'member'::text) AS member,
             (files.payload ->> 'file'::text) AS file) x
      LEFT JOIN membership.member m ON ((m.address = x.member)))
      LEFT JOIN file_membership.record r ON (((r.member = x.member) AND (r.file = x.file))));
END;


--
-- Name: number; Type: SEQUENCE; Schema: import; Owner: -
--

CREATE SEQUENCE import.number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: run; Type: TABLE; Schema: import; Owner: -
--

CREATE TABLE import.run (
    id text DEFAULT ('im-'::text || lpad((nextval('import.number'::regclass))::text, 4, '0'::text)) NOT NULL,
    kind text NOT NULL,
    name text NOT NULL,
    actor text NOT NULL,
    day date NOT NULL,
    dry boolean NOT NULL,
    settled integer NOT NULL,
    refused integer NOT NULL,
    lines jsonb NOT NULL,
    CONSTRAINT run_check CHECK (((settled + refused) = jsonb_array_length(lines))),
    CONSTRAINT run_kind_check CHECK ((kind ~ '^[a-z]+$'::text)),
    CONSTRAINT run_lines_check CHECK ((jsonb_typeof(lines) = 'array'::text)),
    CONSTRAINT run_name_check CHECK ((name <> ''::text)),
    CONSTRAINT run_refused_check CHECK ((refused >= 0)),
    CONSTRAINT run_settled_check CHECK ((settled >= 0))
);


--
-- Name: COLUMN run.name; Type: COMMENT; Schema: import; Owner: -
--

COMMENT ON COLUMN import.run.name IS 'not personal: the name the imported file was uploaded under, such as members.csv';


--
-- Name: records(jsonb); Type: FUNCTION; Schema: import; Owner: -
--

CREATE FUNCTION import.records(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (r.id IS NULL) THEN ('no run '::text || COALESCE(x.run, 'is named'::text))
             WHEN ((r.actor IS DISTINCT FROM cella.actor()) OR (r.day IS DISTINCT FROM cella.verdict_date())) THEN (r.id || ' was not recorded by this write'::text)
             WHEN ((((r.kind IS DISTINCT FROM x.kind) OR (r.dry IS DISTINCT FROM x.dry)) OR (r.settled IS DISTINCT FROM x.settled)) OR (r.refused IS DISTINCT FROM x.refused)) THEN (r.id || ' is not the run the write names'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (records.payload ->> 'run'::text) AS run,
             (records.payload ->> 'kind'::text) AS kind,
             ((records.payload ->> 'dry'::text))::boolean AS dry,
             ((records.payload ->> 'settled'::text))::integer AS settled,
             ((records.payload ->> 'refused'::text))::integer AS refused) x
      LEFT JOIN import.run r ON ((r.id = x.run)));
END;


--
-- Name: adds_up(); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.adds_up() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  ref text;
  net bigint;
  lines bigint;
BEGIN
  IF TG_TABLE_NAME = 'invoice' THEN
    ref := NEW.id;
  ELSE
    ref := NEW.invoice;
  END IF;
  SELECT cella.cents(i.net), (SELECT sum(cella.cents(l.amount)) FROM invoice.line l WHERE l.invoice = i.id)
  INTO net, lines
  FROM invoice.invoice i WHERE i.id = ref;
  IF lines IS DISTINCT FROM net THEN
    RAISE EXCEPTION '%: the lines make % cents, the net %', ref, coalesce(lines, 0), net
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: number_id(text, integer); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.number_id(series text, number integer) RETURNS text
    LANGUAGE sql IMMUTABLE
    RETURN ((series || '-'::text) || lpad((number)::text, 4, '0'::text));


--
-- Name: series; Type: TABLE; Schema: invoice; Owner: -
--

CREATE TABLE invoice.series (
    name text NOT NULL,
    next integer NOT NULL,
    until integer,
    CONSTRAINT series_next_check CHECK ((next > 0)),
    CONSTRAINT series_until_check CHECK ((until > 0))
);


--
-- Name: COLUMN series.name; Type: COMMENT; Schema: invoice; Owner: -
--

COMMENT ON COLUMN invoice.series.name IS 'not personal: a numbering series'' name';


--
-- Name: numbered(jsonb); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.numbered(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (i.id IS NULL) THEN ('no invoice '::text || COALESCE(x.id, 'is named'::text))
             WHEN (i.issued IS DISTINCT FROM cella.verdict_date()) THEN (i.id || ' was not issued by this write'::text)
             WHEN (s.next IS DISTINCT FROM (i.number + 1)) THEN ((i.id || ' is not the last number of '::text) || i.series)
             WHEN ((i.number > 1) AND (NOT (EXISTS ( SELECT
                FROM invoice.invoice q
               WHERE ((q.series = i.series) AND (q.number = (i.number - 1))))))) THEN (((i.id || ' leaves a gap: '::text) || invoice.number_id(i.series, (i.number - 1))) || ' was never issued'::text)
             WHEN (EXISTS ( SELECT
                FROM invoice.invoice q
               WHERE ((q.series = i.series) AND (q.number < i.number) AND (q.issued > i.issued)))) THEN ((i.id || ' is dated before an earlier number of '::text) || i.series)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (numbered.payload ->> 'invoice'::text) AS id) x
      LEFT JOIN invoice.invoice i ON ((i.id = x.id)))
      LEFT JOIN invoice.series s ON ((s.name = i.series)));
END;


--
-- Name: spend(text); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.spend(name text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  n integer;
  upto integer;
BEGIN
  UPDATE invoice.series s SET next = s.next + 1 WHERE s.name = spend.name
    RETURNING s.next - 1, s.until INTO n, upto;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no series %', name USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF upto IS NOT NULL AND n > upto THEN
    RAISE EXCEPTION 'the right to % ends at %; a further number needs a new grant', name, upto
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF EXISTS (SELECT FROM invoice.invoice i WHERE i.series = spend.name AND i.number = n) THEN
    RAISE EXCEPTION '% is already issued: a number is never reused', invoice.number_id(name, n)
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN n;
END
$$;


--
-- Name: stays_issued(); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.stays_issued() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'line' THEN
    RAISE EXCEPTION 'the lines of % never change once issued', OLD.invoice
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF (NEW.id, NEW.series, NEW.number, NEW.issued, NEW.due, NEW.bill_to, NEW.label,
      cella.cents(NEW.net), cella.cents(NEW.vat), cella.cents(NEW.total))
    IS DISTINCT FROM (OLD.id, OLD.series, OLD.number, OLD.issued, OLD.due, OLD.bill_to, OLD.label,
      cella.cents(OLD.net), cella.cents(OLD.vat), cella.cents(OLD.total))
  THEN
    RAISE EXCEPTION '% is issued and never changes; void it and reissue', OLD.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.sent IS NOT NULL AND NEW.sent IS DISTINCT FROM OLD.sent THEN
    RAISE EXCEPTION '% was sent on %', OLD.id, OLD.sent USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.voided IS NOT NULL AND (NEW.voided, NEW.reason) IS DISTINCT FROM (OLD.voided, OLD.reason) THEN
    RAISE EXCEPTION '% was voided on %', OLD.id, OLD.voided USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.voided IS NOT NULL AND NEW.sent IS DISTINCT FROM OLD.sent THEN
    RAISE EXCEPTION '% is voided and is not sent', OLD.id USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: payment; Type: TABLE; Schema: invoice; Owner: -
--

CREATE TABLE invoice.payment (
    id bigint NOT NULL,
    invoice text NOT NULL,
    receipt bigint NOT NULL,
    at date NOT NULL,
    amount cella.amount NOT NULL,
    method text DEFAULT 'transfer'::text NOT NULL,
    reference text NOT NULL
);


--
-- Name: voids(jsonb); Type: FUNCTION; Schema: invoice; Owner: -
--

CREATE FUNCTION invoice.voids(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (i.id IS NULL) THEN ('no invoice '::text || COALESCE(x.id, 'is named'::text))
             WHEN (i.voided IS DISTINCT FROM cella.verdict_date()) THEN (i.id || ' was not voided by this write'::text)
             WHEN (EXISTS ( SELECT
                FROM invoice.payment p
               WHERE (p.invoice = i.id))) THEN (i.id || ' has a payment, so it is not voided; refund or apply what was paid'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (voids.payload ->> 'invoice'::text) AS id) x
      LEFT JOIN invoice.invoice i ON ((i.id = x.id)));
END;


--
-- Name: resolves(); Type: FUNCTION; Schema: invoice_project; Owner: -
--

CREATE FUNCTION invoice_project.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM invoice.invoice i WHERE i.id = NEW.invoice) THEN
    RAISE EXCEPTION 'no invoice %', NEW.invoice USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM project.project p WHERE p.id = NEW.project) THEN
    RAISE EXCEPTION 'no project %', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: lines(text, text); Type: FUNCTION; Schema: invoice_transaction; Owner: -
--

CREATE FUNCTION invoice_transaction.lines(ref text, event text) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.account,
         CASE
             WHEN (lines.event = 'void'::text) THEN
             CASE x.side
                 WHEN 'debit'::text THEN 'credit'::text
                 ELSE 'debit'::text
             END
             ELSE x.side
         END AS side,
     x.cents
    FROM (invoice.invoice i
      CROSS JOIN LATERAL ( VALUES ('411'::text,'debit'::text,cella.cents(i.total)), ('706'::text,'credit'::text,cella.cents(i.net)), ('44571'::text,'credit'::text,cella.cents(i.vat))) x(account, side, cents))
   WHERE ((i.id = lines.ref) AND (x.cents IS NOT NULL));
END;


--
-- Name: posting; Type: TABLE; Schema: invoice_transaction; Owner: -
--

CREATE TABLE invoice_transaction.posting (
    entry text NOT NULL,
    invoice text NOT NULL,
    event text NOT NULL,
    payment bigint,
    CONSTRAINT posting_check CHECK (((event = 'payment'::text) = (payment IS NOT NULL))),
    CONSTRAINT posting_event_check CHECK ((event = ANY (ARRAY['issue'::text, 'payment'::text, 'void'::text])))
);


--
-- Name: unposted(text, text); Type: FUNCTION; Schema: invoice_transaction; Owner: -
--

CREATE FUNCTION invoice_transaction.unposted(ref text, event text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.entry IS NULL) THEN (((unposted.ref || ' posted no '::text) || unposted.event) || ' entry'::text)
             WHEN (e.date IS DISTINCT FROM
             CASE unposted.event
                 WHEN 'void'::text THEN i.voided
                 ELSE i.issued
             END) THEN ((((p.entry || ' is not dated on '::text) || unposted.ref) || '''s '::text) || unposted.event)
             WHEN ((EXISTS ( SELECT l.account,
                 l.side,
                 l.cents
                FROM invoice_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)
             EXCEPT ALL
              SELECT t.account,
                 t.side,
                 cella.cents(t.amount) AS cents
                FROM transaction.line t
               WHERE (t.entry = p.entry))) OR (EXISTS ( SELECT t.account,
                 t.side,
                 cella.cents(t.amount) AS cents
                FROM transaction.line t
               WHERE (t.entry = p.entry)
             EXCEPT ALL
              SELECT l.account,
                 l.side,
                 l.cents
                FROM invoice_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)))) THEN ((((p.entry || ' does not post '::text) || unposted.ref) || '''s '::text) || unposted.event)
             ELSE NULL::text
         END AS "case"
    FROM ((invoice.invoice i
      LEFT JOIN invoice_transaction.posting p ON (((p.invoice = i.id) AND (p.event = unposted.event))))
      LEFT JOIN transaction.entry e ON ((e.id = p.entry)))
   WHERE (i.id = unposted.ref);
END;


--
-- Name: issued(jsonb); Type: FUNCTION; Schema: invoice_transaction; Owner: -
--

CREATE FUNCTION invoice_transaction.issued(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN invoice_transaction.unposted((payload ->> 'invoice'::text), 'issue'::text);


--
-- Name: payment_lines(bigint); Type: FUNCTION; Schema: invoice_transaction; Owner: -
--

CREATE FUNCTION invoice_transaction.payment_lines(ref bigint) RETURNS TABLE(account text, side text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT x.account,
     x.side,
     x.cents
    FROM (invoice.payment p
      CROSS JOIN LATERAL ( VALUES ('512'::text,'debit'::text,cella.cents(p.amount)), ('411'::text,'credit'::text,cella.cents(p.amount))) x(account, side, cents))
   WHERE (p.id = payment_lines.ref);
END;


--
-- Name: voided(jsonb); Type: FUNCTION; Schema: invoice_transaction; Owner: -
--

CREATE FUNCTION invoice_transaction.voided(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN invoice_transaction.unposted((payload ->> 'invoice'::text), 'void'::text);


--
-- Name: cancels(jsonb); Type: FUNCTION; Schema: meeting; Owner: -
--

CREATE FUNCTION meeting.cancels(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no meeting '::text || COALESCE(w.id, 'is named'::text))
             WHEN ((m.status <> 'cancelled'::text) OR (m.settled IS DISTINCT FROM cella.verdict_date())) THEN (m.id || ' was not cancelled by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (cancels.payload ->> 'meeting'::text) AS id) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.id)));
END;


--
-- Name: holds(jsonb); Type: FUNCTION; Schema: meeting; Owner: -
--

CREATE FUNCTION meeting.holds(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.id IS NULL) THEN ('no meeting '::text || COALESCE(w.id, 'is named'::text))
             WHEN ((m.status <> 'held'::text) OR (m.settled IS DISTINCT FROM cella.verdict_date())) THEN (m.id || ' was not held by this write'::text)
             WHEN ((m.at)::date > cella.verdict_date()) THEN (((m.id || ' meets on '::text) || to_char(m.at, 'YYYY-MM-DD'::text)) || ': it is not held before'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (holds.payload ->> 'meeting'::text) AS id) w
      LEFT JOIN meeting.meeting m ON ((m.id = w.id)));
END;


--
-- Name: open_agenda(); Type: FUNCTION; Schema: meeting; Owner: -
--

CREATE FUNCTION meeting.open_agenda() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  m meeting.meeting;
BEGIN
  SELECT * INTO m FROM meeting.meeting WHERE id = coalesce(NEW.meeting, OLD.meeting) FOR SHARE;
  IF m.status <> 'scheduled' THEN
    RAISE EXCEPTION '% was % on %: its agenda is fixed', m.id, m.status, m.settled
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: stays_settled(); Type: FUNCTION; Schema: meeting; Owner: -
--

CREATE FUNCTION meeting.stays_settled() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status = 'cancelled' AND NEW.minuted IS NOT NULL THEN
    RAISE EXCEPTION '% was cancelled: it has no minutes', NEW.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.status <> 'scheduled'
    AND (NEW.status, NEW.settled, NEW.at, NEW.circle, NEW.title, NEW.place, NEW.link)
      IS DISTINCT FROM (OLD.status, OLD.settled, OLD.at, OLD.circle, OLD.title, OLD.place, OLD.link) THEN
    RAISE EXCEPTION '% was % on %', OLD.id, OLD.status, OLD.settled
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: marks(jsonb); Type: FUNCTION; Schema: meeting_membership; Owner: -
--

CREATE FUNCTION meeting_membership.marks(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (w.member IS DISTINCT FROM cella.actor()) THEN (('only '::text || COALESCE(w.member, 'a member'::text)) || ' marks their own attendance; another''s is recorded by the minutes'' keeper'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (marks.payload ->> 'member'::text) AS member) w;
END;


--
-- Name: resolves(); Type: FUNCTION; Schema: meeting_membership; Owner: -
--

CREATE FUNCTION meeting_membership.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  m meeting.meeting;
BEGIN
  SELECT * INTO m FROM meeting.meeting WHERE id = NEW.meeting FOR SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no meeting %', NEW.meeting USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF m.status <> 'scheduled' THEN
    RAISE EXCEPTION '% was % on %: who came is fixed', m.id, m.status, m.settled
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM membership.member mm WHERE mm.address = NEW.member AND mm.status = 'active') THEN
    RAISE EXCEPTION '% is no active member: only a member attends', NEW.member
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: invitation; Type: TABLE; Schema: membership; Owner: -
--

CREATE TABLE membership.invitation (
    member text NOT NULL,
    key bytea NOT NULL,
    label text NOT NULL,
    accepted date,
    CONSTRAINT invitation_key_check CHECK ((length(key) = 32)),
    CONSTRAINT invitation_label_check CHECK ((label <> ''::text))
);


--
-- Name: link; Type: TABLE; Schema: membership; Owner: -
--

CREATE TABLE membership.link (
    digest bytea NOT NULL,
    member text NOT NULL,
    made date NOT NULL,
    CONSTRAINT link_digest_check CHECK ((length(digest) = 32))
);


--
-- Name: accepts(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.accepts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (cella.actor() IS DISTINCT FROM p.member) THEN ('an invitation is taken up by whom it invites, not '::text || cella.actor())
             WHEN (m.status IS DISTINCT FROM 'invited'::text) THEN (COALESCE(p.member, 'no one'::text) || ' is not invited'::text)
             WHEN (NOT (EXISTS ( SELECT
                FROM membership.link l
               WHERE ((encode(l.digest, 'hex'::text) = p.link) AND (l.member = p.member))))) THEN (('the link is not '::text || p.member) || '''s'::text)
             WHEN ((i.accepted IS DISTINCT FROM cella.verdict_date()) OR (encode(i.key, 'hex'::text) IS DISTINCT FROM p.key)) THEN (p.member || '''s invitation was not taken up by this write'::text)
             WHEN (encode(cella.device(), 'hex'::text) IS DISTINCT FROM p.key) THEN 'an invitation is taken up by the device it enrols'::text
             WHEN (NOT (EXISTS ( SELECT
                FROM person.device d
               WHERE ((d.key = i.key) AND (d.address = p.member) AND (d.enrolled_by IS NULL) AND (d.enrolled = cella.verdict_date()))))) THEN (('device '::text || "left"(p.key, 16)) || ' was not enrolled by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (accepts.payload ->> 'member'::text) AS member,
             (accepts.payload ->> 'link'::text) AS link,
             (accepts.payload ->> 'key'::text) AS key) p
      LEFT JOIN membership.member m ON ((m.address = p.member)))
      LEFT JOIN membership.invitation i ON ((i.member = p.member)));
END;


--
-- Name: carries(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.carries(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((p.link IS NOT NULL) AND (l.member IS DISTINCT FROM p.member)) THEN (COALESCE(p.member, 'no one'::text) || '''s invitation carries no link its payload names'::text)
             WHEN ((p.link IS NOT NULL) AND (l.made IS DISTINCT FROM cella.verdict_date())) THEN 'the link was not made by this write'::text
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (carries.payload ->> 'member'::text) AS member,
             (carries.payload ->> 'link'::text) AS link) p
      LEFT JOIN membership.link l ON ((encode(l.digest, 'hex'::text) = p.link)));
END;


--
-- Name: ends(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.ends(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(p.address, 'is named'::text))
             WHEN ((split_part(cella.op(), ':'::text, 3) = 'suspend'::text) AND ((m.status <> 'suspended'::text) OR (m.suspended IS DISTINCT FROM cella.verdict_date()))) THEN (m.address || ' was not suspended by this write'::text)
             WHEN ((split_part(cella.op(), ':'::text, 3) = 'exit'::text) AND ((m.status <> 'exited'::text) OR (m.exited IS DISTINCT FROM cella.verdict_date()))) THEN (m.address || ' did not exit by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (ends.payload ->> 'member'::text) AS address) p
      LEFT JOIN membership.member m ON ((m.address = p.address)));
END;


--
-- Name: erases(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.erases(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(p.member, 'is named'::text))
             WHEN (m.status <> 'exited'::text) THEN (((m.address || ' is '::text) || m.status) || ': only a member who has left is erased'::text)
             WHEN ((p.subject IS DISTINCT FROM m.address) OR ((COALESCE(jsonb_array_length(p.erased), 0) + COALESCE(jsonb_array_length(p.restricted), 0)) <> ( SELECT count(*) AS count
                FROM cella.retention))) THEN (('the erasure is not of all of '::text || m.address) || '''s personal data'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (erases.payload ->> 'member'::text) AS member,
             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,
             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased,
             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'restricted'::text) AS restricted) p
      LEFT JOIN membership.member m ON ((m.address = p.member)));
END;


--
-- Name: invites(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.invites(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(p.address, 'is named'::text))
             WHEN ((m.status <> 'invited'::text) OR (m.invited IS DISTINCT FROM cella.verdict_date())) THEN (m.address || ' was not invited by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (invites.payload ->> 'member'::text) AS address) p
      LEFT JOIN membership.member m ON ((m.address = p.address)));
END;


--
-- Name: links(jsonb); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.links(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (m.address IS NULL) THEN ('no one invited is '::text || COALESCE(p.member, 'named'::text))
             WHEN (m.status <> 'invited'::text) THEN ((m.address || ' is '::text) || m.status)
             WHEN (EXISTS ( SELECT
                FROM membership.invitation i
               WHERE (i.member = p.member))) THEN (m.address || ' has taken up their invitation'::text)
             WHEN ((l.member IS DISTINCT FROM p.member) OR (l.made IS DISTINCT FROM cella.verdict_date())) THEN 'the link was not made by this write'::text
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (links.payload ->> 'member'::text) AS member,
             (links.payload ->> 'link'::text) AS link) p
      LEFT JOIN membership.member m ON ((m.address = p.member)))
      LEFT JOIN membership.link l ON ((encode(l.digest, 'hex'::text) = p.link)));
END;


--
-- Name: moves(); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.moves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NEW.status <> OLD.status AND (OLD.status, NEW.status) NOT IN (
    ('invited', 'active'), ('active', 'suspended'), ('suspended', 'active'),
    ('active', 'exited'), ('suspended', 'exited')
  ) THEN
    RAISE EXCEPTION '% is %, and cannot become %', OLD.address, OLD.status, NEW.status
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: signs(); Type: FUNCTION; Schema: membership; Owner: -
--

CREATE FUNCTION membership.signs() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM person.device d WHERE d.address = NEW.address AND d.revoked IS NULL) THEN
    RAISE EXCEPTION '% holds no device to sign with: they take up their invitation first', NEW.address
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: share; Type: TABLE; Schema: membership_project; Owner: -
--

CREATE TABLE membership_project.share (
    id bigint NOT NULL,
    project text NOT NULL,
    member text NOT NULL,
    amount cella.amount NOT NULL,
    granted date NOT NULL
);


--
-- Name: pot; Type: VIEW; Schema: membership_project; Owner: -
--

CREATE VIEW membership_project.pot AS
 SELECT p.id AS project,
    cella.cents(p.budget) AS budget,
    (COALESCE(sum(cella.cents(s.amount)), (0)::numeric))::bigint AS shared,
    (((cella.cents(p.budget))::numeric - COALESCE(sum(cella.cents(s.amount)), (0)::numeric)))::bigint AS remaining
   FROM (project.project p
     LEFT JOIN membership_project.share s ON ((s.project = p.id)))
  GROUP BY p.id, p.budget;


--
-- Name: covers(jsonb); Type: FUNCTION; Schema: membership_project; Owner: -
--

CREATE FUNCTION membership_project.covers(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (t.shared > t.budget) THEN ((((t.project || '''s shares come to '::text) || (t.shared)::text) || ' cents, more than a budget of '::text) || (t.budget)::text)
             ELSE NULL::text
         END AS "case"
    FROM membership_project.pot t
   WHERE (t.project = (covers.payload ->> 'project'::text));
END;


--
-- Name: within(); Type: FUNCTION; Schema: membership_project; Owner: -
--

CREATE FUNCTION membership_project.within() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  budget bigint;
  archived date;
  shared bigint;
BEGIN
  IF NOT EXISTS (SELECT FROM membership.member m WHERE m.address = NEW.member AND m.status = 'active') THEN
    RAISE EXCEPTION '% is no active member', NEW.member USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT cella.cents(p.budget), p.archived INTO budget, archived FROM project.project p WHERE p.id = NEW.project FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no project %', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF archived IS NOT NULL THEN
    RAISE EXCEPTION '% was archived on %', NEW.project, archived USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF budget IS NULL THEN
    RAISE EXCEPTION '% has no budget to share', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT coalesce(sum(cella.cents(s.amount)), 0) INTO shared FROM membership_project.share s WHERE s.project = NEW.project;
  IF shared + cella.cents(NEW.amount) > budget THEN
    RAISE EXCEPTION 'a share of % cents exceeds what is left of %''s budget, % of % cents',
      cella.cents(NEW.amount), NEW.project, budget - shared, budget
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: membership_task; Owner: -
--

CREATE FUNCTION membership_task.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF NOT EXISTS (SELECT FROM task.task t WHERE t.id = NEW.task) THEN
    RAISE EXCEPTION 'no task %', NEW.task USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NOT EXISTS (SELECT FROM membership.member m WHERE m.address = NEW.member AND m.status = 'active') THEN
    RAISE EXCEPTION '% is no active member: a task goes to one', NEW.member USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: whose(); Type: FUNCTION; Schema: membership_timesheet; Owner: -
--

CREATE FUNCTION membership_timesheet.whose() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM membership.member m WHERE m.address = NEW.member AND m.status IN ('suspended', 'exited')) THEN
    RAISE EXCEPTION '% is a member suspended or gone: they log no time', NEW.member
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: adopts(jsonb); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.adopts(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (t.id IS NULL) THEN ('no terms '::text || COALESCE(x.terms, 'are named'::text))
             WHEN (t.adopted IS DISTINCT FROM cella.verdict_date()) THEN (t.id || ' were not adopted by this write'::text)
             WHEN (((t.salary + t.hours) + t.equal) <> (100)::numeric) THEN (((t.id || ' divide '::text) || ((t.salary + t.hours) + t.equal)) || ' % of the work share, not 100 %'::text)
             WHEN (EXISTS ( SELECT
                FROM patronage.distribution d
               WHERE ((d.year >= t."from") AND (d.approved IS NOT NULL)))) THEN (((t.id || ' would govern '::text) || ( SELECT min(d.year) AS min
                FROM patronage.distribution d
               WHERE ((d.year >= t."from") AND (d.approved IS NOT NULL)))) || ', whose distribution is approved'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (adopts.payload ->> 'terms'::text) AS terms) x
      LEFT JOIN patronage.terms t ON ((t.id = x.terms)));
END;


--
-- Name: basis_of(text); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.basis_of(ref text) RETURNS text
    LANGUAGE sql STABLE
    RETURN (SELECT CASE WHEN (t.salary = (100)::numeric) THEN 'salary'::text WHEN (t.hours = (100)::numeric) THEN 'hours'::text WHEN (t.equal = (100)::numeric) THEN 'equal'::text ELSE 'mix'::text END AS "case" FROM patronage.terms t WHERE (t.id = basis_of.ref));


--
-- Name: distributes(jsonb); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.distributes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no distribution '::text || COALESCE(x.distribution, 'is named'::text))
             WHEN (d.approved IS NULL) THEN (d.id || ' is not approved by the assembly'::text)
             WHEN (d.distributed IS DISTINCT FROM cella.verdict_date()) THEN (d.id || ' was not distributed by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (distributes.payload ->> 'distribution'::text) AS distribution) x
      LEFT JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: portion(text, text); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.portion(ref text, of text) RETURNS bigint
    LANGUAGE sql STABLE
    RETURN COALESCE((SELECT (cella.allocate(cella.amount(patronage.share_of(d.id, 'work'::text)), ARRAY[((t.salary * (100)::numeric))::bigint, ((t.hours * (100)::numeric))::bigint, ((t.equal * (100)::numeric))::bigint]))[array_position(ARRAY['salary'::text, 'hours'::text, 'equal'::text], portion.of)] AS allocate FROM (patronage.distribution d JOIN patronage.terms t ON ((t.id = patronage.terms_for(d.year)))) WHERE ((d.id = portion.ref) AND (patronage.share_of(d.id, 'work'::text) > 0) AND (((t.salary + t.hours) + t.equal) > (0)::numeric))), (0)::bigint);


--
-- Name: divided(text); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.divided(ref text) RETURNS TABLE(basis text, parts bigint, portion bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT b.kind,
     (COALESCE(( SELECT sum(cella.cents(p.amount)) AS sum
            FROM patronage.part p
           WHERE ((p.distribution = divided.ref) AND (p.basis = b.kind))), (0)::numeric))::bigint AS "coalesce",
     patronage.portion(divided.ref, b.kind) AS portion
    FROM unnest(ARRAY['salary'::text, 'hours'::text, 'equal'::text]) WITH ORDINALITY b(kind, n)
   ORDER BY b.n;
END;


--
-- Name: divides(jsonb); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.divides(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN NULL::text
             WHEN (patronage.terms_for(d.year) IS NULL) THEN (d.year || ' has no adopted terms dividing its work share'::text)
             WHEN (d.basis IS DISTINCT FROM patronage.basis_of(patronage.terms_for(d.year))) THEN (((((((d.id || ' divides its work share by '::text) || d.basis) || ', not by '::text) || patronage.basis_of(patronage.terms_for(d.year))) || ' as '::text) || patronage.terms_for(d.year)) || ' say'::text)
             WHEN (EXISTS ( SELECT
                FROM patronage.divided(d.id) v(basis, parts, portion)
               WHERE (v.parts <> v.portion))) THEN ( SELECT ((((((d.id || '''s parts by '::text) || v.basis) || ' make '::text) || v.parts) || ' cents, not its portion of '::text) || v.portion)
                FROM patronage.divided(d.id) v(basis, parts, portion)
               WHERE (v.parts <> v.portion)
              LIMIT 1)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (divides.payload ->> 'distribution'::text) AS distribution) x
      LEFT JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: part_fixed(); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.part_fixed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND cella.redacting() THEN
    RETURN NEW;
  END IF;
  IF TG_OP = 'INSERT' AND EXISTS (
    SELECT FROM patronage.distribution d WHERE d.id = NEW.distribution AND d.approved = cella.verdict_date() AND d.distributed IS NULL
  ) THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'the parts of % are made when it is approved, and never change', coalesce(NEW.distribution, OLD.distribution)
    USING ERRCODE = 'triggered_action_exception';
END
$$;


--
-- Name: share_fixed(); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.share_fixed() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM patronage.distribution d WHERE d.id = coalesce(NEW.distribution, OLD.distribution) AND d.approved IS NOT NULL) THEN
    RAISE EXCEPTION 'the split of % is approved and never changes', coalesce(NEW.distribution, OLD.distribution)
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: splits(jsonb); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.splits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.id IS NULL) THEN ('no distribution '::text || COALESCE(x.distribution, 'is named'::text))
             WHEN (d.approved IS DISTINCT FROM cella.verdict_date()) THEN (d.id || ' was not approved by this write'::text)
             WHEN (cella.verdict_date() < make_date((d.year + 1), 1, 1)) THEN (d.year || ' is not over'::text)
             WHEN (( SELECT COALESCE(sum(cella.cents(s.amount)), (0)::numeric) AS "coalesce"
                FROM patronage.share s
               WHERE (s.distribution = d.id)) <> (cella.cents(d.surplus))::numeric) THEN ((((d.id || '''s shares make '::text) || ( SELECT COALESCE(sum(cella.cents(s.amount)), (0)::numeric) AS "coalesce"
                FROM patronage.share s
               WHERE (s.distribution = d.id))) || ' cents, not its surplus of '::text) || cella.cents(d.surplus))
             WHEN (EXISTS ( SELECT
                FROM patronage.share s
               WHERE ((s.distribution = d.id) AND (abs((((cella.cents(s.amount) * 100))::numeric - ((cella.cents(d.surplus))::numeric * s.percent))) >= (100)::numeric)))) THEN (((d.id || '''s '::text) || ( SELECT min(s.kind) AS min
                FROM patronage.share s
               WHERE ((s.distribution = d.id) AND (abs((((cella.cents(s.amount) * 100))::numeric - ((cella.cents(d.surplus))::numeric * s.percent))) >= (100)::numeric)))) || ' share is not its percent of the surplus'::text)
             WHEN ((patronage.share_of(d.id, 'work'::text) * 4) < cella.cents(d.surplus)) THEN (d.id || '''s work share is under 25 % of the surplus (loi 78-763, art. 33, 3°)'::text)
             WHEN (patronage.share_of(d.id, 'interest'::text) > (patronage.share_of(d.id, 'legal'::text) + patronage.share_of(d.id, 'development'::text))) THEN (d.id || '''s interest on capital exceeds what it puts in reserve (loi 78-763, art. 33, 4°)'::text)
             WHEN (patronage.share_of(d.id, 'interest'::text) > patronage.share_of(d.id, 'work'::text)) THEN (d.id || '''s interest on capital exceeds the work share (loi 78-763, art. 33, 4°)'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (splits.payload ->> 'distribution'::text) AS distribution) x
      LEFT JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: stays_adopted(); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.stays_adopted() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.adopted IS NOT NULL THEN
    RAISE EXCEPTION '% were adopted on %', OLD.id, OLD.adopted
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: stays_approved(); Type: FUNCTION; Schema: patronage; Owner: -
--

CREATE FUNCTION patronage.stays_approved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.distributed IS NOT NULL THEN
    RAISE EXCEPTION 'the % surplus was distributed on %', OLD.year, OLD.distributed
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF OLD.approved IS NOT NULL
    AND (NEW.approved, NEW.year, cella.cents(NEW.surplus), NEW.basis) IS DISTINCT FROM (OLD.approved, OLD.year, cella.cents(OLD.surplus), OLD.basis) THEN
    RAISE EXCEPTION 'the % surplus was approved on %', OLD.year, OLD.approved
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NEW.distributed IS NOT NULL AND NEW.approved IS NULL THEN
    RAISE EXCEPTION '% is not approved by the assembly', OLD.id
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: salary; Type: TABLE; Schema: payslip; Owner: -
--

CREATE TABLE payslip.salary (
    member text NOT NULL,
    "from" date NOT NULL,
    gross cella.amount
);


--
-- Name: basis(integer); Type: FUNCTION; Schema: patronage_payslip; Owner: -
--

CREATE FUNCTION patronage_payslip.basis(year integer) RETURNS TABLE(member text, cents bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT s.member,
     (sum(s.gross))::bigint AS sum
    FROM (generate_series(1, 12) m(n)
      CROSS JOIN LATERAL ( SELECT DISTINCT ON (x.member) x.member,
             cella.cents(x.gross) AS gross
            FROM payslip.salary x
           WHERE (x."from" <= make_date(basis.year, m.n, 1))
           ORDER BY x.member, x."from" DESC) s)
   GROUP BY s.member;
END;


--
-- Name: division(text); Type: FUNCTION; Schema: patronage_payslip; Owner: -
--

CREATE FUNCTION patronage_payslip.division(ref text) RETURNS TABLE(worker text, basis text, quantity bigint, cents bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    BEGIN ATOMIC
 WITH paid AS (
          SELECT b.member,
             b.cents,
             row_number() OVER (ORDER BY b.member) AS n
            FROM (patronage.distribution d
              CROSS JOIN LATERAL patronage_payslip.basis(d.year) b(member, cents))
           WHERE ((d.id = division.ref) AND (b.cents > 0))
         ), split AS (
          SELECT
                 CASE
                     WHEN ((patronage.portion(division.ref, 'salary'::text) > 0) AND (EXISTS ( SELECT
                        FROM paid))) THEN cella.allocate(cella.amount(patronage.portion(division.ref, 'salary'::text)), ( SELECT array_agg(p.cents ORDER BY p.n) AS array_agg
                        FROM paid p))
                     ELSE NULL::bigint[]
                 END AS salary,
                 CASE
                     WHEN ((patronage.portion(division.ref, 'equal'::text) > 0) AND (EXISTS ( SELECT
                        FROM paid))) THEN cella.allocate(cella.amount(patronage.portion(division.ref, 'equal'::text)), ( SELECT array_agg((1)::bigint ORDER BY p.n) AS array_agg
                        FROM paid p))
                     ELSE NULL::bigint[]
                 END AS equal
         )
  SELECT x.member,
     'salary'::text,
     x.cents,
     s.salary[x.n] AS salary
    FROM (paid x
      CROSS JOIN split s)
   WHERE (s.salary[x.n] > 0)
 UNION ALL
  SELECT x.member,
     'equal'::text,
     (1)::bigint AS int8,
     s.equal[x.n] AS equal
    FROM (paid x
      CROSS JOIN split s)
   WHERE (s.equal[x.n] > 0);
END;


--
-- Name: divides(jsonb); Type: FUNCTION; Schema: patronage_payslip; Owner: -
--

CREATE FUNCTION patronage_payslip.divides(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((EXISTS ( SELECT v.worker,
                 v.basis,
                 v.quantity,
                 v.cents
                FROM patronage_payslip.division(d.id) v(worker, basis, quantity, cents)
             EXCEPT ALL
              SELECT p.worker,
                 p.basis,
                 p.quantity,
                 cella.cents(p.amount) AS cents
                FROM patronage.part p
               WHERE ((p.distribution = d.id) AND (p.basis = ANY (ARRAY['salary'::text, 'equal'::text]))))) OR (EXISTS ( SELECT p.worker,
                 p.basis,
                 p.quantity,
                 cella.cents(p.amount) AS cents
                FROM patronage.part p
               WHERE ((p.distribution = d.id) AND (p.basis = ANY (ARRAY['salary'::text, 'equal'::text])))
             EXCEPT ALL
              SELECT v.worker,
                 v.basis,
                 v.quantity,
                 v.cents
                FROM patronage_payslip.division(d.id) v(worker, basis, quantity, cents)))) THEN ((d.id || '''s parts by pay and in equal parts are not its work share divided among those paid in '::text) || d.year)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (divides.payload ->> 'distribution'::text) AS distribution) x
      JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: parts(); Type: FUNCTION; Schema: patronage_payslip; Owner: -
--

CREATE FUNCTION patronage_payslip.parts() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.approved IS NULL AND NEW.approved IS NOT NULL THEN
    INSERT INTO patronage.part (distribution, worker, basis, quantity, amount)
    SELECT NEW.id, v.worker, v.basis, v.quantity, cella.amount(v.cents) FROM patronage_payslip.division(NEW.id) v;
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: month_of(date); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.month_of(day date) RETURNS text
    LANGUAGE sql IMMUTABLE
    RETURN to_char((day)::timestamp with time zone, 'YYYY-MM'::text);


--
-- Name: period; Type: TABLE; Schema: timesheet; Owner: -
--

CREATE TABLE timesheet.period (
    member text NOT NULL,
    month text NOT NULL,
    submitted date,
    approved date,
    approver text,
    CONSTRAINT period_check CHECK (((approved IS NULL) = (approver IS NULL))),
    CONSTRAINT period_month_check CHECK ((month ~ '^\d{4}-(0[1-9]|1[0-2])$'::text))
);


--
-- Name: basis(integer); Type: FUNCTION; Schema: patronage_timesheet; Owner: -
--

CREATE FUNCTION patronage_timesheet.basis(year integer) RETURNS TABLE(member text, minutes bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT e.member,
     sum(e.minutes) AS sum
    FROM (timesheet.entry e
      JOIN timesheet.period p ON (((p.member = e.member) AND (p.month = timesheet.month_of(e.day)))))
   WHERE ((p.approved IS NOT NULL) AND (e.day >= make_date(basis.year, 1, 1)) AND (e.day < make_date((basis.year + 1), 1, 1)))
   GROUP BY e.member;
END;


--
-- Name: division(text); Type: FUNCTION; Schema: patronage_timesheet; Owner: -
--

CREATE FUNCTION patronage_timesheet.division(ref text) RETURNS TABLE(worker text, minutes bigint, cents bigint)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    BEGIN ATOMIC
 WITH worked AS (
          SELECT b.member,
             b.minutes,
             row_number() OVER (ORDER BY b.member) AS n
            FROM (patronage.distribution d
              CROSS JOIN LATERAL patronage_timesheet.basis(d.year) b(member, minutes))
           WHERE ((d.id = division.ref) AND (b.minutes > 0))
         ), split AS (
          SELECT
                 CASE
                     WHEN ((patronage.portion(division.ref, 'hours'::text) > 0) AND (EXISTS ( SELECT
                        FROM worked))) THEN cella.allocate(cella.amount(patronage.portion(division.ref, 'hours'::text)), ( SELECT array_agg(w_1.minutes ORDER BY w_1.n) AS array_agg
                        FROM worked w_1))
                     ELSE NULL::bigint[]
                 END AS hours
         )
  SELECT w.member,
     w.minutes,
     s.hours[w.n] AS hours
    FROM (worked w
      CROSS JOIN split s)
   WHERE (s.hours[w.n] > 0);
END;


--
-- Name: divides(jsonb); Type: FUNCTION; Schema: patronage_timesheet; Owner: -
--

CREATE FUNCTION patronage_timesheet.divides(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((EXISTS ( SELECT v.worker,
                 v.minutes,
                 v.cents
                FROM patronage_timesheet.division(d.id) v(worker, minutes, cents)
             EXCEPT ALL
              SELECT p.worker,
                 p.quantity,
                 cella.cents(p.amount) AS cents
                FROM patronage.part p
               WHERE ((p.distribution = d.id) AND (p.basis = 'hours'::text)))) OR (EXISTS ( SELECT p.worker,
                 p.quantity,
                 cella.cents(p.amount) AS cents
                FROM patronage.part p
               WHERE ((p.distribution = d.id) AND (p.basis = 'hours'::text))
             EXCEPT ALL
              SELECT v.worker,
                 v.minutes,
                 v.cents
                FROM patronage_timesheet.division(d.id) v(worker, minutes, cents)))) THEN ((d.id || '''s parts by time worked are not its portion divided by the minutes approved in '::text) || d.year)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (divides.payload ->> 'distribution'::text) AS distribution) x
      JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: parts(); Type: FUNCTION; Schema: patronage_timesheet; Owner: -
--

CREATE FUNCTION patronage_timesheet.parts() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.approved IS NULL AND NEW.approved IS NOT NULL THEN
    INSERT INTO patronage.part (distribution, worker, basis, quantity, amount)
    SELECT NEW.id, v.worker, 'hours', v.minutes, cella.amount(v.cents) FROM patronage_timesheet.division(NEW.id) v;
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: posted(jsonb); Type: FUNCTION; Schema: patronage_transaction; Owner: -
--

CREATE FUNCTION patronage_transaction.posted(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.entry IS NULL) THEN (COALESCE(x.distribution, 'the distribution'::text) || ' posted no entry'::text)
             WHEN (e.date IS DISTINCT FROM d.distributed) THEN (p.entry || ' is not dated on the distribution'::text)
             WHEN (EXISTS ( SELECT l.account,
                 l.side,
                 l.cents
                FROM patronage_transaction.lines(x.distribution) l(account, side, cents)
             EXCEPT ALL
              SELECT t.account,
                 t.side,
                 cella.cents(t.amount) AS cents
                FROM transaction.line t
               WHERE (t.entry = p.entry))) THEN ((p.entry || ' does not post the split of '::text) || x.distribution)
             WHEN ((EXISTS ( SELECT
                FROM ( SELECT t.account,
                         t.side,
                         cella.cents(t.amount) AS cents
                        FROM transaction.line t
                       WHERE (t.entry = p.entry)
                     EXCEPT ALL
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM patronage_transaction.lines(x.distribution) l(account, side, cents)) r
               WHERE (r.account = '120'::text))) OR (( SELECT COALESCE(sum(
                     CASE r.side
                         WHEN 'debit'::text THEN r.cents
                         ELSE (- r.cents)
                     END), (0)::numeric) AS "coalesce"
                FROM ( SELECT t.account,
                         t.side,
                         cella.cents(t.amount) AS cents
                        FROM transaction.line t
                       WHERE (t.entry = p.entry)
                     EXCEPT ALL
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM patronage_transaction.lines(x.distribution) l(account, side, cents)) r) <> (0)::numeric)) THEN (((p.entry || ' posts more than the split of '::text) || x.distribution) || ', and not in balance away from the result'::text)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT (posted.payload ->> 'distribution'::text) AS distribution) x
      LEFT JOIN patronage.distribution d ON ((d.id = x.distribution)))
      LEFT JOIN patronage_transaction.distribution p ON ((p.distribution = x.distribution)))
      LEFT JOIN transaction.entry e ON ((e.id = p.entry)));
END;


--
-- Name: reserves(jsonb); Type: FUNCTION; Schema: patronage_transaction; Owner: -
--

CREATE FUNCTION patronage_transaction.reserves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (((patronage.share_of(d.id, 'legal'::text) * 100) < (cella.cents(d.surplus) * 15)) AND (( SELECT COALESCE(sum(
                     CASE l.side
                         WHEN 'credit'::text THEN cella.cents(l.amount)
                         ELSE (- cella.cents(l.amount))
                     END), (0)::numeric) AS "coalesce"
                FROM transaction.line l
               WHERE (l.account = '1061'::text)) < (patronage_transaction.highest())::numeric)) THEN (d.id || ' puts less than 15 % in the legal reserve, which is under the highest capital (loi 78-763, art. 33, 1°)'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (reserves.payload ->> 'distribution'::text) AS distribution) x
      JOIN patronage.distribution d ON ((d.id = x.distribution)));
END;


--
-- Name: after(text); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.after(month text) RETURNS date
    LANGUAGE sql IMMUTABLE
    RETURN ((to_date((month || '-01'::text), 'YYYY-MM-DD'::text) + '1 mon'::interval))::date;


--
-- Name: terms; Type: TABLE; Schema: payslip; Owner: -
--

CREATE TABLE payslip.terms (
    one boolean DEFAULT true NOT NULL,
    employee numeric(5,2) NOT NULL,
    employer numeric(5,2) NOT NULL,
    ratio numeric(4,2) NOT NULL,
    CONSTRAINT terms_employee_check CHECK (((employee >= (0)::numeric) AND (employee < (100)::numeric))),
    CONSTRAINT terms_employer_check CHECK ((employer >= (0)::numeric)),
    CONSTRAINT terms_one_check CHECK (one),
    CONSTRAINT terms_ratio_check CHECK ((ratio >= (1)::numeric))
);


--
-- Name: spread(text); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.spread(month text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((s.top)::numeric > ((s.bottom)::numeric * t.ratio)) THEN (((((((spread.month || '''s highest salary, '::text) || s.top) || ' cents, is more than '::text) || t.ratio) || ' times its lowest, '::text) || s.bottom) || ' cents'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT max(cella.cents(p.gross)) AS top,
             min(cella.cents(p.gross)) AS bottom
            FROM payslip.payslip p
           WHERE (p.month = spread.month)) s
      CROSS JOIN payslip.terms t);
END;


--
-- Name: run; Type: TABLE; Schema: payslip; Owner: -
--

CREATE TABLE payslip.run (
    month text NOT NULL,
    generated date NOT NULL,
    approved date,
    approver text,
    paid date,
    CONSTRAINT run_check CHECK (((approved IS NULL) = (approver IS NULL))),
    CONSTRAINT run_check1 CHECK (((paid IS NULL) OR (approved IS NOT NULL))),
    CONSTRAINT run_month_check CHECK ((month ~ '^\d{4}-(0[1-9]|1[0-2])$'::text))
);


--
-- Name: COLUMN run.approver; Type: COMMENT; Schema: payslip; Owner: -
--

COMMENT ON COLUMN payslip.run.approver IS 'not personal: the approver''s pseudonymous address';


--
-- Name: approves(jsonb); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.approves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (r.month IS NULL) THEN ('no run for '::text || COALESCE(x.month, 'the month'::text))
             WHEN ((r.approved IS DISTINCT FROM cella.verdict_date()) OR (r.approver IS DISTINCT FROM cella.actor())) THEN (r.month || '''s run was not approved by this write'::text)
             ELSE payslip.spread(r.month)
         END AS spread
    FROM (( SELECT (approves.payload ->> 'month'::text) AS month) x
      LEFT JOIN payslip.run r ON ((r.month = x.month)));
END;


--
-- Name: first(text); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.first(month text) RETURNS date
    LANGUAGE sql IMMUTABLE
    RETURN to_date((month || '-01'::text), 'YYYY-MM-DD'::text);


--
-- Name: due(text); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.due(month text) RETURNS TABLE(member text, gross bigint, employee bigint, employer bigint, net bigint)
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT s.member,
     s.gross,
     (round((((s.gross)::numeric * t.employee) / (100)::numeric)))::bigint AS round,
     (round((((s.gross)::numeric * t.employer) / (100)::numeric)))::bigint AS round,
     (s.gross - (round((((s.gross)::numeric * t.employee) / (100)::numeric)))::bigint)
    FROM (( SELECT DISTINCT ON (x.member) x.member,
             cella.cents(x.gross) AS gross
            FROM payslip.salary x
           WHERE (x."from" <= payslip.first(due.month))
           ORDER BY x.member, x."from" DESC) s
      CROSS JOIN payslip.terms t);
END;


--
-- Name: generates(jsonb); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.generates(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN ((r.month IS NULL) OR (r.generated IS DISTINCT FROM cella.verdict_date())) THEN (COALESCE(x.month, 'the month'::text) || '''s run was not prepared by this write'::text)
             WHEN (NOT (EXISTS ( SELECT
                FROM payslip.due(x.month) due(member, gross, employee, employer, net)))) THEN (x.month || ' has no salaried member'::text)
             WHEN ((EXISTS ( SELECT d.member,
                 d.gross,
                 d.employee,
                 d.employer,
                 d.net
                FROM payslip.due(x.month) d(member, gross, employee, employer, net)
             EXCEPT
              SELECT p.member,
                 cella.cents(p.gross) AS cents,
                 cella.cents(p.employee) AS cents,
                 cella.cents(p.employer) AS cents,
                 cella.cents(p.net) AS cents
                FROM payslip.payslip p
               WHERE (p.month = x.month))) OR (EXISTS ( SELECT p.member,
                 cella.cents(p.gross) AS cents,
                 cella.cents(p.employee) AS cents,
                 cella.cents(p.employer) AS cents,
                 cella.cents(p.net) AS cents
                FROM payslip.payslip p
               WHERE (p.month = x.month)
             EXCEPT
              SELECT d.member,
                 d.gross,
                 d.employee,
                 d.employer,
                 d.net
                FROM payslip.due(x.month) d(member, gross, employee, employer, net)))) THEN (x.month || '''s payslips are not what its salaried members are due'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (generates.payload ->> 'month'::text) AS month) x
      LEFT JOIN payslip.run r ON ((r.month = x.month)));
END;


--
-- Name: once(); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.once() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (SELECT FROM payslip.run r WHERE r.month = NEW.month) THEN
    RAISE EXCEPTION 'the % run was prepared on %', NEW.month, (SELECT r.generated FROM payslip.run r WHERE r.month = NEW.month)
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: pays(jsonb); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.pays(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (r.month IS NULL) THEN ('no run for '::text || COALESCE(x.month, 'the month'::text))
             WHEN (r.paid IS DISTINCT FROM cella.verdict_date()) THEN (r.month || '''s run was not paid by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (pays.payload ->> 'month'::text) AS month) x
      LEFT JOIN payslip.run r ON ((r.month = x.month)));
END;


--
-- Name: stays(); Type: FUNCTION; Schema: payslip; Owner: -
--

CREATE FUNCTION payslip.stays() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF TG_TABLE_NAME = 'payslip' AND TG_OP = 'UPDATE' AND cella.redacting() THEN
    RETURN NEW;
  END IF;
  IF TG_TABLE_NAME = 'run' THEN
    IF OLD.approved IS NOT NULL AND (NEW.approved, NEW.approver) IS DISTINCT FROM (OLD.approved, OLD.approver) THEN
      RAISE EXCEPTION 'the % run was approved on %', OLD.month, OLD.approved
        USING ERRCODE = 'triggered_action_exception';
    END IF;
    IF OLD.paid IS NOT NULL THEN
      RAISE EXCEPTION 'the % run was paid on %', OLD.month, OLD.paid
        USING ERRCODE = 'triggered_action_exception';
    END IF;
    IF NEW.paid IS NOT NULL AND NEW.approved IS NULL THEN
      RAISE EXCEPTION 'the % run is not approved', OLD.month
        USING ERRCODE = 'triggered_action_exception';
    END IF;
    RETURN NEW;
  END IF;
  IF EXISTS (SELECT FROM payslip.run r WHERE r.month = coalesce(NEW.month, OLD.month) AND r.approved IS NOT NULL) THEN
    RAISE EXCEPTION 'the % run is approved: its payslips never change', coalesce(NEW.month, OLD.month)
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN coalesce(NEW, OLD);
END
$$;


--
-- Name: minutes(text, text); Type: FUNCTION; Schema: payslip_timesheet; Owner: -
--

CREATE FUNCTION payslip_timesheet.minutes(member text, month text) RETURNS integer
    LANGUAGE sql STABLE
    RETURN (SELECT (COALESCE(sum(e.minutes), (0)::bigint))::integer AS "coalesce" FROM timesheet.entry e WHERE ((e.member = minutes.member) AND (timesheet.month_of(e.day) = minutes.month)));


--
-- Name: sheet; Type: VIEW; Schema: timesheet; Owner: -
--

CREATE VIEW timesheet.sheet WITH (security_invoker='true') AS
 SELECT p.member,
    p.month,
    p.submitted,
    p.approved,
    p.approver,
    (((COALESCE(sum(e.minutes), (0)::bigint))::numeric / 60.0))::numeric(6,2) AS hours,
    (((COALESCE(sum(e.minutes) FILTER (WHERE e.billable), (0)::bigint))::numeric / 60.0))::numeric(6,2) AS billable,
    (count(e.id))::integer AS entries,
        CASE
            WHEN (p.approved IS NOT NULL) THEN 'approved'::text
            WHEN (p.submitted IS NOT NULL) THEN 'submitted'::text
            ELSE 'open'::text
        END AS state
   FROM (timesheet.period p
     LEFT JOIN timesheet.entry e ON (((e.member = p.member) AND (timesheet.month_of(e.day) = p.month))))
  GROUP BY p.member, p.month, p.submitted, p.approved, p.approver;


--
-- Name: timed(jsonb); Type: FUNCTION; Schema: payslip_timesheet; Owner: -
--

CREATE FUNCTION payslip_timesheet.timed(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (u.member IS NOT NULL) THEN (((((u.member || '''s '::text) || x.month) || ' is '::text) || COALESCE(u.state, 'not logged'::text)) || ', not approved: the run waits for it'::text)
             WHEN (m.member IS NOT NULL) THEN (((m.member || '''s payslip for '::text) || x.month) || ' does not hold the minutes of their approved month'::text)
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (timed.payload ->> 'month'::text) AS month) x
      LEFT JOIN LATERAL ( SELECT p.member,
             s.state
            FROM (payslip.payslip p
              LEFT JOIN timesheet.sheet s ON (((s.member = p.member) AND (s.month = p.month))))
           WHERE ((p.month = x.month) AND (s.approved IS NULL))
           ORDER BY p.member
          LIMIT 1) u ON (true))
      LEFT JOIN LATERAL ( SELECT p.member
            FROM payslip.payslip p
           WHERE ((p.month = x.month) AND (p.minutes IS DISTINCT FROM payslip_timesheet.minutes(p.member, p.month)))
           ORDER BY p.member
          LIMIT 1) m ON (true));
END;


--
-- Name: unposted(text, text); Type: FUNCTION; Schema: payslip_transaction; Owner: -
--

CREATE FUNCTION payslip_transaction.unposted(ref text, event text) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (r.month IS NULL) THEN ('no run for '::text || COALESCE(unposted.ref, 'the month'::text))
             WHEN (p.entry IS NULL) THEN ((unposted.ref || '''s run posted no '::text) || unposted.event)
             WHEN (e.date IS DISTINCT FROM
             CASE unposted.event
                 WHEN 'accrual'::text THEN (payslip.after(unposted.ref) - 1)
                 ELSE r.paid
             END) THEN ((((p.entry || ' is not dated on '::text) || unposted.ref) || '''s '::text) || unposted.event)
             WHEN (EXISTS ( SELECT l.account,
                 l.side,
                 l.cents
                FROM payslip_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)
             EXCEPT ALL
              SELECT t.account,
                 t.side,
                 cella.cents(t.amount) AS cents
                FROM transaction.line t
               WHERE (t.entry = p.entry))) THEN ((((p.entry || ' does not post '::text) || unposted.ref) || '''s '::text) || unposted.event)
             WHEN ((EXISTS ( SELECT
                FROM ( SELECT t.account,
                         t.side,
                         cella.cents(t.amount) AS cents
                        FROM transaction.line t
                       WHERE (t.entry = p.entry)
                     EXCEPT ALL
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM payslip_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)) x
               WHERE ((x.side = 'credit'::text) AND ((x.account = '512'::text) OR (x.account IN ( SELECT l.account
                        FROM payslip_transaction.lines(unposted.ref, unposted.event) l(account, side, cents))))))) OR (( SELECT COALESCE(sum(
                     CASE x.side
                         WHEN 'debit'::text THEN x.cents
                         ELSE (- x.cents)
                     END), (0)::numeric) AS "coalesce"
                FROM ( SELECT t.account,
                         t.side,
                         cella.cents(t.amount) AS cents
                        FROM transaction.line t
                       WHERE (t.entry = p.entry)
                     EXCEPT ALL
                      SELECT l.account,
                         l.side,
                         l.cents
                        FROM payslip_transaction.lines(unposted.ref, unposted.event) l(account, side, cents)) x) <> (0)::numeric)) THEN (((((p.entry || ' posts more than '::text) || unposted.ref) || '''s '::text) || unposted.event) || ', and not in balance away from its own accounts and the bank'::text)
             ELSE NULL::text
         END AS "case"
    FROM (((( SELECT 1 AS "?column?") one
      LEFT JOIN payslip.run r ON ((r.month = unposted.ref)))
      LEFT JOIN payslip_transaction.posting p ON (((p.month = unposted.ref) AND (p.event = unposted.event))))
      LEFT JOIN transaction.entry e ON ((e.id = p.entry)));
END;


--
-- Name: accrued(jsonb); Type: FUNCTION; Schema: payslip_transaction; Owner: -
--

CREATE FUNCTION payslip_transaction.accrued(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN payslip_transaction.unposted((payload ->> 'month'::text), 'accrual'::text);


--
-- Name: paid(jsonb); Type: FUNCTION; Schema: payslip_transaction; Owner: -
--

CREATE FUNCTION payslip_transaction.paid(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    RETURN payslip_transaction.unposted((payload ->> 'month'::text), 'payment'::text);


--
-- Name: enrols(jsonb); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.enrols(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.address IS DISTINCT FROM cella.actor()) THEN ((cella.actor() || ' may not enrol a device for '::text) || COALESCE(p.address, 'no one'::text))
             WHEN (d.key IS NULL) THEN (('no device '::text || "left"(COALESCE(p.key, 'named'::text), 16)) || ' is enrolled'::text)
             WHEN ((d.address <> p.address) OR (d.enrolled_by IS DISTINCT FROM cella.device()) OR (d.enrolled <> cella.verdict_date())) THEN (('device '::text || "left"(p.key, 16)) || ' was not enrolled by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (enrols.payload ->> 'address'::text) AS address,
             (enrols.payload ->> 'key'::text) AS key) p
      LEFT JOIN person.device d ON ((encode(d.key, 'hex'::text) = p.key)));
END;


--
-- Name: forgets(jsonb); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.forgets(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.subject IS NULL) THEN 'the write erases nothing'::text
             WHEN (p.subject IS DISTINCT FROM cella.actor()) THEN (((cella.actor() || ' may not erase '::text) || p.subject) || '''s contact details'::text)
             WHEN ((p.erased IS DISTINCT FROM '["contact"]'::jsonb) OR (p.restricted IS DISTINCT FROM '[]'::jsonb)) THEN 'a person erases their contact details alone'::text
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,
             (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased,
             (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) -> 'restricted'::text) AS restricted) p;
END;


--
-- Name: own_profile(jsonb); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.own_profile(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (x.address IS NULL) THEN ('no one '::text || COALESCE(p.address, 'is named'::text))
             WHEN (x.address <> cella.actor()) THEN (((cella.actor() || ' may not edit '::text) || x.address) || '''s profile'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (own_profile.payload ->> 'person'::text) AS address) p
      LEFT JOIN person.person x ON ((x.address = p.address)));
END;


--
-- Name: revokes(jsonb); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.revokes(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.key IS NULL) THEN (('no device '::text || "left"(COALESCE(p.key, 'named'::text), 16)) || ' is enrolled'::text)
             WHEN (d.address <> cella.actor()) THEN ((((cella.actor() || ' may not revoke '::text) || d.address) || '''s '::text) || d.label)
             WHEN (d.revoked IS DISTINCT FROM cella.verdict_date()) THEN (((d.address || '''s '::text) || d.label) || ' was not revoked by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (revokes.payload ->> 'key'::text) AS key) p
      LEFT JOIN person.device d ON ((encode(d.key, 'hex'::text) = p.key)));
END;


--
-- Name: stays(); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.stays() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (NEW.key, NEW.address, NEW.enrolled, NEW.enrolled_by) IS DISTINCT FROM (OLD.key, OLD.address, OLD.enrolled, OLD.enrolled_by)
    OR (OLD.revoked IS NOT NULL AND NEW.revoked IS DISTINCT FROM OLD.revoked) THEN
    RAISE EXCEPTION 'device % of % keeps its key, address and enrolment, and stays revoked', OLD.label, OLD.address
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: verifies(text, bytea); Type: FUNCTION; Schema: person; Owner: -
--

CREATE FUNCTION person.verifies(actor text, device bytea) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (d.key IS NULL) THEN (('device '::text || "left"(encode(x.device, 'hex'::text), 16)) || ' is not enrolled'::text)
             WHEN (d.address <> x.actor) THEN ((((((d.address || '''s '::text) || d.label) || ' signs for '::text) || d.address) || ', not for '::text) || x.actor)
             WHEN (d.revoked IS NOT NULL) THEN ((((d.address || '''s '::text) || d.label) || ' was revoked on '::text) || to_char((d.revoked)::timestamp with time zone, 'YYYY-MM-DD'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT verifies.actor AS actor,
             verifies.device AS device) x
      LEFT JOIN person.device d ON ((d.key = x.device)));
END;


--
-- Name: budgets(jsonb); Type: FUNCTION; Schema: project; Owner: -
--

CREATE FUNCTION project.budgets(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.id IS NULL) THEN ('no project '::text || COALESCE(w.id, 'is named'::text))
             WHEN (cella.cents(p.budget) IS DISTINCT FROM w.cents) THEN (p.id || '''s budget was not set by this write'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (budgets.payload ->> 'project'::text) AS id,
             ((budgets.payload ->> 'amount'::text))::bigint AS cents) w
      LEFT JOIN project.project p ON ((p.id = w.id)));
END;


--
-- Name: live(); Type: FUNCTION; Schema: project; Owner: -
--

CREATE FUNCTION project.live() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  archived date;
BEGIN
  SELECT p.archived INTO archived FROM project.project p WHERE p.id = NEW.project;
  IF archived IS NOT NULL THEN
    RAISE EXCEPTION '% was archived on %: its milestones change no more', NEW.project, archived
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: stays_archived(); Type: FUNCTION; Schema: project; Owner: -
--

CREATE FUNCTION project.stays_archived() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.archived IS NOT NULL THEN
    RAISE EXCEPTION '% was archived on %', OLD.id, OLD.archived
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: project_task; Owner: -
--

CREATE FUNCTION project_task.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  archived date;
BEGIN
  IF NOT EXISTS (SELECT FROM task.task t WHERE t.id = NEW.task) THEN
    RAISE EXCEPTION 'no task %', NEW.task USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT p.archived INTO archived FROM project.project p WHERE p.id = NEW.project;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no project %', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF archived IS NOT NULL THEN
    RAISE EXCEPTION '% was archived on %: it takes no tasks', NEW.project, archived USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NEW.milestone IS NOT NULL AND NOT EXISTS (
    SELECT FROM project.milestone m WHERE m.project = NEW.project AND m.n = NEW.milestone
  ) THEN
    RAISE EXCEPTION '% has no milestone %', NEW.project, NEW.milestone USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: resolves(); Type: FUNCTION; Schema: project_timesheet; Owner: -
--

CREATE FUNCTION project_timesheet.resolves() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  archived date;
BEGIN
  IF NOT EXISTS (SELECT FROM timesheet.entry e WHERE e.id = NEW.entry) THEN
    RAISE EXCEPTION 'no entry %', NEW.entry USING ERRCODE = 'triggered_action_exception';
  END IF;
  SELECT p.archived INTO archived FROM project.project p WHERE p.id = NEW.project;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'no project %', NEW.project USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF archived IS NOT NULL THEN
    RAISE EXCEPTION '% was archived on %: it takes no time', NEW.project, archived USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: period_end(text); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.period_end(month text) RETURNS date
    LANGUAGE sql IMMUTABLE
    RETURN ((to_date((month || '-01'::text), 'YYYY-MM-DD'::text) + '1 mon'::interval))::date;


--
-- Name: approves(jsonb); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.approves(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (p.member IS NULL) THEN ((('no timesheet '::text || COALESCE(w.member, '?'::text)) || ' '::text) || COALESCE(w.month, '?'::text))
             WHEN ((p.approved IS DISTINCT FROM cella.verdict_date()) OR (p.approver IS DISTINCT FROM cella.actor())) THEN (((p.member || '''s '::text) || p.month) || ' was not approved by this write'::text)
             WHEN (p.approver = p.member) THEN (p.member || ' may not approve their own time'::text)
             WHEN (p.approved < timesheet.period_end(p.month)) THEN ((p.month || ' runs until '::text) || to_char(((timesheet.period_end(p.month) - 1))::timestamp with time zone, 'YYYY-MM-DD'::text))
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (approves.payload ->> 'member'::text) AS member,
             (approves.payload ->> 'month'::text) AS month) w
      LEFT JOIN timesheet.period p ON (((p.member = w.member) AND (p.month = w.month))));
END;


--
-- Name: logs(jsonb); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.logs(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (w.member IS DISTINCT FROM cella.actor()) THEN ((COALESCE(cella.actor(), 'no one'::text) || ' may not log time for '::text) || COALESCE(w.member, 'no one'::text))
             WHEN (w.day > cella.verdict_date()) THEN (('an entry for '::text || (w.day)::text) || ' is in the future'::text)
             ELSE NULL::text
         END AS "case"
    FROM ( SELECT (logs.payload ->> 'member'::text) AS member,
             ((logs.payload ->> 'day'::text))::date AS day) w;
END;


--
-- Name: open_period(); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.open_period() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  period text := timesheet.month_of(NEW.day);
  approved date;
BEGIN
  INSERT INTO timesheet.period (member, month) VALUES (NEW.member, period) ON CONFLICT DO NOTHING;
  SELECT p.approved INTO approved FROM timesheet.period p WHERE p.member = NEW.member AND p.month = period FOR SHARE;
  IF approved IS NOT NULL THEN
    RAISE EXCEPTION '%''s % was approved on %: it takes no new entries', NEW.member, period, approved
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: stays_approved(); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.stays_approved() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.approved IS NOT NULL THEN
    RAISE EXCEPTION '%''s % was approved on %', OLD.member, OLD.month, OLD.approved
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  IF NEW.approved IS NOT NULL AND NEW.submitted IS NULL THEN
    RAISE EXCEPTION '%''s % is not submitted', NEW.member, NEW.month
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NEW;
END
$$;


--
-- Name: submits(jsonb); Type: FUNCTION; Schema: timesheet; Owner: -
--

CREATE FUNCTION timesheet.submits(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (w.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may not submit '::text) || COALESCE(w.member, 'no one'::text)) || '''s time'::text)
             WHEN ((s.member IS NULL) OR (s.submitted IS NULL)) THEN (((w.member || '''s '::text) || w.month) || ' was not submitted by this write'::text)
             WHEN (s.entries = 0) THEN (((w.member || '''s '::text) || w.month) || ' has no time in it'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (submits.payload ->> 'member'::text) AS member,
             (submits.payload ->> 'month'::text) AS month) w
      LEFT JOIN timesheet.sheet s ON (((s.member = w.member) AND (s.month = w.month))));
END;


--
-- Name: amount(text); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.amount(entry text) RETURNS bigint
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    RETURN (SELECT (COALESCE(sum(cella.cents(l.amount)), (0)::numeric))::bigint AS "coalesce" FROM transaction.line l WHERE ((l.entry = amount.entry) AND (l.side = 'debit'::text)));


--
-- Name: balances(); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.balances() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  ref text;
  lines integer;
  debit bigint;
  credit bigint;
BEGIN
  IF TG_TABLE_NAME = 'entry' THEN
    ref := NEW.id;
  ELSE
    ref := NEW.entry;
  END IF;
  SELECT count(*),
         coalesce(sum(cella.cents(l.amount)) FILTER (WHERE l.side = 'debit'), 0),
         coalesce(sum(cella.cents(l.amount)) FILTER (WHERE l.side = 'credit'), 0)
  INTO lines, debit, credit
  FROM transaction.line l WHERE l.entry = ref;
  IF lines < 2 OR debit <> credit THEN
    RAISE EXCEPTION '% does not balance: % lines debit % and credit % cents', ref, lines, debit, credit
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  RETURN NULL;
END
$$;


--
-- Name: corrects(jsonb); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.corrects(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no entry '::text || COALESCE(x.entry, 'is named'::text))
             WHEN (e.corrects IS DISTINCT FROM x.corrects) THEN ((e.id || ' does not correct '::text) || COALESCE(x.corrects, 'an entry'::text))
             WHEN (latest.id IS DISTINCT FROM x.base) THEN ((((x.corrects || ' moved: its correction is '::text) || COALESCE(latest.id, 'none'::text)) || ', not '::text) || COALESCE(x.base, 'none'::text))
             ELSE NULL::text
         END AS "case"
    FROM ((( SELECT (corrects.payload ->> 'entry'::text) AS entry,
             (corrects.payload ->> 'corrects'::text) AS corrects,
             (corrects.payload ->> 'base'::text) AS base) x
      LEFT JOIN transaction.entry e ON ((e.id = x.entry)))
      LEFT JOIN LATERAL ( SELECT c.id
            FROM transaction.entry c
           WHERE ((c.corrects = x.corrects) AND (c.id <> x.entry) AND (c.receipt < e.receipt))
           ORDER BY c.receipt DESC
          LIMIT 1) latest ON (true));
END;


--
-- Name: numbers(); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.numbers() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
DECLARE
  n integer;
  next text;
BEGIN
  UPDATE transaction.journal SET last = last + 1 RETURNING last INTO n;
  next := 'je-' || lpad(n::text, 4, '0');
  IF NEW.id IS NOT NULL AND NEW.id <> next THEN
    RAISE EXCEPTION '% is not the journal''s next entry, %', NEW.id, next
      USING ERRCODE = 'triggered_action_exception';
  END IF;
  NEW.id := next;
  RETURN NEW;
END
$$;


--
-- Name: pays(jsonb); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.pays(payload jsonb) RETURNS text
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT
         CASE
             WHEN (e.id IS NULL) THEN ('no entry '::text || COALESCE(p.entry, 'is named'::text))
             WHEN (p.amount IS NULL) THEN (e.id || ' names no amount'::text)
             WHEN ( SELECT ((count(*) FILTER (WHERE (NOT (((l.account = '401'::text) AND (l.side = 'debit'::text)) OR ((l.account = '512'::text) AND (l.side = 'credit'::text))))) <> 0) OR (count(*) <> 2) OR (count(DISTINCT l.account) <> 2) OR bool_or((cella.cents(l.amount) <> p.amount)))
                FROM transaction.line l
               WHERE (l.entry = e.id)) THEN (((e.id || ' is not a payment of '::text) || p.amount) || ' cents: 401 debited and 512 credited by it, nothing else'::text)
             ELSE NULL::text
         END AS "case"
    FROM (( SELECT (pays.payload ->> 'entry'::text) AS entry,
             ((pays.payload ->> 'amount'::text))::bigint AS amount) p
      LEFT JOIN transaction.entry e ON ((e.id = p.entry)));
END;


--
-- Name: permanent(); Type: FUNCTION; Schema: transaction; Owner: -
--

CREATE FUNCTION transaction.permanent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'the journal is permanent: a %''s rows never change; a correction is a new entry', TG_TABLE_NAME
    USING ERRCODE = 'triggered_action_exception';
END
$$;


--
-- Name: report; Type: VIEW; Schema: account; Owner: -
--

CREATE VIEW account.report AS
 WITH months AS (
         SELECT to_date(p.month, 'YYYY-MM'::text) AS first,
            p.closed
           FROM account.period p
        ), spans AS (
         SELECT 'month'::text AS kind,
            months.first AS since,
            '1 mon'::interval AS length,
            months.closed
           FROM months
        UNION ALL
         SELECT 'quarter'::text,
            (date_trunc('quarter'::text, (months.first)::timestamp with time zone))::date AS date_trunc,
            '3 mons'::interval AS "interval",
            months.closed
           FROM months
        UNION ALL
         SELECT 'year'::text,
            (date_trunc('year'::text, (months.first)::timestamp with time zone))::date AS date_trunc,
            '1 year'::interval AS "interval",
            months.closed
           FROM months
        ), grouped AS (
         SELECT spans.kind,
            spans.since,
            spans.length,
            bool_and((spans.closed IS NOT NULL)) AS closed
           FROM spans
          GROUP BY spans.kind, spans.since, spans.length
        )
 SELECT
        CASE kind
            WHEN 'month'::text THEN to_char((since)::timestamp with time zone, 'YYYY-MM'::text)
            WHEN 'quarter'::text THEN to_char((since)::timestamp with time zone, 'YYYY-"Q"Q'::text)
            ELSE to_char((since)::timestamp with time zone, 'YYYY'::text)
        END AS id,
    kind,
    since,
    (((since + length))::date - 1) AS until,
        CASE kind
            WHEN 'month'::text THEN to_char((since - length), 'YYYY-MM'::text)
            WHEN 'quarter'::text THEN to_char((since - length), 'YYYY-"Q"Q'::text)
            ELSE to_char((since - length), 'YYYY'::text)
        END AS before,
    ((since - length))::date AS before_since,
    (since - 1) AS before_until,
    closed
   FROM grouped;


--
-- Name: owed; Type: VIEW; Schema: account_membership_transaction; Owner: -
--

CREATE VIEW account_membership_transaction.owed WITH (security_invoker='true') AS
 SELECT member,
    (count(*))::integer AS repayments,
    (sum(cella.cents(amount)))::bigint AS amount,
    (COALESCE(sum(cella.cents(amount)) FILTER (WHERE (paid IS NOT NULL)), (0)::numeric))::bigint AS repaid,
    (COALESCE(sum(cella.cents(amount)) FILTER (WHERE (paid IS NULL)), (0)::numeric))::bigint AS "left",
    min(due) FILTER (WHERE (paid IS NULL)) AS next
   FROM account_membership_transaction.repayment r
  GROUP BY member;


--
-- Name: authority; Type: TABLE; Schema: cella; Owner: -
--

CREATE TABLE cella.authority (
    one boolean DEFAULT true NOT NULL,
    fn regprocedure NOT NULL,
    owner text NOT NULL,
    CONSTRAINT authority_one_check CHECK (one)
);


--
-- Name: reach; Type: TABLE; Schema: cella; Owner: -
--

CREATE TABLE cella.reach (
    what text NOT NULL,
    fn regprocedure NOT NULL,
    owner text NOT NULL
);


--
-- Name: mandate_id_seq; Type: SEQUENCE; Schema: circle; Owner: -
--

ALTER TABLE circle.mandate ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME circle.mandate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setting; Type: TABLE; Schema: circle_meeting; Owner: -
--

CREATE TABLE circle_meeting.setting (
    circle text NOT NULL,
    quorum integer DEFAULT 50 NOT NULL,
    adopts boolean DEFAULT false NOT NULL,
    CONSTRAINT setting_quorum_check CHECK (((quorum >= 1) AND (quorum <= 100)))
);


--
-- Name: attendance; Type: TABLE; Schema: meeting_membership; Owner: -
--

CREATE TABLE meeting_membership.attendance (
    meeting text NOT NULL,
    member text NOT NULL,
    status text NOT NULL,
    marked date,
    by text,
    CONSTRAINT attendance_status_check CHECK ((status = ANY (ARRAY['present'::text, 'excused'::text, 'absent'::text])))
);


--
-- Name: roll; Type: VIEW; Schema: circle_meeting_membership; Owner: -
--

CREATE VIEW circle_meeting_membership.roll AS
 SELECT m.id AS meeting,
    s.member,
    true AS seated,
    a.status
   FROM ((meeting.meeting m
     CROSS JOIN LATERAL circle_membership.seated(m.circle, (m.at)::date) s(member))
     LEFT JOIN meeting_membership.attendance a ON (((a.meeting = m.id) AND (a.member = s.member))))
UNION ALL
 SELECT a.meeting,
    a.member,
    false AS seated,
    a.status
   FROM (meeting_membership.attendance a
     JOIN meeting.meeting m ON ((m.id = a.meeting)))
  WHERE (NOT (EXISTS ( SELECT
           FROM circle_membership.seated(m.circle, (m.at)::date) s(s)
          WHERE (s.s = a.member))));


--
-- Name: quorum; Type: VIEW; Schema: circle_meeting_membership; Owner: -
--

CREATE VIEW circle_meeting_membership.quorum AS
 SELECT m.id AS meeting,
    (count(r.member) FILTER (WHERE r.seated))::integer AS seats,
    (count(r.member) FILTER (WHERE (r.seated AND (r.status = 'present'::text))))::integer AS present,
    (ceil((((count(r.member) FILTER (WHERE r.seated) * COALESCE(s.quorum, 50)))::numeric / 100.0)))::integer AS needed
   FROM ((meeting.meeting m
     LEFT JOIN circle_meeting_membership.roll r ON ((r.meeting = m.id)))
     LEFT JOIN circle_meeting.setting s ON ((s.circle = m.circle)))
  GROUP BY m.id, s.quorum;


--
-- Name: position_id_seq; Type: SEQUENCE; Schema: circle_membership; Owner: -
--

ALTER TABLE circle_membership."position" ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME circle_membership.position_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: billing; Type: TABLE; Schema: client_invoice; Owner: -
--

CREATE TABLE client_invoice.billing (
    invoice text NOT NULL,
    client text NOT NULL
);


--
-- Name: standing; Type: VIEW; Schema: invoice; Owner: -
--

CREATE VIEW invoice.standing AS
 SELECT i.id,
    i.bill_to,
    i.due,
    cella.cents(i.total) AS total,
    COALESCE(p.paid, (0)::bigint) AS paid,
        CASE
            WHEN (i.voided IS NOT NULL) THEN (0)::bigint
            ELSE GREATEST((cella.cents(i.total) - COALESCE(p.paid, (0)::bigint)), (0)::bigint)
        END AS owed,
        CASE
            WHEN (i.voided IS NOT NULL) THEN COALESCE(p.paid, (0)::bigint)
            ELSE GREATEST((COALESCE(p.paid, (0)::bigint) - cella.cents(i.total)), (0)::bigint)
        END AS credit,
        CASE
            WHEN (i.voided IS NOT NULL) THEN 'voided'::text
            WHEN (COALESCE(p.paid, (0)::bigint) = 0) THEN 'unpaid'::text
            WHEN (p.paid < cella.cents(i.total)) THEN 'partial'::text
            WHEN (p.paid = cella.cents(i.total)) THEN 'paid'::text
            ELSE 'overpaid'::text
        END AS state
   FROM (invoice.invoice i
     LEFT JOIN ( SELECT payment.invoice,
            (sum(cella.cents(payment.amount)))::bigint AS paid
           FROM invoice.payment
          GROUP BY payment.invoice) p ON ((p.invoice = i.id)));


--
-- Name: standing; Type: VIEW; Schema: client_invoice; Owner: -
--

CREATE VIEW client_invoice.standing AS
 SELECT c.id AS client,
    c.name,
    (COALESCE(sum(s.owed), (0)::numeric))::bigint AS owed,
    (COALESCE(sum(s.credit), (0)::numeric))::bigint AS credit
   FROM ((client.client c
     LEFT JOIN client_invoice.billing b ON ((b.client = c.id)))
     LEFT JOIN invoice.standing s ON ((s.id = b.invoice)))
  GROUP BY c.id, c.name;


--
-- Name: commission; Type: TABLE; Schema: client_project; Owner: -
--

CREATE TABLE client_project.commission (
    project text NOT NULL,
    client text NOT NULL
);


--
-- Name: cites; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.cites (
    op text NOT NULL,
    owner text NOT NULL
);


--
-- Name: kind; Type: TABLE; Schema: decision; Owner: -
--

CREATE TABLE decision.kind (
    kind text NOT NULL,
    label text NOT NULL,
    fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    owner text NOT NULL,
    CONSTRAINT kind_fields_check CHECK ((jsonb_typeof(fields) = 'array'::text)),
    CONSTRAINT kind_kind_check CHECK ((kind ~ '^[a-z][a-z-]*$'::text))
);


--
-- Name: path; Type: VIEW; Schema: employment_membership; Owner: -
--

CREATE VIEW employment_membership.path AS
 SELECT x.address,
    x.name,
    w.start AS hired,
    w.until AS "left",
    c."from" AS probation,
    c."to" AS probation_end,
    c.shares AS pledged,
    m.invited,
    m.since AS admitted,
    m.exited,
    m.status,
        CASE
            WHEN (m.status = 'exited'::text) THEN 'gone'::text
            WHEN (m.status = ANY (ARRAY['active'::text, 'suspended'::text])) THEN 'member'::text
            WHEN (m.status = 'invited'::text) THEN 'invited'::text
            WHEN (c.worker IS NOT NULL) THEN 'candidate'::text
            ELSE 'employee'::text
        END AS stage
   FROM (((person.person x
     LEFT JOIN employment.worker w ON ((w.address = x.address)))
     LEFT JOIN membership.member m ON ((m.address = x.address)))
     LEFT JOIN employment_membership.candidacy c ON ((c.worker = x.address)))
  WHERE ((w.address IS NOT NULL) OR (m.address IS NOT NULL));


--
-- Name: admission; Type: VIEW; Schema: decision_employment_membership; Owner: -
--

CREATE VIEW decision_employment_membership.admission AS
 SELECT p.address,
    p.name,
    p.stage,
    p.hired,
    p.probation_end,
    p.pledged,
    d.id AS decision,
    d.title,
    d.deadline,
    d.closed,
    ((p.stage = 'invited'::text) AND (p.probation_end < cella.verdict_date()) AND ((d.id IS NULL) OR (d.closed IS NOT NULL))) AS due
   FROM (employment_membership.path p
     LEFT JOIN LATERAL ( SELECT x.id,
            x.title,
            x.deadline,
            x.closed
           FROM (decision_membership.motion m
             JOIN decision.decision x ON ((x.id = m.decision)))
          WHERE ((m.kind = 'admit'::text) AND (m.member = p.address))
          ORDER BY (x.closed IS NULL) DESC, x.proposed DESC, x.id DESC
         LIMIT 1) d ON (true))
  WHERE ((p.probation IS NOT NULL) AND (p.stage = ANY (ARRAY['candidate'::text, 'invited'::text])));


--
-- Name: tabled; Type: TABLE; Schema: decision_meeting; Owner: -
--

CREATE TABLE decision_meeting.tabled (
    item bigint NOT NULL,
    meeting text NOT NULL,
    decision text NOT NULL
);


--
-- Name: mention; Type: VIEW; Schema: decision_membership; Owner: -
--

CREATE VIEW decision_membership.mention AS
 SELECT x.receipt AS message,
    x.decision,
    x.member AS author,
    h.handle,
    decision_membership.named(h.handle) AS member,
    x.at
   FROM (decision.message x
     CROSS JOIN LATERAL unnest(x.mentions) h(handle));


--
-- Name: adopted; Type: VIEW; Schema: document; Owner: -
--

CREATE VIEW document.adopted AS
 SELECT DISTINCT ON (document) document,
    version,
    adopted,
    receipt
   FROM document.adoption a
  ORDER BY document, receipt DESC;


--
-- Name: comment; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.comment (
    id bigint NOT NULL,
    version text NOT NULL,
    author text NOT NULL,
    at date NOT NULL,
    quote text NOT NULL,
    anchor jsonb,
    text text NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    CONSTRAINT comment_anchor_check CHECK (((anchor IS NULL) OR ((anchor ? 'block'::text) AND (anchor ? 'from'::text) AND (anchor ? 'to'::text)))),
    CONSTRAINT comment_quote_check CHECK ((quote <> ''::text))
);


--
-- Name: comment_id_seq; Type: SEQUENCE; Schema: document; Owner: -
--

ALTER TABLE document.comment ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME document.comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: update; Type: TABLE; Schema: document; Owner: -
--

CREATE TABLE document.update (
    receipt bigint NOT NULL,
    document text NOT NULL,
    author text,
    at date NOT NULL,
    bytes bytea NOT NULL
);


--
-- Name: texts; Type: VIEW; Schema: document_membership; Owner: -
--

CREATE VIEW document_membership.texts AS
 SELECT m.address AS member,
    d.id AS document,
    d.title,
    a.version,
    a.adopted,
    r.read
   FROM (((membership.member m
     CROSS JOIN document.adopted a)
     JOIN document.document d ON ((d.id = a.document)))
     LEFT JOIN document_membership.reading r ON (((r.version = a.version) AND (r.member = m.address))));


--
-- Name: slip; Type: VIEW; Schema: employment_payslip; Owner: -
--

CREATE VIEW employment_payslip.slip WITH (security_invoker='true') AS
 SELECT p.month,
    p.member,
    wp.name,
    w.job
   FROM (payslip.payslip p
     JOIN (employment.worker w
     JOIN person.person wp ON ((wp.address = w.address))) ON ((w.address = p.member)));


--
-- Name: sheet; Type: VIEW; Schema: employment_timesheet; Owner: -
--

CREATE VIEW employment_timesheet.sheet WITH (security_invoker='true') AS
 SELECT s.member,
    wp.name,
    s.month,
    s.hours,
    s.billable,
    s.entries,
    s.state,
    s.submitted,
    s.approved,
    s.approver,
    ap.name AS approver_name
   FROM ((timesheet.sheet s
     JOIN (employment.worker w
     JOIN person.person wp ON ((wp.address = w.address))) ON ((w.address = s.member)))
     LEFT JOIN (employment.worker a
     JOIN person.person ap ON ((ap.address = a.address))) ON ((a.address = s.approver)));


--
-- Name: claim; Type: VIEW; Schema: expense_membership; Owner: -
--

CREATE VIEW expense_membership.claim AS
 SELECT e.id AS expense,
    e.member,
    mp.name,
    e.decider,
    dp.name AS decider_name
   FROM ((expense.expense e
     JOIN (membership.member m
     JOIN person.person mp ON ((mp.address = m.address))) ON ((m.address = e.member)))
     LEFT JOIN (membership.member d
     JOIN person.person dp ON ((dp.address = d.address))) ON ((d.address = e.decider)));


--
-- Name: contract; Type: TABLE; Schema: file; Owner: -
--

CREATE TABLE file.contract (
    id text DEFAULT ('fi-'::text || lpad((nextval('file.number'::regclass))::text, 4, '0'::text)) CONSTRAINT file_id_not_null NOT NULL,
    class text CONSTRAINT file_class_not_null NOT NULL,
    subject text,
    name text CONSTRAINT file_name_not_null NOT NULL,
    type text CONSTRAINT file_type_not_null NOT NULL,
    size integer CONSTRAINT file_size_not_null NOT NULL,
    bytes bytea,
    hash bytea GENERATED ALWAYS AS (cella.digest(bytes)) STORED,
    uploader text CONSTRAINT file_uploader_not_null NOT NULL,
    uploaded date CONSTRAINT file_uploaded_not_null NOT NULL,
    CONSTRAINT file_check CHECK (((class = 'none'::text) = (subject IS NULL))),
    CONSTRAINT file_check1 CHECK (((bytes IS NULL) OR (octet_length(bytes) = size))),
    CONSTRAINT file_class_check CHECK ((class = ANY (ARRAY['none'::text, 'expense-receipt'::text, 'payroll'::text, 'profile'::text]))),
    CONSTRAINT file_name_check CHECK ((name <> ''::text)),
    CONSTRAINT file_size_check CHECK (((size > 0) AND (size <= file.largest()))),
    CONSTRAINT file_type_check CHECK ((type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))
);


--
-- Name: receipt; Type: TABLE; Schema: file; Owner: -
--

CREATE TABLE file.receipt (
    id text DEFAULT ('fi-'::text || lpad((nextval('file.number'::regclass))::text, 4, '0'::text)) CONSTRAINT file_id_not_null NOT NULL,
    class text CONSTRAINT file_class_not_null NOT NULL,
    subject text,
    name text CONSTRAINT file_name_not_null NOT NULL,
    type text CONSTRAINT file_type_not_null NOT NULL,
    size integer CONSTRAINT file_size_not_null NOT NULL,
    bytes bytea,
    hash bytea GENERATED ALWAYS AS (cella.digest(bytes)) STORED,
    uploader text CONSTRAINT file_uploader_not_null NOT NULL,
    uploaded date CONSTRAINT file_uploaded_not_null NOT NULL,
    CONSTRAINT file_check CHECK (((class = 'none'::text) = (subject IS NULL))),
    CONSTRAINT file_check1 CHECK (((bytes IS NULL) OR (octet_length(bytes) = size))),
    CONSTRAINT file_class_check CHECK ((class = ANY (ARRAY['none'::text, 'expense-receipt'::text, 'payroll'::text, 'profile'::text]))),
    CONSTRAINT file_name_check CHECK ((name <> ''::text)),
    CONSTRAINT file_size_check CHECK (((size > 0) AND (size <= file.largest()))),
    CONSTRAINT file_type_check CHECK ((type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))
);


--
-- Name: record; Type: TABLE; Schema: file; Owner: -
--

CREATE TABLE file.record (
    id text DEFAULT ('fi-'::text || lpad((nextval('file.number'::regclass))::text, 4, '0'::text)) CONSTRAINT file_id_not_null NOT NULL,
    class text CONSTRAINT file_class_not_null NOT NULL,
    subject text,
    name text CONSTRAINT file_name_not_null NOT NULL,
    type text CONSTRAINT file_type_not_null NOT NULL,
    size integer CONSTRAINT file_size_not_null NOT NULL,
    bytes bytea,
    hash bytea GENERATED ALWAYS AS (cella.digest(bytes)) STORED,
    uploader text CONSTRAINT file_uploader_not_null NOT NULL,
    uploaded date CONSTRAINT file_uploaded_not_null NOT NULL,
    CONSTRAINT file_check CHECK (((class = 'none'::text) = (subject IS NULL))),
    CONSTRAINT file_check1 CHECK (((bytes IS NULL) OR (octet_length(bytes) = size))),
    CONSTRAINT file_class_check CHECK ((class = ANY (ARRAY['none'::text, 'expense-receipt'::text, 'payroll'::text, 'profile'::text]))),
    CONSTRAINT file_name_check CHECK ((name <> ''::text)),
    CONSTRAINT file_size_check CHECK (((size > 0) AND (size <= file.largest()))),
    CONSTRAINT file_type_check CHECK ((type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))
);


--
-- Name: shared; Type: TABLE; Schema: file; Owner: -
--

CREATE TABLE file.shared (
    id text DEFAULT ('fi-'::text || lpad((nextval('file.number'::regclass))::text, 4, '0'::text)) CONSTRAINT file_id_not_null NOT NULL,
    class text CONSTRAINT file_class_not_null NOT NULL,
    subject text,
    name text CONSTRAINT file_name_not_null NOT NULL,
    type text CONSTRAINT file_type_not_null NOT NULL,
    size integer CONSTRAINT file_size_not_null NOT NULL,
    bytes bytea,
    hash bytea GENERATED ALWAYS AS (cella.digest(bytes)) STORED,
    uploader text CONSTRAINT file_uploader_not_null NOT NULL,
    uploaded date CONSTRAINT file_uploaded_not_null NOT NULL,
    CONSTRAINT file_check CHECK (((class = 'none'::text) = (subject IS NULL))),
    CONSTRAINT file_check1 CHECK (((bytes IS NULL) OR (octet_length(bytes) = size))),
    CONSTRAINT file_class_check CHECK ((class = ANY (ARRAY['none'::text, 'expense-receipt'::text, 'payroll'::text, 'profile'::text]))),
    CONSTRAINT file_name_check CHECK ((name <> ''::text)),
    CONSTRAINT file_size_check CHECK (((size > 0) AND (size <= file.largest()))),
    CONSTRAINT file_type_check CHECK ((type ~ '^[a-z]+/[a-z0-9.+-]+$'::text))
);


--
-- Name: line; Type: TABLE; Schema: invoice; Owner: -
--

CREATE TABLE invoice.line (
    invoice text NOT NULL,
    n integer NOT NULL,
    description text NOT NULL,
    quantity numeric(12,3) NOT NULL,
    unit_price cella.amount NOT NULL,
    amount cella.amount NOT NULL,
    vat_rate numeric(5,2) NOT NULL,
    CONSTRAINT line_check CHECK (((cella.cents(amount))::numeric = round((quantity * (cella.cents(unit_price))::numeric)))),
    CONSTRAINT line_n_check CHECK ((n > 0)),
    CONSTRAINT line_quantity_check CHECK ((quantity > (0)::numeric)),
    CONSTRAINT line_vat_rate_check CHECK ((vat_rate >= (0)::numeric))
);


--
-- Name: payment_id_seq; Type: SEQUENCE; Schema: invoice; Owner: -
--

ALTER TABLE invoice.payment ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME invoice.payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: item; Type: TABLE; Schema: meeting; Owner: -
--

CREATE TABLE meeting.item (
    id bigint NOT NULL,
    meeting text NOT NULL,
    pos double precision NOT NULL,
    title text NOT NULL,
    presenter text DEFAULT ''::text NOT NULL,
    minutes integer,
    CONSTRAINT item_minutes_check CHECK (((minutes IS NULL) OR ((minutes >= 1) AND (minutes <= 600)))),
    CONSTRAINT item_title_check CHECK ((title <> ''::text))
);


--
-- Name: item_id_seq; Type: SEQUENCE; Schema: meeting; Owner: -
--

ALTER TABLE meeting.item ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME meeting.item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: share_id_seq; Type: SEQUENCE; Schema: membership_project; Owner: -
--

ALTER TABLE membership_project.share ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME membership_project.share_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: assignment; Type: TABLE; Schema: membership_task; Owner: -
--

CREATE TABLE membership_task.assignment (
    task text NOT NULL,
    member text NOT NULL
);


--
-- Name: applied; Type: TABLE; Schema: migration; Owner: -
--

CREATE TABLE migration.applied (
    path text NOT NULL,
    hash text NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_share; Type: VIEW; Schema: patronage_payslip; Owner: -
--

CREATE VIEW patronage_payslip.work_share AS
 SELECT d.id AS distribution,
    v.worker AS member,
    v.quantity AS basis,
    v.cents AS amount
   FROM (patronage.distribution d
     CROSS JOIN LATERAL patronage_payslip.division(d.id) v(worker, basis, quantity, cents))
  WHERE ((v.basis = 'salary'::text) AND (( SELECT cella.sees('patronage'::text) AS sees) OR (v.worker = cella.reader()) OR cella.reaches('patronage'::text, v.worker)));


--
-- Name: time_share; Type: VIEW; Schema: patronage_timesheet; Owner: -
--

CREATE VIEW patronage_timesheet.time_share AS
 SELECT d.id AS distribution,
    v.worker AS member,
    v.minutes,
    v.cents AS amount
   FROM (patronage.distribution d
     CROSS JOIN LATERAL patronage_timesheet.division(d.id) v(worker, minutes, cents))
  WHERE (( SELECT cella.sees('patronage'::text) AS sees) OR (v.worker = cella.reader()) OR cella.reaches('patronage'::text, v.worker));


--
-- Name: filing; Type: TABLE; Schema: project_task; Owner: -
--

CREATE TABLE project_task.filing (
    task text NOT NULL,
    project text NOT NULL,
    milestone integer
);


--
-- Name: number; Type: SEQUENCE; Schema: task; Owner: -
--

CREATE SEQUENCE task.number
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task; Type: TABLE; Schema: task; Owner: -
--

CREATE TABLE task.task (
    id text DEFAULT ('t-'::text || nextval('task.number'::regclass)) NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'todo'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    due date,
    created date NOT NULL,
    completed date,
    CONSTRAINT task_check CHECK (((status = 'done'::text) = (completed IS NOT NULL))),
    CONSTRAINT task_priority_check CHECK ((priority = ANY (ARRAY['urgent'::text, 'high'::text, 'normal'::text, 'low'::text]))),
    CONSTRAINT task_status_check CHECK ((status = ANY (ARRAY['backlog'::text, 'todo'::text, 'doing'::text, 'done'::text]))),
    CONSTRAINT task_title_check CHECK ((title <> ''::text))
);


--
-- Name: count; Type: VIEW; Schema: project_task; Owner: -
--

CREATE VIEW project_task.count AS
 SELECT f.project,
    (count(*))::integer AS tasks,
    (count(*) FILTER (WHERE (t.status = 'done'::text)))::integer AS done
   FROM (project_task.filing f
     JOIN task.task t ON ((t.id = f.task)))
  GROUP BY f.project;


--
-- Name: entry_id_seq; Type: SEQUENCE; Schema: timesheet; Owner: -
--

ALTER TABLE timesheet.entry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME timesheet.entry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: journal; Type: TABLE; Schema: transaction; Owner: -
--

CREATE TABLE transaction.journal (
    one boolean DEFAULT true NOT NULL,
    last integer NOT NULL,
    CONSTRAINT journal_last_check CHECK ((last >= 0)),
    CONSTRAINT journal_one_check CHECK (one)
);


--
-- Name: contract; Type: TABLE ATTACH; Schema: file; Owner: -
--

ALTER TABLE ONLY file.file ATTACH PARTITION file.contract FOR VALUES IN ('payroll');


--
-- Name: receipt; Type: TABLE ATTACH; Schema: file; Owner: -
--

ALTER TABLE ONLY file.file ATTACH PARTITION file.receipt FOR VALUES IN ('expense-receipt');


--
-- Name: record; Type: TABLE ATTACH; Schema: file; Owner: -
--

ALTER TABLE ONLY file.file ATTACH PARTITION file.record FOR VALUES IN ('profile');


--
-- Name: shared; Type: TABLE ATTACH; Schema: file; Owner: -
--

ALTER TABLE ONLY file.file ATTACH PARTITION file.shared FOR VALUES IN ('none');


--
-- Data for Name: account; Type: TABLE DATA; Schema: account; Owner: -
--

COPY account.account (code, label, kind, parent, holder, frozen, cash) FROM stdin;
1012	Capital souscrit, appelé, non versé	equity	\N	\N	f	f
1013	Capital souscrit, appelé, versé	equity	\N	\N	f	f
1061	Réserve légale	equity	\N	\N	f	f
1068	Autres réserves (impartageables), fonds de développement	equity	\N	\N	f	f
120	Résultat de l'exercice (bénéfice)	equity	\N	\N	f	f
401	Fournisseurs	liability	\N	\N	f	f
411	Clients	asset	\N	\N	f	f
421	Personnel — rémunérations dues	liability	\N	\N	f	f
424	Participation des salariés aux résultats	liability	\N	\N	f	f
431	Sécurité sociale	liability	\N	\N	f	f
44566	TVA déductible sur autres biens et services	asset	\N	\N	f	f
44571	TVA collectée	liability	\N	\N	f	f
455	Associés — comptes courants	liability	\N	\N	f	f
4562	Apporteurs — capital appelé, non versé	asset	\N	\N	f	f
4567	Associés — capital à rembourser	liability	\N	\N	f	f
457	Associés — intérêts aux parts à payer	liability	\N	\N	f	f
512	Banque — Crédit Coopératif	asset	\N	\N	f	t
606	Achats non stockés de matières et fournitures	expense	\N	\N	f	f
613	Locations	expense	\N	\N	f	f
6251	Voyages et déplacements	expense	\N	\N	f	f
6256	Missions	expense	\N	\N	f	f
6257	Réceptions	expense	\N	\N	f	f
626	Frais postaux et de télécommunications, logiciels	expense	\N	\N	f	f
641	Rémunérations du personnel	expense	\N	\N	f	f
645	Charges de sécurité sociale et de prévoyance	expense	\N	\N	f	f
706	Prestations de services	income	\N	\N	f	f
101301	Capital — Camille Martin	equity	1013	camille@lanterne.example	f	f
101302	Capital — Yusuf Demir	equity	1013	yusuf@lanterne.example	f	f
101303	Capital — Hugo Lefèvre	equity	1013	hugo@lanterne.example	f	f
101304	Capital — Julien Petit	equity	1013	julien@lanterne.example	f	f
101305	Capital — Léa Bernard	equity	1013	lea@lanterne.example	f	f
101306	Capital — Thomas Nguyen	equity	1013	thomas@lanterne.example	f	f
101307	Capital — Sofia Rossi	equity	1013	sofia@lanterne.example	f	f
101308	Capital — Malik Benali	equity	1013	malik@lanterne.example	f	f
101309	Capital — Amina Diallo	equity	1013	amina@lanterne.example	f	f
101311	Capital — Paul Garnier	equity	1013	paul@lanterne.example	t	f
101310	redacted	equity	1013	chloe@lanterne.example	t	f
\.


--
-- Data for Name: period; Type: TABLE DATA; Schema: account; Owner: -
--

COPY account.period (month, closed) FROM stdin;
2026-10	\N
2026-11	\N
2026-12	\N
2026-07	2026-08-05
2026-08	2026-09-04
2026-09	2026-10-05
\.


--
-- Data for Name: rubric; Type: TABLE DATA; Schema: account; Owner: -
--

COPY account.rubric (id, sheet, n, kind, label, side, prefixes, adds, subtracts) FROM stdin;
assets	balance	1	heading	Actif	\N	{}	{}	{}
fixed	balance	2	heading	Actif immobilisé	\N	{}	{}	{}
intangible	balance	3	line	Immobilisations incorporelles	debit	{20,280,290}	{}	{}
tangible	balance	4	line	Immobilisations corporelles	debit	{2,21,22,23,281,282,291,292,293}	{}	{}
financial	balance	5	line	Immobilisations financières	debit	{26,27,296,297}	{}	{}
fixed-total	balance	6	total	Total actif immobilisé	\N	{}	{intangible,tangible,financial}	{}
current	balance	7	heading	Actif circulant	\N	{}	{}	{}
stocks	balance	8	line	Stocks et en-cours	debit	{3}	{}	{}
advances-paid	balance	9	line	Avances et acomptes versés sur commandes	debit	{4091}	{}	{}
receivables	balance	10	line	Clients et comptes rattachés	debit	{41,491}	{}	{}
other-receivables	balance	11	line	Autres créances	debit	{4096,4098,425,4287,4387,441,4456,4458,4561,462,465,4687}	{}	{}
called-capital	balance	12	line	Capital souscrit et appelé, non versé	debit	{4562}	{}	{}
securities	balance	13	line	Valeurs mobilières de placement	debit	{50,590}	{}	{}
cash	balance	14	line	Disponibilités	debit	{5,51,53,54}	{}	{}
prepaid	balance	15	line	Charges constatées d'avance	debit	{486}	{}	{}
current-total	balance	16	total	Total actif circulant	\N	{}	{stocks,advances-paid,receivables,other-receivables,called-capital,securities,cash,prepaid}	{}
assets-total	balance	17	total	Total de l'actif	\N	{}	{fixed-total,current-total}	{}
liabilities	balance	18	heading	Passif	\N	{}	{}	{}
equity	balance	19	heading	Capitaux propres	\N	{}	{}	{}
capital	balance	20	line	Capital	credit	{101,108}	{}	{}
premiums	balance	21	line	Primes d'émission, de fusion, d'apport	credit	{104}	{}	{}
revaluation	balance	22	line	Écarts de réévaluation	credit	{105}	{}	{}
legal-reserve	balance	23	line	Réserve légale	credit	{1061}	{}	{}
statutory-reserves	balance	24	line	Réserves statutaires ou contractuelles	credit	{1063}	{}	{}
other-reserves	balance	25	line	Autres réserves	credit	{106,1062,1064,1068}	{}	{}
carried	balance	26	line	Report à nouveau	credit	{11}	{}	{}
to-allocate	balance	27	line	Résultat à affecter	credit	{12}	{}	{}
period-result	balance	28	line	Résultat de la période	credit	{6,7}	{}	{}
grants	balance	29	line	Subventions d'investissement	credit	{13}	{}	{}
regulated	balance	30	line	Provisions réglementées	credit	{14}	{}	{}
equity-total	balance	31	total	Total capitaux propres	\N	{}	{capital,premiums,revaluation,legal-reserve,statutory-reserves,other-reserves,carried,to-allocate,period-result,grants,regulated}	{}
provisions	balance	32	line	Provisions pour risques et charges	credit	{15}	{}	{}
debts	balance	33	heading	Dettes	\N	{}	{}	{}
bank-loans	balance	34	line	Emprunts et dettes auprès des établissements de crédit	credit	{164,519}	{}	{}
other-loans	balance	35	line	Emprunts et dettes financières divers	credit	{1,16,17,455}	{}	{}
advances-received	balance	36	line	Avances et acomptes reçus sur commandes	credit	{419}	{}	{}
suppliers	balance	37	line	Dettes fournisseurs et comptes rattachés	credit	{401,403,4081}	{}	{}
tax-social	balance	38	line	Dettes fiscales et sociales	credit	{421,422,424,427,4282,4286,43,4382,4386,442,443,444,4455,4457,446,447,4482,4486}	{}	{}
fixed-suppliers	balance	39	line	Dettes sur immobilisations et comptes rattachés	credit	{404,405,4084}	{}	{}
other-debts	balance	40	line	Autres dettes	credit	{4,457,4567,46,4686,509}	{}	{}
deferred	balance	41	line	Produits constatés d'avance	credit	{487}	{}	{}
debts-total	balance	42	total	Total dettes	\N	{}	{bank-loans,other-loans,advances-received,suppliers,tax-social,fixed-suppliers,other-debts,deferred}	{}
liabilities-total	balance	43	total	Total du passif	\N	{}	{equity-total,provisions,debts-total}	{}
operating-income	income	1	heading	Produits d'exploitation	\N	{}	{}	{}
goods-sold	income	2	line	Ventes de marchandises	credit	{707,7097}	{}	{}
production-sold	income	3	line	Production vendue (biens et services)	credit	{70}	{}	{}
production-stored	income	4	line	Production stockée	credit	{713}	{}	{}
production-capitalised	income	5	line	Production immobilisée	credit	{72}	{}	{}
subsidies	income	6	line	Subventions d'exploitation	credit	{74}	{}	{}
reversals	income	7	line	Reprises sur amortissements et provisions, transferts de charges	credit	{781,791}	{}	{}
other-income	income	8	line	Autres produits	credit	{7,75}	{}	{}
operating-income-total	income	9	total	Total des produits d'exploitation	\N	{}	{goods-sold,production-sold,production-stored,production-capitalised,subsidies,reversals,other-income}	{}
operating-expenses	income	10	heading	Charges d'exploitation	\N	{}	{}	{}
goods-bought	income	11	line	Achats de marchandises	debit	{607,6087,6097}	{}	{}
goods-stock	income	12	line	Variation de stock de marchandises	debit	{6037}	{}	{}
materials	income	13	line	Achats de matières premières et autres approvisionnements	debit	{601,602,6081,6082,6091,6092}	{}	{}
materials-stock	income	14	line	Variation de stock de matières premières et approvisionnements	debit	{6031,6032}	{}	{}
external	income	15	line	Autres achats et charges externes	debit	{60,61,62}	{}	{}
taxes	income	16	line	Impôts, taxes et versements assimilés	debit	{63}	{}	{}
wages	income	17	line	Salaires et traitements	debit	{64,641,644}	{}	{}
social	income	18	line	Charges sociales	debit	{645,646,647,648}	{}	{}
depreciation	income	19	line	Dotations aux amortissements et aux provisions	debit	{681}	{}	{}
other-expenses	income	20	line	Autres charges	debit	{6,65}	{}	{}
operating-expenses-total	income	21	total	Total des charges d'exploitation	\N	{}	{goods-bought,goods-stock,materials,materials-stock,external,taxes,wages,social,depreciation,other-expenses}	{}
operating-result	income	22	total	Résultat d'exploitation	\N	{}	{operating-income-total}	{operating-expenses-total}
financial-income	income	23	line	Produits financiers	credit	{76,786,796}	{}	{}
financial-expenses	income	24	line	Charges financières	debit	{66,686}	{}	{}
financial-result	income	25	total	Résultat financier	\N	{}	{financial-income}	{financial-expenses}
current-result	income	26	total	Résultat courant avant impôts	\N	{}	{operating-result,financial-result}	{}
exceptional-income	income	27	line	Produits exceptionnels	credit	{77,787,797}	{}	{}
exceptional-expenses	income	28	line	Charges exceptionnelles	debit	{67,687}	{}	{}
exceptional-result	income	29	total	Résultat exceptionnel	\N	{}	{exceptional-income}	{exceptional-expenses}
participation	income	30	line	Participation des salariés aux résultats	debit	{691}	{}	{}
income-tax	income	31	line	Impôts sur les bénéfices	debit	{69,695,696,698}	{}	{}
result	income	32	total	Bénéfice ou perte	\N	{}	{current-result,exceptional-result}	{participation,income-tax}
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: account; Owner: -
--

COPY account.terms (id, "from", share, minimum, instalments, delay, repayments, adopted) FROM stdin;
st-2021	2021	50.00	20	10	12	3	2021-03-01
\.


--
-- Data for Name: adoption; Type: TABLE DATA; Schema: account_decision; Owner: -
--

COPY account_decision.adoption (terms, decision) FROM stdin;
\.


--
-- Data for Name: allowance; Type: TABLE DATA; Schema: account_membership; Owner: -
--

COPY account_membership.allowance (member, amount) FROM stdin;
camille@lanterne.example	500.00
yusuf@lanterne.example	500.00
hugo@lanterne.example	500.00
julien@lanterne.example	500.00
lea@lanterne.example	500.00
thomas@lanterne.example	500.00
sofia@lanterne.example	500.00
malik@lanterne.example	500.00
amina@lanterne.example	500.00
chloe@lanterne.example	500.00
\.


--
-- Data for Name: credit; Type: TABLE DATA; Schema: account_membership_patronage_transaction; Owner: -
--

COPY account_membership_patronage_transaction.credit (distribution, member, account, shares, amount, until, entry) FROM stdin;
\.


--
-- Data for Name: plan; Type: TABLE DATA; Schema: account_membership_payslip_transaction; Owner: -
--

COPY account_membership_payslip_transaction.plan (member, instalments, each, since) FROM stdin;
\.


--
-- Data for Name: withheld; Type: TABLE DATA; Schema: account_membership_payslip_transaction; Owner: -
--

COPY account_membership_payslip_transaction.withheld (month, member, amount, entry) FROM stdin;
\.


--
-- Data for Name: draw; Type: TABLE DATA; Schema: account_membership_transaction; Owner: -
--

COPY account_membership_transaction.draw (entry, member, amount) FROM stdin;
\.


--
-- Data for Name: paid; Type: TABLE DATA; Schema: account_membership_transaction; Owner: -
--

COPY account_membership_transaction.paid (entry, member, amount, via) FROM stdin;
\.


--
-- Data for Name: repayment; Type: TABLE DATA; Schema: account_membership_transaction; Owner: -
--

COPY account_membership_transaction.repayment (member, n, due, amount, entry, paid) FROM stdin;
paul@lanterne.example	1	2026-11-30	500.00	\N	\N
paul@lanterne.example	2	2027-11-30	500.00	\N	\N
paul@lanterne.example	3	2028-11-30	500.00	\N	\N
chloe@lanterne.example	1	2027-11-07	333.34	\N	\N
chloe@lanterne.example	2	2028-11-07	333.33	\N	\N
chloe@lanterne.example	3	2029-11-07	333.33	\N	\N
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: account_membership_transaction; Owner: -
--

COPY account_membership_transaction.subscription (member, account, shares, entry, amount, cancelled) FROM stdin;
\.


--
-- Data for Name: authority; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.authority (one, fn, owner) FROM stdin;
t	circle_membership.may(text,text,bigint,date)	circle-membership
\.


--
-- Data for Name: head; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.head (one, n, hash) FROM stdin;
t	30	\\x0af3efe18db74ae65a35a1dc6a7c560f7fbc82ada86f750ec73794ce43bbf7a3
\.


--
-- Data for Name: keyring; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.keyring (one, fn, owner) FROM stdin;
t	person.verifies(text,bytea)	person
\.


--
-- Data for Name: receipt; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.receipt (n, op, actor, device, nonce, request, signature, payload, at, hash, sig) FROM stdin;
49	client:client:erase	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	553ec5f49058a8467228e8d65f55d350	\\x87ad5ec6c9f9b375d2fa7e26315b2fe067615d0e55de3c319d8426f040814171	\\x6817590af36363110f57a7b76bb2cd8ca8841d4de559c3612a9c61e7230a7fbab367bcce7d63d4b9e4389e57ac78b2ad979ff8cab098c18813770ce1c44f8c0c	\\x65a5cb2da4c901b2f38bab996cf11a42186d88c22096a0e53924be66a4899291	2026-10-25T13:48:06.764672Z	\\xb9a079aebf44f35ad4e900a680347bd324f49f236ecda36ca7f1889555996145	\\xa421571358130d368b2bb2b93780c56254ae813ac3e3769fdb9ce9157b896d10627cdf8663506e6c9edf00d7f10570208f2f7375a466b2903c108faf5ad50409
51	person:person:profile	lea@lanterne.example	\\x2646566ac94e44d96732c0c1113fdaf5b4de4940b43fd91c456d587a8d8b5fb1	7e47b88a16aec5f9b49219ea1e5ad3e5	\\x16cced530515e07e408acc2f07a82d56dbac40ea50321d4b817aa33b4ce7e426	\\x77d333cff7acf92e302b02059088e16ac9435800d6e48437925b45999482fafc8cf098511bc312c70ab69bfef7e170e8447fcd68a0c1b982c93418d867af1b09	\\x66c971d38279e56aa449cf3ecd33479271cc0ccb1373efefc51714a2ec30d0f6	2026-10-25T13:48:06.848794Z	\\x8accc3e40fce3f8b6c281a4203be9c25d6ab24c92707d4b52dce126c6dfef267	\\x6f765ea94f011f8356920c5d2eb1d4004de3027efa69cfc0251cdf2cb9db45f9fd8d008d3cbdd6ad99bb76c552b36c91c97284307042d0a39fddc2519834a400
53	person:person:forget	lea@lanterne.example	\\x2646566ac94e44d96732c0c1113fdaf5b4de4940b43fd91c456d587a8d8b5fb1	073a4be2911a12caafd1c320f9f890e9	\\x5d7f37e80babb5637b9f0e5c93e0854d5050c6dc6ff6eb21f7f296b6056dd966	\\x249b62f131dbcd1750683e70d444aa70dd4bc486146d7025dbdff0292137d27cae96aaf762f695bdd4014d5913f6169582641967ad64ab4c313248055be8f608	\\xe32771980b0c55d6525b5c019eea414c8685e9794fe7bdbf2feef8e6327e435d	2026-10-25T13:48:06.929880Z	\\x59de53ac58b1982da37f175410d19acb7daa4972b9826c500f6f730e3c7334b2	\\x367cd28a7bcd13b5fe957d7cf719cf3657d58b5811391a56934eea75278ef215556bb9ac27bf2ce97bcbd63709c6481c1498d4e2c98cf5243dc75737af2c230d
55	expense:expense:capture	chloe@lanterne.example	\\xf36e685af3f374908d21da18445e823162c4b63fad1bf789500a7a3839bb964e	936d66c039e43b911866e4f8eddaeb8e	\\x000a5b9f873a53c62fb177bf9aebc17d3225f64938a6209a5aaff1f369d9d5c3	\\x7d2d20df7a80bdd73e03402dab52d40cf21d4adc12a4cf81a3cddf7f954f29e8cb9b983f128d75af8e7fa4814b8b9a292c8ba6a02058579aa90120195ee48a0c	\\x4946b2e779fc96d40dd4dee23b9ec7750814e5d808cae3b72766687b4ce14278	2026-10-25T13:48:07.101791Z	\\x4199ef8b454580cebaae703e5255b4bd1c15acdc7e1176a7de02738a4a97103a	\\x8612122f3ddefa83a9b1336f901325004c237a0f09fed820f54f42d350a74d8c1326d6fa2eaf5281bc89abfbf2e230b2d7a9646ed9b3588fc8b44093017dfe06
56	decision:decision:propose	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	3abd577619687b88eb36d818cb92397f	\\x9a07085dc72640ddcb0df2b7a25faa14ce3843361e0321c2b190e2348f1e6604	\\x82fdb38764f7a501f5ddbbedf0c6789053cfdddcf81b133a63db9622ab35117566552fb622c562eabf05ee0c4f102804f3fe7c442cee60de70096908da4f6808	\\x2a05f8f70c94da397c014a190f6864c587c547259f475625bf5ebad4439d6ecd	2026-10-25T13:48:07.180263Z	\\x2e9f8aec7588885b7ca6268a7989bed7f1e0f5492b9357828d22fb1a68fb3897	\\xfe68c7fb355bbd9d410e5420dd806c73a58db5793e64f11760a15f8ae6e4c2f31ed167fadd939405116559f1fc4ff8fdc38f7b61cc009ce836914c7bd7ea4407
57	decision:decision:vote	amina@lanterne.example	\\xde69b2a7eecafc743ac6df34b86f48dbe73bf021b58403ebcb0977498dbc6270	c0392c5727ebbf90cf1ff86ea07624b6	\\x6409c134b4e9e30694556cd93acbd3f1c8861d751fb6ad6ad04f3f6dc43e63a4	\\xa14e6bbf689943add2ce24b554336b12ebab7fb2981fbf82e6637841cef3f27ccf9f6c122b1c96f41aa3d9e64ff620b96b18a9f70aaee4f4488059e2f6758700	\\x6f44cbc576d86c0df1e9bb2ef6456649842abda66b72be6fe8119d0ce36d9ab9	2026-10-25T13:48:07.226843Z	\\xcbb28d21e3fd02e8265260e5879b4816b08ac555c57f40aa64e1d354a9d7668b	\\xe0e5811a80c8ee8a66d9d66d935fe9ad96a770c68718ac022ba6e2cf21312a2d83ce50b259ca79e2ee8d3654260b193db453c3ddb59ebb6a2ca1f6d164653001
58	decision:decision:vote	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	3383e9d2d1cae68d9569da2ce9e19465	\\x370ad34595a28710274bd72ad0f60731276b9da67652533ee665775dbbb2aacf	\\x16ed5b2b2364bb84810c92c88c5cda6a4a106c0ac373655a1c2a3500b45015da5fe1c986a7ebdaece50c5ff180fb4f914f862cd4b90b2b9ab4bc076c4237c707	\\xedd3b43703c4036977fd1b4f95df479c9fbf4d2d3bd9645f286293015ede799a	2026-10-25T13:48:07.265801Z	\\x72ac2462b7ff5bf753e91f6aada42c6d6e70b1a770b9326d95c8b522d323c39e	\\xc52f676bdf786d3ddf74f146640c3885c5bfde696b0b35b718f769c01d7a11309c3cb768d73140c1a2c99d7996f99afa352a216c8245b71a679054131842bc0f
59	decision:decision:vote	chloe@lanterne.example	\\xf36e685af3f374908d21da18445e823162c4b63fad1bf789500a7a3839bb964e	e23898956d8d49b13c3b49ff11045002	\\xc25ff0088c221bf6b90908b8fdab094e2d4f4bf6d3a8ff37bf8c33a0384eddb2	\\x2e33963c6fc21abb360947a4796f491aa2020c373d2ccbfdbbe06fffc48ed0ff88776efe95a38cd6c4bc8d085b6081f6c05b25f1dc2a9d9486e07fca6f47f20f	\\x4c957cfbc870fdea3e9e8850593ce7a7831b7bee49543e1a21c29e797281889f	2026-10-25T13:48:07.303595Z	\\x5d84a47b5b793652621f7b2645de995c1dd476ffd80c31442447b1c369951b86	\\x47cacbaad643caec002ffbc064509dd8570a1a5e20ee8b8c829e86ff6bd9c7cf2ee8a1099b6e59589c10a48329915905ca519dc28a3136aeccd8fa347a63450e
60	decision:decision:vote	hugo@lanterne.example	\\xf282134bfa3aef3cc8ab7f12975595d23d584b78b55119c308c01234f0b99f22	18f26656fbaca8b1e4c5c6a6d4d53b49	\\x67d9374d1db4f398ae3d8bb21939473d91aa9e2a1456f64cd8e28667c7600537	\\x7c7df91b2bcfb7e6fe7e8a2d5a34b8661a8a04b2917ad92ab657039795593c9c1c2f586973a4c3ce2e5a30eb60d5b528e02adc8ba3194674d829a874b5554a01	\\x549e6553acfa31958b082577d9ec070b93ab0a65d211d3d7047b951947d2f942	2026-10-25T13:48:07.342851Z	\\xd02749aff87c19eca01915b5da2bac9b1cc8a22779bbd440c9caaf20c6f56bf1	\\xa4a8bc35de612557b87116b278397cee55cae264ffd29f4248c4cd040dfc7d9435c3506bc8d5068b7b8b4ad7930766c092b5063ff35aaa8706a3720be9db970d
61	decision:decision:vote	julien@lanterne.example	\\xbb6c45e69eca21fa48f39a688e57754cd7480413420d372bc2c59bb8dbc100fb	dd1ce2b22f017d8497188aed5fc50bed	\\x9c3467d6d6cd7a2a4c124d7a1abec455d040e4208ecada27565dfb096014088b	\\xcf4dd3e756bf5133eefa4af0ecc761afae8ece1572c9d378996a908e4ce5814323ddf8c5af0887512afff35dfea586d44a20aa26d5001138eba27ab7ad1b7d06	\\x5e838a9a34889f3baebcac9c36a10c799faaa89015bdc2d1abf1297cb6c0d3ec	2026-10-25T13:48:07.380655Z	\\xfe65c10a67d82d4201aafee14772488c01f4a8479835dd4b70bfbf219638e0f4	\\x56259cb5259ed7e1d5c75da91b4a226d4e19d63754b46af53f97e72343accc3a47d2bfad878bd733d418b6b058e0a0c27a0d272dd6f693d1169962dcdb52f907
62	decision:decision:vote	lea@lanterne.example	\\x2646566ac94e44d96732c0c1113fdaf5b4de4940b43fd91c456d587a8d8b5fb1	e2fb779390f0e5e5d34fadaf064c34f5	\\xe447e5aad5e992c04faad09368405ea1b350e926ae7011ab279e6d147a2c446d	\\xe416b9fdb7ed6feda5d3457a8107e0e83e7920292832703952fd1b6e08fc4c7f8493a2882f6fd69a25f8a0d3d6eac13d7a35decb8bca1c892d58d10a7194eb04	\\x61a48f32517237a70f885eb2b5cdfb8906c49ff600cf954ded014cfc0e77fc7e	2026-10-25T13:48:07.418374Z	\\x03b0e0521ceab602c1b67ec3dac0af71c8d0cae05779caa82dcb0f90f30b9432	\\x68814173d34303fa2fa0de74bc94fa21b1e22129580b89ce06085ded06371b5c6e9a8292b8a2827daa40bf19ce1ec88f0aa5865dac28453585d5e020912c2a05
63	decision:decision:vote	malik@lanterne.example	\\x9c5d931883bf543c435020c46586f89e4d9c95af9757b54d95c8a3c915721047	f07e76ed32433e75319c800ea9ab3a52	\\xe99408ded22dfe833f435150f01bc56c6236813de792cfa1550d627503401bf9	\\x778d14a7dec4203a0694df15dd45caeae0f43cb010a113c006f43c154d71a7f7943a13ef6ffb31a2ecd501d593bced6c25a47cb988c1493f714a5563bcc7b10c	\\x1d466004d9babef11ceba63047f6bbcea28bf33135da8d87d1955da62bc86c93	2026-10-25T13:48:07.458870Z	\\xb8c9d1bb6fc1aa373099470148cdca531219e79691ef7b78b9ab64956c481b1c	\\x1b933604e88d7d3695a224ef12335d428178b87dd0246ab2bd6415403f55a87331407400251dd09f6d5f54e2a4ce88bb3024c96a85de6c96e1084adce3a24903
64	decision:decision:vote	sofia@lanterne.example	\\x03743a748f5aad5efb4a4950180b610dfe362f5b5c25c388dd4e99b505f4eea8	b831487be0f4c7031c3fbe17e8fb4d86	\\xb96491cc3a6c85a5ae31823ce1ab680e8a4e9ea129efb7186eee8df164562d90	\\xdbf61edc4ea952d75405ba5e3627e4d9945a6a07a880b2b32c9a8109fefcc00b412990d82625c80cae0f37bc390e2dc1f8011f5837e13a5eede04dd78178bc0f	\\x9473fd5594ae9a9a3a7f705dd0ac0c1b223f78232210e413cc9d989b6ebfef22	2026-10-25T13:48:07.496953Z	\\x2986b31aaaeea848cd8ed1071f636f0bc234563b5b6ae26915e0500def97810f	\\x4484dc84de8bfaad6ff1956c3a2e94d75dca4972a9bef5d1d10ea5d3b42b983d8d37927fbe31a184a4f45a15ce6e1f69f7c32f7fa566297bb222d0ba7a906506
65	decision:decision:vote	thomas@lanterne.example	\\xa7618b710f90d71b7540510cb74df1bb1cc4e4abbe18e9bb022a057c5b5bcc3b	296b8482bd398eb69b9c93bf7390b040	\\xbb11b1957c1fe265c626444d1adde113349670d84693a3990244b51f3419fa52	\\x58c9962eb291e250d39a881e28b27ffbecc17e08379f88d2922f65818e06433911ed18ae6f5d8d375b63362d43dc0f13d2408fce0a95ee815832bf00dae7a309	\\xf982564ee198df4bf4950fed408e1d961d5b006b4d61fa977689ffa356420250	2026-10-25T13:48:07.535470Z	\\x22af6bc96c08a3adbd85b3de8b44f9ec3fe3d9e5e9f3214d947e353ba5a241dc	\\x9986c09bdc92ce6a4da4c5185e8a58c26634878ea403eebebc3eb50e98a69336137b9a4c8e8c8477c3ccbdd27392f2ff9156ac75d57b856244b25f9461287d0f
66	decision:decision:vote	yusuf@lanterne.example	\\xe4710f55f6a0a35687bca218113cb0279136bbd0d6d87211eb245116fbbd819d	dca2f86c895855d8e82dfcae61dc5333	\\x3555f33207e3537b22648bd8326cf63270c8aff30d5fa5c40c3d8717a9e1681e	\\xa2f966b6498412db7baeaf4ed7f882fdcd9abf0e26fdea86a3db696faf70c9b63edf6df688a63198a04f2457f9508b2807b85dd4c7c22274f40b5cefff708b0a	\\x3afb76f26388206532e2f0cb0442163b5347f954c3850cac5ccb4ab9d8fab2fb	2026-10-25T13:48:07.573886Z	\\x7f18e742a04ece0deb3a3fc854072756b7b4d7d7c1821698d1651e394035e01c	\\x9cd2ee24f5aac5a1fc7b448748492ee434b06e69c29415128efffe4704527f4cd671099bc99dd7a01526acf6ab5d3c4e0f4d45917ff33628ac04b2bbde78b10d
67	decision:decision:close	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	517ea8bf6473b3846c65c8c791d3fb4f	\\x45ccb3d51af99c18b2f86bcb9963039661e5ebf3e8d3ace0f03d811631672b83	\\xb9e6cf777f9a033472387e3f07d3b506b82719c0371f411077638cfe4241be507dc6756b38f576c1b5852331eb555b650ed2fd5c2d0533e677c6a0477596670a	\\xc37203d9f4cf3d16e13e7c20346dba1b2bbe01b0aec623741e79978acfe3e5bb	2026-10-25T13:48:07.644122Z	\\xde6f7faf9a050cea25a81a50f1910fe5557ab2b1bc67622978bd3351b6ba5964	\\x2d4b6971ba6a064012d5b33e652303739163c298893495ee3730d31eb537a6dac871123e05ed7228eb40a477de1eb5fb0ec6d32cadfdf9cdcaf4690e597ed60c
68	membership:member:exit	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	6fcefa91e98de1e6218f59c2bfbca85f	\\xf17bffc2f455d64ccef34cf143e69d136f4d39a109a033a3ca2cad369d674d5b	\\xfe029c7c64bb83a966f37cf702f0eefad49967874fb84bb3d4cb3640735a6113685eab6648b4fd9683b63a1aaf76b035e4658df7bf2315dee674702defd2e907	\\xfd15dde5572bdea534864a098d4b79a729d5fdbf29adb93678d6cb264591685e	2026-10-25T13:48:07.730864Z	\\x5d50814580cfe31a5c8019fe31d9f379050e0007c9e0d87a117ad440c97bc481	\\x59d8d790bc93c27eb397001141a1701fea481773e5f193da7019aa5c3d7199ab92e94bb541fff6ee5570cc93703f874ec113ed0e2d5c90a219f471748cbbd905
69	decision:decision:propose	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	6bd0e0968c4668cdfa57ef84c6e94feb	\\xa0303fdd495807b4044b4f75801552a296879c181b6bab3c57777b7708282287	\\x1b8a9a1f3620e8af7e3413ec19f8d327d1f54a498023dc1419bb03ebfe62ba3cbb6a78dcc2b625fb24d7948b4e9e78e191d0669945435493fbeedcdd6ced2604	\\x0548b1b7e971dd0aca8e33c9d446646ed8e5e2c81923c60443ea408207a46e54	2026-10-25T13:48:07.818885Z	\\x5d78645d7d9a7c82938143779220b8d238cde4b5050a485ef17c905923e632bb	\\x25d58e28002d752117088e3246793a901bee3794233447f53c83afe9f819667162d33e890b9e4a7bb9e316b4ee818987c0235efc95223ea5d2713c8352e7f706
70	decision:decision:vote	amina@lanterne.example	\\xde69b2a7eecafc743ac6df34b86f48dbe73bf021b58403ebcb0977498dbc6270	ab657d6686d53eb7f3181a8976e0adf4	\\x1263b125841bd557d48b472d2294c3bd5060fe6f130409bad5252b7165b0e7ba	\\x3948d81c3f6e24fb78164d8501e3b2732b5979a46965e1f2ea796bfc5271111ed4dd29784f79a48ca3bf4ad029205b98c50540910a65bb4bd6a0ddf0d5174902	\\x878f900bcb54018e56a5eacb95231861dfc71a41a82866a6f9a23a4b60d6fd0a	2026-10-25T13:48:07.863530Z	\\xd4194c1266e9940bedb4ec7fccd21d82e05d084abe4113f610b3f58ead0cc9fd	\\x588aceee2e658282723378f2a1df16de796f71095d0833407cb101f61e6c0e58792f307c266fc96859a4d0d97d1b8a693afe1aa5e586f4cc25142e1b1563200f
71	decision:decision:vote	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	c60e1c8b30a90541e2cd713c6dd79145	\\x2b1b8cceabf1be253c60c1ad7ef94426ce0bd559f86c903ac6c8e313f2177cd5	\\x83e8b5d1d0e74a3ac2ecbcc57c500fb2f5e880100b50abcb7c7eebdf1190d3dc4c718c19f05e8005e652f279640a6f43b18e0a08e89db4a22682321b8ec7bd0c	\\x35c7b671b9dc48fdf8e6f70ea7532efb686c404192b5c6343e0a965faf19d96d	2026-10-25T13:48:07.924006Z	\\xd17a829119d11d0d16271eda2f6521abb3440961cfcf3c42bfb799ddc8e3d16c	\\xf924b6c51b35a0804e31bceb735f2c53857a79fb4d619e7634682f9fe19411d708a3826efd85ad2db40c03cd735f17b5982b31f848a386efbfd2209c3951ab0b
72	decision:decision:vote	hugo@lanterne.example	\\xf282134bfa3aef3cc8ab7f12975595d23d584b78b55119c308c01234f0b99f22	aa2a6090dd732306c2907b94f05f7b2c	\\x149fdc2c3f61511309ecee960af1e1e3d968f5f454b84568a41c3d02f27a5a5c	\\xbc14dc118e2a215435c303d50a4e4a8a22360556f392e246fb82ae78bc3718291ac9326b7f535ac3818e82c718d8a6223ab83422a2293fb4c778e1ae657a5c04	\\xfc606745f0145f055855d7c006f7cb656aa41fbc0a515491d9250ccfbc8e2102	2026-10-25T13:48:07.962512Z	\\x6dbfd9c4b04bfcf7d1ff7876d24e7c11d205882aaaf6cffc0e3a1528ea5cf01d	\\x46c218074872f0ae801398b0e66f3b2962a6b67b1714aeb38c02c646b555de1f59ac9ae5f5fbc3cc4b7a7e37ad43389f11d09b71429798ea18d8887824fc1f05
73	decision:decision:vote	julien@lanterne.example	\\xbb6c45e69eca21fa48f39a688e57754cd7480413420d372bc2c59bb8dbc100fb	13f5e94883b926cdccf1ba59ab032f6a	\\x8998fae51ad472647b6760dd86e11ce04e4bb3234a3cd486bd322efa1a975d63	\\x415e45d5f5dedf311f7892809e711057c48948e29c5aefd3aa0fe10352d7f1072b343d5467e7bd8cc050100526431c6879b07a180d8d23e1676bf8f2c91fc20b	\\x009fbf64079dcd6820881e1018fb0fb875abf9b74fa1080012dd6ce1c39ecf8e	2026-10-25T13:48:08.000305Z	\\xebbe75974a992956cec93b6087a180c83dba52d461119ea23e245d97241155ba	\\x412f992e3439a3b69754a3bede606ecf1a6b091ef8d50c427cd1cf9f33f117b8fc4875c4bb2e93a2d7870d2ef84e3189b6e5841f8f1f662c866c698c34891c00
74	decision:decision:vote	lea@lanterne.example	\\x2646566ac94e44d96732c0c1113fdaf5b4de4940b43fd91c456d587a8d8b5fb1	c313c5a80548401458c4bfe865452c65	\\x576b45663c465569984f89db9e6e0004cac722e59929fb0fe22181b249e66679	\\x5d050e9f03f5af039cab8ab21db47b425f72eb415407301fee0386ee9674f60205aa68facd5f6b8cbf2e8416f274b4db9fb8cb9473e7928cdcc3f053ce30550b	\\xa6519f76d79a5a0cce48c4ada6055a14895bf40766985d0e076b1a438ef6141f	2026-10-25T13:48:08.038454Z	\\xdbf4212ac77b497f8c118045ea501b1060e2f1e234fbb507a60b775c2cb8a68d	\\xe7fbc1e5e5e77f3fcf9c57295ac5c1e1270a22ad07709008db49532f7f1527f3d942278c0fed9ede1be830ae83f3bae0a2b8c6fb9516cfbfe9a97dc0180be301
75	decision:decision:vote	malik@lanterne.example	\\x9c5d931883bf543c435020c46586f89e4d9c95af9757b54d95c8a3c915721047	925beff6800a8016292ad3af105e0965	\\x8cc6efc6ab042b29fef1b97cd8e267f024e2f981341e3fa7df1183c6a031b50f	\\xc431b6eee277019b31e277727e4901be9b88a29417f7ba15a119d693a76b74a63fc1ab280b17406f57a600aa02d1e6a7bef6c917ab62f4d385ab9a848cc78e09	\\xff1898bb4ead2b2bcd35ccebaeec4434f87e32556a2e5a5f0d80c9d2292f76bb	2026-10-25T13:48:08.077240Z	\\xe5c8a08398ca1058b3819bf9d38a8349ff60e7367f9f90a96b5c17b81cc3e47d	\\xc57d26c2029d660018faf3c298e6d1adba2a0901e5089aff28ed2c286a2b442a962b305596a81d1ac72834852dbe26d9e31b035b6fe0b666ce4fecaf3c44440a
76	decision:decision:vote	sofia@lanterne.example	\\x03743a748f5aad5efb4a4950180b610dfe362f5b5c25c388dd4e99b505f4eea8	37405e6de4799373ed0109bc13cd538b	\\x7c7a573a7be013ee83aa2a2240a7e8c7bc11481b68d91337bcf2ddff4ce58e87	\\xef319557d238263b8026da938a0ba4a1e20ba4dbea34e565b12f3d0849435b14d71744a5008cb348ba2063223b348f245e24f5873be8101afbcfa6865b90d201	\\x94f4e2d0c3dcbae1d7088f59e123bfbb93450c650f99af4db1a68f1fdebccd0c	2026-10-25T13:48:08.115590Z	\\xf55f1c6a1d42cb023529db8a2af4d9461e81bf5f4bb122244c29f8e9ce43ecd3	\\xb757fc8e45887eb0ea800b474c5d482bde0aff1321901ed12d1a23d2c9422bccbef16b0bc61501c504706f372d347d9348aab0692dbd5a35ec67b1fa0f03d608
77	decision:decision:vote	thomas@lanterne.example	\\xa7618b710f90d71b7540510cb74df1bb1cc4e4abbe18e9bb022a057c5b5bcc3b	84827c01351d71d2ccb6a96a490fb37b	\\xe41bfd560378f6fdac079ba5616cfc4ed07d6c6a46e0716ce4e2a09346671160	\\x249215878eb293307ed31a69a6275a1c17267b9c368f6434e3fb235dce5240a3a0c0044125f0286e55d241ebcf9468098d6715cb4597b179e468f91619aada0e	\\x3523c9c6f5771a1363ff7c692a9f74a2432284c0d3bad0aa6901d172b1ab49e4	2026-10-25T13:48:08.160958Z	\\x3d248d3bc8ab6481627d09c1dc2d5021a0658596aa0860b5a86dd242c26729ba	\\xd483ad6a4b3e12ebb183cddf4189c7134abb3ccb4e9eb9ed5421dded00337fa0af1d83e866ebda9203534365c77eb0b01f3a64727eea9d34946e88a9caabd00f
78	decision:decision:vote	yusuf@lanterne.example	\\xe4710f55f6a0a35687bca218113cb0279136bbd0d6d87211eb245116fbbd819d	89668da00736e0686a97624f64963671	\\x7b9c83b7d9b9e40ff36167dd4ddcb2818d309c3deb7bf30eff43990c526faaa8	\\x6aebb0511cc6b2337c5c74b4a46483e5656a45d239f575f5fcd06556a1fa01a25ae6a078f67f0fcc2f6819acd85d9fde7f6dd6d9b9504db058ee41271ce9910d	\\xa64e6c4cf70769287d330ce71e2c37c41e652470e03a2b2b5e2200fd352748e1	2026-10-25T13:48:08.199794Z	\\x22abab949dd722a7edb3770d69a500f611cff3c70c6f68cec5f003c22427af65	\\xffe147e8dffa51abf798ff5d7b46e276b22183cc620c9334454e37d1f02e750c5de6afb6430e4035dd80c25d5c33e0a19e41a0cd63920524a29409633c6a8000
79	decision:decision:close	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	05929d274da0cbd1c13b5cdd34be1701	\\x7a2d64228796926ff409af3d24910070ada6fc8d3efc329a2b4abb56144b14d2	\\x99956d923aae61bba3efa097ba495690662549303dd9500d36b41bbb60d3f0a290b6dedcb2d79429c63f44001a7a51dfea748f0ef26b7fc3ca487ebe1af9f901	\\xccf4a1e905a8593da86323767c651f90f723c3e1f9bbed0f2eaa3ac48f179e6d	2026-10-25T13:48:08.252811Z	\\x97f5a18ec33c36cfa27511b414d3a5ff9fecb0b76aafb7a5e39b6db176ebf629	\\xa0e2df34a4d909803b9d61819ca5458d02f7fb5491a4e74c561eb31ccac93ba8d896fa4fe642b56777afa2991daf1316f029565bda773fccc2a3c7381a51f604
80	membership:member:erase	camille@lanterne.example	\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	1a5305a496c7feb2a3c8d0d106b489a9	\\xdd2e20f4cf53f8a02d03dd5886438d033187ea6fab444362e716acc976b70ecc	\\x4c429275d7858c374fba5ed1328abf44cfaba187953e1315c3dac986bf1ea3152de30e0dceed269e5c975423f039cafaf14bd7de74511a7cfb38741607ae8a06	\\xb1ce149fdb3b5ece72e3e038b9636b1580cc22aedd2978beb90b9b3e9de94250	2026-10-25T13:48:08.339159Z	\\x9afdb2617d97496771793295dbe1be859d3b35dc4ac37b2bfa6f703e5cc5ab51	\\x3a6010583247b42701e53d59730ceba0b85c9fd8f9305e96727a78d42398c89a297774427c80f4b066a0d321b5696decf18b6670fdcb0c49b61419d9d329360a
81	person:person:profile	hugo@lanterne.example	\\xf282134bfa3aef3cc8ab7f12975595d23d584b78b55119c308c01234f0b99f22	0168d9a9f0bc5c3f2e1a5af7e989a737	\\xf819cacbec7105e16cd7d87db1f13d307eb521d7a84056be96ca0fc68226e364	\\xac33d43a1400da8b8ca4815a47b52cbfe2fe692837c94dddfc5e53c6571c2f1e9685ffaca8bd113bfc7ef25af08de0a64d5f2851b7b1addf6ba9aa82a4b2db0e	\\xf220d1f7183400ab406b3b4cfba67a9359f1d1fb237b928d10971b119700f873	2026-10-25T13:48:23.125778Z	\\x8c6a4910f63d220887ab4e84df63648946663e7a1abf731d7fc238e3f4237120	\\xd5d9a1df9df5a27ad708d202f96ff8e3b18a055c7cad28006e677239cf8c46450f10f63170321025f1c6d74adc768d59ac8652b56eb1a9c74755e3c615eca106
\.


--
-- Data for Name: log; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.log (n, op, actor, date, payload, form, receipt, rules, prev, hash, sig) FROM stdin;
1	client:client:erase	camille@lanterne.example	2026-10-24	\\x65a5cb2da4c901b2f38bab996cf11a42186d88c22096a0e53924be66a4899291	{"client": "halles-roux", "erasure": {"$erasure": {"erased": ["contact"], "subject": "halles-roux", "restricted": []}}}	49	[{"text": "55041ba8e596cbef8fd8a98e34ea466cc9ecda33d7651d05fb9eefa84fcc3c4f", "owner": "circle-membership", "function": "circle_membership.empowered(jsonb)"}, {"text": "e89d5dab0937fd46b4ca891383d8d2bfad81ad95053c074cfa9d6517c5af6c77", "owner": "client", "function": "client.erases(jsonb)"}]	\\x0000000000000000000000000000000000000000000000000000000000000000	\\xffeb15a3958fcb3de30fd3bb1c13b6a210817be2381ebeedd4a1d31173ff8aa5	\\x7e205dd6cd9b526f2efa0831c6da8fedfb6c9365d093d2982a2091459879b2717e9a94b57cfe348069fb2fde6610492f331eb1e027c10c1aef2ae5a88667d009
2	person:person:profile	lea@lanterne.example	2026-10-24	\\x66c971d38279e56aa449cf3ecd33479271cc0ccb1373efefc51714a2ec30d0f6	{"fields": ["email", "phone"], "person": "lea@lanterne.example", "values": {"email": {"$commit": "689b201e3f79b7e2737c14586d1b05aef6cee13c14395bcce44822ba4f791fda"}, "phone": {"$commit": "74df59625213f36843a6aa86725401f77c1e82ea9bc77e3634c65a170020c6cc"}}}	51	[{"text": "b69e135406014016141841e464f57c5561fd6d92b12e51aadf62595314bd672f", "owner": "person", "function": "person.own_profile(jsonb)"}]	\\xffeb15a3958fcb3de30fd3bb1c13b6a210817be2381ebeedd4a1d31173ff8aa5	\\x8b1cce73bab4a00d33f964fb249d10cb7a0ec7c70d7d8bc49b4b0b360c7181de	\\xbe3dfe7f0fe2d5899cd6ae4d345b264c9d318b8e0bf9afcec90110e29f44a3649d05928fd13cd290e61a80c51fe1e505da13976c3aed532a9e9092cc3661520e
3	person:person:forget	lea@lanterne.example	2026-10-24	\\xe32771980b0c55d6525b5c019eea414c8685e9794fe7bdbf2feef8e6327e435d	{"person": "lea@lanterne.example", "erasure": {"$erasure": {"erased": ["contact"], "subject": "lea@lanterne.example", "restricted": []}}}	53	[{"text": "4c48015db890c9c16ed21580c1ef9736f016ac09b45dacd08170cc6014c5dc07", "owner": "person", "function": "person.forgets(jsonb)"}]	\\x8b1cce73bab4a00d33f964fb249d10cb7a0ec7c70d7d8bc49b4b0b360c7181de	\\xfacde88a07af7227b8c399dff3c69c471a82f283f566e8d7d94c7745d281fff0	\\x7d13d78bda26f4d853b9f8b5b4126cb3fbd056ff9091b0064023d8d2e68f8c144e04d5ae7472e89d44d432b0a2f0b00ac59ac03b1e58505059e66a95e6364e03
4	expense:expense:capture	chloe@lanterne.example	2026-10-24	\\x4946b2e779fc96d40dd4dee23b9ec7750814e5d808cae3b72766687b4ce14278	{"day": "2026-10-23", "label": {"$commit": "dbc64f64e21aafb646c6886d39474bc95a25499654ca28c893d6e8d09eefaa0d"}, "amount": 3200, "member": "chloe@lanterne.example", "expense": "ex-0005", "receipt": {"$commit": "8f4dac598e113849061d7d419a7c5519724561e471ffc614749f8e87794a82e9"}, "category": "6251"}	55	[{"text": "c3deed64467c6490bde4ab2c517e9a77cc2cb740495225521a3465a9cde34eb7", "owner": "expense", "function": "expense.captures(jsonb)"}, {"text": "f19a8f42daae29214a290b19607a93d6ecd77134bb905f88ec922912c65b0188", "owner": "expense-file", "function": "expense_file.attaches(jsonb)"}]	\\xfacde88a07af7227b8c399dff3c69c471a82f283f566e8d7d94c7745d281fff0	\\x2ca9bf0a67c387cdc13fb7fc62462d5769fae29f4bdde2da84a36d25066958f4	\\x973a5e38eb0ec7ba8ef700d6b79c1c2a32af32dd5d28cdb4207ca68874c83b7aed3b41ad190acc5bc0675a767e9f7757751a492fe9a7abbb80815f4388178b09
5	decision:decision:propose	camille@lanterne.example	2026-10-24	\\x2a05f8f70c94da397c014a190f6864c587c547259f475625bf5ebad4439d6ecd	{"circle": "ag", "motions": [{"args": {"member": "chloe@lanterne.example"}, "kind": "exit"}], "deadline": "2026-11-07", "decision": "d-2026-013", "procedure": "consent"}	56	[{"text": "86b2c2444f97fb89930f88997ce8109a3d72b7c0d7284fefd5ec7e889aca10f5", "owner": "account-decision", "function": "account_decision.asks(jsonb)"}, {"text": "46238e5504eae07f6e432e188c61c5d84ffeaa46075bff9d3cce889445ec3b96", "owner": "circle-decision", "function": "circle_decision.asks(jsonb)"}, {"text": "408e7e4b847940b3a3136080c08b68f7aec722096561c31d463f3bfb76cddde7", "owner": "circle-decision-membership", "function": "circle_decision_membership.asks(jsonb)"}, {"text": "42c32c9b6e0b127ea61b826ccf90cd5ecbb1eb61c281a2c4a7b3d351cd1ddfaa", "owner": "circle-decision-membership", "function": "circle_decision_membership.sits(jsonb)"}, {"text": "527f3c7bf6d579d22cb9e84b5db15bf923799c7db0073483199694f45bbd5fd3", "owner": "decision", "function": "decision.proposes(jsonb)"}, {"text": "ad5ea511e1cde8eaa3bcdd8def7cf4156ce12ae8cdab1bb1a1758b4d6b99ed44", "owner": "decision-document", "function": "decision_document.asks(jsonb)"}, {"text": "ce1712129bafbbba5591da9809f19dc83aa19c9f57208f1b7d94c12c8b9b6cb5", "owner": "decision-membership", "function": "decision_membership.asks(jsonb)"}, {"text": "81f441ae28101c19efc66a0d9cf233f51b668ed8507fa2bd8fa20a2ab102c037", "owner": "decision-patronage", "function": "decision_patronage.asks(jsonb)"}]	\\x2ca9bf0a67c387cdc13fb7fc62462d5769fae29f4bdde2da84a36d25066958f4	\\x951e8be070400544da73f8a1afc66c9c35d736d4a16a1342ccc1f40bc746352a	\\xd02873a08900b8461839f3fe60252a2224bd48bef4f996075b62827e6c9830522dc6ce12881c365ede88d9cc67c1db9498d9f365a2ef9473e6e4321c98aa4b08
6	decision:decision:vote	amina@lanterne.example	2026-10-24	\\x6f44cbc576d86c0df1e9bb2ef6456649842abda66b72be6fe8119d0ce36d9ab9	{"member": "amina@lanterne.example", "stance": "consent", "receipt": 57, "decision": "d-2026-013"}	57	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x951e8be070400544da73f8a1afc66c9c35d736d4a16a1342ccc1f40bc746352a	\\x4a204fceb4f4003e1ee4fda3125bf377385123e504263b6346437447b7146b63	\\x256ad0d675f0a57e79b943d41bd87daafcc23de08b2c4cd3e0aae9f45450e863f4b526742e4581b14276338fa6da69bbfb6bb26794dc905b567b976ef7ec9808
7	decision:decision:vote	camille@lanterne.example	2026-10-24	\\xedd3b43703c4036977fd1b4f95df479c9fbf4d2d3bd9645f286293015ede799a	{"member": "camille@lanterne.example", "stance": "consent", "receipt": 58, "decision": "d-2026-013"}	58	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x4a204fceb4f4003e1ee4fda3125bf377385123e504263b6346437447b7146b63	\\x7a32ffbeea466b9e157ce24c13cb4a5d28ede049a736d50f2dd1d4e12c49e432	\\x65d1369324959c6f801705cfa53b17e365388e5e19d49f4f03e10ede28432663dc47a7d77772aedfa09e5e02cb0a0b2441349b217ff3b8b60265e614b82ad10c
8	decision:decision:vote	chloe@lanterne.example	2026-10-24	\\x4c957cfbc870fdea3e9e8850593ce7a7831b7bee49543e1a21c29e797281889f	{"member": "chloe@lanterne.example", "stance": "consent", "receipt": 59, "decision": "d-2026-013"}	59	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x7a32ffbeea466b9e157ce24c13cb4a5d28ede049a736d50f2dd1d4e12c49e432	\\xd685a8a330469230836b66c9e32fe191131fda151cba8d8c9fbae0a2ade7b49f	\\xe8016ddc8d39a38b9e37d099102b8bcddf434d4ce1f0aebf76c7fb45b67f899ad4d1bb9994b4a38f760c40ad462c3063d716107dfc4bc5c9d0849dcfcc685c07
9	decision:decision:vote	hugo@lanterne.example	2026-10-24	\\x549e6553acfa31958b082577d9ec070b93ab0a65d211d3d7047b951947d2f942	{"member": "hugo@lanterne.example", "stance": "consent", "receipt": 60, "decision": "d-2026-013"}	60	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\xd685a8a330469230836b66c9e32fe191131fda151cba8d8c9fbae0a2ade7b49f	\\xf34176ebf51929913134a5d00662d78a5b6e2a3f3599e3e40b8e260671d620ff	\\xa8a2c9261d0da20847365b5dfde718420f3016034623049a16e1dce1e0cca6aebea359f73e5bdfe8eeae705ba75c049e40c6c5be39f2c99f035ea3429aaad60b
10	decision:decision:vote	julien@lanterne.example	2026-10-24	\\x5e838a9a34889f3baebcac9c36a10c799faaa89015bdc2d1abf1297cb6c0d3ec	{"member": "julien@lanterne.example", "stance": "consent", "receipt": 61, "decision": "d-2026-013"}	61	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\xf34176ebf51929913134a5d00662d78a5b6e2a3f3599e3e40b8e260671d620ff	\\x6ca50d4dc21e5341bb9e55922af5639d4e19ace27661064a2315a5a7838e052b	\\x527348afa35333cb8ba5f0f425065fb8b4eba649593c7970e06a130ebc483ede8ae43b67e3d3e287f6b2e954645fe1d56e3d93a7fc2c9c25b864121d4277dd0f
11	decision:decision:vote	lea@lanterne.example	2026-10-24	\\x61a48f32517237a70f885eb2b5cdfb8906c49ff600cf954ded014cfc0e77fc7e	{"member": "lea@lanterne.example", "stance": "consent", "receipt": 62, "decision": "d-2026-013"}	62	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x6ca50d4dc21e5341bb9e55922af5639d4e19ace27661064a2315a5a7838e052b	\\x25b0c283900bbede6096c2389083cd6c2a149d80cce16a26b2bb9a8e0d7322ba	\\x61c09a2cc350c663ffb9496fc7f780eb6af2fc6e62d424dc0287e9a447d9a13e3c646a8f6a63e4062f684b6b09945e2ee0b0d732ea0604e95faa5579cf19560b
12	decision:decision:vote	malik@lanterne.example	2026-10-24	\\x1d466004d9babef11ceba63047f6bbcea28bf33135da8d87d1955da62bc86c93	{"member": "malik@lanterne.example", "stance": "consent", "receipt": 63, "decision": "d-2026-013"}	63	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x25b0c283900bbede6096c2389083cd6c2a149d80cce16a26b2bb9a8e0d7322ba	\\xb36f335a9867c08f3d15abee81f4124d4e95a3f9f0c8fc8ba3da68e7fee7bd4e	\\x5e38b2bba79a86fe0ac31c65d0b4c73fcd079b01a8099ca5add25654684344cf1377e4694036a832b8a41d0300ba8eda3d2820a3075e92ddfa79084b79617007
13	decision:decision:vote	sofia@lanterne.example	2026-10-24	\\x9473fd5594ae9a9a3a7f705dd0ac0c1b223f78232210e413cc9d989b6ebfef22	{"member": "sofia@lanterne.example", "stance": "consent", "receipt": 64, "decision": "d-2026-013"}	64	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\xb36f335a9867c08f3d15abee81f4124d4e95a3f9f0c8fc8ba3da68e7fee7bd4e	\\x5b5dbcbd028658e7513be6d05a6275580071b82fb9c3a1d2c840f05614f0ec91	\\x053eb06167da54561dbdf6f65372d7992e186a5dc1741bf84bb3d790c56b954aff6adb3cc0250f39ef63cbd8202a738324b90817bc7e46fe5398a444c651ef06
14	decision:decision:vote	thomas@lanterne.example	2026-10-24	\\xf982564ee198df4bf4950fed408e1d961d5b006b4d61fa977689ffa356420250	{"member": "thomas@lanterne.example", "stance": "consent", "receipt": 65, "decision": "d-2026-013"}	65	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x5b5dbcbd028658e7513be6d05a6275580071b82fb9c3a1d2c840f05614f0ec91	\\x11e1bc8b6571b75ed6071fb15c225773f23eaebe92f0483d842f7db20f27cf72	\\xc8767f69bf9201cff22cc79db7c2d29ec7dc70c7c659821435147178f291232ab867a5006470860a8f39f6131c9d888b26fdbdc2641ae1e57b206f432ddfd905
15	decision:decision:vote	yusuf@lanterne.example	2026-10-24	\\x3afb76f26388206532e2f0cb0442163b5347f954c3850cac5ccb4ab9d8fab2fb	{"member": "yusuf@lanterne.example", "stance": "consent", "receipt": 66, "decision": "d-2026-013"}	66	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x11e1bc8b6571b75ed6071fb15c225773f23eaebe92f0483d842f7db20f27cf72	\\x47495610a1add9e654f0f4cb3aaa86da86f9770c39cc726a5bfc91cec0172515	\\xd520bdb3fb13ed12a6b5a5aec680db6606fd48c3c45cb64d2edfdbddc33f78a5102c5aeae8a51d8267df24a803148981691412acbf5f738c0d88eb74b263de0d
16	decision:decision:close	camille@lanterne.example	2026-11-07	\\xc37203d9f4cf3d16e13e7c20346dba1b2bbe01b0aec623741e79978acfe3e5bb	{"admitted": [], "decision": "d-2026-013"}	67	[{"text": "f14289a832e6b082de1b7281153435b254fabd2061ade34ea820112c4bfdf57a", "owner": "circle-decision-membership", "function": "circle_decision_membership.settles(jsonb)"}, {"text": "42c32c9b6e0b127ea61b826ccf90cd5ecbb1eb61c281a2c4a7b3d351cd1ddfaa", "owner": "circle-decision-membership", "function": "circle_decision_membership.sits(jsonb)"}, {"text": "2807de534b3206ec290a6f6324276c299bb789eee2a8b6ca63900cc7e5d6beff", "owner": "decision", "function": "decision.closes(jsonb)"}, {"text": "df9a8302ae2f6e300a8570db2956fb32bdc08bc6f86fee18d3bc77014cb8bc7f", "owner": "decision-membership", "function": "decision_membership.closes(jsonb)"}]	\\x47495610a1add9e654f0f4cb3aaa86da86f9770c39cc726a5bfc91cec0172515	\\x82c453ecc9d3e70d4865c9c7554390c101d58a90c3f04802ce7181433d6b1460	\\xc191be30591f1d5d4f3b4eeeab5898033b1ad320197bbce9a0a140173f611ca7a97fea411b459457e3eeb9e9c3e9918da0fb4c34b0cccaf361530a36c5c38601
17	membership:member:exit	camille@lanterne.example	2026-11-07	\\xfd15dde5572bdea534864a098d4b79a729d5fdbf29adb93678d6cb264591685e	{"member": "chloe@lanterne.example", "decision": "d-2026-013"}	68	[{"text": "b29c4dfbbc3e4a230cc517f8d7ec3e3cf7573c5e02031376127969def0d7ef1f", "owner": "circle-decision-membership", "function": "circle_decision_membership.carried(jsonb)"}, {"text": "9f5b588466c5b8aa11de1c407764a1c00e83e7cdea3a99357f1bf6f4e1308092", "owner": "decision-membership", "function": "decision_membership.ends(jsonb)"}, {"text": "d65753e496b1f814987f698900d7216a60c084bbd360a14c6c4fa3133d819fdb", "owner": "membership", "function": "membership.ends(jsonb)"}]	\\x82c453ecc9d3e70d4865c9c7554390c101d58a90c3f04802ce7181433d6b1460	\\x7f4d0f950ba99b9625e660eee991693acb14fe4ba0ef93a4a9f3ea9fdd49d9d9	\\xc4a966f6ec9ec5429cd0a5de826def6420834ac0cd484a3696be6b5e0846306dfbdabb7d7473bce43062c5b2436706452dd438104d4db27286fdb8950558d203
18	decision:decision:propose	camille@lanterne.example	2026-11-08	\\x0548b1b7e971dd0aca8e33c9d446646ed8e5e2c81923c60443ea408207a46e54	{"circle": "ag", "motions": [{"args": {"member": "chloe@lanterne.example"}, "kind": "erase"}], "deadline": "2026-11-22", "decision": "d-2026-014", "procedure": "consent"}	69	[{"text": "86b2c2444f97fb89930f88997ce8109a3d72b7c0d7284fefd5ec7e889aca10f5", "owner": "account-decision", "function": "account_decision.asks(jsonb)"}, {"text": "46238e5504eae07f6e432e188c61c5d84ffeaa46075bff9d3cce889445ec3b96", "owner": "circle-decision", "function": "circle_decision.asks(jsonb)"}, {"text": "408e7e4b847940b3a3136080c08b68f7aec722096561c31d463f3bfb76cddde7", "owner": "circle-decision-membership", "function": "circle_decision_membership.asks(jsonb)"}, {"text": "42c32c9b6e0b127ea61b826ccf90cd5ecbb1eb61c281a2c4a7b3d351cd1ddfaa", "owner": "circle-decision-membership", "function": "circle_decision_membership.sits(jsonb)"}, {"text": "527f3c7bf6d579d22cb9e84b5db15bf923799c7db0073483199694f45bbd5fd3", "owner": "decision", "function": "decision.proposes(jsonb)"}, {"text": "ad5ea511e1cde8eaa3bcdd8def7cf4156ce12ae8cdab1bb1a1758b4d6b99ed44", "owner": "decision-document", "function": "decision_document.asks(jsonb)"}, {"text": "ce1712129bafbbba5591da9809f19dc83aa19c9f57208f1b7d94c12c8b9b6cb5", "owner": "decision-membership", "function": "decision_membership.asks(jsonb)"}, {"text": "81f441ae28101c19efc66a0d9cf233f51b668ed8507fa2bd8fa20a2ab102c037", "owner": "decision-patronage", "function": "decision_patronage.asks(jsonb)"}]	\\x7f4d0f950ba99b9625e660eee991693acb14fe4ba0ef93a4a9f3ea9fdd49d9d9	\\xb7316dd272163f322d76cae38dab29750de264fc892425393a36ebdddcb6ae7c	\\x33484adfef8cbae7018a7a4bf2a9196f497cfedb1c5ddc5841d3e9c5ee67a29465017bb47e9c67f73d37321e8cd03a6f46a398f3322f2552857efa1acd632307
19	decision:decision:vote	amina@lanterne.example	2026-11-08	\\x878f900bcb54018e56a5eacb95231861dfc71a41a82866a6f9a23a4b60d6fd0a	{"member": "amina@lanterne.example", "stance": "consent", "receipt": 70, "decision": "d-2026-014"}	70	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\xb7316dd272163f322d76cae38dab29750de264fc892425393a36ebdddcb6ae7c	\\x91e679f91635beb62ad21d31922a4967bb15ae7c7d665a23f36dbda43c4e87be	\\xbd79ad9af81cee7cfca1ab68905e7a67c67dbbb8f388279c80f05f37cdca26ed92bdf5feb145d3d2d6e82e56ccfadb5d0cca849eb36b66f84deb830e32600f08
20	decision:decision:vote	camille@lanterne.example	2026-11-08	\\x35c7b671b9dc48fdf8e6f70ea7532efb686c404192b5c6343e0a965faf19d96d	{"member": "camille@lanterne.example", "stance": "consent", "receipt": 71, "decision": "d-2026-014"}	71	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x91e679f91635beb62ad21d31922a4967bb15ae7c7d665a23f36dbda43c4e87be	\\x48ee43cd753f9b91c1fa6a215caf9d2820945a649576965a2e301c2f076df864	\\x3852471ccb880ea98461867655e51160643351aa214a1300667575cde2992487915cec0dc21ad011b7d8e74bd87afd0111f9d769d7bc4c59def9371c28bb450e
21	decision:decision:vote	hugo@lanterne.example	2026-11-08	\\xfc606745f0145f055855d7c006f7cb656aa41fbc0a515491d9250ccfbc8e2102	{"member": "hugo@lanterne.example", "stance": "consent", "receipt": 72, "decision": "d-2026-014"}	72	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x48ee43cd753f9b91c1fa6a215caf9d2820945a649576965a2e301c2f076df864	\\x1f89713c56bca5c85ba4bf7023e5240dfe85319aabebe8479d1f4a8e53e157f4	\\x66c870673442d2df1cd68f0b915d065fd71eb059213377dc7b64907e1ab9ab0b2213c2cf435f796255ee4a17d26c8c3136efa0e6822cb2b3a66564030d36850a
22	decision:decision:vote	julien@lanterne.example	2026-11-08	\\x009fbf64079dcd6820881e1018fb0fb875abf9b74fa1080012dd6ce1c39ecf8e	{"member": "julien@lanterne.example", "stance": "consent", "receipt": 73, "decision": "d-2026-014"}	73	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x1f89713c56bca5c85ba4bf7023e5240dfe85319aabebe8479d1f4a8e53e157f4	\\x2cf6e11604c42fd8b46e15c8bbe9b78f9a7e6b258b45cca0e9b38ba8fec06c82	\\xd79cadf5f1e9f69067246cca5fd56f59082182191a399f6c181149d0a383ec37d2c4610b3116981da3375d27a1fd26333c67f3800310b2596cb6a3a686e1990a
23	decision:decision:vote	lea@lanterne.example	2026-11-08	\\xa6519f76d79a5a0cce48c4ada6055a14895bf40766985d0e076b1a438ef6141f	{"member": "lea@lanterne.example", "stance": "consent", "receipt": 74, "decision": "d-2026-014"}	74	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x2cf6e11604c42fd8b46e15c8bbe9b78f9a7e6b258b45cca0e9b38ba8fec06c82	\\x0894431a8c7d6ab41de48ab9c113be836c00e828dc79f7b6d858cfd254f971ad	\\x7dfad1f4647db3cbeb6910c0438765f04a698336df7a50734dd38eeff4d8373c9955adac2bacf7bd8452aaaf31569572586710d85196f015c604abb1fd46750e
24	decision:decision:vote	malik@lanterne.example	2026-11-08	\\xff1898bb4ead2b2bcd35ccebaeec4434f87e32556a2e5a5f0d80c9d2292f76bb	{"member": "malik@lanterne.example", "stance": "consent", "receipt": 75, "decision": "d-2026-014"}	75	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x0894431a8c7d6ab41de48ab9c113be836c00e828dc79f7b6d858cfd254f971ad	\\x9c56684ac98e6e94b96ac0095b219ae9f11a154c00d66ce093ac219fc5a9fc44	\\xf0e2ccba5c433abebf281ad46d39b302940364745331d55fb5929edeedd5e59fb7522c06b92cd9749fb3f2474ea45ba93021ce748cd0871faeafa31b8e1d6604
25	decision:decision:vote	sofia@lanterne.example	2026-11-08	\\x94f4e2d0c3dcbae1d7088f59e123bfbb93450c650f99af4db1a68f1fdebccd0c	{"member": "sofia@lanterne.example", "stance": "consent", "receipt": 76, "decision": "d-2026-014"}	76	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x9c56684ac98e6e94b96ac0095b219ae9f11a154c00d66ce093ac219fc5a9fc44	\\x3eb05ba91c352174ba9acbe1bc6ec3a29660561906bade4c2e3d04fda644e68b	\\x8c6d6a551922f359064be413f2718c5a6811916a43de0642aab7fd9215391aaf8c9d847baa6d63d6548f07bc170028686619193bf6a5621fc66b48fb36ef0108
26	decision:decision:vote	thomas@lanterne.example	2026-11-08	\\x3523c9c6f5771a1363ff7c692a9f74a2432284c0d3bad0aa6901d172b1ab49e4	{"member": "thomas@lanterne.example", "stance": "consent", "receipt": 77, "decision": "d-2026-014"}	77	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x3eb05ba91c352174ba9acbe1bc6ec3a29660561906bade4c2e3d04fda644e68b	\\x3c3fbc60e20ebf28e64da70777e59238d098379299dc7c9e8708ddf31187f076	\\xc8b0589e19387383f79009a1d0b603c03027dc8b65ff1c18c55390cc8a77cc41246b95094be2be76ee63bd3fd5dc88fa0c5e4edb6243faee8ec377360e141109
27	decision:decision:vote	yusuf@lanterne.example	2026-11-08	\\xa64e6c4cf70769287d330ce71e2c37c41e652470e03a2b2b5e2200fd352748e1	{"member": "yusuf@lanterne.example", "stance": "consent", "receipt": 78, "decision": "d-2026-014"}	78	[{"text": "c786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae", "owner": "circle-decision-membership", "function": "circle_decision_membership.on_roll(jsonb)"}, {"text": "f9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6", "owner": "decision", "function": "decision.own_stance(jsonb)"}]	\\x3c3fbc60e20ebf28e64da70777e59238d098379299dc7c9e8708ddf31187f076	\\xdb9c3a3db1e5cacb7cc47e95cf9826602168d30e8e134f1a7ca023a243e71117	\\x10a24baf622b9436f723e5495c4ac7d361c2ebb2e5285bf20038d08e8784a19556852cbc26c69aa691d7aebdd388b8e882c124733774052500b3cf8e21083d03
28	decision:decision:close	camille@lanterne.example	2026-11-22	\\xccf4a1e905a8593da86323767c651f90f723c3e1f9bbed0f2eaa3ac48f179e6d	{"admitted": [], "decision": "d-2026-014"}	79	[{"text": "f14289a832e6b082de1b7281153435b254fabd2061ade34ea820112c4bfdf57a", "owner": "circle-decision-membership", "function": "circle_decision_membership.settles(jsonb)"}, {"text": "42c32c9b6e0b127ea61b826ccf90cd5ecbb1eb61c281a2c4a7b3d351cd1ddfaa", "owner": "circle-decision-membership", "function": "circle_decision_membership.sits(jsonb)"}, {"text": "2807de534b3206ec290a6f6324276c299bb789eee2a8b6ca63900cc7e5d6beff", "owner": "decision", "function": "decision.closes(jsonb)"}, {"text": "df9a8302ae2f6e300a8570db2956fb32bdc08bc6f86fee18d3bc77014cb8bc7f", "owner": "decision-membership", "function": "decision_membership.closes(jsonb)"}]	\\xdb9c3a3db1e5cacb7cc47e95cf9826602168d30e8e134f1a7ca023a243e71117	\\x0fc82698c24fc0cbaead24aa6a9f6a57004e87d3e8a3d686f50398b0dbdb0db0	\\x2e38301ca38d501afe1b96f971e6afd6c0ed24c1fb349ba9da2a43c58a5f0097d9b80b48b921a33fa6abee9de0199fa2ea7359fdaa66eedb6a405682a3f67d00
29	membership:member:erase	camille@lanterne.example	2026-11-22	\\xb1ce149fdb3b5ece72e3e038b9636b1580cc22aedd2978beb90b9b3e9de94250	{"member": "chloe@lanterne.example", "erasure": {"$erasure": {"erased": ["contact", "profile"], "subject": "chloe@lanterne.example", "restricted": ["books", "expense-receipt", "payroll"]}}, "decision": "d-2026-014"}	80	[{"text": "b29c4dfbbc3e4a230cc517f8d7ec3e3cf7573c5e02031376127969def0d7ef1f", "owner": "circle-decision-membership", "function": "circle_decision_membership.carried(jsonb)"}, {"text": "9f5b588466c5b8aa11de1c407764a1c00e83e7cdea3a99357f1bf6f4e1308092", "owner": "decision-membership", "function": "decision_membership.ends(jsonb)"}, {"text": "c924a2e08fce81f6491191c9c7a90d1dd50c8f15a64c9cfefb48a60eae2dcf77", "owner": "membership", "function": "membership.erases(jsonb)"}]	\\x0fc82698c24fc0cbaead24aa6a9f6a57004e87d3e8a3d686f50398b0dbdb0db0	\\x49255da1cd1afe4523e91e2a94d271a27858b2cc77047cc2aeab98624be643e8	\\x9fe6d4afe50ea5954ed203912ba70a460c98bbd72e92b2fb71cf07cc2a7a4490b92150b87a5316325e39a0fbc707f380a10ad8bbe14f10e0c11b45b04f025b0a
30	person:person:profile	hugo@lanterne.example	2026-10-24	\\xf220d1f7183400ab406b3b4cfba67a9359f1d1fb237b928d10971b119700f873	{"fields": ["email", "phone"], "person": "hugo@lanterne.example", "values": {"email": {"$commit": "209043bb17fdbaa9238a0abf8d531d1058e236b46eb3037fcd0f5edaa0bc7908"}, "phone": {"$commit": "dc8128ff3c61b5926193b489e19021976f6ac00fb6dbdaade7708a4625c5c6fe"}}}	81	[{"text": "b69e135406014016141841e464f57c5561fd6d92b12e51aadf62595314bd672f", "owner": "person", "function": "person.own_profile(jsonb)"}]	\\x49255da1cd1afe4523e91e2a94d271a27858b2cc77047cc2aeab98624be643e8	\\x0af3efe18db74ae65a35a1dc6a7c560f7fbc82ada86f750ec73794ce43bbf7a3	\\x65b9f695e5462a9ea5298fc3e7f701eed224582a8b074ee068b0ef51ac9f323fa433bcf28fe58df571d84bdaf2597aafb5465968414919a43d7c550de484040c
\.


--
-- Data for Name: personal; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.personal (schema, tab, col, class, subject, owner) FROM stdin;
account	account	label	books	holder	account
client	client	name	contact	id	client
client	client	email	contact	id	client
client	client	phone	contact	id	client
client	client	address	contact	id	client
client	client	note	contact	id	client
expense	expense	label	expense-receipt	member	expense
expense	expense	receipt	expense-receipt	member	expense
file	receipt	name	expense-receipt	subject	file
file	receipt	bytes	expense-receipt	subject	file
file	contract	name	payroll	subject	file
file	contract	bytes	payroll	subject	file
file	record	name	profile	subject	file
file	record	bytes	profile	subject	file
patronage	part	quantity	payroll	worker	patronage
patronage	part	amount	payroll	worker	patronage
payslip	salary	gross	payroll	member	payslip
payslip	payslip	gross	payroll	member	payslip
payslip	payslip	employee	payroll	member	payslip
payslip	payslip	employer	payroll	member	payslip
payslip	payslip	net	payroll	member	payslip
person	person	name	profile	address	person
person	person	email	contact	address	person
person	person	phone	contact	address	person
employment	worker	name	payroll	address	employment
\.


--
-- Data for Name: power; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.power (op, power, amount, owner) FROM stdin;
account:period:close	close-period	\N	account
account:capital:pay	record-receipt	\N	account
account:capital:repay	repay-capital	\N	account
client:client:add	edit-client	\N	client
client:client:update	edit-client	\N	client
client:client:archive	edit-client	\N	client
client:client:erase	erase-personal-data	\N	client
document:document:edit	edit-document	\N	document
document:document:version	edit-document	\N	document
document:document:comment	edit-document	\N	document
document:document:create	edit-document	\N	document
expense:expense:approve	approve-expense	amount	expense
expense:expense:refuse	approve-expense	\N	expense
expense:expense:reimburse	reimburse-expense	amount	expense
invoice:invoice:issue	issue-invoice	\N	invoice
invoice:invoice:send	issue-invoice	\N	invoice
invoice:invoice:payment	record-receipt	\N	invoice
invoice:invoice:void	issue-invoice	\N	invoice
meeting:meeting:schedule	schedule-meeting	\N	meeting
meeting:meeting:cancel	schedule-meeting	\N	meeting
meeting:meeting:hold	keep-minutes	\N	meeting
meeting:meeting:minute	keep-minutes	\N	meeting
patronage:distribution:distribute	distribute-surplus	\N	patronage
payslip:run:generate	prepare-payroll	\N	payslip
payslip:run:approve	approve-payroll	\N	payslip
payslip:run:pay	pay-payroll	\N	payslip
person:device:recover	recover-key	\N	person
employment:worker:hire	hire-worker	\N	employment
membership:member:invite	invite-member	\N	membership
membership:member:link	invite-member	\N	membership
employment-membership:candidacy:open	hire-worker	\N	employment-membership
project:project:create	manage-project	\N	project
project:milestone:add	manage-project	\N	project
project:milestone:complete	manage-project	\N	project
project:project:budget	set-budget	amount	project
project:project:archive	manage-project	\N	project
task:task:create	edit-task	\N	task
task:task:move	edit-task	\N	task
task:task:complete	edit-task	\N	task
timesheet:entry:log	log-time	\N	timesheet
timesheet:period:submit	log-time	\N	timesheet
timesheet:period:approve	approve-time	\N	timesheet
transaction:transaction:post	record-entry	\N	transaction
transaction:transaction:pay	pay-supplier	amount	transaction
transaction:transaction:adjust	record-entry	\N	transaction
account-transaction:entry:carry	carry-books	\N	account-transaction
client-invoice:billing:link	issue-invoice	\N	client-invoice
client-project:project:link	manage-project	\N	client-project
employment-file:worker:attach	hire-worker	\N	employment-file
invoice-project:invoice:link	issue-invoice	\N	invoice-project
meeting-membership:attendance:record	keep-minutes	\N	meeting-membership
membership-project:project:share	set-budget	amount	membership-project
membership-task:task:assign	edit-task	\N	membership-task
project-task:task:file	edit-task	\N	project-task
\.


--
-- Data for Name: reach; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.reach (what, fn, owner) FROM stdin;
transaction	account_transaction.holds(text,text)	account-transaction
\.


--
-- Data for Name: reading; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.reading (what, key, power, owner) FROM stdin;
account	\N	repay-capital	account
account	\N	record-entry	account
account	\N	carry-books	account
account	\N	close-period	account
account	\N	distribute-surplus	account
patronage	\N	distribute-surplus	patronage
payslip	\N	prepare-payroll	payslip
payslip	\N	approve-payroll	payslip
payslip	\N	pay-payroll	payslip
timesheet	\N	approve-time	timesheet
timesheet	\N	prepare-payroll	timesheet
timesheet	\N	distribute-surplus	timesheet
transaction	\N	record-entry	transaction
transaction	\N	carry-books	transaction
transaction	\N	close-period	transaction
file	expense-receipt	approve-expense	circle-file-membership
file	expense-receipt	reimburse-expense	circle-file-membership
file	payroll	approve-payroll	circle-file-membership
file	payroll	pay-payroll	circle-file-membership
file	payroll	hire-worker	circle-file-membership
file	profile	invite-member	circle-file-membership
\.


--
-- Data for Name: rule; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.rule (op, fn, owner) FROM stdin;
account:period:close	account.closes(jsonb)	account
account:terms:adopt	account.adopts(jsonb)	account
circle:circle:nest	circle.nests(jsonb)	circle
circle:mandate:grant	circle.grants(jsonb)	circle
circle:mandate:revoke	circle.revokes(jsonb)	circle
circle:circle:nest	circle.carves(jsonb)	circle
circle:mandate:grant	circle.carves(jsonb)	circle
circle:mandate:revoke	circle.carves(jsonb)	circle
client:client:erase	client.erases(jsonb)	client
decision:decision:close	decision.closes(jsonb)	decision
decision:decision:vote	decision.own_stance(jsonb)	decision
decision:decision:propose	decision.proposes(jsonb)	decision
decision:message:post	decision.posts(jsonb)	decision
document:document:adopt	document.adopts(jsonb)	document
expense:expense:capture	expense.captures(jsonb)	expense
expense:expense:submit	expense.submits(jsonb)	expense
expense:expense:approve	expense.decides(jsonb)	expense
expense:expense:refuse	expense.decides(jsonb)	expense
expense:expense:reimburse	expense.reimburses(jsonb)	expense
file:file:upload	file.uploads(jsonb)	file
import:run:record	import.records(jsonb)	import
invoice:invoice:issue	invoice.numbered(jsonb)	invoice
invoice:invoice:void	invoice.voids(jsonb)	invoice
meeting:meeting:hold	meeting.holds(jsonb)	meeting
meeting:meeting:cancel	meeting.cancels(jsonb)	meeting
patronage:distribution:approve	patronage.splits(jsonb)	patronage
patronage:distribution:approve	patronage.divides(jsonb)	patronage
patronage:distribution:distribute	patronage.distributes(jsonb)	patronage
patronage:terms:adopt	patronage.adopts(jsonb)	patronage
payslip:run:generate	payslip.generates(jsonb)	payslip
payslip:run:approve	payslip.approves(jsonb)	payslip
payslip:run:pay	payslip.pays(jsonb)	payslip
person:person:profile	person.own_profile(jsonb)	person
person:device:enrol	person.enrols(jsonb)	person
person:device:revoke	person.revokes(jsonb)	person
person:person:forget	person.forgets(jsonb)	person
employment:worker:hire	employment.hires(jsonb)	employment
employment:worker:hire	employment.carries(jsonb)	employment
membership:member:admit	membership.admitted(jsonb)	membership
membership:member:invite	membership.invites(jsonb)	membership
membership:member:suspend	membership.ends(jsonb)	membership
membership:member:exit	membership.ends(jsonb)	membership
membership:member:erase	membership.erases(jsonb)	membership
membership:member:invite	membership.carries(jsonb)	membership
membership:member:link	membership.links(jsonb)	membership
membership:member:accept	membership.accepts(jsonb)	membership
employment-membership:candidacy:open	employment_membership.opens(jsonb)	employment-membership
project:project:budget	project.budgets(jsonb)	project
timesheet:entry:log	timesheet.logs(jsonb)	timesheet
timesheet:period:submit	timesheet.submits(jsonb)	timesheet
timesheet:period:approve	timesheet.approves(jsonb)	timesheet
transaction:transaction:adjust	transaction.corrects(jsonb)	transaction
transaction:transaction:pay	transaction.pays(jsonb)	transaction
decision:decision:propose	account_decision.asks(jsonb)	account-decision
account:terms:adopt	account_decision.adopts(jsonb)	account-decision
patronage:distribution:approve	account_patronage.closed(jsonb)	account-patronage
transaction:transaction:post	account_transaction.cashless(jsonb)	account-transaction
transaction:transaction:adjust	account_transaction.restores(jsonb)	account-transaction
account-transaction:entry:carry	account_transaction.carries(jsonb)	account-transaction
decision:decision:propose	circle_decision.asks(jsonb)	circle-decision
circle:circle:nest	circle_decision.nests(jsonb)	circle-decision
circle:mandate:grant	circle_decision.grants(jsonb)	circle-decision
circle:mandate:revoke	circle_decision.revokes(jsonb)	circle-decision
meeting:meeting:schedule	circle_meeting.meets(jsonb)	circle-meeting
account:period:close	circle_membership.empowered(jsonb)	circle-membership
account:capital:pay	circle_membership.empowered(jsonb)	circle-membership
account:capital:repay	circle_membership.empowered(jsonb)	circle-membership
client:client:add	circle_membership.empowered(jsonb)	circle-membership
client:client:update	circle_membership.empowered(jsonb)	circle-membership
client:client:archive	circle_membership.empowered(jsonb)	circle-membership
client:client:erase	circle_membership.empowered(jsonb)	circle-membership
document:document:edit	circle_membership.empowered(jsonb)	circle-membership
document:document:version	circle_membership.empowered(jsonb)	circle-membership
document:document:comment	circle_membership.empowered(jsonb)	circle-membership
document:document:create	circle_membership.empowered(jsonb)	circle-membership
expense:expense:approve	circle_membership.empowered(jsonb)	circle-membership
expense:expense:refuse	circle_membership.empowered(jsonb)	circle-membership
expense:expense:reimburse	circle_membership.empowered(jsonb)	circle-membership
invoice:invoice:issue	circle_membership.empowered(jsonb)	circle-membership
invoice:invoice:send	circle_membership.empowered(jsonb)	circle-membership
invoice:invoice:payment	circle_membership.empowered(jsonb)	circle-membership
invoice:invoice:void	circle_membership.empowered(jsonb)	circle-membership
meeting:meeting:schedule	circle_membership.empowered(jsonb)	circle-membership
meeting:meeting:cancel	circle_membership.empowered(jsonb)	circle-membership
meeting:meeting:hold	circle_membership.empowered(jsonb)	circle-membership
meeting:meeting:minute	circle_membership.empowered(jsonb)	circle-membership
patronage:distribution:distribute	circle_membership.empowered(jsonb)	circle-membership
payslip:run:generate	circle_membership.empowered(jsonb)	circle-membership
payslip:run:approve	circle_membership.empowered(jsonb)	circle-membership
payslip:run:pay	circle_membership.empowered(jsonb)	circle-membership
person:device:recover	circle_membership.empowered(jsonb)	circle-membership
employment:worker:hire	circle_membership.empowered(jsonb)	circle-membership
membership:member:invite	circle_membership.empowered(jsonb)	circle-membership
membership:member:link	circle_membership.empowered(jsonb)	circle-membership
employment-membership:candidacy:open	circle_membership.empowered(jsonb)	circle-membership
project:project:create	circle_membership.empowered(jsonb)	circle-membership
project:milestone:add	circle_membership.empowered(jsonb)	circle-membership
project:milestone:complete	circle_membership.empowered(jsonb)	circle-membership
project:project:budget	circle_membership.empowered(jsonb)	circle-membership
project:project:archive	circle_membership.empowered(jsonb)	circle-membership
task:task:create	circle_membership.empowered(jsonb)	circle-membership
task:task:move	circle_membership.empowered(jsonb)	circle-membership
task:task:complete	circle_membership.empowered(jsonb)	circle-membership
timesheet:entry:log	circle_membership.empowered(jsonb)	circle-membership
timesheet:period:submit	circle_membership.empowered(jsonb)	circle-membership
timesheet:period:approve	circle_membership.empowered(jsonb)	circle-membership
transaction:transaction:post	circle_membership.empowered(jsonb)	circle-membership
transaction:transaction:pay	circle_membership.empowered(jsonb)	circle-membership
transaction:transaction:adjust	circle_membership.empowered(jsonb)	circle-membership
account-transaction:entry:carry	circle_membership.empowered(jsonb)	circle-membership
circle:circle:message	circle_membership.sits(jsonb)	circle-membership
client-invoice:billing:link	circle_membership.empowered(jsonb)	circle-membership
client-project:project:link	circle_membership.empowered(jsonb)	circle-membership
document:document:adopt	decision_document.adopts(jsonb)	decision-document
decision:decision:propose	decision_document.asks(jsonb)	decision-document
decision:message:post	decision_document.links(jsonb)	decision-document
decision:decision:propose	decision_membership.asks(jsonb)	decision-membership
decision:decision:close	decision_membership.closes(jsonb)	decision-membership
membership:member:admit	decision_membership.admits(jsonb)	decision-membership
membership:member:suspend	decision_membership.ends(jsonb)	decision-membership
membership:member:exit	decision_membership.ends(jsonb)	decision-membership
membership:member:erase	decision_membership.ends(jsonb)	decision-membership
decision:message:post	decision_membership.mentions(jsonb)	decision-membership
patronage:distribution:approve	decision_patronage.approves(jsonb)	decision-patronage
decision:decision:propose	decision_patronage.asks(jsonb)	decision-patronage
patronage:terms:adopt	decision_patronage.adopts(jsonb)	decision-patronage
meeting:meeting:minute	document_meeting.keeps(jsonb)	document-meeting
document-membership:version:read	document_membership.reads(jsonb)	document-membership
employment-file:worker:attach	employment_file.files(jsonb)	employment-file
employment-file:worker:attach	circle_membership.empowered(jsonb)	circle-membership
employment-timesheet:entry:log	timesheet.logs(jsonb)	employment-timesheet
employment-timesheet:entry:log	employment_timesheet.works(jsonb)	employment-timesheet
employment-timesheet:period:submit	timesheet.submits(jsonb)	employment-timesheet
employment-timesheet:period:submit	employment_timesheet.works(jsonb)	employment-timesheet
expense-file:expense:attach	expense_file.attaches(jsonb)	expense-file
expense:expense:capture	expense_file.attaches(jsonb)	expense-file
expense-project:expense:rebill	expense_project.files(jsonb)	expense-project
expense:expense:approve	expense_transaction.charged(jsonb)	expense-transaction
expense:expense:reimburse	expense_transaction.paid(jsonb)	expense-transaction
file-membership:member:attach	file_membership.files(jsonb)	file-membership
invoice-project:invoice:link	circle_membership.empowered(jsonb)	circle-membership
invoice:invoice:issue	invoice_transaction.issued(jsonb)	invoice-transaction
invoice:invoice:void	invoice_transaction.voided(jsonb)	invoice-transaction
meeting-membership:attendance:mark	meeting_membership.marks(jsonb)	meeting-membership
meeting-membership:attendance:record	circle_membership.empowered(jsonb)	circle-membership
project:project:budget	membership_project.covers(jsonb)	membership-project
membership-project:project:share	circle_membership.empowered(jsonb)	circle-membership
membership-task:task:assign	circle_membership.empowered(jsonb)	circle-membership
patronage:distribution:approve	patronage_payslip.divides(jsonb)	patronage-payslip
patronage:distribution:approve	patronage_timesheet.divides(jsonb)	patronage-timesheet
patronage:distribution:distribute	patronage_transaction.posted(jsonb)	patronage-transaction
patronage:distribution:approve	patronage_transaction.reserves(jsonb)	patronage-transaction
payslip:run:generate	payslip_timesheet.timed(jsonb)	payslip-timesheet
payslip:run:approve	payslip_transaction.accrued(jsonb)	payslip-transaction
payslip:run:pay	payslip_transaction.paid(jsonb)	payslip-transaction
project-task:task:file	circle_membership.empowered(jsonb)	circle-membership
account:account:draw	account_membership_transaction.draws(jsonb)	account-membership-transaction
account:capital:pay	account_membership_transaction.pays(jsonb)	account-membership-transaction
account:capital:repay	account_membership_transaction.repays(jsonb)	account-membership-transaction
account:terms:adopt	circle_decision_membership.carried(jsonb)	circle-decision-membership
circle:circle:nest	circle_decision_membership.carried(jsonb)	circle-decision-membership
circle:mandate:grant	circle_decision_membership.carried(jsonb)	circle-decision-membership
circle:mandate:revoke	circle_decision_membership.carried(jsonb)	circle-decision-membership
document:document:adopt	circle_decision_membership.carried(jsonb)	circle-decision-membership
membership:member:admit	circle_decision_membership.carried(jsonb)	circle-decision-membership
membership:member:suspend	circle_decision_membership.carried(jsonb)	circle-decision-membership
membership:member:exit	circle_decision_membership.carried(jsonb)	circle-decision-membership
membership:member:erase	circle_decision_membership.carried(jsonb)	circle-decision-membership
patronage:distribution:approve	circle_decision_membership.carried(jsonb)	circle-decision-membership
patronage:terms:adopt	circle_decision_membership.carried(jsonb)	circle-decision-membership
decision:decision:vote	circle_decision_membership.on_roll(jsonb)	circle-decision-membership
circle-membership:position:add	circle_decision_membership.carried(jsonb)	circle-decision-membership
circle-membership:position:remove	circle_decision_membership.carried(jsonb)	circle-decision-membership
circle-membership:position:add	circle_decision_membership.seats(jsonb)	circle-decision-membership
circle-membership:position:remove	circle_decision_membership.unseats(jsonb)	circle-decision-membership
decision:decision:propose	circle_decision_membership.sits(jsonb)	circle-decision-membership
decision:decision:close	circle_decision_membership.sits(jsonb)	circle-decision-membership
decision:decision:propose	circle_decision_membership.asks(jsonb)	circle-decision-membership
decision:decision:close	circle_decision_membership.settles(jsonb)	circle-decision-membership
decision:message:post	circle_decision_membership.sits(jsonb)	circle-decision-membership
expense:expense:approve	circle_expense_membership.within(jsonb)	circle-expense-membership
meeting:item:add	circle_meeting_membership.sits(jsonb)	circle-meeting-membership
meeting:item:move	circle_meeting_membership.sits(jsonb)	circle-meeting-membership
meeting:item:remove	circle_meeting_membership.sits(jsonb)	circle-meeting-membership
meeting:meeting:schedule	circle_meeting_membership.reaches(jsonb)	circle-meeting-membership
meeting:meeting:hold	circle_meeting_membership.reaches(jsonb)	circle-meeting-membership
meeting:meeting:cancel	circle_meeting_membership.reaches(jsonb)	circle-meeting-membership
meeting:meeting:minute	circle_meeting_membership.reaches(jsonb)	circle-meeting-membership
meeting-membership:attendance:record	circle_meeting_membership.reaches(jsonb)	circle-meeting-membership
meeting-membership:attendance:record	circle_meeting_membership.records(jsonb)	circle-meeting-membership
project:project:create	circle_membership_project.runs(jsonb)	circle-membership-project
project:milestone:add	circle_membership_project.runs(jsonb)	circle-membership-project
project:milestone:complete	circle_membership_project.runs(jsonb)	circle-membership-project
project:project:budget	circle_membership_project.runs(jsonb)	circle-membership-project
project:project:archive	circle_membership_project.runs(jsonb)	circle-membership-project
membership-project:project:share	circle_membership_project.runs(jsonb)	circle-membership-project
timesheet:period:approve	circle_membership_timesheet.approves(jsonb)	circle-membership-timesheet
employment-project-timesheet:entry:book	timesheet.logs(jsonb)	employment-project-timesheet
employment-project-timesheet:entry:book	employment_timesheet.works(jsonb)	employment-project-timesheet
patronage:distribution:distribute	account_membership_patronage_transaction.credited(jsonb)	account-membership-patronage-transaction
payslip:run:pay	account_membership_payslip_transaction.deducted(jsonb)	account-membership-payslip-transaction
account:capital:spread	account_membership_payslip_transaction.spreads(jsonb)	account-membership-payslip-transaction
\.


--
-- Data for Name: rule_text; Type: TABLE DATA; Schema: cella; Owner: -
--

COPY cella.rule_text (hash, fn, body) FROM stdin;
\\x55041ba8e596cbef8fd8a98e34ea466cc9ecda33d7651d05fb9eefa84fcc3c4f	circle_membership.empowered(jsonb)	CREATE OR REPLACE FUNCTION circle_membership.empowered(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN ((w.amount IS NOT NULL) AND (w.cents IS NULL)) THEN (((w.op || ' names its amount in '::text) || w.amount) || ', which the payload lacks'::text)\n             WHEN (NOT circle_membership.may(cella.actor(), w.power, w.cents, cella.verdict_date())) THEN (((cella.actor() || ' holds no mandate for '::text) || w.power) || COALESCE(((' up to '::text || (cella.amount(w.cents))::text) || ' €'::text), ''::text))\n             ELSE NULL::text\n         END AS "case"\n    FROM ( SELECT p.op,\n             p.power,\n             p.amount,\n             ((empowered.payload ->> p.amount))::bigint AS cents\n            FROM cella.power p\n           WHERE (p.op = cella.op())) w;\nEND\n
\\xe89d5dab0937fd46b4ca891383d8d2bfad81ad95053c074cfa9d6517c5af6c77	client.erases(jsonb)	CREATE OR REPLACE FUNCTION client.erases(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (c.id IS NULL) THEN ('no client '::text || COALESCE(p.client, 'is named'::text))\n             WHEN (c.kind <> 'person'::text) THEN (c.id || ' is a company: its data is not personal'::text)\n             WHEN ((p.subject IS DISTINCT FROM c.id) OR (p.erased IS DISTINCT FROM '["contact"]'::jsonb)) THEN (('the erasure is not of '::text || c.id) || '''s contact data'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (erases.payload ->> 'client'::text) AS client,\n             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,\n             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased) p\n      LEFT JOIN client.client c ON ((c.id = p.client)));\nEND\n
\\xb69e135406014016141841e464f57c5561fd6d92b12e51aadf62595314bd672f	person.own_profile(jsonb)	CREATE OR REPLACE FUNCTION person.own_profile(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (x.address IS NULL) THEN ('no one '::text || COALESCE(p.address, 'is named'::text))\n             WHEN (x.address <> cella.actor()) THEN (((cella.actor() || ' may not edit '::text) || x.address) || '''s profile'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (own_profile.payload ->> 'person'::text) AS address) p\n      LEFT JOIN person.person x ON ((x.address = p.address)));\nEND\n
\\x4c48015db890c9c16ed21580c1ef9736f016ac09b45dacd08170cc6014c5dc07	person.forgets(jsonb)	CREATE OR REPLACE FUNCTION person.forgets(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (p.subject IS NULL) THEN 'the write erases nothing'::text\n             WHEN (p.subject IS DISTINCT FROM cella.actor()) THEN (((cella.actor() || ' may not erase '::text) || p.subject) || '''s contact details'::text)\n             WHEN ((p.erased IS DISTINCT FROM '["contact"]'::jsonb) OR (p.restricted IS DISTINCT FROM '[]'::jsonb)) THEN 'a person erases their contact details alone'::text\n             ELSE NULL::text\n         END AS "case"\n    FROM ( SELECT (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,\n             (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased,\n             (((forgets.payload -> 'erasure'::text) -> '$erasure'::text) -> 'restricted'::text) AS restricted) p;\nEND\n
\\xc3deed64467c6490bde4ab2c517e9a77cc2cb740495225521a3465a9cde34eb7	expense.captures(jsonb)	CREATE OR REPLACE FUNCTION expense.captures(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))\n             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN ((COALESCE(cella.actor(), 'no one'::text) || ' may not claim an expense for '::text) || e.member)\n             WHEN (e.day > cella.verdict_date()) THEN (('an expense on '::text || (e.day)::text) || ' is in the future'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (captures.payload ->> 'expense'::text) AS expense) x\n      LEFT JOIN expense.expense e ON ((e.id = x.expense)));\nEND\n
\\xf19a8f42daae29214a290b19607a93d6ecd77134bb905f88ec922912c65b0188	expense_file.attaches(jsonb)	CREATE OR REPLACE FUNCTION expense_file.attaches(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN ((x.file IS NULL) AND (cella.op() = 'expense:expense:capture'::text)) THEN NULL::text\n             WHEN (e.id IS NULL) THEN ('no expense '::text || COALESCE(x.expense, 'is named'::text))\n             WHEN (e.member IS DISTINCT FROM cella.actor()) THEN (((COALESCE(cella.actor(), 'no one'::text) || ' may not attach a receipt to '::text) || e.member) || '''s expense'::text)\n             WHEN (e.status = ANY (ARRAY['refused'::text, 'reimbursed'::text])) THEN ((e.id || ' is '::text) || e.status)\n             WHEN (r.file IS NULL) THEN ((COALESCE(x.file, 'no file'::text) || ' is not attached to '::text) || e.id)\n             ELSE file.stored(x.file, 'expense-receipt'::text, e.member)\n         END AS stored\n    FROM ((( SELECT (attaches.payload ->> 'expense'::text) AS expense,\n             (attaches.payload ->> 'file'::text) AS file) x\n      LEFT JOIN expense.expense e ON ((e.id = x.expense)))\n      LEFT JOIN expense_file.receipt r ON (((r.expense = x.expense) AND (r.file = x.file))));\nEND\n
\\x86b2c2444f97fb89930f88997ce8109a3d72b7c0d7284fefd5ec7e889aca10f5	account_decision.asks(jsonb)	CREATE OR REPLACE FUNCTION account_decision.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (t.id IS NULL) THEN (('no terms '::text || COALESCE((m.args ->> 'terms'::text), 'are named'::text)) || ' to adopt'::text)\n                     WHEN (t.adopted IS NOT NULL) THEN ((t.id || ' were adopted on '::text) || to_char((t.adopted)::timestamp with time zone, 'YYYY-MM-DD'::text))\n                     WHEN (a.decision IS NULL) THEN ((m.decision || ' does not ask to adopt '::text) || t.id)\n                     ELSE NULL::text\n                 END AS r\n            FROM ((decision.motion m\n              LEFT JOIN account.terms t ON ((t.id = (m.args ->> 'terms'::text))))\n              LEFT JOIN account_decision.adoption a ON (((a.decision = m.decision) AND (a.terms = t.id))))\n           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'terms'::text))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\x46238e5504eae07f6e432e188c61c5d84ffeaa46075bff9d3cce889445ec3b96	circle_decision.asks(jsonb)	CREATE OR REPLACE FUNCTION circle_decision.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN ((m.kind = 'nest'::text) AND (NOT (EXISTS ( SELECT\n                        FROM circle.circle c\n                       WHERE (c.id = (m.args ->> 'circle'::text)))))) THEN (('no circle '::text || COALESCE((m.args ->> 'circle'::text), 'is named'::text)) || ' to nest'::text)\n                     WHEN ((m.kind = 'nest'::text) AND (NOT (EXISTS ( SELECT\n                        FROM circle.circle c\n                       WHERE (c.id = (m.args ->> 'parent'::text)))))) THEN (('no circle '::text || COALESCE((m.args ->> 'parent'::text), 'is named'::text)) || ' to nest under'::text)\n                     WHEN ((m.kind = 'grant'::text) AND (NOT (EXISTS ( SELECT\n                        FROM circle.role r\n                       WHERE (r.id = (m.args ->> 'role'::text)))))) THEN ('no role '::text || COALESCE((m.args ->> 'role'::text), 'is named'::text))\n                     WHEN ((m.kind = 'grant'::text) AND (COALESCE((m.args ->> 'power'::text), ''::text) !~ '^[a-z][a-z-]*$'::text)) THEN 'a power is named in lower case, such as approve-time'::text\n                     WHEN ((m.kind = 'grant'::text) AND (m.args ? 'limit'::text) AND (m.args ? 'budget'::text)) THEN 'a mandate caps by a limit per write or by a budget, not both'::text\n                     WHEN ((m.kind = 'grant'::text) AND (m.args ? 'budget'::text) AND (COALESCE((m.args ->> 'per'::text), ''::text) <> ALL (ARRAY['month'::text, 'year'::text]))) THEN 'a budget runs per month or per year'::text\n                     WHEN ((m.kind = 'revoke'::text) AND (NOT (EXISTS ( SELECT\n                        FROM circle.mandate x_1\n                       WHERE (((m.args ->> 'mandate'::text) ~ '^[0-9]{1,18}$'::text) AND (x_1.id = ((m.args ->> 'mandate'::text))::bigint) AND (x_1.revoked IS NULL)))))) THEN ('no mandate in force '::text || COALESCE((m.args ->> 'mandate'::text), 'is named'::text))\n                     WHEN ((NOT circle_decision.decides(d.circle, COALESCE(m.circle, '*'::text))) OR ((m.kind = 'nest'::text) AND (NOT circle_decision.decides(d.circle, (m.args ->> 'parent'::text))) AND (d.circle IS DISTINCT FROM (m.args ->> 'parent'::text)))) THEN ((((d.circle || ' may not decide to '::text) || m.kind) || ' in '::text) || COALESCE(m.circle, 'every working circle'::text))\n                     ELSE NULL::text\n                 END AS r\n            FROM (circle_decision.motion m\n              JOIN decision.decision d ON ((d.id = m.decision)))\n           WHERE (m.decision = (asks.payload ->> 'decision'::text))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\x408e7e4b847940b3a3136080c08b68f7aec722096561c31d463f3bfb76cddde7	circle_decision_membership.asks(jsonb)	CREATE OR REPLACE FUNCTION circle_decision_membership.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (NOT (EXISTS ( SELECT\n                        FROM circle.circle c\n                       WHERE ((c.id = d.circle) AND (c.parent IS NULL))))) THEN ((('only the assembly decides to '::text || a.kind) || ' a member, not '::text) || d.circle)\n                     ELSE NULL::text\n                 END AS r\n            FROM (decision_membership.motion a\n              JOIN decision.decision d ON ((d.id = a.decision)))\n           WHERE (a.decision = (asks.payload ->> 'decision'::text))\n         UNION ALL\n          SELECT\n                 CASE\n                     WHEN (NOT (EXISTS ( SELECT\n                        FROM circle.circle c\n                       WHERE (c.id = g.circle)))) THEN ('no circle '::text || COALESCE(g.circle, 'is named'::text))\n                     WHEN ((g.kind = 'seat'::text) AND (NOT (EXISTS ( SELECT\n                        FROM membership.member m\n                       WHERE ((m.address = g.member) AND (m.status = 'active'::text)))))) THEN (COALESCE(g.member, 'no one'::text) || ' is not an active member'::text)\n                     WHEN ((g.kind = 'seat'::text) AND (g.role IS NOT NULL) AND (NOT (EXISTS ( SELECT\n                        FROM circle.role x_1\n                       WHERE ((x_1.id = g.role) AND (x_1.circle = ANY (ARRAY[g.circle, '*'::text]))))))) THEN ((('no role '::text || g.role) || ' in '::text) || g.circle)\n                     WHEN ((g.kind = 'unseat'::text) AND (NOT (EXISTS ( SELECT\n                        FROM circle_membership."position" o\n                       WHERE ((o.circle = g.circle) AND (o.member = g.member) AND (NOT (o.role IS DISTINCT FROM g.role)) AND (o.until IS NULL)))))) THEN ((COALESCE(g.member, 'no one'::text) || ' holds no such seat in '::text) || g.circle)\n                     WHEN (NOT circle_decision.decides(d.circle, g.circle)) THEN ((d.circle || ' may not decide who sits in '::text) || g.circle)\n                     ELSE NULL::text\n                 END AS "case"\n            FROM (( SELECT m.decision,\n                     m.kind,\n                     (m.args ->> 'circle'::text) AS circle,\n                     (m.args ->> 'member'::text) AS member,\n                     (m.args ->> 'role'::text) AS role\n                    FROM decision.motion m\n                   WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = ANY (ARRAY['seat'::text, 'unseat'::text])))) g\n              JOIN decision.decision d ON ((d.id = g.decision)))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\x42c32c9b6e0b127ea61b826ccf90cd5ecbb1eb61c281a2c4a7b3d351cd1ddfaa	circle_decision_membership.sits(jsonb)	CREATE OR REPLACE FUNCTION circle_decision_membership.sits(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is named'::text))\n             WHEN ((NOT (EXISTS ( SELECT\n                FROM circle_membership.seated(d.circle, cella.verdict_date()) s(s)\n               WHERE (s.s = cella.actor())))) OR (NOT (EXISTS ( SELECT\n                FROM membership.member m\n               WHERE ((m.address = cella.actor()) AND (m.status = 'active'::text)))))) THEN ((((((cella.actor() || ' holds no seat in '::text) || d.circle) || ', so may not '::text) || split_part(cella.op(), ':'::text, 3)) || ' '::text) || d.id)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (sits.payload ->> 'decision'::text) AS decision) p\n      LEFT JOIN decision.decision d ON ((d.id = p.decision)));\nEND\n
\\x527f3c7bf6d579d22cb9e84b5db15bf923799c7db0073483199694f45bbd5fd3	decision.proposes(jsonb)	CREATE OR REPLACE FUNCTION decision.proposes(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.id, 'is named'::text))\n             WHEN ((d.proposed IS DISTINCT FROM cella.verdict_date()) OR (d.closed IS NOT NULL)) THEN (d.id || ' was not proposed by this write'::text)\n             WHEN (d.deadline <= d.proposed) THEN ((d.id || '''s deadline must come after '::text) || to_char((d.proposed)::timestamp with time zone, 'YYYY-MM-DD'::text))\n             WHEN (( SELECT count(*) AS count\n                FROM decision.motion m\n               WHERE (m.decision = d.id)) <> jsonb_array_length(COALESCE(p.motions, '[]'::jsonb))) THEN (d.id || ' decides otherwise than its payload names'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (proposes.payload ->> 'decision'::text) AS id,\n             (proposes.payload -> 'motions'::text) AS motions) p\n      LEFT JOIN decision.decision d ON ((d.id = p.id)));\nEND\n
\\xad5ea511e1cde8eaa3bcdd8def7cf4156ce12ae8cdab1bb1a1758b4d6b99ed44	decision_document.asks(jsonb)	CREATE OR REPLACE FUNCTION decision_document.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (v.id IS NULL) THEN (('no version '::text || COALESCE((m.args ->> 'version'::text), 'is named'::text)) || ' to adopt'::text)\n                     WHEN ((a.decision IS NULL) OR (a.hash <> v.hash)) THEN (((m.decision || ' does not adopt '::text) || v.id) || ' as it hashes'::text)\n                     ELSE NULL::text\n                 END AS r\n            FROM ((decision.motion m\n              LEFT JOIN document.version v ON ((v.id = (m.args ->> 'version'::text))))\n              LEFT JOIN decision_document.adoption a ON (((a.decision = m.decision) AND (a.document = v.document) AND (a.version = v.id))))\n           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'adopt'::text))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\xce1712129bafbbba5591da9809f19dc83aa19c9f57208f1b7d94c12c8b9b6cb5	decision_membership.asks(jsonb)	CREATE OR REPLACE FUNCTION decision_membership.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (m.member IS NULL) THEN ((m.decision || ' names no member to '::text) || m.kind)\n                     WHEN (mm.address IS NULL) THEN ('no member '::text || m.member)\n                     WHEN ((m.kind = 'admit'::text) AND (mm.status <> 'invited'::text)) THEN (((m.member || ' is '::text) || mm.status) || ', not invited'::text)\n                     WHEN ((m.kind = 'admit'::text) AND (COALESCE(m.shares, 0) <= 0)) THEN 'an admission subscribes a whole number of shares'::text\n                     WHEN ((m.kind = 'suspend'::text) AND (mm.status <> 'active'::text)) THEN (((m.member || ' is '::text) || mm.status) || ', not active'::text)\n                     WHEN ((m.kind = 'exit'::text) AND (mm.status <> ALL (ARRAY['active'::text, 'suspended'::text]))) THEN ((m.member || ' is '::text) || mm.status)\n                     WHEN ((m.kind = 'erase'::text) AND (mm.status <> 'exited'::text)) THEN (((m.member || ' is '::text) || mm.status) || ': only a member who has left is erased'::text)\n                     ELSE NULL::text\n                 END AS r\n            FROM (decision_membership.motion m\n              LEFT JOIN membership.member mm ON ((mm.address = m.member)))\n           WHERE (m.decision = (asks.payload ->> 'decision'::text))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\x81f441ae28101c19efc66a0d9cf233f51b668ed8507fa2bd8fa20a2ab102c037	decision_patronage.asks(jsonb)	CREATE OR REPLACE FUNCTION decision_patronage.asks(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (t.id IS NULL) THEN (('no terms '::text || COALESCE((m.args ->> 'terms'::text), 'are named'::text)) || ' to adopt'::text)\n                     WHEN (t.adopted IS NOT NULL) THEN ((t.id || ' were adopted on '::text) || to_char((t.adopted)::timestamp with time zone, 'YYYY-MM-DD'::text))\n                     WHEN (a.decision IS NULL) THEN ((m.decision || ' does not ask to adopt '::text) || t.id)\n                     ELSE NULL::text\n                 END AS r\n            FROM ((decision.motion m\n              LEFT JOIN patronage.terms t ON ((t.id = (m.args ->> 'terms'::text))))\n              LEFT JOIN decision_patronage.adoption a ON (((a.decision = m.decision) AND (a.terms = t.id))))\n           WHERE ((m.decision = (asks.payload ->> 'decision'::text)) AND (m.kind = 'patronage'::text))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\xc786fd4214f65f1d544368dae7e8dc49132fa0349f895d81bd51be032be9f3ae	circle_decision_membership.on_roll(jsonb)	CREATE OR REPLACE FUNCTION circle_decision_membership.on_roll(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (NOT (EXISTS ( SELECT\n                FROM circle_decision_membership.roll r\n               WHERE ((r.decision = p.decision) AND (r.member = p.member))))) THEN ((COALESCE(p.member, 'no one'::text) || ' is not on the roll of '::text) || COALESCE(p.decision, 'no decision'::text))\n             WHEN (NOT (EXISTS ( SELECT\n                FROM membership.member m\n               WHERE ((m.address = p.member) AND (m.status = 'active'::text))))) THEN (p.member || ' is not an active member'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM ( SELECT (on_roll.payload ->> 'decision'::text) AS decision,\n             (on_roll.payload ->> 'member'::text) AS member) p;\nEND\n
\\xf9142eddd70dcf4865c93315982d6e728b4397986659a0c3a906a29ecb0cecc6	decision.own_stance(jsonb)	CREATE OR REPLACE FUNCTION decision.own_stance(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (p.member IS DISTINCT FROM cella.actor()) THEN ((cella.actor() || ' may not vote for '::text) || COALESCE(p.member, 'no one'::text))\n             ELSE NULL::text\n         END AS "case"\n    FROM ( SELECT (own_stance.payload ->> 'member'::text) AS member) p;\nEND\n
\\xf14289a832e6b082de1b7281153435b254fabd2061ade34ea820112c4bfdf57a	circle_decision_membership.settles(jsonb)	CREATE OR REPLACE FUNCTION circle_decision_membership.settles(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN ((d.id IS NULL) OR (d.closed IS NULL)) THEN NULL::text\n             WHEN COALESCE(circle_decision_membership.passes(d.id), false) THEN ( SELECT x.r\n                FROM ( SELECT\n                             CASE\n                                 WHEN (a.member IS NULL) THEN ((d.id || ' passes, and its close does not admit '::text) || m.member)\n                                 ELSE circle_decision_membership.seats(jsonb_build_object('position', a."position", 'decision', d.id))\n                             END AS r\n                        FROM (decision_membership.motion m\n                          LEFT JOIN jsonb_to_recordset(COALESCE((settles.payload -> 'admitted'::text), '[]'::jsonb)) a(member text, "position" bigint) ON ((a.member = m.member)))\n                       WHERE ((m.decision = d.id) AND (m.kind = 'admit'::text))) x\n               WHERE (x.r IS NOT NULL)\n              LIMIT 1)\n             WHEN (jsonb_array_length(COALESCE((settles.payload -> 'admitted'::text), '[]'::jsonb)) > 0) THEN (d.id || ' does not pass, so its close admits no one'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (settles.payload ->> 'decision'::text) AS id) p\n      LEFT JOIN decision.decision d ON ((d.id = p.id)));\nEND\n
\\x2807de534b3206ec290a6f6324276c299bb789eee2a8b6ca63900cc7e5d6beff	decision.closes(jsonb)	CREATE OR REPLACE FUNCTION decision.closes(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (d.id IS NULL) THEN ('no decision '::text || p.id)\n             WHEN (d.closed IS DISTINCT FROM cella.verdict_date()) THEN (d.id || ' was not closed by this write'::text)\n             WHEN (d.closed < d.deadline) THEN ((d.id || ' is open until '::text) || to_char((d.deadline)::timestamp with time zone, 'YYYY-MM-DD'::text))\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (closes.payload ->> 'decision'::text) AS id) p\n      LEFT JOIN decision.decision d ON ((d.id = p.id)));\nEND\n
\\xdf9a8302ae2f6e300a8570db2956fb32bdc08bc6f86fee18d3bc77014cb8bc7f	decision_membership.closes(jsonb)	CREATE OR REPLACE FUNCTION decision_membership.closes(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT x.r\n    FROM ( SELECT\n                 CASE\n                     WHEN (m.member IS NULL) THEN (((closes.payload ->> 'decision'::text) || ' does not admit '::text) || a.member)\n                     WHEN (mm.shares IS DISTINCT FROM m.shares) THEN ((((a.member || ' holds '::text) || COALESCE(mm.shares, 0)) || ' shares, not '::text) || m.shares)\n                     ELSE membership.admitted(jsonb_build_object('member', a.member))\n                 END AS r\n            FROM ((jsonb_to_recordset(COALESCE((closes.payload -> 'admitted'::text), '[]'::jsonb)) a(member text)\n              LEFT JOIN decision_membership.motion m ON (((m.decision = (closes.payload ->> 'decision'::text)) AND (m.kind = 'admit'::text) AND (m.member = a.member))))\n              LEFT JOIN membership.member mm ON ((mm.address = a.member)))) x\n   WHERE (x.r IS NOT NULL)\n  LIMIT 1;\nEND\n
\\xb29c4dfbbc3e4a230cc517f8d7ec3e3cf7573c5e02031376127969def0d7ef1f	circle_decision_membership.carried(jsonb)	CREATE OR REPLACE FUNCTION circle_decision_membership.carried(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))\n             WHEN (d.closed IS NULL) THEN (d.id || ' is not closed'::text)\n             WHEN (NOT circle_decision_membership.passes(d.id)) THEN ((d.id || ' does not pass by '::text) || d.rule)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (carried.payload ->> 'decision'::text) AS decision) p\n      LEFT JOIN decision.decision d ON ((d.id = p.decision)));\nEND\n
\\x9f5b588466c5b8aa11de1c407764a1c00e83e7cdea3a99357f1bf6f4e1308092	decision_membership.ends(jsonb)	CREATE OR REPLACE FUNCTION decision_membership.ends(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (d.id IS NULL) THEN ('no decision '::text || COALESCE(p.decision, 'is cited'::text))\n             WHEN (NOT (EXISTS ( SELECT\n                FROM decision_membership.motion m\n               WHERE ((m.decision = d.id) AND (m.kind = split_part(cella.op(), ':'::text, 3)) AND (m.member = p.member))))) THEN ((((d.id || ' does not '::text) || split_part(cella.op(), ':'::text, 3)) || ' '::text) || COALESCE(p.member, 'anyone'::text))\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (ends.payload ->> 'decision'::text) AS decision,\n             (ends.payload ->> 'member'::text) AS member) p\n      LEFT JOIN decision.decision d ON ((d.id = p.decision)));\nEND\n
\\xd65753e496b1f814987f698900d7216a60c084bbd360a14c6c4fa3133d819fdb	membership.ends(jsonb)	CREATE OR REPLACE FUNCTION membership.ends(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(p.address, 'is named'::text))\n             WHEN ((split_part(cella.op(), ':'::text, 3) = 'suspend'::text) AND ((m.status <> 'suspended'::text) OR (m.suspended IS DISTINCT FROM cella.verdict_date()))) THEN (m.address || ' was not suspended by this write'::text)\n             WHEN ((split_part(cella.op(), ':'::text, 3) = 'exit'::text) AND ((m.status <> 'exited'::text) OR (m.exited IS DISTINCT FROM cella.verdict_date()))) THEN (m.address || ' did not exit by this write'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (ends.payload ->> 'member'::text) AS address) p\n      LEFT JOIN membership.member m ON ((m.address = p.address)));\nEND\n
\\xc924a2e08fce81f6491191c9c7a90d1dd50c8f15a64c9cfefb48a60eae2dcf77	membership.erases(jsonb)	CREATE OR REPLACE FUNCTION membership.erases(payload jsonb)\n RETURNS text\n LANGUAGE sql\n STABLE\nBEGIN ATOMIC\n SELECT\n         CASE\n             WHEN (m.address IS NULL) THEN ('no member '::text || COALESCE(p.member, 'is named'::text))\n             WHEN (m.status <> 'exited'::text) THEN (((m.address || ' is '::text) || m.status) || ': only a member who has left is erased'::text)\n             WHEN ((p.subject IS DISTINCT FROM m.address) OR ((COALESCE(jsonb_array_length(p.erased), 0) + COALESCE(jsonb_array_length(p.restricted), 0)) <> ( SELECT count(*) AS count\n                FROM cella.retention))) THEN (('the erasure is not of all of '::text || m.address) || '''s personal data'::text)\n             ELSE NULL::text\n         END AS "case"\n    FROM (( SELECT (erases.payload ->> 'member'::text) AS member,\n             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) ->> 'subject'::text) AS subject,\n             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'erased'::text) AS erased,\n             (((erases.payload -> 'erasure'::text) -> '$erasure'::text) -> 'restricted'::text) AS restricted) p\n      LEFT JOIN membership.member m ON ((m.address = p.member)));\nEND\n
\.


--
-- Data for Name: circle; Type: TABLE DATA; Schema: circle; Owner: -
--

COPY circle.circle (id, name, parent, purpose, procedure, path) FROM stdin;
ag	Assemblée générale	\N	every member, one vote: statutes, admissions, accounts and surplus	consent	{ag}
coordination	Coordination	ag	weekly: pipeline, staffing and anything that crosses circles	consent	{ag,coordination}
web	Web	coordination	sites, shops and applications	consent	{ag,coordination,web}
brand	Brand	coordination	identity, print, packaging, illustration and motion	consent	{ag,coordination,brand}
marketing	Marketing	coordination	strategy, content, social media and campaigns	consent	{ag,coordination,marketing}
operations	Operations	coordination	finance, administration, contracts and tools	consent	{ag,coordination,operations}
\.


--
-- Data for Name: mandate; Type: TABLE DATA; Schema: circle; Owner: -
--

COPY circle.mandate (id, role, power, text, "limit", budget, per, "from", until, revoked) FROM stdin;
1	member	edit-client	add and edit clients	\N	\N	\N	\N	\N	\N
2	member	edit-document	edit, version and comment on documents	\N	\N	\N	\N	\N	\N
3	member	edit-task	create, assign, file and move tasks	\N	\N	\N	\N	\N	\N
4	member	log-time	log and submit one's own time	\N	\N	\N	\N	\N	\N
5	member	invite-member	invite someone to join, with their first device	\N	\N	\N	\N	\N	\N
6	manager	commit	sign contracts and commit spending	20000.00	\N	\N	\N	\N	\N
7	finance	record-entry	record entries in the books	\N	\N	\N	\N	\N	\N
8	finance	carry-books	carry the books over from the co-op's last tool	\N	\N	\N	\N	\N	\N
9	finance	pay-supplier	pay suppliers	3000.00	\N	\N	\N	\N	\N
10	finance	prepare-payroll	prepare the monthly pay run	\N	\N	\N	\N	\N	\N
11	finance	pay-payroll	pay the monthly pay run	\N	\N	\N	\N	\N	\N
12	manager	approve-payroll	approve the monthly pay run	\N	\N	\N	\N	\N	\N
13	manager	hire-worker	hire workers and open their candidacies	\N	\N	\N	\N	\N	\N
14	finance	reimburse-expense	reimburse members' expenses	3000.00	\N	\N	\N	\N	\N
15	manager	approve-expense	approve members' expenses	2000.00	\N	\N	\N	\N	\N
16	finance	issue-invoice	issue invoices	\N	\N	\N	\N	\N	\N
17	finance	record-receipt	record money received	\N	\N	\N	\N	\N	\N
18	finance	repay-capital	repay departed associates' capital	\N	\N	\N	\N	\N	\N
19	finance	close-period	close a period	\N	\N	\N	\N	\N	\N
20	finance	distribute-surplus	distribute a surplus the assembly approved	\N	\N	\N	\N	\N	\N
21	lead	approve-expense	approve what the circle's members spend	\N	1000.00	month	\N	\N	\N
22	lead	send-quote	send a quote	15000.00	\N	\N	\N	\N	\N
23	manager	manage-project	start and run projects	\N	\N	\N	\N	\N	\N
24	manager	set-budget	set a project's budget and grant shares of it	50000.00	\N	\N	\N	\N	\N
25	manager	erase-personal-data	erase a person's data among the clients, when they ask	\N	\N	\N	\N	\N	\N
26	manager	approve-time	approve timesheets	\N	\N	\N	\N	\N	\N
27	lead	manage-project	start and run projects	\N	\N	\N	\N	\N	\N
28	lead	set-budget	set a project's budget and grant shares of it	15000.00	\N	\N	\N	\N	\N
29	lead	approve-time	approve timesheets	\N	\N	\N	\N	\N	\N
30	treasurer	approve-time	approve everyone's timesheets	\N	\N	\N	\N	\N	\N
31	lead	schedule-meeting	schedule and cancel the circle's meetings	\N	\N	\N	\N	\N	\N
32	manager	schedule-meeting	schedule and cancel meetings	\N	\N	\N	\N	\N	\N
33	secretary	keep-minutes	hold the circle's meetings, record who came and keep their minutes	\N	\N	\N	\N	\N	\N
34	lead	keep-minutes	hold the circle's meetings, record who came and keep their minutes	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: circle; Owner: -
--

COPY circle.role (id, circle, name, duty) FROM stdin;
member	ag	Member	every member, seated in the assembly; what every member may do is granted to it
manager	ag	Gérante	the legal representative, elected by the assembly for four years
lead	*	Circle lead	runs a working circle and sits on coordination
secretary	*	Secretary	keeps a circle's minutes and records who came to its meetings
finance	operations	Finance	issues invoices, pays suppliers and closes the books each month
treasurer	ag	Treasurer	finance's hand in the assembly: approves everyone's time for the pay run
\.


--
-- Data for Name: counted; Type: TABLE DATA; Schema: circle_decision_membership; Owner: -
--

COPY circle_decision_membership.counted (decision, member) FROM stdin;
d-2026-006	amina@lanterne.example
d-2026-006	camille@lanterne.example
d-2026-006	chloe@lanterne.example
d-2026-006	hugo@lanterne.example
d-2026-006	julien@lanterne.example
d-2026-006	lea@lanterne.example
d-2026-006	malik@lanterne.example
d-2026-006	sofia@lanterne.example
d-2026-006	thomas@lanterne.example
d-2026-006	yusuf@lanterne.example
d-2026-007	amina@lanterne.example
d-2026-007	camille@lanterne.example
d-2026-007	chloe@lanterne.example
d-2026-007	hugo@lanterne.example
d-2026-007	julien@lanterne.example
d-2026-007	lea@lanterne.example
d-2026-007	malik@lanterne.example
d-2026-007	sofia@lanterne.example
d-2026-007	thomas@lanterne.example
d-2026-007	yusuf@lanterne.example
d-2026-013	amina@lanterne.example
d-2026-013	camille@lanterne.example
d-2026-013	chloe@lanterne.example
d-2026-013	hugo@lanterne.example
d-2026-013	julien@lanterne.example
d-2026-013	lea@lanterne.example
d-2026-013	malik@lanterne.example
d-2026-013	sofia@lanterne.example
d-2026-013	thomas@lanterne.example
d-2026-013	yusuf@lanterne.example
d-2026-014	amina@lanterne.example
d-2026-014	camille@lanterne.example
d-2026-014	hugo@lanterne.example
d-2026-014	julien@lanterne.example
d-2026-014	lea@lanterne.example
d-2026-014	malik@lanterne.example
d-2026-014	sofia@lanterne.example
d-2026-014	thomas@lanterne.example
d-2026-014	yusuf@lanterne.example
\.


--
-- Data for Name: roll; Type: TABLE DATA; Schema: circle_decision_membership; Owner: -
--

COPY circle_decision_membership.roll (decision, member) FROM stdin;
d-2026-006	amina@lanterne.example
d-2026-006	camille@lanterne.example
d-2026-006	chloe@lanterne.example
d-2026-006	hugo@lanterne.example
d-2026-006	julien@lanterne.example
d-2026-006	lea@lanterne.example
d-2026-006	malik@lanterne.example
d-2026-006	sofia@lanterne.example
d-2026-006	thomas@lanterne.example
d-2026-006	yusuf@lanterne.example
d-2026-007	amina@lanterne.example
d-2026-007	camille@lanterne.example
d-2026-007	chloe@lanterne.example
d-2026-007	hugo@lanterne.example
d-2026-007	julien@lanterne.example
d-2026-007	lea@lanterne.example
d-2026-007	malik@lanterne.example
d-2026-007	sofia@lanterne.example
d-2026-007	thomas@lanterne.example
d-2026-007	yusuf@lanterne.example
d-2026-011	camille@lanterne.example
d-2026-011	hugo@lanterne.example
d-2026-011	julien@lanterne.example
d-2026-011	malik@lanterne.example
d-2026-011	yusuf@lanterne.example
d-2026-012	amina@lanterne.example
d-2026-012	camille@lanterne.example
d-2026-012	chloe@lanterne.example
d-2026-012	hugo@lanterne.example
d-2026-012	julien@lanterne.example
d-2026-012	lea@lanterne.example
d-2026-012	malik@lanterne.example
d-2026-012	sofia@lanterne.example
d-2026-012	thomas@lanterne.example
d-2026-012	yusuf@lanterne.example
d-2026-013	amina@lanterne.example
d-2026-013	camille@lanterne.example
d-2026-013	chloe@lanterne.example
d-2026-013	hugo@lanterne.example
d-2026-013	julien@lanterne.example
d-2026-013	lea@lanterne.example
d-2026-013	malik@lanterne.example
d-2026-013	sofia@lanterne.example
d-2026-013	thomas@lanterne.example
d-2026-013	yusuf@lanterne.example
d-2026-014	amina@lanterne.example
d-2026-014	camille@lanterne.example
d-2026-014	chloe@lanterne.example
d-2026-014	hugo@lanterne.example
d-2026-014	julien@lanterne.example
d-2026-014	lea@lanterne.example
d-2026-014	malik@lanterne.example
d-2026-014	sofia@lanterne.example
d-2026-014	thomas@lanterne.example
d-2026-014	yusuf@lanterne.example
\.


--
-- Data for Name: opener; Type: TABLE DATA; Schema: circle_file_membership; Owner: -
--

COPY circle_file_membership.opener (class, power) FROM stdin;
expense-receipt	approve-expense
expense-receipt	reimburse-expense
payroll	approve-payroll
payroll	pay-payroll
payroll	hire-worker
profile	invite-member
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: circle_meeting; Owner: -
--

COPY circle_meeting.setting (circle, quorum, adopts) FROM stdin;
ag	50	t
coordination	50	f
\.


--
-- Data for Name: position; Type: TABLE DATA; Schema: circle_membership; Owner: -
--

COPY circle_membership."position" (id, circle, member, role, since, until) FROM stdin;
1	ag	camille@lanterne.example	member	\N	\N
2	ag	yusuf@lanterne.example	member	\N	\N
3	ag	hugo@lanterne.example	member	\N	\N
4	ag	julien@lanterne.example	member	\N	\N
5	ag	lea@lanterne.example	member	\N	\N
6	ag	thomas@lanterne.example	member	\N	\N
7	ag	sofia@lanterne.example	member	\N	\N
8	ag	malik@lanterne.example	member	\N	\N
9	ag	amina@lanterne.example	member	\N	\N
10	ag	chloe@lanterne.example	member	\N	\N
11	brand	camille@lanterne.example	\N	\N	\N
12	web	yusuf@lanterne.example	lead	\N	\N
13	brand	hugo@lanterne.example	lead	\N	\N
14	operations	julien@lanterne.example	lead	\N	\N
15	web	lea@lanterne.example	\N	\N	\N
16	web	thomas@lanterne.example	\N	\N	\N
17	brand	sofia@lanterne.example	\N	\N	\N
18	marketing	malik@lanterne.example	lead	\N	\N
19	web	amina@lanterne.example	\N	\N	\N
20	marketing	chloe@lanterne.example	\N	\N	\N
21	ag	camille@lanterne.example	manager	2024-06-20	2028-06-20
22	operations	julien@lanterne.example	finance	\N	\N
23	ag	julien@lanterne.example	treasurer	\N	\N
24	coordination	camille@lanterne.example	\N	\N	\N
25	coordination	yusuf@lanterne.example	\N	\N	\N
26	coordination	hugo@lanterne.example	\N	\N	\N
27	coordination	malik@lanterne.example	\N	\N	\N
28	coordination	julien@lanterne.example	\N	\N	\N
29	ag	julien@lanterne.example	secretary	\N	\N
30	coordination	malik@lanterne.example	secretary	\N	\N
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: client; Owner: -
--

COPY client.client (id, kind, name, form, email, phone, address, parent, tags, note, status) FROM stdin;
halles	company	Les Halles Paysannes	SCIC SA	\N	\N	\N	\N	{}	a network of farmers' shops; brand refresh and an online shop	active
clairval	company	Ville de Clairval	commune	\N	\N	\N	\N	{}	the town website, rebuilt to RGAA accessibility; won by tender	active
nuvola	company	Nuvola Énergie	SCIC SAS	\N	\N	\N	\N	{}	a citizen solar co-op; monthly marketing retainer	active
mauve	company	Compagnie Mauve Horizon	association	\N	\N	\N	\N	{}	a theatre company; season posters and brochure	active
velo	company	Vélo Solidaire	association	\N	\N	\N	\N	{}	a bike repair workshop; brand identity at the solidarity rate	active
ferrand	company	Maison Ferrand	SARL	\N	\N	\N	\N	{}	an artisan bakery group; packaging design	active
terres	company	Fondation Terres Vives	fondation	\N	\N	\N	\N	{}	a land-trust foundation; annual report and microsite	active
ondine	company	Atelier Ondine	SAS	\N	\N	\N	\N	{}	a ceramics studio; online shop	active
halles-roux	person	redacted	\N	redacted	redacted	\N	halles	{}	redacted	archived
\.


--
-- Data for Name: billing; Type: TABLE DATA; Schema: client_invoice; Owner: -
--

COPY client_invoice.billing (invoice, client) FROM stdin;
F-2026-0041	halles
F-2026-0042	nuvola
F-2026-0043	clairval
F-2026-0044	mauve
F-2026-0045	ondine
F-2026-0046	nuvola
F-2026-0047	halles
F-2026-0048	nuvola
F-2026-0049	clairval
F-2026-0050	velo
F-2026-0051	velo
F-2026-0052	ferrand
F-2026-0053	nuvola
F-2026-0054	halles
F-2026-0055	terres
\.


--
-- Data for Name: commission; Type: TABLE DATA; Schema: client_project; Owner: -
--

COPY client_project.commission (project, client) FROM stdin;
halles-shop	halles
clairval-site	clairval
nuvola-retainer	nuvola
mauve-posters	mauve
velo-identity	velo
ferrand-packaging	ferrand
terres-report	terres
ondine-shop	ondine
\.


--
-- Data for Name: cites; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.cites (op, owner) FROM stdin;
account:terms:adopt	account-decision
circle:circle:nest	circle-decision
circle:mandate:grant	circle-decision
circle:mandate:revoke	circle-decision
document:document:adopt	decision-document
membership:member:admit	decision-membership
membership:member:suspend	decision-membership
membership:member:exit	decision-membership
membership:member:erase	decision-membership
patronage:distribution:approve	decision-patronage
patronage:terms:adopt	decision-patronage
circle-membership:position:add	circle-decision-membership
circle-membership:position:remove	circle-decision-membership
\.


--
-- Data for Name: decision; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.decision (id, circle, title, rule, proposed, deadline, body, closed, cutoff, procedure) FROM stdin;
d-2026-006	ag	Approve the 2025 accounts and allocate the surplus	majority	2026-06-01	2026-06-20	The 2025 surplus of 61 400 € is allocated as the statutes require: 45 % to\nthe members as their share of work (participation), 40 % to the indivisible\nreserves and 15 % as interest on capital.\n	2026-06-20	11	majority
d-2026-007	ag	Adopt the internal rules, version 3	consent	2026-06-01	2026-06-20	Version 3 adds remote work days and the solidarity rate for associations.	2026-06-20	22	consent
d-2026-011	coordination	Raise the day rate for 2027	consent	2026-10-12	2026-11-09	Raise the standard day rate from 520 € to 560 €, keep the solidarity rate\nat 380 €, and publish the rate card as drafted.\n	\N	\N	consent
d-2026-012	ag	Admit Inès Haddad as a member	consent	2026-10-14	2026-10-31	Inès has worked with the web circle since September 2025 and asks to join.\nShe subscribes 20 shares.\n	\N	\N	consent
d-2026-013	ag	End Chloé Moreau's membership	consent	2026-10-24	2026-11-07		2026-11-07	67	consent
d-2026-014	ag	Erase Chloé Moreau's personal data	consent	2026-11-08	2026-11-22		2026-11-22	79	consent
\.


--
-- Data for Name: kind; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.kind (kind, label, fields, owner) FROM stdin;
terms	Adopt the capital's terms	[{"name": "terms", "type": "text", "label": "Terms", "options": "terms"}]	account-decision
nest	Nest a circle	[{"name": "circle", "type": "text", "label": "Circle"}, {"name": "parent", "type": "text", "label": "Under"}]	circle-decision
grant	Grant a mandate	[{"name": "role", "type": "text", "label": "Role"}, {"name": "power", "type": "text", "label": "Power"}, {"name": "text", "type": "text", "label": "Grants"}, {"name": "limit", "type": "number", "label": "Limit per write, €", "optional": true}, {"name": "budget", "type": "number", "label": "Budget, €", "optional": true}, {"name": "per", "type": "text", "label": "Budget per (month or year)", "optional": true}]	circle-decision
revoke	Revoke a mandate	[{"name": "mandate", "type": "number", "label": "Mandate"}]	circle-decision
adopt	Adopt a document version	[{"name": "version", "type": "text", "label": "Version", "options": "versions"}]	decision-document
admit	Admit a member	[{"name": "member", "type": "text", "label": "Address"}, {"name": "shares", "type": "number", "label": "Shares"}]	decision-membership
suspend	Suspend a member	[{"name": "member", "type": "text", "label": "Address"}]	decision-membership
exit	End a membership	[{"name": "member", "type": "text", "label": "Address"}]	decision-membership
erase	Erase a former member's personal data	[{"name": "member", "type": "text", "label": "Address"}]	decision-membership
patronage	Adopt the work share's terms	[{"name": "terms", "type": "text", "label": "Terms", "options": "bases"}]	decision-patronage
seat	Seat a member	[{"name": "circle", "type": "text", "label": "Circle"}, {"name": "member", "type": "text", "label": "Address"}, {"name": "role", "type": "text", "label": "Role", "optional": true}]	circle-decision-membership
unseat	End a seat	[{"name": "circle", "type": "text", "label": "Circle"}, {"name": "member", "type": "text", "label": "Address"}, {"name": "role", "type": "text", "label": "Role", "optional": true}]	circle-decision-membership
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.message (receipt, decision, member, reply, body, mentions, links, at) FROM stdin;
\.


--
-- Data for Name: motion; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.motion (decision, n, kind, args) FROM stdin;
d-2026-012	1	admit	{"member": "ines@lanterne.example", "shares": 20}
d-2026-013	1	exit	{"member": "chloe@lanterne.example"}
d-2026-014	1	erase	{"member": "chloe@lanterne.example"}
\.


--
-- Data for Name: procedure; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.procedure (id, label, rule, share_num, share_den, quorum_num, quorum_den) FROM stdin;
consent	Consent	consent	\N	\N	0	1
majority	Majority	majority	\N	\N	0	1
two-thirds	Two thirds	majority	2	3	0	1
ordinary	Ordinary assembly	majority	\N	\N	1	4
extraordinary	Extraordinary assembly	majority	2	3	1	2
\.


--
-- Data for Name: vote; Type: TABLE DATA; Schema: decision; Owner: -
--

COPY decision.vote (receipt, decision, member, stance, at) FROM stdin;
1	d-2026-006	camille@lanterne.example	for	2026-06-20
2	d-2026-006	yusuf@lanterne.example	for	2026-06-20
3	d-2026-006	hugo@lanterne.example	for	2026-06-20
4	d-2026-006	julien@lanterne.example	for	2026-06-20
5	d-2026-006	lea@lanterne.example	for	2026-06-20
6	d-2026-006	thomas@lanterne.example	for	2026-06-20
7	d-2026-006	sofia@lanterne.example	abstain	2026-06-20
8	d-2026-006	malik@lanterne.example	for	2026-06-20
9	d-2026-006	amina@lanterne.example	for	2026-06-20
10	d-2026-006	chloe@lanterne.example	for	2026-06-20
12	d-2026-007	camille@lanterne.example	consent	2026-06-20
13	d-2026-007	yusuf@lanterne.example	consent	2026-06-20
14	d-2026-007	hugo@lanterne.example	consent	2026-06-20
15	d-2026-007	julien@lanterne.example	consent	2026-06-20
16	d-2026-007	lea@lanterne.example	consent	2026-06-20
17	d-2026-007	thomas@lanterne.example	consent	2026-06-20
18	d-2026-007	sofia@lanterne.example	consent	2026-06-20
19	d-2026-007	malik@lanterne.example	consent	2026-06-20
20	d-2026-007	amina@lanterne.example	consent	2026-06-20
21	d-2026-007	chloe@lanterne.example	consent	2026-06-20
23	d-2026-011	camille@lanterne.example	consent	2026-10-13
24	d-2026-011	malik@lanterne.example	object	2026-10-14
25	d-2026-012	yusuf@lanterne.example	consent	2026-10-15
26	d-2026-012	amina@lanterne.example	consent	2026-10-16
27	d-2026-012	thomas@lanterne.example	consent	2026-10-17
28	d-2026-012	lea@lanterne.example	consent	2026-10-18
29	d-2026-012	camille@lanterne.example	consent	2026-10-19
30	d-2026-012	julien@lanterne.example	consent	2026-10-20
31	d-2026-012	chloe@lanterne.example	consent	2026-10-21
32	d-2026-012	hugo@lanterne.example	object	2026-10-21
33	d-2026-012	hugo@lanterne.example	consent	2026-10-23
57	d-2026-013	amina@lanterne.example	consent	2026-10-24
58	d-2026-013	camille@lanterne.example	consent	2026-10-24
59	d-2026-013	chloe@lanterne.example	consent	2026-10-24
60	d-2026-013	hugo@lanterne.example	consent	2026-10-24
61	d-2026-013	julien@lanterne.example	consent	2026-10-24
62	d-2026-013	lea@lanterne.example	consent	2026-10-24
63	d-2026-013	malik@lanterne.example	consent	2026-10-24
64	d-2026-013	sofia@lanterne.example	consent	2026-10-24
65	d-2026-013	thomas@lanterne.example	consent	2026-10-24
66	d-2026-013	yusuf@lanterne.example	consent	2026-10-24
70	d-2026-014	amina@lanterne.example	consent	2026-11-08
71	d-2026-014	camille@lanterne.example	consent	2026-11-08
72	d-2026-014	hugo@lanterne.example	consent	2026-11-08
73	d-2026-014	julien@lanterne.example	consent	2026-11-08
74	d-2026-014	lea@lanterne.example	consent	2026-11-08
75	d-2026-014	malik@lanterne.example	consent	2026-11-08
76	d-2026-014	sofia@lanterne.example	consent	2026-11-08
77	d-2026-014	thomas@lanterne.example	consent	2026-11-08
78	d-2026-014	yusuf@lanterne.example	consent	2026-11-08
\.


--
-- Data for Name: adoption; Type: TABLE DATA; Schema: decision_document; Owner: -
--

COPY decision_document.adoption (decision, document, version, hash) FROM stdin;
d-2026-007	internal-rules	internal-rules@3	\\x2dbdec170b88e09bb6b69f4a0f2dee1be0afa6cab33be5da28573f9f707e84df
d-2026-011	rate-card-2027	rate-card-2027@2	\\x57dcc73b18f9beebd9bbd5142eeaaca29c690847c3530822d783a1c8c992a2d2
\.


--
-- Data for Name: tabled; Type: TABLE DATA; Schema: decision_meeting; Owner: -
--

COPY decision_meeting.tabled (item, meeting, decision) FROM stdin;
1	ag-2026-06-20	d-2026-006
2	ag-2026-06-20	d-2026-007
19	coordination-2026-10-12	d-2026-011
22	coordination-2026-10-19	d-2026-011
23	coordination-2026-10-19	d-2026-012
29	ag-2026-10-31	d-2026-012
30	ag-2026-10-31	d-2026-011
\.


--
-- Data for Name: adoption; Type: TABLE DATA; Schema: decision_patronage; Owner: -
--

COPY decision_patronage.adoption (terms, decision) FROM stdin;
\.


--
-- Data for Name: approval; Type: TABLE DATA; Schema: decision_patronage; Owner: -
--

COPY decision_patronage.approval (distribution, decision) FROM stdin;
2025	d-2026-006
\.


--
-- Data for Name: adoption; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.adoption (receipt, document, version, base, adopted) FROM stdin;
38	internal-rules	internal-rules@3	\N	2026-06-20
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.comment (id, version, author, at, quote, anchor, text, resolved) FROM stdin;
1	rate-card-2027@2	malik@lanterne.example	2026-10-21	from 4 800 €	{"to": "AAEBvgYAAhY=", "from": "AQHUBgEBvgYAAgo=", "block": "413@1"}	Nuvola renews in January at the current rate; do we hold it for existing retainers?	f
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.document (id, title) FROM stdin;
internal-rules	Règlement intérieur
rate-card-2027	Rate card 2027
minutes-ag-2026-06-20	Minutes, Annual general assembly
\.


--
-- Data for Name: update; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.update (receipt, document, author, at, bytes) FROM stdin;
34	internal-rules	\N	2026-05-28	\\x6c6f726f000000000000000000000000c03f24db0004830900ef0300ef03011001010000000000000001010000000000050100000100840117040103000a04000000000400020006040000002e0400020034040000004e040002005204000000d60204000200dc0204000000e40204000200e80204000000a00404000200a60404000000b20404000200b60404000000c00604000200c60604000000ea0604000200ee06040000009a07040002009e0704000000b60704000200ba07230474797065056c6576656c047465787404626f6c64066974616c696306626c6f636b73270102021600210b0180028180028280028380028480028580028680028780028880028980028a80f70101044003000204000502030604000902070a00020400030b0e040009020f120002040003131604000902171a00020400031b1e040019021f22000223260002272a000246040004020103040004020103040007040332310400040201030400070403aa01a9010400040201030400070403e401e3010400040201030400030403040003040304000304033e0110060b030510060b030510040b07050c0010060b030510040b07050c0010060b030510040b07050c0010060b030510040b030510040b030510040b01052d080101130801010c0601017f0c010103060101590c01010506010182010c010111060101150601010b0601011100970500000001050768656164696e67030109021552c3a8676c656d656e7420696e74c3a9726965757200170101050768656164696e67030209020c576f726b696e672074696d6500270201050970617261677261706809027f412066756c6c2d74696d65206d656d62657220776f726b7320333520686f7572732061207765656b2e20557020746f20746872656520646179732061207765656b206d617920626520776f726b65642072656d6f74656c793b205475657364617920697320612073747564696f2064617920666f722065766572796f6e652e8408030100ab010301050768656164696e67030209020350617900b2010401050970617261677261706809025950617920666f6c6c6f7773206f6e6520677269643a2074686520726174696f206265747765656e20746865206869676865737420616e6420746865206c6f776573742073616c617279206973206174206d6f737420312e362e840303010090020501050768656164696e67030209020552617465730099020601050970617261677261706809028201546865207374616e64617264206461792072617465206973207365742065616368207965617220627920636f6f7264696e6174696f6e2e204173736f63696174696f6e7320616e6420636f2d6f70732077697468206665776572207468616e2074656e207374616666207061792074686520736f6c6964617269747920726174652e840a040100a0030701050768656164696e670302090211436c69656e74732077652072656675736500b5030801050662756c6c6574090215466f7373696c206675656c20636f6d70616e69657300cd030901050662756c6c657409020b41726d73206d616b65727300db030a01050662756c6c6574090211506f6c69746963616c2070617274696573
35	rate-card-2027	\N	2026-10-09	\\x6c6f726f000000000000000000000000628b9b470004ad0a00d10300d103011001010000000000000001010000000000050100000100b6011f040103000a0400000000040002000604000000240400020028040000009402040002009a0204000000ac0204000200b00204000000e00204000200e40204000000840304000200880304000000ac0304000200b00304000000ee0304000200f20304000000a00404000200a40404000000d60404000200da04040000008a05040002008e0504000000be0504000200c20504000000f40504000200f80504000000ba0604000200be0604000000ec0604000200f006230474797065056c6576656c0474657874066974616c696304626f6c6406626c6f636b731b0102020e0015070180028180028280028380028480028580028680bd020104500300020400090203060002080003070a040009020b0e00020400170f12000213160002171a00020400171b1e00021f22000223260002040017272a00022b2e00022f32000204000f33360002373a00025304000402010304000b04034241c601c501040004020103040003040308000304030400030403040003040308000304030400030403040003040308000304030400030403040003040308000304030400030403580110060b030510040b0b050c000c0010060b030510040b07050c0010040b030510040b030510040b07050c0010040b030510040b030510040b07050c0010040b030510040b030510040b07050c0010040b030510040b01053c0801010e0601017110010108060101150a01010f060101110601011c0a01011606010118060101150a010117060101180601011e0a0101160601011800d50500000001050768656164696e67030109020e526174652063617264203230323700120101050970617261677261706809027144617920726174657320616e642070726f6a65637420666c6f6f727320666f7220323032372e204173736f63696174696f6e7320616e6420636f2d6f70732077697468206665776572207468616e2074656e207374616666207061792074686520736f6c6964617269747920726174652e84040301840a0401008a010201050768656164696e67030209020853657276696365730096010301050662756c6c6574090217446179206f6620776f726b20e280942070657220646179840b040100b0010000009601050662756c6c65740902115374616e646172643a2035363020e282ac00c2010100009601050662756c6c6574090213536f6c696461726974793a2033383020e282ac00d6010401050662756c6c657409021e4272616e64206964656e7469747920e28094207065722070726f6a656374840e040100f701000000d601050662756c6c65740902185374616e646172643a2066726f6d20362030303020e282ac009002010000d601050662756c6c657409021a536f6c696461726974793a2066726f6d20332033303020e282ac00ab020501050662756c6c65740902175765627369746520e28094207065722070726f6a6563748407040100c502000000ab02050662756c6c65740902195374616e646172643a2066726f6d2031322030303020e282ac00df02010000ab02050662756c6c657409021a536f6c696461726974793a2066726f6d20372035303020e282ac00fa020601050662756c6c65740902204d61726b6574696e672072657461696e657220e2809420706572206d6f6e746884120401009d03000000fa02050662756c6c65740902185374616e646172643a2066726f6d20342038303020e282ac00b603010000fa02050662756c6c657409021a536f6c696461726974793a2066726f6d20322034303020e282ac
36	rate-card-2027	\N	2026-10-20	\\x6c6f726f0000000000000000000000001a9b266b0004a103d10359d10359011101010000000000000000010100000000000501000001003609040103000a04000000a20704000200f20304000000b00704000200b40704000000ec0704000200f007040000009e0804000200a20820047479706505656d62656403726566047465787404626f6c6406626c6f636b731601020504000301000d040180028180028180038581805601041703000206000b02000306000204000f070a00020b0e000215040006020b1c002100060508000306050400030605180110080b05090510040b07050c0010040b030510040b01050c140101190a010116060101180c010302010003019604020102ad0100d10302010505656d62656405086465636973696f6e050a642d323032362d3031310902013500d8030301050662756c6c657409021b4f6e6c696e652073686f7020e28094207065722070726f6a656374840b040100f603000000d803050662756c6c65740902185374616e646172643a2066726f6d20392035303020e282ac008f04010000d803050662756c6c657409021a536f6c696461726974793a2066726f6d20362030303020e282ac
37	minutes-ag-2026-06-20	\N	2026-06-22	\\x6c6f726f000000000000000000000000d6a1275f0004b00b00dd0500dd050110010100000000000000010100000000000501000001007d16040103000c040000000004000200060400000048040000005204000200580400000068040002006c040000009403040002009a0304000000e40304000200e803040000009208040000009c0804000200a20804000000e40804000200e80804000000de0a04000000e80a04000200ee0a04000000fc0a04000200800b260474797065056c6576656c047465787405656d6265640372656604626f6c6406626c6f636b732a0102021800240c0180028180028280028380028480028580028680028780028880028980028a80028b80f201010441030002040005020306060003050804000d02090c00020d1004000902111400020400031518060003171a04000d021b1e00021f220600032124040009022528000249040004020103040003060204030100040201030400030403040004020103040007040378770400030602040301000402010304000304030400030602040301000402010304000304033c0110060b030510080b0110060b030510040b030510060b030510040b07050c0010080b0110060b030510040b030510080b0110060b030510040b01052608010120120101070601019301080101240601019202160101200601017a120101060601011c00cb0700000001050768656164696e6703010902204d696e757465732c20416e6e75616c2067656e6572616c20617373656d626c79002401010505656d62656405076d656574696e67050d61672d323032362d30362d3230090200290201050768656164696e67030209020750726573656e7400340301050970617261677261706809029501416c6c2074656e206d656d626572732c206174207468652073747564696f3a2043616d696c6c652c2059757375662c204875676f2c204a756c69656e2c204cc3a9612c2054686f6d61732c20536f6669612c204d616c696b2c20416d696e6120616e642043686c6fc3a92e2043616d696c6c6520636861697265643b204a756c69656e20746f6f6b20746865206d696e757465732e00ca010401050768656164696e670302090224312e205468652032303235206163636f756e747320616e642074686520737572706c757300f20105010509706172616772617068090294024a756c69656e2070726573656e746564207468652032303235206163636f756e74732c20636c6f73696e67206f6e206120737572706c7573206f662036312034303020e282ac2e2054686520617373656d626c7920617070726f766564207468656d20616e642073706c69742074686520737572706c7573206173206c6f692037382d3736332c206172742e20333320616c6c6f77733a203435202520746f20746865206d656d6265727320666f7220746865697220776f726b2c203135202520746f20746865206c6567616c20726573657276652c203235202520746f2074686520646576656c6f706d656e742066756e6420616e64203135202520617320696e746572657374206f6e206361706974616c2e8408050100890406010505656d62656405086465636973696f6e050a642d323032362d3030360902008e040701050768656164696e670302090220322e2054686520696e7465726e616c2072756c65732c2076657273696f6e203300b2040801050970617261677261706809027a43616d696c6c652070726573656e7465642076657273696f6e20332c20776869636820616464732072656d6f746520776f726b206461797320616e642074686520736f6c69646172697479207261746520666f72206173736f63696174696f6e732e204576657279206d656d62657220636f6e73656e7465642e00af0509010505656d62656405086465636973696f6e050a642d323032362d303037090200b4050a01050768656164696e670302090206436c6f73656400be050b01050970617261677261706809021c5468652073657373696f6e20636c6f7365642061742031323a34302e
\.


--
-- Data for Name: version; Type: TABLE DATA; Schema: document; Owner: -
--

COPY document.version (id, document, n, saved, snapshot, frontier, vv) FROM stdin;
internal-rules@3	internal-rules	3	2026-05-28	\\x6c6f726f000000000000000000000000966f487d0003170400004c4f524f0004224d18604082dc030000b200ef0300ef0301100101000100030900f000050100000100840117040103000a041c005004000200060a00102e0a0010340a00104e0a0010520a0020d6020b0020dc020c0011e40c0011e80c0020a004180020a604180011b20c0011b60c0020c006180011c6500011ea0c0011ee0c00209a071800209e07300011b60c00f05aba07230474797065056c6576656c047465787404626f6c64066974616c696306626c6f636b73270102021600210b0180028180028280028380028480028580028680028780028880028980028a80f70101044003000204000502030604000902070a00020400030b0e0d00200f121b00300313160d0021171a0d00f40a1b1e040019021f22000223260002272a00024604000402010306005707040332310d0047aa01a9010f0035e401e30f002703040500723e0110060b030505006f040b07050c000c000d012900010500f74e01052d080101130801010c0601017f0c010103060101590c01010506010182010c010111060101150601010b0601011100970500000001050768656164696e67030109021552c3a8676c656d656e7420696e74c3a972696575720017012700f79a0209020c576f726b696e672074696d6500270201050970617261677261706809027f412066756c6c2d74696d65206d656d62657220776f726b7320333520686f7572732061207765656b2e20557020746f20746872656520646179732061207765656b206d617920626520776f726b65642072656d6f74656c793b205475657364617920697320612073747564696f2064617920666f722065766572796f6e652e8408030100ab0103db00ba0209020350617900b20104ac00f1195950617920666f6c6c6f7773206f6e6520677269643a2074686520726174696f206265747765656e1200b16869676865737420616e641000306c6f770f005273616c61729400f70474206d6f737420312e362e84030301009002056101da020902055261746573009902068800e18201546865207374616e64617264d40040726174655500f0097365742065616368207965617220627920636f6f7264696e9f00916e2e204173736f63690d0011739a00f00b636f2d6f70732077697468206665776572207468616e2074656e600061666620706179bf0092736f6c6964617269746c009a2e840a040100a00307b200f72c11436c69656e74732077652072656675736500b5030801050662756c6c6574090215466f7373696c206675656c20636f6d70616e69657300cd03092500f7010b41726d73206d616b65727300db030a4000f00011506f6c69746963616c20706172743c00f00a020066720101dc0700020076760101de07000083048c040300000000005881205801000000050000000c00000000000000000100000000010200767646eb67dcf4030000dd0400004c4f524f0004224d186040829b040000f2230002010006626c6f636b7304030474797065040768656164696e6704746578740701010600056c6576656c0302000101000002009002000300010904001012000f44000f24a604450017044500c092020093020091020904001756000f48000f1f344700019b19001a0018090400198c001202d000a409706172616772617068d20037b604008600409b02009a83001b2783000f3f000618523e007b290028090400a07b000f4b010415c64c01080701cba20300a30300a103090400ab84000f4800042fdc0208010170ad0100ae0100ac97011bb248000fcc000628e802cd0040b40100b33f001bb5cf00033f00740662756c6c6574470128ee063c0040b70300b6c3001fcd3c0012289e073c0040cf0300ce3c001fdb3c001219ba3c0070dd0300dc03000dc90200f500f515000003000000020301010100011552c3a8676c656d656e7420696e74c3a97269657572012a007104020100020108060038260000460023130146009aa004010552617465733700320301a83e001a0a3800141a7e00fa002e010c576f726b696e672074696d653e003102013675001a183d00141b7500f271b204018201546865207374616e64617264206461792072617465206973207365742065616368207965617220627920636f6f7264696e6174696f6e2e204173736f63696174696f6e7320616e6420636f2d6f70732077697468206665776572207468616e2074656e207374616666207061792074686520736f6c6964617269746c00182eb500b10a000809b80484021f220d0c00f806e401e30114150e01066974616c6963010300010184420114290a01a04e017f412066756c6c2d0901f01b206d656d62657220776f726b7320333520686f7572732061207765656b2e20557020746f207468726565f40004190071206d61792062653600f00265642072656d6f74656c793b20547565731c0110692a006073747564696f3800cc20666f722065766572796f6ec800fe0d0a0954fe01cb01ce01bd01020a00070932311011be010104626f6c64c70014a39401fb05c0060111436c69656e7473207765207265667573d701410301c806d8011a22d80114ae0b0178d6020103506179580100360021de0236001a06360014b4360051e402015950d400f1006c6c6f7773206f6e6520677269643ab5011072f70181206265747765656e12007168696768657374fc0170746865206c6f770f005273616c61722a01ab74206d6f737420312e361c01910809ea02b201070a03e4017faa01a9010607041b010514b71b01fe08ea060115466f7373696c206675656c20636f6d70616e69340312f01f011a2ae90014cf4800ed9a07010b41726d73206d616b6572720321a00727011a163e0014dd3e00ff03b6070111506f6c69746963616c207061727482000012bc440000a10133080083fb062603011006ff0a04020216000f15002e2088020ebc01128e022a301c05021600170000f0030216000c0b000102030405060708090a27013d00f044210b0180028180028280028380028480028580028680028780028880028980028a800000003d008500c900080144018c01d40113024f028b02c7020d03450382034f0416055a05900531067906b706fb061700000000002eb76b2501000000050000000d00000100000000000000000000000108008306626c6f636b732f438b07b304000000000000	[{"peer": "1", "counter": 494}]	{"1": 495}
rate-card-2027@1	rate-card-2027	1	2026-10-09	\\x6c6f726f00000000000000000000000084584d210003f00300004c4f524f0004224d18604082b5030000b200d10300d10301100101000100030900f000050100000100b6011f040103000a041c005004000200060a0010240a0010280a002094020b00209a020c0011ac0c0011b00c0011e00c0011e40c0020840324002188032400010c0011b00c0011ee0c0011f20c0020a004240020a404240011d60c0011da0c00208a051800208e05180011be0c0011c20c0011f40c0011f80c0020ba06240011be9a0011ec0c00f05df006230474797065056c6576656c0474657874066974616c696304626f6c6406626c6f636b731b0102020e0015070180028180028280028380028480028580028680bd020104500300020400090203060002080003070a040009020b0e00020400170f12000213160002171a2400b1171b1e00021f22000223260f00a0272a00022b2e00022f320f00f40c0f33360002373a00025304000402010304000b04034241c601c501110072030403080003040a000105000f0f0015f401580110060b030510040b0b050c000c000e006207050c0010041a00011f000f11001bf31801053c0801010e0601017110010108060101150a01010f060101110601011c0a01011606010118180013170c00141e1800f14600d50500000001050768656164696e67030109020e526174652063617264203230323700120101050970617261677261706809027144617920726174657320616e642070726f6a65637420666c6f6f727320666f723700d22e204173736f63696174696f6e2a00f736636f2d6f70732077697468206665776572207468616e2074656e207374616666207061792074686520736f6c6964617269747920726174652e84040301840a0401008a0102ac00f72f0209020853657276696365730096010301050662756c6c6574090217446179206f6620776f726b20e280942070657220646179840b040100b001000000962e00f005115374616e646172643a2035363020e282ac00c25e030824002513539500423a203338260037d601042300c01e4272616e64206964656e74bc00047800032201b7840e040100f701000000d6350016187c009266726f6d20362030305d003a9002012b00181a8300012d00333320332d0037ab020555008d17576562736974658300b607040100c502000000ab022d011b198300253132840010df8400082c000e840033372035840037fa02068400f504204d61726b6574696e672072657461696e65728f00f7016d6f6e746884120401009d03000000fa8d000c1001333420385f003ab603012b000e8c00333220342d00f00a020066720101a00700020076760101a20700002d053605030000000000df4e861001000000050000000c00000000000000000100000000010200767646eb67dccd030000ed0400004c4f524f0004224d18604082ab040000f2230002010006626c6f636b7304030474797065040768656164696e6704746578740701010600056c6576656c03020001010000020090020003000109040010120007440012024400740662756c6c6574430037a404003c00909202009102090400124a000e3c00a4097061726167726170683f0018283e007f1400130904002b78001219da780040ad0200ac78001f453c0012288e05760040c70200c63c001f5f3c001219c23c0040e10200e03c001f7a3c001219f83c0040fc0200fb3c001b8a2c010fac0104249a02ad0117047101708c01008d01008bb0011b9648000fb0010328b002fc0040980100973c001f9dc0001228be063c009f9f03009e03090400b078001219e4780040b20100b178001fb678001219f0780040b80300b778001fc2780012288803b40040c40100c378001fd63c001219b03c0040d80100d73c001ff73c001219f23c0070f90100f801000d9303003e00f50e000003000000020301010100010e526174652063617264203230323701230071040201000201080600381c00003f002312013f00fa0fa004011a536f6c696461726974793a2066726f6d20332033303020e282ac4c00320301a653001a304d0014148c00f11424017144617920726174657320616e642070726f6a65637420666c6f6f727320666f72a300d22e204173736f63696174696f6e2a00f51b636f2d6f70732077697468206665776572207468616e2074656e20737461666620706179207468652073ad00016800182ea300f82912000f112ae2019f01a20199019c012326110212000a11424108097a7714150e02066974616c696304626f6c6402030001018403010101841a01142d1a01f404d60401175765627369746520e2809420706572d000087400f104080006078605292c1d0208000507000e0f1e015f0011015f00085a0014475a00c38a0501195374616e6461726472014f31322030730103219005c0011a2e730114614c002fbe05c001003f3720354d000312c44d000bc001147c4d00f507f40501204d61726b6574696e672072657461696e6572fe005c6d6f6e7468fc0052b6063b3e19fc003f24251afc0005148d2302c89402010853657276696365734b00005e02219c02eb001a10eb0014983b0040ac0201175f02756f6620776f726b9700386461794a0000910152dc02292c1595003f161716950005149ff8004bba06011891013f34203843010321c006a5001a2ca50014b2a50046e00201114b002f353647030212e6e9001a1e440014b88f002fec06d401003f32203491000312f291000bd40114c491004884030113e1032f3338930002218a03d7001a22930014d8460060ac03011e4272d303856964656e746974797f0103e4030c830143ea03373a14032f1c1d14030614f961002dee0383011f3613030512f4ac0000830133080083a308260301d606f2140402021e00151d0024f001188001aa019e019303246a326a347c32050b0e000f0a000202000f260005e2021e00100f0001020304050600010200f04e1b0102020e00150701800281800282800283800284800285800286800000003d007900b500f1002d016901a501ed0129026502a102dd02190355039103d0031d04ea0444059005dd0540067b06d50620076407b107f7075808a3081f0000000000c5f2563401000000050000000d00000100000000000000000000000108008306626c6f636b732f438b07c304000000000000	[{"peer": "1", "counter": 464}]	{"1": 465}
rate-card-2027@2	rate-card-2027	2	2026-10-20	\\x6c6f726f00000000000000000000000048cbee800003be0400004c4f524f0004224d1860408283040000b200aa0400aa0401100101000100030900f000050100000100e00126040103000e041c005004000200060a0010240a0010280a002094020b00209a020c0011ac0c0011b00c0011e00c0011e40c0020840324002188032400010c0011b00c0011ee0c0011f20c0020a004240020a404240011d60c0011da0c00208a051800208e05180011be0c0011c20c0011f40c0011f80c0020ba06240011be9a0011ec0c0011f00c0020a207360020b0071e0011b40c0011ec0c0011f00c00209e081800f143a2082d0474797065056c6576656c0474657874066974616c696304626f6c6405656d6265640372656606626c6f636b73280102090400010108000301001b09018002818002818002828002838002848002851200f00886808c030104660300020400090203060002080003070a0d00200b0e1500b1170f12000213160002171a0f00a11b1e00021f22000223260f00a0272a00022b2e00022f320f00f0031333360002373a00023b3e06000b1d001f401600f40c0f41440002454800026904000402010304000b04034241c601c501110072030403080003040a000105000f0f001788110a02071e0021003400f4016f0110060b030510040b0b050c000c000e006207050c0010041a00011f000f11001e40080b05095800083900f3180105480801010e0601017110010108060101150a01010f060101110601011c0a01011606010118180013170c00141e180044140101190c00f7af0c010302010003019604020102820700000001050768656164696e67030109020e526174652063617264203230323700120101050970617261677261706809027144617920726174657320616e642070726f6a65637420666c6f6f727320666f7220323032372e204173736f63696174696f6e7320616e6420636f2d6f70732077697468206665776572207468616e2074656e207374616666207061792074686520736f6c6964617269747920726174652e84040301840a0401008a0103ac00f72f0209020853657276696365730096010401050662756c6c6574090217446179206f6620776f726b20e280942070657220646179840b040100b001000000962e00f005115374616e646172643a2035363020e282ac00c2fa030824002513539500423a203338260037d601052300301e4272e700856964656e746974797800032201b7840e040100f701000000d6350016187c009266726f6d20362030305d003a9002012b00181a8300012d00333320332d0037ab020655008d17576562736974658300b607040100c502000000ab022d011b198300253132840010df8400082c000e840033372035840037fa02088400f504204d61726b6574696e672072657461696e65728f00f7016d6f6e746884120401009d03000000fa8d000c1001333420385f003ab603012b000e8c00333220342d0052d103020105b204f70f05086465636973696f6e050a642d323032362d3031310902013500d80307b200c51b4f6e6c696e652073686f70ab0004bd0100390210f6ad0026d8033a010cad0015390c013a8f04012b000ead0006ea01f00a020066720101d20800020076760101d408000076067f06030000000000447860ac01000000050000000c00000000000000000100000000010200767646eb67dc9b040000ff0500004c4f524f0004224d18604082bd050000f2230002010006626c6f636b7304030474797065040768656164696e6704746578740701010600056c6576656c030200010100000200c802000300010904000f020000440012024400740662756c6c6574430037a208003c00909104009004090400104e000780000f3c000328a4043c009092020091020904001286000e3c00a4097061726167726170687b0018283e007f1400130904002b78001219da780040ad0200ac78001f453c0012288e05760040c70200c63c001f5f3c001219c23c0040e10200e03c001f7a3c001219f83c0040fc0200fb3c001b8a2c010fe80104249a02e9011704ad01708c01008d01008bec011b9648000fb0010328b002fc0040980100973c001f9dc0001228be063c009f9f03009e03090400b078001219e4780040b20100b178001fb678001219f0780040b80300b778001fc2780012288803b40040c40100c378001bd1780012041803f40705656d62656403726566040a642d323032362d303131ac0232aa07002100a704086465636973696f6e8a01a0d30300d40300d50300d29d001fd69d001219b09d0040d80100d79d001bd89d000fc9010328b407d90040da0300d978001ff63c001219f03c0040f80300f73c001ff7b4001219f2b40070f90100f801000d6404003e00300000037104f5070301010100010e526174652063617264203230323701230071040201000201080600381c00003f002311023f00fa0f9e08011a536f6c696461726974793a2066726f6d20362030303020e282ac4c00320301a44d001a304d002312014d002fa0044d00003f3320334d000312a6a0000b4d001414d900f11424017144617920726174657320616e642070726f6a65637420666c6f6f727320666f72f000d22e204173736f63696174696f6e2a00f51b636f2d6f70732077697468206665776572207468616e2074656e20737461666620706179207468652073fa00016800182ef000f82912000f112ae2019f01a20199019c012326110212000a11424108097a7714150e02066974616c696304626f6c6402030001018403010101846701142d1a01f404d60401175765627369746520e2809420706572d000087400f104080006078605292c1d0208000507000e0f1e015f0011015f00085a0014475a00c38a0501195374616e64617264bf012f3132c001052190050d021a2ec00114614c002fbe05c001003f372035c0010312c44d000bc001147c4d00f507f40501204d61726b6574696e672072657461696e6572fe005c6d6f6e7468fc0052b6063b3e19fc003f24251afc0005148d2302c89402010853657276696365734b0000ab02219c02eb001a10eb0014983b0040ac0201175f02756f6620776f726b9700386461794a0000910152dc02292c1595003f161716950005149ff8004bba06011891013f34203843010321c006a5001a2ca50014b2a50046e00201114b002f353694030212e6e9001a1e440014b88f002fec06d401003f32203491000312f291000bd40114c4910048840301132e042f3338930002218a03d7001a22930014d5930070a2070100000304c7040a220014d8680060ac03011e4272f503856964656e74697479a1010306040ca50143ea03373a36032f1c1d36030614da8300ff00b007011b4f6e6c696e652073686f705e000d43e80731345e002f16175e000614f85e002dec0703021f3946030521f2072c010b030214f90a012dee034b001f364b0001f30906000705f403ba0395030206000405221f06000000080083d60a2603014307f41c04020226001d250024fe068d05188001aa01da02bb019303246a326a34ae0232e30132050d1200130c000202000f30000df4010226001413000102030405060708000102002028017a09d1010108000301001b09018002810300a1828002838002848002850f00f04486800000003d007900b500f1002d016901a501e10129026502a102dd0219035503b603f2032e046a04a604e50432057f054c06a606f2063f07a207dd0737088208c608130959097b09dc093a0a850ad60a2700000000004d147a0201000000050000000d00000100000000000000000000000108008306626c6f636b732f438b07d505000000000000	[{"peer": "1", "counter": 553}]	{"1": 554}
minutes-ag-2026-06-20@1	minutes-ag-2026-06-20	1	2026-06-22	\\x6c6f726f00000000000000000000000004d00d260003b60400004c4f524f0004224d186040827b040000b200dd0500dd0501100101000100030900e00501000001007d16040103000c041b005004000200060a001048050010520f0010580a0010680a00106c0a002094030b00209a030c0011e40c0011e80c002092081200209c081e0011a20c0011e40c0011e80c0020de0a1e0020e80a1e0011ee0c0011fc0c00f4a4800b260474797065056c6576656c047465787405656d6265640372656604626f6c6406626c6f636b732a0102021800240c0180028180028280028380028480028580028680028780028880028980028a80028b80f201010441030002040005020306060003050804000d02090c00020d1004000902111400020400031518060003171a04000d021b1e00021f22060003212404000902252800024904000402010304000306020403010004020103040003040318005f07040378771f00010c3100a33c0110060b030510080b090010040e000113006b040b07050c001a00072800f25401052608010120120101070601019301080101240601019202160101200601017a120101060601011c00cb0700000001050768656164696e6703010902204d696e757465732c20416e6e75616c2067656e6572616c20617373656d626c7900240101056f01f70e05076d656574696e67050d61672d323032362d30362d323009020029025700f47a0209020750726573656e7400340301050970617261677261706809029501416c6c2074656e206d656d626572732c206174207468652073747564696f3a2043616d696c6c652c2059757375662c204875676f2c204a756c69656e2c204cc3a9612c2054686f6d61732c20536f6669612c204d616c696b2c20416d696e6120616e642043686c6fc3a92e4c009320636861697265643b47005120746f6f6b7500126dfe005a2e00ca0104c200f10624312e205468652032303235206163636f756e74735d00003800ba737572706c757300f20105e00023940263001270010112653000094600e42c20636c6f73696e67206f6e20614c00e2206f662036312034303020e282ac7d000485017220617070726f764d00116d86004373706c693901028c00f118206173206c6f692037382d3736332c206172742e20333320616c6c6f77733a203435202520746fbf00037c014020666f720701a7697220776f726b2c20312400606c6567616c20c600677276652c20321b0010648803b16f706d656e742066756e649100013c00b0617320696e746572657374dd00f5016361706974616c2e84080501008904064a02c3086465636973696f6e050a644a028a30360902008e040787012220320a01015600106e910090756c65732c207665723f006a203300b204088301147af601068301052e00f1042c20776869636820616464732072656d6f7465fb004720646179de01e16f6c6964617269747920726174652701f3046173736f63696174696f6e732e20457665727947014020636f6eec027f65642e00af0509e4000a7a37090200b4050ae400ba06436c6f73656400be050bca00101c810231736573ea000034022065642e03f01131323a34302e00020066720101b80b00020076760101ba0b0000b005b90503000000000009f1580a01000000050000000c00000000000000000100000000010200767646eb67dc93040000b00500004c4f524f0004224d186040826e050000f2230002010006626c6f636b7304030474797065040768656164696e6704746578740701010600056c6576656c030200010100000200c8020003000109040009020000440012044400f40705656d62656403726566040a642d323032362d3030365200329a08002100a704086465636973696f6e5b00fb008b04008c04008d04008a040904000e61000fa5000424a208a60017044b00709004009104008f48001024b70007ed000ea900330d6167aa0044362d3230ac001450ab0087076d656574696e675f00bb26002700280025090400295e000fa600041f58a500019b2b002c002a09040032ea0012024b01a409706172616772617068930037e80800850040b40400b3e1001b3483000f3f0006186c3e007b360035090400af7b000e1d0106c6011437180224e60a1b010fc60101fb00b10500b20500b30500b005090400b461000f2001042fee0a21010170b60500b70500b548001bbe48000fe5000628800be60040c00500bf3f001bca24010f8700042f9a0387000170cc0100cd0100cbf6021bf248000f87000628e803870070f40100f301000d3003004100300000033d03f519030101010001204d696e757465732c20416e6e75616c2067656e6572616c20617373656d626c7901350071040201000201080600384000005100230d025100709208010000030465000a220014112200f0089c080120322e2054686520696e7465726e616c2072756c82003076657294032a203374003f0301a47500021428c6001f48740004142c2100aa52010750726573656e745a003102015ace001a0eac001434ac00d2e408017a43616d696c6c6520704100266564a700f0492c20776869636820616464732072656d6f746520776f726b206461797320616e642074686520736f6c69646172697479207261746520666f72206173736f63696174696f6e732e204576657279206d656d62657220636f6ea9003a65642eac00300301ea0601300301f41d0107cd011436e600b368019501416c6c2074656e4d0052732c206174850073747564696f3a20ce00f1292c2059757375662c204875676f2c204a756c69656e2c204cc3a9612c2054686f6d61732c20536f6669612c204d616c696b2c20416d696e61d5007443686c6fc3a92e4c009320636861697265643b47005120746f6f6b7500126d5b020bc9003102016ec80010a6540307c80014b376012fde0ad0010414b72200ace80a0106436c6f736564240121f00a62001a0cd10114c0390040fc0a011c7a02317365736a02116345000025015b31323a3430aa00410301820b4f001a384f0014cd7201529403012431cc02c732303235206163636f756e74fc016c7572706c7573a600219c0357001a48570014f4570052e403019402940107770200c701096600112cbf0084696e67206f6e20616c00e2206f662036312034303020e282ac9d0004cc037220617070726f764d00116dcd015173706c6974ae0103ac00f118206173206c6f692037382d3736332c206172742e20333320616c6c6f77733a203435202520746f8f0003660201d302517468656972ff02372c20312400306c6567e203976573657276652c20321b001064df07b16f706d656e742066756e649100013c002261731d0430657374dd00796361706974616c9f01f31a0a000b09ea03a404ab03ae039d03020a000709787710119e030104626f6c64010300010184000800836708260301bd06ff0b0402021800101700480a16ac0250ae040a48fa010a1405021800180001f0040218000d0c000102030405060708090a0b2a014000f04b240c0180028180028280028380028480028580028680028780028880028980028a80028b800000003d009e00e60044018801c70103026402ac02eb0233037203c303e5033804590491043f05070629066206b10608076708190000000000f3971e1c01000000050000000d00000100000000000000000000000108008306626c6f636b732f438b078605000000000000	[{"peer": "1", "counter": 732}]	{"1": 733}
\.


--
-- Data for Name: minutes; Type: TABLE DATA; Schema: document_meeting; Owner: -
--

COPY document_meeting.minutes (meeting, document) FROM stdin;
ag-2026-06-20	minutes-ag-2026-06-20
\.


--
-- Data for Name: reading; Type: TABLE DATA; Schema: document_membership; Owner: -
--

COPY document_membership.reading (version, member, read) FROM stdin;
internal-rules@3	camille@lanterne.example	2026-06-20
internal-rules@3	yusuf@lanterne.example	2026-06-20
internal-rules@3	hugo@lanterne.example	2026-06-20
internal-rules@3	julien@lanterne.example	2026-06-20
internal-rules@3	lea@lanterne.example	2026-06-20
internal-rules@3	thomas@lanterne.example	2026-06-20
internal-rules@3	sofia@lanterne.example	2026-06-20
internal-rules@3	malik@lanterne.example	2026-06-20
internal-rules@3	amina@lanterne.example	2026-06-20
internal-rules@3	chloe@lanterne.example	2026-06-20
\.


--
-- Data for Name: worker; Type: TABLE DATA; Schema: employment; Owner: -
--

COPY employment.worker (address, name, job, contract, start, until, minutes, hired) FROM stdin;
camille@lanterne.example	Camille Martin	brand strategist	permanent	2021-03-01	\N	2100	2021-03-01
yusuf@lanterne.example	Yusuf Demir	lead developer	permanent	2021-03-01	\N	2100	2021-03-01
hugo@lanterne.example	Hugo Lefèvre	graphic designer	permanent	2021-03-01	\N	2100	2021-03-01
paul@lanterne.example	Paul Garnier	art director	permanent	2021-03-01	2025-11-30	2100	2021-03-01
julien@lanterne.example	Julien Petit	administration and finance	permanent	2021-03-15	\N	2100	2021-03-15
lea@lanterne.example	Léa Bernard	UX and interface designer	permanent	2021-07-12	\N	2100	2021-07-12
thomas@lanterne.example	Thomas Nguyen	full-stack developer	permanent	2021-10-04	\N	2100	2021-10-04
sofia@lanterne.example	Sofia Rossi	illustrator and motion designer	permanent	2022-03-07	\N	2100	2022-03-07
malik@lanterne.example	Malik Benali	marketing strategist	permanent	2022-05-02	\N	2100	2022-05-02
amina@lanterne.example	Amina Diallo	backend developer	permanent	2022-12-12	\N	2100	2022-12-12
ines@lanterne.example	Inès Haddad	junior developer	permanent	2025-09-01	\N	2100	2025-09-01
chloe@lanterne.example	redacted	content and social media	permanent	2023-08-07	\N	2100	2023-08-07
\.


--
-- Data for Name: record; Type: TABLE DATA; Schema: employment_file; Owner: -
--

COPY employment_file.record (worker, file) FROM stdin;
ines@lanterne.example	fi-0003
\.


--
-- Data for Name: candidacy; Type: TABLE DATA; Schema: employment_membership; Owner: -
--

COPY employment_membership.candidacy (worker, "from", "to", shares, opened) FROM stdin;
julien@lanterne.example	2021-03-15	2021-08-31	20	2021-03-15
lea@lanterne.example	2021-07-12	2022-01-09	20	2021-07-12
thomas@lanterne.example	2021-10-04	2022-04-03	20	2021-10-04
sofia@lanterne.example	2022-03-07	2022-09-04	20	2022-03-07
malik@lanterne.example	2022-05-02	2022-11-01	20	2022-05-02
amina@lanterne.example	2022-12-12	2023-06-11	20	2022-12-12
chloe@lanterne.example	2023-08-07	2024-02-04	20	2023-08-07
ines@lanterne.example	2025-09-01	2026-08-31	20	2025-09-01
\.


--
-- Data for Name: expense; Type: TABLE DATA; Schema: expense; Owner: -
--

COPY expense.expense (id, member, day, label, category, net, vat, receipt, status, submitted, decided, decider, reimbursed) FROM stdin;
ex-0001	sofia@lanterne.example	2026-10-19	Print proofs for the press check	606	150.00	30.00	receipt-imprimerie-du-parc-1019.pdf	submitted	2026-10-20	\N	\N	\N
ex-0002	thomas@lanterne.example	2026-10-21	Train to Clairval and back	6251	78.55	7.85	sncf-1021.pdf	draft	\N	\N	\N	\N
ex-0004	lea@lanterne.example	2026-10-23	Display font licence	626	120.00	24.00	foundry-invoice-2291.pdf	submitted	2026-10-23	\N	\N	\N
ex-0003	chloe@lanterne.example	2026-10-22	redacted	6257	42.00	4.20	redacted	submitted	2026-10-22	\N	\N	\N
ex-0005	chloe@lanterne.example	2026-10-23	redacted	6251	32.00	\N	redacted	draft	\N	\N	\N	\N
\.


--
-- Data for Name: receipt; Type: TABLE DATA; Schema: expense_file; Owner: -
--

COPY expense_file.receipt (expense, file) FROM stdin;
ex-0001	fi-0004
ex-0003	fi-0005
\.


--
-- Data for Name: threshold; Type: TABLE DATA; Schema: expense_invoice_project_timesheet; Owner: -
--

COPY expense_invoice_project_timesheet.threshold (since, burn, margin) FROM stdin;
2026-01-01	90	20
\.


--
-- Data for Name: rebill; Type: TABLE DATA; Schema: expense_project; Owner: -
--

COPY expense_project.rebill (expense, project) FROM stdin;
ex-0001	ferrand-packaging
ex-0002	clairval-site
ex-0003	nuvola-retainer
\.


--
-- Data for Name: posting; Type: TABLE DATA; Schema: expense_transaction; Owner: -
--

COPY expense_transaction.posting (entry, expense, event) FROM stdin;
\.


--
-- Data for Name: contract; Type: TABLE DATA; Schema: file; Owner: -
--

COPY file.contract (id, class, subject, name, type, size, bytes, uploader, uploaded) FROM stdin;
fi-0003	payroll	ines@lanterne.example	contrat-ines-haddad.pdf	application/pdf	962	\\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203520302052203e3e203e3e202f436f6e74656e7473203420302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f4c656e67746820333930203e3e0a73747265616d0a4254202f4631203136205466203536203738302054642028436f6e74726174206465207472617661696c20e020647572e96520696e64e97465726d696ee9652920546a2045540a4254202f46312031312054662035362037353820546420284c616e7465726e652053434f50205341524c2c204d6f6e74726575696c2920546a2045540a4254202f463120313120546620353620373336205464202853616c617269e965203a20496ee873204861646461642920546a2045540a4254202f4631203131205466203536203731342054642028506f737465203a2064e976656c6f707065757365206a756e696f722920546a2045540a4254202f463120313120546620353620363932205464202844e9627574203a203165722073657074656d62726520323032352c20333520686575726573207061722073656d61696e652920546a2045540a4254202f46312031312054662035362036373020546420285369676ee920e0204d6f6e74726575696c206c6520323520616ffb7420323032352920546a2045540a656e6473747265616d0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a787265660a3020360a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323431203030303030206e200a30303030303030363832203030303030206e200a747261696c65720a3c3c202f53697a652036202f526f6f74203120302052203e3e0a7374617274787265660a3737390a2525454f460a	camille@lanterne.example	2025-08-25
\.


--
-- Data for Name: receipt; Type: TABLE DATA; Schema: file; Owner: -
--

COPY file.receipt (id, class, subject, name, type, size, bytes, uploader, uploaded) FROM stdin;
fi-0004	expense-receipt	sofia@lanterne.example	receipt-imprimerie-du-parc-1019.pdf	application/pdf	968	\\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203520302052203e3e203e3e202f436f6e74656e7473203420302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f4c656e67746820333936203e3e0a73747265616d0a4254202f4631203136205466203536203738302054642028496d7072696d6572696520647520506172632920546a2045540a4254202f46312031312054662035362037353820546420284d6f6e74726575696c2c203139206f63746f62726520323032362920546a2045540a4254202f46312031312054662035362037333620546420284661637475726520323032362d313031392d30372920546a2045540a4254202f4631203131205466203536203731342054642028457072657576657320636f756c6575722c20707265737365203a203135302c3030204555522048542920546a2045540a4254202f46312031312054662035362036393220546420285456412032302025203a2033302c3030204555522920546a2045540a4254202f4631203131205466203536203637302054642028546f74616c20545443203a203138302c3030204555522920546a2045540a4254202f4631203131205466203536203634382054642028506179e9207061722063617274652c20536f66696120526f7373692920546a2045540a656e6473747265616d0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a787265660a3020360a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323431203030303030206e200a30303030303030363838203030303030206e200a747261696c65720a3c3c202f53697a652036202f526f6f74203120302052203e3e0a7374617274787265660a3738350a2525454f460a	sofia@lanterne.example	2026-10-20
fi-0005	expense-receipt	chloe@lanterne.example	redacted	application/pdf	921	\N	chloe@lanterne.example	2026-10-22
\.


--
-- Data for Name: record; Type: TABLE DATA; Schema: file; Owner: -
--

COPY file.record (id, class, subject, name, type, size, bytes, uploader, uploaded) FROM stdin;
fi-0002	profile	camille@lanterne.example	bulletin-souscription-camille.pdf	application/pdf	890	\\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203520302052203e3e203e3e202f436f6e74656e7473203420302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f4c656e67746820333138203e3e0a73747265616d0a4254202f463120313620546620353620373830205464202842756c6c6574696e20646520736f75736372697074696f6e20646520706172747320736f6369616c65732920546a2045540a4254202f46312031312054662035362037353820546420284c616e7465726e652053434f50205341524c2920546a2045540a4254202f46312031312054662035362037333620546420284173736f6369e965203a2043616d696c6c65204d617274696e2920546a2045540a4254202f463120313120546620353620373134205464202834302070617274732064652035302c3030204555522c20736f69742032203030302c3030204555522920546a2045540a4254202f46312031312054662035362036393220546420285369676ee920e0204d6f6e74726575696c206c6520316572206d61727320323032312920546a2045540a656e6473747265616d0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a787265660a3020360a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323431203030303030206e200a30303030303030363130203030303030206e200a747261696c65720a3c3c202f53697a652036202f526f6f74203120302052203e3e0a7374617274787265660a3730370a2525454f460a	camille@lanterne.example	2024-06-14
\.


--
-- Data for Name: shared; Type: TABLE DATA; Schema: file; Owner: -
--

COPY file.shared (id, class, subject, name, type, size, bytes, uploader, uploaded) FROM stdin;
fi-0001	none	\N	statuts-lanterne-2024.pdf	application/pdf	859	\\x255044462d312e340a312030206f626a0a3c3c202f54797065202f436174616c6f67202f5061676573203220302052203e3e0a656e646f626a0a322030206f626a0a3c3c202f54797065202f5061676573202f4b696473205b33203020525d202f436f756e742031203e3e0a656e646f626a0a332030206f626a0a3c3c202f54797065202f50616765202f506172656e74203220302052202f4d65646961426f78205b30203020353935203834325d202f5265736f7572636573203c3c202f466f6e74203c3c202f4631203520302052203e3e203e3e202f436f6e74656e7473203420302052203e3e0a656e646f626a0a342030206f626a0a3c3c202f4c656e67746820323837203e3e0a73747265616d0a4254202f463120313620546620353620373830205464202853746174757473206465204c616e7465726e652920546a2045540a4254202f4631203131205466203536203735382054642028536f6369e974e920636f6f70e972617469766520657420706172746963697061746976652c205341524c20e0206361706974616c207661726961626c652920546a2045540a4254202f46312031312054662035362037333620546420285369e86765203a204d6f6e74726575696c205c2839335c292920546a2045540a4254202f463120313120546620353620373134205464202856657273696f6e2061646f7074e96520706172206c27617373656d626ce9652067e96ee972616c65206475203134206a75696e20323032342920546a2045540a656e6473747265616d0a656e646f626a0a352030206f626a0a3c3c202f54797065202f466f6e74202f53756274797065202f5479706531202f42617365466f6e74202f48656c766574696361202f456e636f64696e67202f57696e416e7369456e636f64696e67203e3e0a656e646f626a0a787265660a3020360a303030303030303030302036353533352066200a30303030303030303039203030303030206e200a30303030303030303538203030303030206e200a30303030303030313135203030303030206e200a30303030303030323431203030303030206e200a30303030303030353739203030303030206e200a747261696c65720a3c3c202f53697a652036202f526f6f74203120302052203e3e0a7374617274787265660a3637360a2525454f460a	camille@lanterne.example	2024-06-14
\.


--
-- Data for Name: record; Type: TABLE DATA; Schema: file_membership; Owner: -
--

COPY file_membership.record (member, file) FROM stdin;
camille@lanterne.example	fi-0002
\.


--
-- Data for Name: run; Type: TABLE DATA; Schema: import; Owner: -
--

COPY import.run (id, kind, name, actor, day, dry, settled, refused, lines) FROM stdin;
\.


--
-- Data for Name: invoice; Type: TABLE DATA; Schema: invoice; Owner: -
--

COPY invoice.invoice (id, series, number, issued, due, bill_to, label, net, vat, total, sent, voided, reason) FROM stdin;
F-2026-0041	F-2026	41	2026-07-03	2026-08-02	Les Halles Paysannes	Online shop, milestone 1 of 4: design	12000.00	2400.00	14400.00	\N	\N	\N
F-2026-0042	F-2026	42	2026-07-06	2026-08-05	Nuvola Énergie	Marketing retainer, July	4800.00	960.00	5760.00	\N	\N	\N
F-2026-0043	F-2026	43	2026-07-15	2026-08-14	Ville de Clairval	Town website, lot 1: audit and architecture	12000.00	2400.00	14400.00	\N	\N	\N
F-2026-0044	F-2026	44	2026-07-21	2026-08-20	Compagnie Mauve Horizon	Season 26-27 posters and brochure	6200.00	1240.00	7440.00	\N	\N	\N
F-2026-0045	F-2026	45	2026-07-28	2026-08-27	Atelier Ondine	Online shop, fixed price	9500.00	1900.00	11400.00	\N	\N	\N
F-2026-0046	F-2026	46	2026-08-03	2026-09-02	Nuvola Énergie	Marketing retainer, August	4800.00	960.00	5760.00	\N	\N	\N
F-2026-0047	F-2026	47	2026-08-27	2026-09-26	Les Halles Paysannes	Online shop, milestone 2 of 4: build	12000.00	2400.00	14400.00	\N	\N	\N
F-2026-0048	F-2026	48	2026-09-01	2026-10-01	Nuvola Énergie	Marketing retainer, September	4800.00	960.00	5760.00	\N	\N	\N
F-2026-0049	F-2026	49	2026-09-04	2026-10-04	Ville de Clairval	Town website, lot 2: design system and templates	12000.00	2400.00	14400.00	\N	\N	\N
F-2026-0050	F-2026	50	2026-09-11	2026-10-11	Vélo Solidaire	Brand identity	3800.00	760.00	4560.00	\N	2026-09-12	wrong amount; reissued as F-2026-0051 at the solidarity rate
F-2026-0051	F-2026	51	2026-09-12	2026-10-12	Vélo Solidaire	Brand identity, solidarity rate	3300.00	660.00	3960.00	\N	\N	\N
F-2026-0052	F-2026	52	2026-09-25	2026-10-25	Maison Ferrand	Packaging design, range of six	14000.00	2800.00	16800.00	\N	\N	\N
F-2026-0053	F-2026	53	2026-10-01	2026-10-31	Nuvola Énergie	Marketing retainer, October	4800.00	960.00	5760.00	\N	\N	\N
F-2026-0054	F-2026	54	2026-10-08	2026-11-07	Les Halles Paysannes	Online shop, milestone 3 of 4: launch	12000.00	2400.00	14400.00	\N	\N	\N
F-2026-0055	F-2026	55	2026-10-16	2026-11-15	Fondation Terres Vives	Annual report and microsite, milestone 1 of 2	9000.00	1800.00	10800.00	\N	\N	\N
\.


--
-- Data for Name: line; Type: TABLE DATA; Schema: invoice; Owner: -
--

COPY invoice.line (invoice, n, description, quantity, unit_price, amount, vat_rate) FROM stdin;
F-2026-0041	1	Online shop, milestone 1 of 4: design	1.000	12000.00	12000.00	20.00
F-2026-0042	1	Marketing retainer, July	1.000	4800.00	4800.00	20.00
F-2026-0043	1	Town website, lot 1: audit and architecture	1.000	12000.00	12000.00	20.00
F-2026-0044	1	Season 26-27 posters and brochure	1.000	6200.00	6200.00	20.00
F-2026-0045	1	Online shop, fixed price	1.000	9500.00	9500.00	20.00
F-2026-0046	1	Marketing retainer, August	1.000	4800.00	4800.00	20.00
F-2026-0047	1	Online shop, milestone 2 of 4: build	1.000	12000.00	12000.00	20.00
F-2026-0048	1	Marketing retainer, September	1.000	4800.00	4800.00	20.00
F-2026-0049	1	Town website, lot 2: design system and templates	1.000	12000.00	12000.00	20.00
F-2026-0050	1	Brand identity	1.000	3800.00	3800.00	20.00
F-2026-0051	1	Brand identity, solidarity rate	1.000	3300.00	3300.00	20.00
F-2026-0052	1	Packaging design, range of six	1.000	14000.00	14000.00	20.00
F-2026-0053	1	Marketing retainer, October	1.000	4800.00	4800.00	20.00
F-2026-0054	1	Online shop, milestone 3 of 4: launch	1.000	12000.00	12000.00	20.00
F-2026-0055	1	Annual report and microsite, milestone 1 of 2	1.000	9000.00	9000.00	20.00
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: invoice; Owner: -
--

COPY invoice.payment (id, invoice, receipt, at, amount, method, reference) FROM stdin;
1	F-2026-0041	39	2026-07-29	14400.00	transfer	F-2026-0041/1
2	F-2026-0042	40	2026-07-31	5760.00	transfer	F-2026-0042/1
3	F-2026-0043	41	2026-09-08	14400.00	transfer	F-2026-0043/1
4	F-2026-0045	42	2026-08-24	11400.00	transfer	F-2026-0045/1
5	F-2026-0046	43	2026-08-28	5760.00	transfer	F-2026-0046/1
6	F-2026-0047	44	2026-09-24	14400.00	transfer	F-2026-0047/1
7	F-2026-0048	45	2026-09-29	5760.00	transfer	F-2026-0048/1
8	F-2026-0049	46	2026-10-20	14400.00	transfer	F-2026-0049/1
9	F-2026-0051	47	2026-10-05	1980.00	transfer	F-2026-0051/1
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: invoice; Owner: -
--

COPY invoice.series (name, next, until) FROM stdin;
F-2026	56	\N
\.


--
-- Data for Name: charge; Type: TABLE DATA; Schema: invoice_project; Owner: -
--

COPY invoice_project.charge (invoice, project) FROM stdin;
F-2026-0041	halles-shop
F-2026-0042	nuvola-retainer
F-2026-0043	clairval-site
F-2026-0044	mauve-posters
F-2026-0045	ondine-shop
F-2026-0046	nuvola-retainer
F-2026-0047	halles-shop
F-2026-0048	nuvola-retainer
F-2026-0049	clairval-site
F-2026-0050	velo-identity
F-2026-0051	velo-identity
F-2026-0052	ferrand-packaging
F-2026-0053	nuvola-retainer
F-2026-0054	halles-shop
F-2026-0055	terres-report
\.


--
-- Data for Name: posting; Type: TABLE DATA; Schema: invoice_transaction; Owner: -
--

COPY invoice_transaction.posting (entry, invoice, event, payment) FROM stdin;
je-0002	F-2026-0041	issue	\N
je-0010	F-2026-0041	payment	1
je-0004	F-2026-0042	issue	\N
je-0011	F-2026-0042	payment	2
je-0006	F-2026-0043	issue	\N
je-0023	F-2026-0043	payment	3
je-0007	F-2026-0044	issue	\N
je-0008	F-2026-0045	issue	\N
je-0016	F-2026-0045	payment	4
je-0012	F-2026-0046	issue	\N
je-0018	F-2026-0046	payment	5
je-0017	F-2026-0047	issue	\N
je-0029	F-2026-0047	payment	6
je-0020	F-2026-0048	issue	\N
je-0032	F-2026-0048	payment	7
je-0021	F-2026-0049	issue	\N
je-0040	F-2026-0049	payment	8
je-0025	F-2026-0050	issue	\N
je-0026	F-2026-0050	void	\N
je-0027	F-2026-0051	issue	\N
je-0034	F-2026-0051	payment	9
je-0030	F-2026-0052	issue	\N
je-0033	F-2026-0053	issue	\N
je-0036	F-2026-0054	issue	\N
je-0038	F-2026-0055	issue	\N
\.


--
-- Data for Name: item; Type: TABLE DATA; Schema: meeting; Owner: -
--

COPY meeting.item (id, meeting, pos, title, presenter, minutes) FROM stdin;
1	ag-2026-06-20	1	The 2025 accounts and the surplus	Julien	45
2	ag-2026-06-20	2	The internal rules, version 3	Camille	30
3	coordination-2026-09-07	1	Pipeline	Camille	20
4	coordination-2026-09-07	2	Staffing for September	Yusuf	15
5	coordination-2026-09-07	3	Timesheets from 1 September	Julien	10
6	coordination-2026-09-14	1	Pipeline	Camille	20
7	coordination-2026-09-14	2	Ferrand packaging: the range concept	Hugo	15
8	coordination-2026-09-14	3	Staffing	Yusuf	10
9	coordination-2026-09-21	1	Pipeline	Camille	20
10	coordination-2026-09-21	2	Halles shop: the launch plan	Léa	15
11	coordination-2026-09-21	3	Inès asks to join	Camille	10
12	coordination-2026-09-28	1	Pipeline	Camille	20
13	coordination-2026-09-28	2	Staffing for October	Yusuf	15
14	coordination-2026-09-28	3	2027 rates: a first draft	Malik	20
15	coordination-2026-10-05	1	Pipeline	Camille	15
16	coordination-2026-10-05	2	September's books, closing today	Julien	10
17	coordination-2026-10-05	3	Rate card 2027, version 1	Malik	20
18	coordination-2026-10-12	1	Pipeline	Camille	15
19	coordination-2026-10-12	2	Raise the day rate for 2027	Malik	20
20	coordination-2026-10-12	3	Inès's admission: a proposal to the assembly	Camille	15
21	coordination-2026-10-19	1	Pipeline	Camille	15
22	coordination-2026-10-19	2	The day rate: Malik's objection	Malik	20
23	coordination-2026-10-19	3	Admit Inès Haddad as a member	Camille	10
24	coordination-2026-10-19	4	Staffing for November	Yusuf	15
25	coordination-2026-10-26	1	Pipeline	Camille	15
26	coordination-2026-10-26	2	Staffing for November	Yusuf	15
27	coordination-2026-10-26	3	Preparing the assembly of 31 October	Camille	20
28	ag-2026-10-31	1	The minutes of 20 June	Julien	10
29	ag-2026-10-31	2	Admit Inès Haddad as a member	Camille	20
30	ag-2026-10-31	3	Raise the day rate for 2027	Malik	30
\.


--
-- Data for Name: meeting; Type: TABLE DATA; Schema: meeting; Owner: -
--

COPY meeting.meeting (id, circle, title, at, place, link, scheduled, status, settled, minuted) FROM stdin;
coordination-2026-10-26	coordination	Coordination	2026-10-26 10:00:00	Studio	https://meet.lanterne.example/coordination	2026-10-19	scheduled	\N	\N
ag-2026-10-31	ag	General assembly	2026-10-31 10:00:00	Studio, 14 rue des Graviers, Montreuil	\N	2026-10-01	scheduled	\N	\N
ag-2026-06-20	ag	Annual general assembly	2026-06-20 10:00:00	Studio, 14 rue des Graviers, Montreuil	\N	2026-05-29	held	2026-06-20	2026-06-20
coordination-2026-09-07	coordination	Coordination	2026-09-07 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-09-07	\N
coordination-2026-09-14	coordination	Coordination	2026-09-14 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-09-14	\N
coordination-2026-09-21	coordination	Coordination	2026-09-21 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-09-21	\N
coordination-2026-09-28	coordination	Coordination	2026-09-28 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-09-28	\N
coordination-2026-10-05	coordination	Coordination	2026-10-05 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-10-05	\N
coordination-2026-10-12	coordination	Coordination	2026-10-12 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-10-12	\N
coordination-2026-10-19	coordination	Coordination	2026-10-19 10:00:00	Studio	https://meet.lanterne.example/coordination	\N	held	2026-10-19	\N
\.


--
-- Data for Name: attendance; Type: TABLE DATA; Schema: meeting_membership; Owner: -
--

COPY meeting_membership.attendance (meeting, member, status, marked, by) FROM stdin;
ag-2026-06-20	camille@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	yusuf@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	hugo@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	julien@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	lea@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	thomas@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	sofia@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	malik@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	amina@lanterne.example	present	2026-06-20	julien@lanterne.example
ag-2026-06-20	chloe@lanterne.example	present	2026-06-20	julien@lanterne.example
coordination-2026-09-07	camille@lanterne.example	present	2026-09-07	malik@lanterne.example
coordination-2026-09-07	yusuf@lanterne.example	present	2026-09-07	malik@lanterne.example
coordination-2026-09-07	hugo@lanterne.example	present	2026-09-07	malik@lanterne.example
coordination-2026-09-07	malik@lanterne.example	present	2026-09-07	malik@lanterne.example
coordination-2026-09-07	julien@lanterne.example	present	2026-09-07	malik@lanterne.example
coordination-2026-09-14	camille@lanterne.example	present	2026-09-14	malik@lanterne.example
coordination-2026-09-14	yusuf@lanterne.example	present	2026-09-14	malik@lanterne.example
coordination-2026-09-14	hugo@lanterne.example	present	2026-09-14	malik@lanterne.example
coordination-2026-09-14	malik@lanterne.example	present	2026-09-14	malik@lanterne.example
coordination-2026-09-14	julien@lanterne.example	present	2026-09-14	malik@lanterne.example
coordination-2026-09-21	camille@lanterne.example	present	2026-09-21	malik@lanterne.example
coordination-2026-09-21	yusuf@lanterne.example	present	2026-09-21	malik@lanterne.example
coordination-2026-09-21	hugo@lanterne.example	present	2026-09-21	malik@lanterne.example
coordination-2026-09-21	malik@lanterne.example	present	2026-09-21	malik@lanterne.example
coordination-2026-09-21	julien@lanterne.example	present	2026-09-21	malik@lanterne.example
coordination-2026-09-21	lea@lanterne.example	present	2026-09-21	lea@lanterne.example
coordination-2026-09-28	camille@lanterne.example	present	2026-09-28	malik@lanterne.example
coordination-2026-09-28	yusuf@lanterne.example	present	2026-09-28	malik@lanterne.example
coordination-2026-09-28	malik@lanterne.example	present	2026-09-28	malik@lanterne.example
coordination-2026-09-28	julien@lanterne.example	present	2026-09-28	malik@lanterne.example
coordination-2026-09-28	hugo@lanterne.example	excused	2026-09-28	malik@lanterne.example
coordination-2026-10-05	camille@lanterne.example	present	2026-10-05	malik@lanterne.example
coordination-2026-10-05	yusuf@lanterne.example	present	2026-10-05	malik@lanterne.example
coordination-2026-10-05	hugo@lanterne.example	present	2026-10-05	malik@lanterne.example
coordination-2026-10-05	malik@lanterne.example	present	2026-10-05	malik@lanterne.example
coordination-2026-10-05	julien@lanterne.example	present	2026-10-05	malik@lanterne.example
coordination-2026-10-12	camille@lanterne.example	present	2026-10-12	malik@lanterne.example
coordination-2026-10-12	hugo@lanterne.example	present	2026-10-12	malik@lanterne.example
coordination-2026-10-12	malik@lanterne.example	present	2026-10-12	malik@lanterne.example
coordination-2026-10-12	julien@lanterne.example	present	2026-10-12	malik@lanterne.example
coordination-2026-10-12	yusuf@lanterne.example	excused	2026-10-12	malik@lanterne.example
coordination-2026-10-19	camille@lanterne.example	present	2026-10-19	malik@lanterne.example
coordination-2026-10-19	yusuf@lanterne.example	present	2026-10-19	malik@lanterne.example
coordination-2026-10-19	hugo@lanterne.example	present	2026-10-19	malik@lanterne.example
coordination-2026-10-19	malik@lanterne.example	present	2026-10-19	malik@lanterne.example
coordination-2026-10-19	julien@lanterne.example	present	2026-10-19	malik@lanterne.example
\.


--
-- Data for Name: invitation; Type: TABLE DATA; Schema: membership; Owner: -
--

COPY membership.invitation (member, key, label, accepted) FROM stdin;
ines@lanterne.example	\\x3a9ffc55d8edf3db06f0c483ff627b9cd037cfc992712952777619c181705f36	phone	2026-10-01
\.


--
-- Data for Name: link; Type: TABLE DATA; Schema: membership; Owner: -
--

COPY membership.link (digest, member, made) FROM stdin;
\.


--
-- Data for Name: member; Type: TABLE DATA; Schema: membership; Owner: -
--

COPY membership.member (address, status, since, shares, invited, suspended, exited) FROM stdin;
camille@lanterne.example	active	2021-03-01	40	\N	\N	\N
yusuf@lanterne.example	active	2021-03-01	40	\N	\N	\N
hugo@lanterne.example	active	2021-03-01	40	\N	\N	\N
julien@lanterne.example	active	2021-09-01	20	\N	\N	\N
lea@lanterne.example	active	2022-01-10	20	\N	\N	\N
thomas@lanterne.example	active	2022-04-04	20	\N	\N	\N
sofia@lanterne.example	active	2022-09-05	20	\N	\N	\N
malik@lanterne.example	active	2022-11-02	20	\N	\N	\N
amina@lanterne.example	active	2023-06-12	20	\N	\N	\N
paul@lanterne.example	exited	2021-03-01	30	\N	\N	2025-11-30
ines@lanterne.example	invited	\N	0	2026-09-30	\N	\N
chloe@lanterne.example	exited	2024-02-05	20	\N	\N	2026-11-07
\.


--
-- Data for Name: share; Type: TABLE DATA; Schema: membership_project; Owner: -
--

COPY membership_project.share (id, project, member, amount, granted) FROM stdin;
1	halles-shop	yusuf@lanterne.example	1500.00	2026-06-15
2	nuvola-retainer	malik@lanterne.example	1200.00	2026-09-01
3	ferrand-packaging	hugo@lanterne.example	2000.00	2026-09-14
4	terres-report	camille@lanterne.example	3000.00	2026-10-12
\.


--
-- Data for Name: assignment; Type: TABLE DATA; Schema: membership_task; Owner: -
--

COPY membership_task.assignment (task, member) FROM stdin;
t-1	yusuf@lanterne.example
t-2	thomas@lanterne.example
t-3	amina@lanterne.example
t-4	amina@lanterne.example
t-5	yusuf@lanterne.example
t-6	thomas@lanterne.example
t-7	lea@lanterne.example
t-8	lea@lanterne.example
t-9	lea@lanterne.example
t-10	chloe@lanterne.example
t-11	chloe@lanterne.example
t-12	malik@lanterne.example
t-13	malik@lanterne.example
t-14	malik@lanterne.example
t-15	julien@lanterne.example
t-16	hugo@lanterne.example
t-17	sofia@lanterne.example
t-18	hugo@lanterne.example
t-19	sofia@lanterne.example
t-20	camille@lanterne.example
t-21	hugo@lanterne.example
t-22	hugo@lanterne.example
t-23	sofia@lanterne.example
t-24	sofia@lanterne.example
t-25	lea@lanterne.example
t-26	amina@lanterne.example
t-27	camille@lanterne.example
t-28	julien@lanterne.example
t-29	camille@lanterne.example
t-30	yusuf@lanterne.example
t-31	julien@lanterne.example
t-33	thomas@lanterne.example
\.


--
-- Data for Name: applied; Type: TABLE DATA; Schema: migration; Owner: -
--

COPY migration.applied (path, hash, at) FROM stdin;
apps/org/core/notary/sql/001-cella.sql	f57b6e254caea7512aed16d22f334e134c2f70921d0652b6ff775b17f5144cf2	2026-10-25 14:48:04.944097+01
apps/org/core/notary/sql/002-rules-role.sql	071dade3672b9a04e287d0501aa58abe59d2d9ce92c21e6468a626d8a556bee0	2026-10-25 14:48:04.96925+01
apps/org/core/notary/sql/003-vault.sql	2d819e83cae0cf5f2fc49a813bcddabc456ce547a439175b2e63c12e9f704255	2026-10-25 14:48:04.972518+01
apps/org/core/notary/sql/004-reader.sql	7cf0764cfd6376e86c0a17dc334c9a0175acfa5da7649cce5ba7bff9aa7f1ff9	2026-10-25 14:48:04.974975+01
apps/org/feats/account/core/sql/001-account.sql	afd46922f8341ebdb953d50daba370ca57932d39b44b9b3a92da01e8252b638c	2026-10-25 14:48:04.980874+01
apps/org/feats/account/core/sql/002-powers.sql	186118d8a8276c17ee676edb31d1952ca8489be6b8bded429cc414a0f7f2609e	2026-10-25 14:48:04.986634+01
apps/org/feats/account/core/sql/003-cash.sql	702f3b29d6c310785f492c5f1e5703eb3d33cee78a5acaf07f489f5d2dca0402	2026-10-25 14:48:04.989203+01
apps/org/feats/account/core/sql/004-capital.sql	72c67f1d064c567a13cf825772b36d37606479ffa3e0215534c657a9d4eacd08	2026-10-25 14:48:04.991815+01
apps/org/feats/account/core/sql/005-personal.sql	83523cc199cfbaf3be98fda5bdb31dc294febea3a39f9e45ecc1b14272702f93	2026-10-25 14:48:04.995355+01
apps/org/feats/account/core/sql/006-terms.sql	4c88ee3753bda36d7f663fbae67bb0a8f5151ddcc1c19134b9d2c45427feb41a	2026-10-25 14:48:04.999344+01
apps/org/feats/account/core/sql/007-statements.sql	1224d0de662ec79204d52bc6df0ef173a69aac218e4ea7d8b1642c2335bbcace	2026-10-25 14:48:05.00772+01
apps/org/feats/account/core/sql/008-open.sql	f0903d27d029c5b6b3a6c4231b6c37ece2d115a77cc1eb4fe8d47cabc0ff7145	2026-10-25 14:48:05.022062+01
apps/org/feats/account/core/sql/009-reads.sql	b248665f7026529428f811bae1e01b6cd97cfbc2a67a9ea12ae300dd52e55f34	2026-10-25 14:48:05.026248+01
apps/org/feats/circle/core/sql/001-circle.sql	23a4e2e9fc9bd16d2a0054f10f66bf71c6513b96820c40355acf1bcb95be293e	2026-10-25 14:48:05.030347+01
apps/org/feats/circle/core/sql/002-tree.sql	fe5ed6d7ed3798d6c122dac586dd4adf7ae1bc5cc621b6b7b619b9adbf51bab6	2026-10-25 14:48:05.037395+01
apps/org/feats/circle/core/sql/003-carved.sql	a4663cb7a94970f572a767c06aed79c147fdd22ead85577de920fedb3dc327a9	2026-10-25 14:48:05.042242+01
apps/org/feats/circle/core/sql/004-personal.sql	5092cee66b8f4b954b4ebf6ff747020ff7c60b45e509abacf12587034aa3231c	2026-10-25 14:48:05.045411+01
apps/org/feats/circle/core/sql/005-procedure.sql	f8c4a8d0133bceefc18249067973fae71d0ecf5c2d8ef0504b093cb59b522ad1	2026-10-25 14:48:05.04681+01
apps/org/feats/client/core/sql/001-client.sql	dbaee5fe8132da2981561a0c76145bc2845cc3530ef3f4643be59e672b38505a	2026-10-25 14:48:05.048487+01
apps/org/feats/client/core/sql/002-powers.sql	cfc96b5ae5aa09dec6f9edfd8b47caa071f3e40cc41049edba5364c9c7e65170	2026-10-25 14:48:05.052361+01
apps/org/feats/client/core/sql/003-personal.sql	e99976aecdc75a22eb5c1a6b9fae52c5d92fc0fcdacb3e34cc253db990b6b1e5	2026-10-25 14:48:05.054023+01
apps/org/feats/decision/core/sql/001-decision.sql	3450b5fc7c01bf32aef5e1b7591d6f5913ce74f5872acd0a9273ae600489d3a7	2026-10-25 14:48:05.057127+01
apps/org/feats/decision/core/sql/002-rules-read.sql	b8afb3057ec345a816c5aa46c8a69404b262259f1c43f3855a1eb8813be86247	2026-10-25 14:48:05.061439+01
apps/org/feats/decision/core/sql/003-cites.sql	f92891031b7caabeeeea35e001cdccd04d5e118e33ccc68af4c990bf628db0d5	2026-10-25 14:48:05.063454+01
apps/org/feats/decision/core/sql/004-stance.sql	ee730e29e2d1c5bd41727cdf6cc580f31857c8083fa303ba43d081aeb9d0bc3d	2026-10-25 14:48:05.066181+01
apps/org/feats/decision/core/sql/005-motion.sql	f2186719b8ef2adcd5a3d263b92a6e99da5bdd3554626c728f74adfb496d87a8	2026-10-25 14:48:05.068229+01
apps/org/feats/decision/core/sql/006-procedure.sql	9e7c3b1fb2d45dca1b81a9662b58f1de8520bae5089474062c7cc3d0fa1a9e3a	2026-10-25 14:48:05.074541+01
apps/org/feats/decision/core/sql/007-message.sql	4d1ce7be5d026b07dd02d7c4253b5b128684099678f6375919e09209330c09e3	2026-10-25 14:48:05.080004+01
apps/org/feats/document/core/sql/001-document.sql	336d9d6c0d1802aeae969ec2c6d782575de332e1a23b0211324fda39acdeecf4	2026-10-25 14:48:05.084701+01
apps/org/feats/document/core/sql/002-powers.sql	eaeb216db1d6e9a3e9896e001457b664a38697ddbc419c8442229bb0493a6e18	2026-10-25 14:48:05.093673+01
apps/org/feats/document/core/sql/003-create.sql	de7c391b70ba162b2050853305a183d086dfd83a40ea775fa43b209bcb6a4a78	2026-10-25 14:48:05.094913+01
apps/org/feats/expense/core/sql/001-expense.sql	bba0f9bc5d3aa240a81d007e985e1452d840070209ed64a4cbd177f227570c3b	2026-10-25 14:48:05.096663+01
apps/org/feats/expense/core/sql/002-powers.sql	145cff9e0cdd869cd8ca37ae66b52a42d387d24521e3557096103ab81611d8c6	2026-10-25 14:48:05.103798+01
apps/org/feats/expense/core/sql/003-personal.sql	07d5a30b406c2488d4e95250b36db097d4e265f7026d9ca5ff1f58c8a0f87e10	2026-10-25 14:48:05.105011+01
apps/org/feats/file/core/sql/001-file.sql	3ea36a0bf8af9fb1f8f67aef0d6bded35afa5d1f8e41e7842f016e1f5f22d952	2026-10-25 14:48:05.107085+01
apps/org/feats/file/core/sql/002-personal.sql	a39914807fb9bf255305a1ff14def9c3f54f420c3991bb30a9f65af511165944	2026-10-25 14:48:05.118772+01
apps/org/feats/file/core/sql/003-reads.sql	b3ddee5ae322a4d340ad6105dea22a3b75ade870891815d83eeb86cffd364406	2026-10-25 14:48:05.121978+01
apps/org/feats/import/core/sql/001-import.sql	cc4f9df1f5087ec556a9ad8f19e3cf797bf66b7d5b9d457f55e5ffe497afeeaf	2026-10-25 14:48:05.124673+01
apps/org/feats/invoice/core/sql/001-invoice.sql	24f935874fd66ff310e0d1b3f986537173c28ab28c67484f96b97f7cf5829c7c	2026-10-25 14:48:05.12854+01
apps/org/feats/invoice/core/sql/002-powers.sql	cb23fea10d30ab0a7b6e825726fa3a6879352a50746a53fc048c52e62f9602c0	2026-10-25 14:48:05.138902+01
apps/org/feats/invoice/core/sql/003-personal.sql	4676ae006a3d1960e3252a1bf3bed5e773ed5e7179709aa124005da68ad5d0a6	2026-10-25 14:48:05.140164+01
apps/org/feats/meeting/core/sql/001-meeting.sql	a143e22c74ab5529b3ca29eb661c26995f4a0229c98ba1c71bc62cf032d08134	2026-10-25 14:48:05.141399+01
apps/org/feats/meeting/core/sql/002-powers.sql	95142c6654c324a0cf6e09a5404a3eec4ac5febcc5d52da8607fd71d460c83b3	2026-10-25 14:48:05.146933+01
apps/org/feats/patronage/core/sql/001-patronage.sql	a4ac077bb0f87e6b928ca2f41ec8fdba967696a04a5b4003aa99ef64c0455573	2026-10-25 14:48:05.148468+01
apps/org/feats/patronage/core/sql/002-powers.sql	f9115a8dffadc1d33d70f25e4df101f57584eb6c972ea426905f462a8e75cd9b	2026-10-25 14:48:05.160083+01
apps/org/feats/patronage/core/sql/003-personal.sql	e3e6d393b5542f502d966fa246bbdfb4947c4e6f1dc8e16b561672a417b685b1	2026-10-25 14:48:05.161385+01
apps/org/feats/patronage/core/sql/004-reads.sql	8fdb5fca82b0e97fb91e519709a6b68109296df10c46a55e24b57c2e65f48758	2026-10-25 14:48:05.16337+01
apps/org/feats/payslip/core/sql/001-payslip.sql	d5660c91fdccfa8383882f82cd30313ae2240df661ece8fec341976f097bbf94	2026-10-25 14:48:05.165502+01
apps/org/feats/payslip/core/sql/002-powers.sql	80f786b1f75622b35045bcd2a95179fd2369f7a67c0b24f86caa286aefea4c00	2026-10-25 14:48:05.173475+01
apps/org/feats/payslip/core/sql/003-personal.sql	ff8e2bfd80c0eebb25fe5d545a5bd52d3f339a262d29056589b0970871327551	2026-10-25 14:48:05.17513+01
apps/org/feats/payslip/core/sql/004-reads.sql	d6f19a0a180b236a8d6ede1dafe379845af7d7667e94880cc39bf8e81b1dce88	2026-10-25 14:48:05.177435+01
apps/org/feats/person/core/sql/001-person.sql	b87d460d957ac602eebc2f4730185841f506fcc326d2eafedbda65af62b7fa56	2026-10-25 14:48:05.180405+01
apps/org/feats/person/core/sql/002-device.sql	d5346e0416210c1db52c9d5cbdddfa59bd97d8f5c4bcaa8f42c4e5ce04c7e630	2026-10-25 14:48:05.183748+01
apps/org/feats/person/core/sql/003-powers.sql	4c97bbee8648ae55eb58b880e69ecc7a2baa1bd40e9c0aef16dffe73041b0a5b	2026-10-25 14:48:05.188701+01
apps/org/feats/person/core/sql/004-personal.sql	77d16e4cd51fb2a4c226b5f29f47cb47bc0f78638b073b117ee5e2b600257601	2026-10-25 14:48:05.190468+01
apps/org/feats/person/feats/employment/core/sql/001-employment.sql	09f3a6640755b380ee7e67d90221225f717aa7f71801e0ee75857dbaf55b3c9d	2026-10-25 14:48:05.19393+01
apps/org/feats/person/feats/employment/core/sql/002-powers.sql	61c8436a02c9bbbf159705872761355321bd1487e0cf3d0ed3ad973ec5c30062	2026-10-25 14:48:05.198825+01
apps/org/feats/person/feats/employment/core/sql/003-personal.sql	6f5945e4b898daf84ca941dda157b3319ffb8f45d510df1f545e2a4f0acf52f2	2026-10-25 14:48:05.201312+01
apps/org/feats/person/feats/employment/core/sql/004-device.sql	d9bc9aa1792892f3915f9ac588a297f6ab0af9ff09bafd1a53b608083765b3b6	2026-10-25 14:48:05.205401+01
apps/org/feats/person/feats/membership/core/sql/001-membership.sql	0e9ef980a3a8d317c1ef91e56bda8943d9005293a24ddb43ec962721b425b53f	2026-10-25 14:48:05.207319+01
apps/org/feats/person/feats/membership/core/sql/002-rules-read.sql	2c56815c74d389fdcc4158f78508982006d6fdc581dd01b4c6bfb4b011d281bd	2026-10-25 14:48:05.211666+01
apps/org/feats/person/feats/membership/core/sql/004-powers.sql	d1fd0fcf0926ae66033f200fcf4b3ecfcb05b47a145a0959334f2c181d63c30f	2026-10-25 14:48:05.21333+01
apps/org/feats/person/feats/membership/core/sql/005-lifecycle.sql	ad737d8b8e0b7598f18bc826ac94efe5a7ab0f1cbbd6b84b67e79a415c2f6c9c	2026-10-25 14:48:05.215072+01
apps/org/feats/person/feats/membership/core/sql/006-erase.sql	e8219e38ac03795efde6cb0b7fec4245e13b2d724738800ff8f94b146c907949	2026-10-25 14:48:05.219385+01
apps/org/feats/person/feats/membership/core/sql/007-invitation.sql	4fb41a69d8cfc9b84457758ac63df3c7db0d92fbe26ed97f5c9125c540043666	2026-10-25 14:48:05.223237+01
apps/org/feats/person/feats/membership/core/sql/008-link.sql	bb7e79fea5707d9efd24b103f835a19ed2ec0228c7510658d54b3a39a194d2b5	2026-10-25 14:48:05.22718+01
apps/org/feats/person/grafts/employment-membership/sql/001-employment-membership.sql	c866e71715db5dddaf6bb8bc6786903a8551d34f21310db947b4131b6b0eb72c	2026-10-25 14:48:05.232698+01
apps/org/feats/project/core/sql/001-project.sql	0127c415174409ba046323c2dda68789ab0046397aed7fb458d6d6b252446d53	2026-10-25 14:48:05.23758+01
apps/org/feats/project/core/sql/002-powers.sql	a89b3ae9eb512aff1ecfba2369ec7514f915235fd9e77ff459f4f852b25e6ac5	2026-10-25 14:48:05.242207+01
apps/org/feats/task/core/sql/001-task.sql	79b0a44c21df417d3671babb33550e723afa7409dd82a7342e9bd85e26dbb0fb	2026-10-25 14:48:05.243691+01
apps/org/feats/task/core/sql/002-powers.sql	06d88f8bf0141dbc7f626b82e5be9b438f77345b13f772e38cedb5656617bf72	2026-10-25 14:48:05.246657+01
apps/org/feats/timesheet/core/sql/001-timesheet.sql	8a0b88fd17624316a7b8cfa33de22fe1caa2f6bd4f3471033727df0150035a8b	2026-10-25 14:48:05.247984+01
apps/org/feats/timesheet/core/sql/002-powers.sql	ea68afd2f52dd48bbb037b782ee4b96b0d430220e43813ad844428b641bae527	2026-10-25 14:48:05.254467+01
apps/org/feats/timesheet/core/sql/003-personal.sql	4ef8aa889db50f21cb85f213f09876c04fecdfea80572027070a23e570b9b70b	2026-10-25 14:48:05.25593+01
apps/org/feats/timesheet/core/sql/004-reads.sql	a7bcfa0cd2d5929523bbcbae2ab3b7011a076779bce79922047964b701d9433f	2026-10-25 14:48:05.257255+01
apps/org/feats/transaction/core/sql/001-transaction.sql	ee41eb94be724729e07949b4b9a968ae298c684358fd69f7b4d7ce52fc93bd48	2026-10-25 14:48:05.259697+01
apps/org/feats/transaction/core/sql/002-journal.sql	32056e907028e06bc1113cf194ea24c3c65b9ce6a0dbf983277067274c4d24ed	2026-10-25 14:48:05.265312+01
apps/org/feats/transaction/core/sql/003-powers.sql	18f9a2ad5815511b2a180a3d8bcb73327906e87ce766428d4b40a9c1aa4bfddf	2026-10-25 14:48:05.268475+01
apps/org/feats/transaction/core/sql/004-pay.sql	982d5561bff7b7e5c49aa53acc6aaa660813532bcd020fb0241b3ab4ab4d05d6	2026-10-25 14:48:05.269825+01
apps/org/feats/transaction/core/sql/006-adjust.sql	be6f5eded1518ead8f0fb8eaa774f49b5b50015706ad72b1b49033a571723c37	2026-10-25 14:48:05.271797+01
apps/org/feats/transaction/core/sql/007-reads.sql	6f05baa2b78e79b4592164207969eedb684c6d99a51c16d6c1f4b95aeefb2823	2026-10-25 14:48:05.272981+01
apps/org/grafts/account-decision/sql/001-account-decision.sql	2f6e91c9bf2ab1d09f9a5804bf127f750b0dabfcdfd24c304523a6008d7b6055	2026-10-25 14:48:05.27584+01
apps/org/grafts/account-membership/sql/001-account-membership.sql	12cddc9961919545a0e9a470003179cee72b45f6c70ba7b6d078b0d924b279a3	2026-10-25 14:48:05.280023+01
apps/org/grafts/account-membership/sql/002-capital.sql	adc279adf81175c2efd8a6345b8e2625359f9b37c0611bec7cdb1482311bcb14	2026-10-25 14:48:05.284105+01
apps/org/grafts/account-membership/sql/003-reads.sql	0b52a5b7a110658d17cf7532b1eb662ba98077b9910f1acc7ad94df52be820e7	2026-10-25 14:48:05.287071+01
apps/org/grafts/account-patronage/sql/001-account-patronage.sql	6e3d483adde734e951b43592a3badb53e7abb0c1f4e370100d60a82e68932a98	2026-10-25 14:48:05.289511+01
apps/org/grafts/account-transaction/sql/001-account-transaction.sql	0f8c9ab0b1fa49081b8c9cf131638221a22c09815fa6ed7f4af45619d053f2f1	2026-10-25 14:48:05.291469+01
apps/org/grafts/account-transaction/sql/002-cash.sql	1eeacfa7f5a24019a93411f776e3a35b59693572dfb8aceaa957cf4f6e380929	2026-10-25 14:48:05.293731+01
apps/org/grafts/account-transaction/sql/003-statements.sql	c48157983ed3dfa83374ae7d729b3d29d12258d84927708e9b90b9c61095058d	2026-10-25 14:48:05.296435+01
apps/org/grafts/account-transaction/sql/004-carry.sql	a33b36a46552f0bde376791abf75233e89f4f03f5575271a1c622d96783232dd	2026-10-25 14:48:05.299667+01
apps/org/grafts/account-transaction/sql/005-reads.sql	3c0721023147d29359544bff146763e290da419837055a67d29ccab2705b4420	2026-10-25 14:48:05.302226+01
apps/org/grafts/circle-decision/sql/001-circle-decision.sql	f83d81e480848021d2f2f24139163610a78743541e32c6b72f44c5daaa06d243	2026-10-25 14:48:05.304883+01
apps/org/grafts/circle-decision/sql/002-procedure.sql	e66b16cce10bcb1185985e174f16ff5c9429dd49e1a399a7f40b412a1ad045c5	2026-10-25 14:48:05.30951+01
apps/org/grafts/circle-meeting/sql/001-circle-meeting.sql	03d643daaf0649b35727dfd59e48c9f16a1cdb55c01f1d746414db5b69df3e31	2026-10-25 14:48:05.311429+01
apps/org/grafts/circle-membership/sql/001-circle-membership.sql	62d7e74b7b8f3d99abe1825a95c72ed579ae8219396822a403b9edeb9d64c27e	2026-10-25 14:48:05.316418+01
apps/org/grafts/circle-membership/sql/002-may.sql	dd9961c13e9dc97e38c8cd7c47fd92d2b853ac062bfb1303bb5cb19115668fc6	2026-10-25 14:48:05.31977+01
apps/org/grafts/circle-membership/sql/003-position.sql	c0e5b92c6c76dfa23ce7722de853f2e2a3577a967dcbe890cc5ee4d1a5690465	2026-10-25 14:48:05.322522+01
apps/org/grafts/circle-membership/sql/004-sits.sql	a73b3d002094412bfbf3d2b09c2b66bb52bc711ccca725fc6d81344908e49772	2026-10-25 14:48:05.323962+01
apps/org/grafts/circle-membership/sql/005-over.sql	712c01593e4acb3ce7de385c669eebf06fe80ca0b12914af16ca21329d6273c8	2026-10-25 14:48:05.325977+01
apps/org/grafts/circle-membership/sql/006-authority.sql	d57bb65508dae7260ceb22bfc8053665f5fefbf229a14e27fb8e1f5ccd5902bd	2026-10-25 14:48:05.327859+01
apps/org/grafts/client-invoice/sql/001-client-invoice.sql	05c131c0621dea4749d4ea2964b37ef64b0867d7ac64fe81d854b70f3cde347d	2026-10-25 14:48:05.329413+01
apps/org/grafts/client-invoice/sql/002-powers.sql	710aee49978c7eb10141a81709bd261f0cef2970938ac3d0fcd989dd13ef0d92	2026-10-25 14:48:05.333261+01
apps/org/grafts/client-project/sql/001-client-project.sql	e60a25a5c1ad4f69e8793350ad9e447ea03df543082ba4e32ef58cca705ea47e	2026-10-25 14:48:05.335799+01
apps/org/grafts/client-project/sql/002-powers.sql	95fe4abc61f21b75a5111d4ebd9ed2f2aff5322ef1953f652475b112b8558551	2026-10-25 14:48:05.3399+01
apps/org/grafts/decision-document/sql/001-decision-document.sql	f39999fc2782469b1424433e68ce8534b3dd81302356f55b7d566aa5ab10c2fe	2026-10-25 14:48:05.342238+01
apps/org/grafts/decision-document/sql/002-adopt.sql	1467bb56b891dee59ecf4787ad29fe22cbc40b236a3f1d49c1a2ef852f92bb90	2026-10-25 14:48:05.345952+01
apps/org/grafts/decision-document/sql/003-link.sql	a2cd816758f6e8d59dc685785d77d9641f555f7293bdc57595e8fcb144aa13b9	2026-10-25 14:48:05.348389+01
apps/org/grafts/decision-meeting/sql/001-decision-meeting.sql	367d9f604ac928b3d50a00415021e188f6e94469187cd665730595f0cf4f151a	2026-10-25 14:48:05.350637+01
apps/org/grafts/decision-membership/sql/001-decision-membership.sql	2a41df334d13ee8fa1d7e0b4b5357071ead594698e72001446f8f8df8885d518	2026-10-25 14:48:05.354094+01
apps/org/grafts/decision-membership/sql/002-erase.sql	d2f6541b839536929745db9776d782b677bd37c8259706fffb2f320ddbd29e43	2026-10-25 14:48:05.358586+01
apps/org/grafts/decision-membership/sql/003-mention.sql	c074455f18a1e8a15027c61a8e139bc626e59337ee54ec5a74d1eade7f81a38f	2026-10-25 14:48:05.361243+01
apps/org/grafts/decision-patronage/sql/001-decision-patronage.sql	386aba75fcaa7243ad15a0799d3b0596f478063729bca894edfbd2ff52b18f3c	2026-10-25 14:48:05.363715+01
apps/org/grafts/document-meeting/sql/001-document-meeting.sql	8752347e9ee5bcb8977dbbd98940c6837598e128ec31899d6cf3dabf261355ea	2026-10-25 14:48:05.368112+01
apps/org/grafts/document-membership/sql/001-document-membership.sql	69c4321377b231e404a21688d90ecb7fd87e0d4c5a832642ef3df57dfada0f08	2026-10-25 14:48:05.374236+01
apps/org/grafts/employment-file/sql/001-employment-file.sql	3728a448fa3fc1e12d05ebe1f83f72cc30993dc2655df393ab63bd81b512cd02	2026-10-25 14:48:05.37731+01
apps/org/grafts/employment-payslip/sql/001-employment-payslip.sql	5d76e704c06a9fd7af96d8b0e08881636085a8985ee527843401b248ac3276a0	2026-10-25 14:48:05.379917+01
apps/org/grafts/employment-payslip/sql/002-reads.sql	bd0ac0394eb001c74288d374d50e658694643dc0a925f42fe8616f6050cf2c52	2026-10-25 14:48:05.382178+01
apps/org/grafts/employment-timesheet/sql/001-employment-timesheet.sql	d787cd16aa09a364fe27217820c40346921ce266aa9d0948b7929299129f05ea	2026-10-25 14:48:05.383582+01
apps/org/grafts/employment-timesheet/sql/002-reads.sql	9d816c04824f235a907ede10f37d0be426079dcb645279638daa46f3ad6e0935	2026-10-25 14:48:05.386075+01
apps/org/grafts/expense-file/sql/001-expense-file.sql	5155089770950fdd66cc303fc62fc8b3891d72c45d8fd0ab51c27fa7f24991f8	2026-10-25 14:48:05.387538+01
apps/org/grafts/expense-membership/sql/001-expense-membership.sql	883626ae5e16db0c8da89cca91c85b80f65d1e8c1660abba8342ebb5fa5a5a7d	2026-10-25 14:48:05.390596+01
apps/org/grafts/expense-project/sql/001-expense-project.sql	c457106f2ee1cd3c034f4694b4801bc012fa12f6ab2aaa52e5c6fe0d5dde74e2	2026-10-25 14:48:05.393477+01
apps/org/grafts/expense-transaction/sql/001-expense-transaction.sql	4e4d3370cb37e1dcf302907a46d8abb72f323cc4805bb90fc0fbf62fd7aa9705	2026-10-25 14:48:05.400259+01
apps/org/grafts/file-membership/sql/001-file-membership.sql	785908f84774d6540761a9a60fcf07380c91ab7014e42baf82656a862851c01a	2026-10-25 14:48:05.407605+01
apps/org/grafts/invoice-project/sql/001-invoice-project.sql	624ad3a475e9618f8cc6482a399c3ca2ddf9da8326fbbb305fdec880c584c202	2026-10-25 14:48:05.411356+01
apps/org/grafts/invoice-project/sql/002-powers.sql	89ff403546b716556d69781e01909abe3dc2787ded98a5cf45124d4ab0fb5d45	2026-10-25 14:48:05.414349+01
apps/org/grafts/invoice-transaction/sql/001-invoice-transaction.sql	cb7248940f2938585ec5ecf3d2704d99988fa4745d97ee4693058452026accc3	2026-10-25 14:48:05.415834+01
apps/org/grafts/meeting-membership/sql/001-meeting-membership.sql	1b1b1ed7d10859281153c9d3f41dfde896779c6dff24ed9ab4de29fc151d93e3	2026-10-25 14:48:05.421552+01
apps/org/grafts/membership-project/sql/001-membership-project.sql	9313676a80ffe10ee22ce9a3c2d41b3206510364853f143f9f41c66d3d95c356	2026-10-25 14:48:05.425369+01
apps/org/grafts/membership-project/sql/002-powers.sql	b2dd40e1ee84b213a355e24916bafdfb5f7e3d4ede1f88dde54bdf993f83353c	2026-10-25 14:48:05.429107+01
apps/org/grafts/membership-task/sql/001-membership-task.sql	05f6c3cf1722893276d548cf5e3f129806603423b109a87c620cc712e7949e1d	2026-10-25 14:48:05.43024+01
apps/org/grafts/membership-task/sql/002-powers.sql	d87e33c2fc13c90bd66ba270d50146980d371881b122af020f5ac14f4c01ea8c	2026-10-25 14:48:05.432518+01
apps/org/grafts/membership-timesheet/sql/001-membership-timesheet.sql	6b12080439193d1d06c7d4c8417898b066aad6ac0f61a325d160b73a78a0617b	2026-10-25 14:48:05.433628+01
apps/org/grafts/patronage-payslip/sql/001-patronage-payslip.sql	da0ba7ff883047ec200628478f44947730242e1b9bc4315efd1f91dbf7bded86	2026-10-25 14:48:05.43494+01
apps/org/grafts/patronage-payslip/sql/002-reads.sql	24b1d45de6f9b02ea29237b80de5002671d22a1943090886e8dd562da34a9b80	2026-10-25 14:48:05.438354+01
apps/org/grafts/patronage-timesheet/sql/001-patronage-timesheet.sql	560b5cec1ed5688115a394af85402d240324308d2837ae6aeb8bf4e5cc830dda	2026-10-25 14:48:05.439933+01
apps/org/grafts/patronage-timesheet/sql/002-reads.sql	24fb822a45fbd1dcff9ecd3e3dc1bb25f6a4073f12e898a15b43c492c7288100	2026-10-25 14:48:05.443269+01
apps/org/grafts/patronage-transaction/sql/001-patronage-transaction.sql	3a4d68518a4a723a7ad7d4d16536c1002119e282827083409b971f0829a4c1f9	2026-10-25 14:48:05.445119+01
apps/org/grafts/payslip-timesheet/sql/001-payslip-timesheet.sql	2447b99caba87d9a9ffe66abef36adc80750dc84d8413ee661f37d073159760a	2026-10-25 14:48:05.449419+01
apps/org/grafts/payslip-transaction/sql/001-payslip-transaction.sql	5edea0c08aa856190b5660910205fbb8a7e86717b8f45bdb26ee6e742286697a	2026-10-25 14:48:05.451347+01
apps/org/grafts/payslip-transaction/sql/002-withheld.sql	b2d615dffe8c808b056101570efef3c6f0e5a04db3fc1233c9ad8dcfc843bcf2	2026-10-25 14:48:05.455748+01
apps/org/grafts/project-task/sql/001-project-task.sql	b7bbf2585fc1f3aab05fdf9046dbebc25680a0a2dafbafd55599a4aa66e43f24	2026-10-25 14:48:05.459955+01
apps/org/grafts/project-task/sql/002-powers.sql	60b053dc167cca67a40ab539871d2894b7adb7c7988c093f5bef8276052a5ecd	2026-10-25 14:48:05.464858+01
apps/org/grafts/project-timesheet/sql/001-project-timesheet.sql	a4130ee54c2fedc15d10bfb0a1fb4346bc87ffed355d746216debbc55df1b1b0	2026-10-25 14:48:05.466919+01
apps/org/grafts/project-timesheet/sql/002-cost.sql	7ecc3803f4b5a7ccbd59d16c9d2f9bb3126f681aadd256bb8ef3c6161d73170e	2026-10-25 14:48:05.474127+01
apps/org/grafts/project-timesheet/sql/003-reads.sql	6184727612d1dba371ceab3397f83202f0ee7a1498bc52d7493f453a8c8674f9	2026-10-25 14:48:05.478763+01
apps/org/grafts/account-membership-patronage/sql/001-account-membership-patronage.sql	5491eb15f2591765b7e14a436ebd70ac615ddfd2788938829f7860b4e005b3ce	2026-10-25 14:48:05.480196+01
apps/org/grafts/account-membership-patronage/sql/002-reads.sql	3546e605fcd822cd53078213ca143480660a0f13558d62b7f636b2cb51cbb786	2026-10-25 14:48:05.482603+01
apps/org/grafts/account-membership-transaction/sql/001-account-membership-transaction.sql	60dc6d23a902ebb91892b0444e0b9622c57bedb50117e7d60a6cbd5e6f00fa90	2026-10-25 14:48:05.483963+01
apps/org/grafts/account-membership-transaction/sql/002-capital.sql	c85b9533efc1229e0f5264c8a8db32d13852a511e32f3c09901cd131ada2140e	2026-10-25 14:48:05.488969+01
apps/org/grafts/account-membership-transaction/sql/003-reads.sql	7ff8579b8dd2115df1969184b4c94193a1159d6aa53d169d04066187327baba0	2026-10-25 14:48:05.495633+01
apps/org/grafts/circle-decision-membership/sql/001-circle-decision-membership.sql	5713bd01788de56de2dade4501c1d43c442952b45f221dc1f9c5bb9b7809dca1	2026-10-25 14:48:05.497905+01
apps/org/grafts/circle-decision-membership/sql/002-counted.sql	81153092b30bbb9154bafb1b03dccc2b03cf44df90c214afe3509cdf2ad8e2f0	2026-10-25 14:48:05.501679+01
apps/org/grafts/circle-decision-membership/sql/003-seats.sql	9186dd39c9492b4567ef5d3bd3e34110958dc4005d152c31f501be34b747e30c	2026-10-25 14:48:05.504843+01
apps/org/grafts/circle-decision-membership/sql/004-sits.sql	5ee0eb72b6c2600733d70508b2c4e2ab337c47fc062f156a6cb673ef331dd32c	2026-10-25 14:48:05.508196+01
apps/org/grafts/circle-decision-membership/sql/005-governance.sql	8a9fbf05d7e27899f67cd02bfcf21f08ca56747b8d6ba7311d6931683ea4d6a7	2026-10-25 14:48:05.509743+01
apps/org/grafts/circle-decision-membership/sql/006-procedure.sql	d57885f5e1e00d120a7d00279d0e429e933846309da53cab39f1ad99915d9546	2026-10-25 14:48:05.512454+01
apps/org/grafts/circle-decision-membership/sql/007-deliberation.sql	55f4c0a27461e1958c91d5f859262e87ae3b05ddba18fe8a84fc2ff66d726d39	2026-10-25 14:48:05.515156+01
apps/org/grafts/circle-expense-membership/sql/001-circle-expense-membership.sql	a2fc530fa9d1ec822fcc9ef2c6e8cfcc397c3e83dffc26209c288ad1fa9e9955	2026-10-25 14:48:05.516385+01
apps/org/grafts/circle-file-membership/sql/001-circle-file-membership.sql	7401270e67a922fb3af6189994ff80065ceefdb355d0ca7d8a2e96505f6d5a67	2026-10-25 14:48:05.518552+01
apps/org/grafts/circle-file-membership/sql/002-reads.sql	21c4dc708f5706ed0af8ca34b0200bbc2f27d5f840346fb520acd176fc0357c4	2026-10-25 14:48:05.521122+01
apps/org/grafts/circle-meeting-membership/sql/001-circle-meeting-membership.sql	66f63a424a3f09c45df6ac502e939b223c5c3ab7ed3074c38337d683d09cb51e	2026-10-25 14:48:05.522477+01
apps/org/grafts/circle-membership-project/sql/001-circle-membership-project.sql	392bf93a2d2c6fb051cf2b2ceccd2bc883bd2426b8a3cd2b0e90f31cb3ccc799	2026-10-25 14:48:05.527081+01
apps/org/grafts/circle-membership-timesheet/sql/001-circle-membership-timesheet.sql	fb78eddad7b859e6548ece6c77d4596d9de53667d517811d734ee0ed195a57be	2026-10-25 14:48:05.528853+01
apps/org/grafts/circle-membership-timesheet/sql/002-workers.sql	69b28e03862ed121d2c3b5946afa0f14e837c268846db58b8e0ba22ade4bf908	2026-10-25 14:48:05.530523+01
apps/org/grafts/decision-employment-membership/sql/001-decision-employment-membership.sql	70689043a10e95286fd346d96d7769e961296ef797a15131a347678c8a5717d0	2026-10-25 14:48:05.532994+01
apps/org/grafts/employment-project-timesheet/sql/001-employment-project-timesheet.sql	ba71272b4a2381632805865a44be126b4f595b77778758e0ba2f788939bfa5fc	2026-10-25 14:48:05.536289+01
apps/org/grafts/account-membership-patronage-transaction/sql/001-account-membership-patronage-transaction.sql	314302dd689081eed31ea89aef523988fe875ad32483619cb441141ccd5200ac	2026-10-25 14:48:05.537879+01
apps/org/grafts/account-membership-patronage-transaction/sql/002-reads.sql	59e007a0da6f6335570807ccdd03edc04370ddb9a0d0339bf5c7f9bce88569c9	2026-10-25 14:48:05.545005+01
apps/org/grafts/account-membership-patronage-transaction/sql/003-return.sql	1487d6fd275991159665a64fcd5387e55d5b2dd36e0dee5c7412bd3c3c7522c1	2026-10-25 14:48:05.546653+01
apps/org/grafts/account-membership-payslip-transaction/sql/001-account-membership-payslip-transaction.sql	9864a439ba2569125c6e79f31e1a557160f1c15090fea336e4cbee838542d768	2026-10-25 14:48:05.550985+01
apps/org/grafts/account-membership-payslip-transaction/sql/002-reads.sql	a9454de2de93796c427149c5b843384039439387456f429767abb58a8b0c6fe0	2026-10-25 14:48:05.557519+01
apps/org/grafts/expense-invoice-project-timesheet/sql/001-expense-invoice-project-timesheet.sql	626bc977942efd8c674619d5c36aa30d59a26172531ae01febea08686bb52cfc	2026-10-25 14:48:05.559761+01
\.


--
-- Data for Name: distribution; Type: TABLE DATA; Schema: patronage; Owner: -
--

COPY patronage.distribution (id, year, surplus, basis, approved, distributed) FROM stdin;
2025	2025	61400.00	salary	\N	\N
\.


--
-- Data for Name: part; Type: TABLE DATA; Schema: patronage; Owner: -
--

COPY patronage.part (distribution, worker, basis, quantity, amount) FROM stdin;
\.


--
-- Data for Name: share; Type: TABLE DATA; Schema: patronage; Owner: -
--

COPY patronage.share (distribution, kind, percent, amount) FROM stdin;
2025	work	45.00	27630.00
2025	legal	15.00	9210.00
2025	development	25.00	15350.00
2025	interest	15.00	9210.00
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: patronage; Owner: -
--

COPY patronage.terms (id, "from", salary, hours, equal, capital, adopted) FROM stdin;
st-2021	2021	100.00	0.00	0.00	50.00	2021-03-01
\.


--
-- Data for Name: distribution; Type: TABLE DATA; Schema: patronage_transaction; Owner: -
--

COPY patronage_transaction.distribution (distribution, entry) FROM stdin;
\.


--
-- Data for Name: payslip; Type: TABLE DATA; Schema: payslip; Owner: -
--

COPY payslip.payslip (month, member, minutes, gross, employee, employer, net) FROM stdin;
2026-07	amina@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-07	camille@lanterne.example	\N	3000.00	660.00	1200.00	2340.00
2026-07	hugo@lanterne.example	\N	2800.00	616.00	1120.00	2184.00
2026-07	julien@lanterne.example	\N	2600.00	572.00	1040.00	2028.00
2026-07	lea@lanterne.example	\N	2500.00	550.00	1000.00	1950.00
2026-07	malik@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-07	sofia@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-07	thomas@lanterne.example	\N	2500.00	550.00	1000.00	1950.00
2026-07	yusuf@lanterne.example	\N	3000.00	660.00	1200.00	2340.00
2026-08	amina@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-08	camille@lanterne.example	\N	3000.00	660.00	1200.00	2340.00
2026-08	hugo@lanterne.example	\N	2800.00	616.00	1120.00	2184.00
2026-08	julien@lanterne.example	\N	2600.00	572.00	1040.00	2028.00
2026-08	lea@lanterne.example	\N	2500.00	550.00	1000.00	1950.00
2026-08	malik@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-08	sofia@lanterne.example	\N	2400.00	528.00	960.00	1872.00
2026-08	thomas@lanterne.example	\N	2500.00	550.00	1000.00	1950.00
2026-08	yusuf@lanterne.example	\N	3000.00	660.00	1200.00	2340.00
2026-09	amina@lanterne.example	9240	2400.00	528.00	960.00	1872.00
2026-09	camille@lanterne.example	9240	3000.00	660.00	1200.00	2340.00
2026-09	hugo@lanterne.example	9240	2800.00	616.00	1120.00	2184.00
2026-09	julien@lanterne.example	9240	2600.00	572.00	1040.00	2028.00
2026-09	lea@lanterne.example	9240	2500.00	550.00	1000.00	1950.00
2026-09	malik@lanterne.example	9240	2400.00	528.00	960.00	1872.00
2026-09	sofia@lanterne.example	9240	2400.00	528.00	960.00	1872.00
2026-09	thomas@lanterne.example	9240	2500.00	550.00	1000.00	1950.00
2026-09	yusuf@lanterne.example	9240	3000.00	660.00	1200.00	2340.00
2026-07	chloe@lanterne.example	\N	\N	\N	\N	\N
2026-08	chloe@lanterne.example	\N	\N	\N	\N	\N
2026-09	chloe@lanterne.example	9240	\N	\N	\N	\N
\.


--
-- Data for Name: run; Type: TABLE DATA; Schema: payslip; Owner: -
--

COPY payslip.run (month, generated, approved, approver, paid) FROM stdin;
2026-07	2026-07-24	2026-07-27	camille@lanterne.example	2026-07-28
2026-08	2026-08-24	2026-08-27	camille@lanterne.example	2026-08-28
2026-09	2026-09-24	2026-09-25	camille@lanterne.example	2026-09-28
\.


--
-- Data for Name: salary; Type: TABLE DATA; Schema: payslip; Owner: -
--

COPY payslip.salary (member, "from", gross) FROM stdin;
camille@lanterne.example	2025-01-01	3000.00
yusuf@lanterne.example	2025-01-01	3000.00
hugo@lanterne.example	2025-01-01	2800.00
julien@lanterne.example	2025-01-01	2600.00
lea@lanterne.example	2025-01-01	2500.00
thomas@lanterne.example	2025-01-01	2500.00
sofia@lanterne.example	2025-01-01	2400.00
malik@lanterne.example	2025-01-01	2400.00
amina@lanterne.example	2025-01-01	2400.00
ines@lanterne.example	2026-10-01	2200.00
chloe@lanterne.example	2025-01-01	\N
\.


--
-- Data for Name: terms; Type: TABLE DATA; Schema: payslip; Owner: -
--

COPY payslip.terms (one, employee, employer, ratio) FROM stdin;
t	22.00	40.00	1.60
\.


--
-- Data for Name: posting; Type: TABLE DATA; Schema: payslip_transaction; Owner: -
--

COPY payslip_transaction.posting (entry, month, event) FROM stdin;
je-0009	2026-07	carried
je-0019	2026-08	carried
je-0031	2026-09	carried
\.


--
-- Data for Name: device; Type: TABLE DATA; Schema: person; Owner: -
--

COPY person.device (key, address, label, enrolled, enrolled_by, revoked) FROM stdin;
\\xe3d57b852954504fc7846b5f4788f2c9d32dbd307a2c4acd8dfccfcfc3f3ce41	camille@lanterne.example	laptop	2025-01-15	\N	\N
\\x2adcb6a5bd3dd539774a0678679c8b6d2ae83921833ca924cd46f83d479afdab	camille@lanterne.example	phone	2025-01-15	\N	\N
\\xe4710f55f6a0a35687bca218113cb0279136bbd0d6d87211eb245116fbbd819d	yusuf@lanterne.example	laptop	2025-01-15	\N	\N
\\xf46789898446718845e6621727395138c2269e457f80ff506b83a71115548b9a	yusuf@lanterne.example	phone	2025-01-15	\N	\N
\\xf282134bfa3aef3cc8ab7f12975595d23d584b78b55119c308c01234f0b99f22	hugo@lanterne.example	laptop	2025-01-15	\N	\N
\\xbb6c45e69eca21fa48f39a688e57754cd7480413420d372bc2c59bb8dbc100fb	julien@lanterne.example	laptop	2025-01-15	\N	\N
\\x2305fade72337ec75ff0927935c8f5ab799edac1b7cf130934144a971f5c0673	julien@lanterne.example	phone	2025-01-15	\N	\N
\\x2646566ac94e44d96732c0c1113fdaf5b4de4940b43fd91c456d587a8d8b5fb1	lea@lanterne.example	laptop	2025-01-15	\N	\N
\\xa7618b710f90d71b7540510cb74df1bb1cc4e4abbe18e9bb022a057c5b5bcc3b	thomas@lanterne.example	laptop	2025-01-15	\N	\N
\\x03743a748f5aad5efb4a4950180b610dfe362f5b5c25c388dd4e99b505f4eea8	sofia@lanterne.example	laptop	2025-01-15	\N	\N
\\x9c5d931883bf543c435020c46586f89e4d9c95af9757b54d95c8a3c915721047	malik@lanterne.example	laptop	2025-01-15	\N	\N
\\xf1be40e61711cbf4fd010ea89126de0d9844c829c9ed640d93133e5ae16a6112	malik@lanterne.example	phone	2025-01-15	\N	\N
\\xde69b2a7eecafc743ac6df34b86f48dbe73bf021b58403ebcb0977498dbc6270	amina@lanterne.example	laptop	2025-01-15	\N	\N
\\xf36e685af3f374908d21da18445e823162c4b63fad1bf789500a7a3839bb964e	chloe@lanterne.example	laptop	2025-01-15	\N	\N
\\x5bde8e5802142f5265d1d1b865ed76c7ef33e198610f1907515c258e09aae665	hugo@lanterne.example	old laptop	2025-01-15	\N	2026-05-12
\\xff90a68ec8b6d60847c7ee05353821fb22e4587802863bdfd9eb42d1bea4e529	ines@lanterne.example	laptop	2025-09-01	\N	\N
\\x3a9ffc55d8edf3db06f0c483ff627b9cd037cfc992712952777619c181705f36	ines@lanterne.example	phone	2026-10-01	\N	\N
\.


--
-- Data for Name: person; Type: TABLE DATA; Schema: person; Owner: -
--

COPY person.person (address, name, email, phone) FROM stdin;
camille@lanterne.example	Camille Martin	\N	\N
yusuf@lanterne.example	Yusuf Demir	\N	\N
julien@lanterne.example	Julien Petit	\N	\N
thomas@lanterne.example	Thomas Nguyen	\N	\N
sofia@lanterne.example	Sofia Rossi	\N	\N
malik@lanterne.example	Malik Benali	\N	\N
amina@lanterne.example	Amina Diallo	\N	\N
paul@lanterne.example	Paul Garnier	\N	\N
ines@lanterne.example	Inès Haddad	\N	\N
lea@lanterne.example	Léa Bernard	redacted	redacted
chloe@lanterne.example	redacted	\N	\N
hugo@lanterne.example	Hugo Lefèvre	hugo@moreau.example	+33 7 00 00 00 02
\.


--
-- Data for Name: milestone; Type: TABLE DATA; Schema: project; Owner: -
--

COPY project.milestone (project, n, title, due, completed) FROM stdin;
halles-shop	1	Design	2026-07-03	2026-07-03
halles-shop	2	Build	2026-08-28	2026-08-27
halles-shop	3	Launch	2026-10-09	2026-10-08
halles-shop	4	Care and handover	2026-11-27	\N
clairval-site	1	Lot 1: audit and architecture	2026-07-15	2026-07-15
clairval-site	2	Lot 2: design system and templates	2026-09-04	2026-09-04
nuvola-retainer	1	Q3 review	2026-10-02	2026-10-02
nuvola-retainer	2	Q4 review and renewal	2026-12-11	\N
mauve-posters	1	Posters	2026-07-10	2026-07-10
mauve-posters	2	Brochure	2026-07-21	2026-07-20
velo-identity	1	Concepts	2026-08-28	2026-08-28
velo-identity	2	Identity and guidelines	2026-09-11	2026-09-11
ferrand-packaging	1	Range concept	2026-09-11	2026-09-11
ferrand-packaging	2	Six packs, print-ready	2026-09-25	2026-09-25
ferrand-packaging	3	Print supervision	2026-11-06	\N
terres-report	1	Report design	2026-10-16	2026-10-16
terres-report	2	Microsite	2026-11-27	\N
ondine-shop	1	Shop, fixed price	2026-07-28	2026-07-28
\.


--
-- Data for Name: project; Type: TABLE DATA; Schema: project; Owner: -
--

COPY project.project (id, title, circle, summary, started, due, budget, archived) FROM stdin;
halles-shop	Les Halles Paysannes, online shop	web	An online shop for a network of farmers' shops: weekly baskets, click and\ncollect at six shops, and the farmers' own product sheets. Fixed price in\nfour milestones of 12 000 €, invoiced as each is delivered.	2026-06-08	2026-11-27	48000.00	\N
clairval-site	Ville de Clairval, town website	web	The town website rebuilt to RGAA accessibility, won by tender in two lots.\nThe build itself is a later tender.	2026-06-22	2026-09-04	24000.00	\N
nuvola-retainer	Nuvola Énergie, marketing retainer	marketing	A citizen solar co-op's marketing: strategy, newsletter and social media,\n4 800 € a month, renewed each January.	2026-01-05	2026-12-31	57600.00	\N
mauve-posters	Compagnie Mauve Horizon, season posters	brand	Posters and a brochure for the theatre company's 26-27 season.	2026-06-01	2026-07-21	6200.00	\N
velo-identity	Vélo Solidaire, brand identity	brand	A brand identity for a bike repair workshop, at the solidarity rate.	2026-08-17	2026-09-11	3300.00	\N
ferrand-packaging	Maison Ferrand, packaging	brand	Packaging for an artisan bakery group's range of six, from concept to the\npress check at the printer.	2026-09-01	2026-11-06	14000.00	\N
terres-report	Fondation Terres Vives, annual report and microsite	brand	The land trust's annual report, in print and as a microsite with its map of\nthe farms it holds. Two milestones of 9 000 €.	2026-09-14	2026-11-27	18000.00	\N
ondine-shop	Atelier Ondine, online shop	web	An online shop for a ceramics studio, at a fixed price.	2026-05-18	2026-07-28	9500.00	2026-09-01
\.


--
-- Data for Name: filing; Type: TABLE DATA; Schema: project_task; Owner: -
--

COPY project_task.filing (task, project, milestone) FROM stdin;
t-1	halles-shop	3
t-2	halles-shop	3
t-3	halles-shop	3
t-4	halles-shop	4
t-5	halles-shop	4
t-6	halles-shop	4
t-7	halles-shop	4
t-8	clairval-site	2
t-9	clairval-site	2
t-10	nuvola-retainer	\N
t-11	nuvola-retainer	\N
t-12	nuvola-retainer	1
t-13	nuvola-retainer	\N
t-14	nuvola-retainer	2
t-15	mauve-posters	\N
t-16	velo-identity	1
t-17	velo-identity	2
t-18	ferrand-packaging	1
t-19	ferrand-packaging	2
t-20	ferrand-packaging	2
t-21	ferrand-packaging	3
t-22	ferrand-packaging	3
t-23	terres-report	1
t-24	terres-report	1
t-25	terres-report	2
t-26	terres-report	2
t-27	terres-report	\N
\.


--
-- Data for Name: booking; Type: TABLE DATA; Schema: project_timesheet; Owner: -
--

COPY project_timesheet.booking (entry, project) FROM stdin;
1	halles-shop
2	halles-shop
3	halles-shop
4	halles-shop
5	halles-shop
6	halles-shop
7	halles-shop
8	halles-shop
9	halles-shop
10	halles-shop
11	halles-shop
12	halles-shop
13	halles-shop
14	halles-shop
15	halles-shop
16	halles-shop
17	halles-shop
18	halles-shop
19	halles-shop
20	halles-shop
21	halles-shop
22	halles-shop
23	halles-shop
24	halles-shop
25	halles-shop
26	halles-shop
27	halles-shop
28	halles-shop
29	halles-shop
30	halles-shop
31	halles-shop
32	halles-shop
33	halles-shop
34	halles-shop
35	halles-shop
36	halles-shop
37	halles-shop
38	halles-shop
39	halles-shop
40	terres-report
41	terres-report
42	terres-report
43	terres-report
44	terres-report
45	terres-report
46	terres-report
47	terres-report
48	terres-report
49	terres-report
89	halles-shop
90	halles-shop
91	halles-shop
92	halles-shop
93	halles-shop
94	halles-shop
95	halles-shop
96	halles-shop
97	halles-shop
98	halles-shop
99	halles-shop
100	halles-shop
101	halles-shop
102	halles-shop
103	halles-shop
104	halles-shop
105	halles-shop
106	halles-shop
107	halles-shop
108	halles-shop
109	halles-shop
110	halles-shop
111	halles-shop
112	halles-shop
113	halles-shop
114	halles-shop
115	halles-shop
116	halles-shop
117	halles-shop
118	halles-shop
119	halles-shop
120	halles-shop
121	halles-shop
122	halles-shop
123	halles-shop
124	halles-shop
125	halles-shop
126	halles-shop
127	halles-shop
177	halles-shop
178	halles-shop
179	halles-shop
180	halles-shop
181	halles-shop
182	halles-shop
183	halles-shop
184	halles-shop
185	halles-shop
186	halles-shop
187	halles-shop
188	halles-shop
189	halles-shop
190	halles-shop
191	halles-shop
192	halles-shop
193	halles-shop
194	halles-shop
195	halles-shop
196	halles-shop
197	halles-shop
198	halles-shop
199	halles-shop
200	halles-shop
201	halles-shop
202	halles-shop
203	halles-shop
204	halles-shop
205	halles-shop
206	halles-shop
207	halles-shop
208	halles-shop
209	halles-shop
210	halles-shop
211	halles-shop
212	halles-shop
213	halles-shop
214	halles-shop
215	halles-shop
216	terres-report
217	terres-report
218	terres-report
219	terres-report
220	terres-report
221	terres-report
222	terres-report
223	terres-report
224	terres-report
225	terres-report
265	clairval-site
266	clairval-site
267	clairval-site
268	clairval-site
269	terres-report
270	terres-report
271	terres-report
272	terres-report
273	terres-report
274	terres-report
275	terres-report
276	terres-report
277	terres-report
278	terres-report
279	terres-report
280	terres-report
281	terres-report
282	terres-report
283	terres-report
284	terres-report
285	terres-report
286	terres-report
287	terres-report
288	terres-report
289	terres-report
290	terres-report
291	terres-report
292	terres-report
293	terres-report
294	terres-report
295	terres-report
296	terres-report
297	terres-report
298	terres-report
338	velo-identity
339	velo-identity
340	velo-identity
341	velo-identity
342	velo-identity
343	velo-identity
344	velo-identity
345	velo-identity
346	velo-identity
347	ferrand-packaging
348	ferrand-packaging
349	ferrand-packaging
350	ferrand-packaging
351	ferrand-packaging
352	ferrand-packaging
353	ferrand-packaging
354	ferrand-packaging
355	ferrand-packaging
356	ferrand-packaging
357	ferrand-packaging
358	ferrand-packaging
359	ferrand-packaging
360	ferrand-packaging
361	ferrand-packaging
362	ferrand-packaging
363	ferrand-packaging
364	ferrand-packaging
365	ferrand-packaging
366	ferrand-packaging
367	ferrand-packaging
368	ferrand-packaging
369	ferrand-packaging
370	ferrand-packaging
371	ferrand-packaging
372	ferrand-packaging
373	ferrand-packaging
374	ferrand-packaging
375	ferrand-packaging
376	ferrand-packaging
377	ferrand-packaging
378	ferrand-packaging
379	ferrand-packaging
380	ferrand-packaging
381	ferrand-packaging
382	ferrand-packaging
383	ferrand-packaging
384	ferrand-packaging
385	ferrand-packaging
386	terres-report
387	terres-report
388	terres-report
389	terres-report
390	terres-report
391	terres-report
392	terres-report
393	terres-report
394	terres-report
395	terres-report
396	terres-report
397	terres-report
398	terres-report
399	terres-report
400	terres-report
401	terres-report
402	terres-report
403	terres-report
404	terres-report
405	terres-report
406	terres-report
407	terres-report
408	terres-report
409	terres-report
410	terres-report
450	velo-identity
451	velo-identity
452	velo-identity
453	velo-identity
454	velo-identity
455	velo-identity
456	velo-identity
457	velo-identity
458	velo-identity
459	ferrand-packaging
460	ferrand-packaging
461	ferrand-packaging
462	ferrand-packaging
463	ferrand-packaging
464	ferrand-packaging
465	ferrand-packaging
466	ferrand-packaging
467	ferrand-packaging
468	ferrand-packaging
469	ferrand-packaging
470	ferrand-packaging
471	ferrand-packaging
472	ferrand-packaging
473	ferrand-packaging
474	ferrand-packaging
475	ferrand-packaging
476	ferrand-packaging
477	ferrand-packaging
478	terres-report
479	terres-report
480	terres-report
481	terres-report
482	terres-report
483	terres-report
484	terres-report
485	terres-report
486	terres-report
487	terres-report
488	terres-report
489	terres-report
490	terres-report
491	terres-report
492	terres-report
532	ferrand-packaging
533	ferrand-packaging
534	ferrand-packaging
535	ferrand-packaging
536	ferrand-packaging
537	ferrand-packaging
538	ferrand-packaging
539	ferrand-packaging
540	ferrand-packaging
541	ferrand-packaging
542	ferrand-packaging
543	ferrand-packaging
544	ferrand-packaging
545	ferrand-packaging
546	ferrand-packaging
547	ferrand-packaging
548	ferrand-packaging
549	ferrand-packaging
550	ferrand-packaging
551	terres-report
552	terres-report
553	terres-report
554	terres-report
555	terres-report
556	terres-report
557	terres-report
558	terres-report
559	terres-report
560	terres-report
561	terres-report
562	terres-report
563	terres-report
564	terres-report
565	terres-report
605	nuvola-retainer
606	nuvola-retainer
607	nuvola-retainer
608	nuvola-retainer
609	nuvola-retainer
610	nuvola-retainer
611	nuvola-retainer
612	nuvola-retainer
613	nuvola-retainer
614	nuvola-retainer
615	nuvola-retainer
616	nuvola-retainer
617	nuvola-retainer
618	nuvola-retainer
619	nuvola-retainer
620	nuvola-retainer
621	nuvola-retainer
622	nuvola-retainer
623	nuvola-retainer
624	nuvola-retainer
625	nuvola-retainer
626	nuvola-retainer
627	nuvola-retainer
628	nuvola-retainer
629	nuvola-retainer
630	nuvola-retainer
631	nuvola-retainer
632	nuvola-retainer
633	nuvola-retainer
634	nuvola-retainer
635	nuvola-retainer
636	nuvola-retainer
637	nuvola-retainer
638	nuvola-retainer
639	nuvola-retainer
640	nuvola-retainer
641	nuvola-retainer
642	nuvola-retainer
643	nuvola-retainer
683	nuvola-retainer
684	nuvola-retainer
685	nuvola-retainer
686	nuvola-retainer
687	nuvola-retainer
688	nuvola-retainer
689	nuvola-retainer
690	nuvola-retainer
691	nuvola-retainer
692	nuvola-retainer
693	nuvola-retainer
694	nuvola-retainer
695	nuvola-retainer
696	nuvola-retainer
697	nuvola-retainer
698	nuvola-retainer
699	nuvola-retainer
700	nuvola-retainer
701	nuvola-retainer
702	nuvola-retainer
703	nuvola-retainer
704	nuvola-retainer
705	nuvola-retainer
706	nuvola-retainer
707	nuvola-retainer
708	nuvola-retainer
709	nuvola-retainer
710	nuvola-retainer
711	nuvola-retainer
712	nuvola-retainer
713	nuvola-retainer
714	nuvola-retainer
715	nuvola-retainer
716	nuvola-retainer
717	nuvola-retainer
718	nuvola-retainer
719	nuvola-retainer
720	nuvola-retainer
721	nuvola-retainer
\.


--
-- Data for Name: cost; Type: TABLE DATA; Schema: project_timesheet; Owner: -
--

COPY project_timesheet.cost (since, hourly) FROM stdin;
2026-01-01	23.64
\.


--
-- Data for Name: rate; Type: TABLE DATA; Schema: project_timesheet; Owner: -
--

COPY project_timesheet.rate (since, hourly) FROM stdin;
2026-01-01	80.00
\.


--
-- Data for Name: task; Type: TABLE DATA; Schema: task; Owner: -
--

COPY task.task (id, title, status, priority, due, created, completed) FROM stdin;
t-1	Payment provider go-live checklist	done	high	2026-10-06	2026-09-14	2026-10-06
t-2	Load test the checkout	done	high	2026-10-05	2026-09-14	2026-10-05
t-3	Import products from the farmers' spreadsheet	done	normal	2026-09-25	2026-09-01	2026-09-25
t-4	Train the shops' staff on the back office	doing	normal	2026-10-30	2026-10-08	\N
t-5	Write the handover guide	todo	normal	2026-11-20	2026-10-08	\N
t-6	Fix VAT display on mixed baskets	doing	urgent	2026-10-27	2026-10-19	\N
t-7	Monthly analytics report, October	backlog	low	2026-11-05	2026-10-08	\N
t-8	RGAA audit of the templates	done	high	2026-09-03	2026-08-24	2026-09-03
t-9	Design system tokens and components	done	normal	2026-09-02	2026-08-10	2026-09-02
t-10	October newsletter	done	normal	2026-10-09	2026-09-28	2026-10-09
t-11	Social calendar, November	doing	normal	2026-10-28	2026-10-12	\N
t-12	Q3 campaign report	done	normal	2026-10-02	2026-09-21	2026-10-02
t-13	Campaign for the community solar open day	todo	high	2026-11-06	2026-10-12	\N
t-14	Q4 review and renewal proposal	backlog	normal	2026-12-11	2026-10-05	\N
t-15	Chase the overdue invoice F-2026-0044	todo	high	2026-10-31	2026-10-20	\N
t-16	Three logo concepts	done	normal	2026-08-28	2026-08-17	2026-08-27
t-17	Brand guidelines	done	normal	2026-09-11	2026-08-31	2026-09-11
t-18	Range concept boards	done	high	2026-09-11	2026-09-01	2026-09-10
t-19	Die lines for the six packs	done	normal	2026-09-23	2026-09-11	2026-09-22
t-20	Print-ready files	done	high	2026-09-25	2026-09-14	2026-09-25
t-21	Press check at the printer	todo	high	2026-11-04	2026-09-28	\N
t-22	Order colour proofs	doing	normal	2026-10-29	2026-10-12	\N
t-23	Annual report layout	done	high	2026-10-14	2026-09-28	2026-10-14
t-24	Infographics for the map of the farms	done	normal	2026-10-15	2026-09-28	2026-10-15
t-25	Microsite wireframes	doing	high	2026-10-30	2026-10-12	\N
t-26	Microsite build	todo	normal	2026-11-20	2026-10-12	\N
t-27	Quotes for printing the report	doing	normal	2026-10-28	2026-10-14	\N
t-28	Close October's books	todo	high	2026-11-05	2026-10-19	\N
t-29	Rate card 2027: answer Malik's comment	todo	normal	2026-11-07	2026-10-21	\N
t-30	Prepare Inès's onboarding as a member	todo	normal	2026-11-02	2026-10-20	\N
t-31	Renew the studio's insurance	backlog	low	2026-12-01	2026-10-05	\N
t-32	Portfolio pages for Vélo Solidaire and Maison Ferrand	backlog	low	\N	2026-10-05	\N
t-33	Plugin updates on Atelier Ondine's shop	done	normal	2026-09-30	2026-09-21	2026-09-30
\.


--
-- Data for Name: entry; Type: TABLE DATA; Schema: timesheet; Owner: -
--

COPY timesheet.entry (id, member, day, minutes, billable, note) FROM stdin;
1	yusuf@lanterne.example	2026-09-01	120	t	Shop: payments and launch
2	yusuf@lanterne.example	2026-09-02	120	t	Shop: payments and launch
3	yusuf@lanterne.example	2026-09-03	120	t	Shop: payments and launch
4	yusuf@lanterne.example	2026-09-04	120	t	Shop: payments and launch
5	yusuf@lanterne.example	2026-09-07	120	t	Shop: payments and launch
6	yusuf@lanterne.example	2026-09-08	120	t	Shop: payments and launch
7	yusuf@lanterne.example	2026-09-09	120	t	Shop: payments and launch
8	yusuf@lanterne.example	2026-09-10	120	t	Shop: payments and launch
9	yusuf@lanterne.example	2026-09-11	120	t	Shop: payments and launch
10	yusuf@lanterne.example	2026-09-14	120	t	Shop: payments and launch
11	yusuf@lanterne.example	2026-09-15	120	t	Shop: payments and launch
12	yusuf@lanterne.example	2026-09-16	120	t	Shop: payments and launch
13	yusuf@lanterne.example	2026-09-17	120	t	Shop: payments and launch
14	yusuf@lanterne.example	2026-09-18	120	t	Shop: payments and launch
15	yusuf@lanterne.example	2026-09-21	120	t	Shop: payments and launch
16	yusuf@lanterne.example	2026-09-22	120	t	Shop: payments and launch
17	yusuf@lanterne.example	2026-09-23	120	t	Shop: payments and launch
18	yusuf@lanterne.example	2026-09-24	120	t	Shop: payments and launch
19	yusuf@lanterne.example	2026-09-25	120	t	Shop: payments and launch
20	yusuf@lanterne.example	2026-09-28	120	t	Shop: payments and launch
21	yusuf@lanterne.example	2026-09-29	120	t	Shop: payments and launch
22	yusuf@lanterne.example	2026-09-30	120	t	Shop: payments and launch
23	yusuf@lanterne.example	2026-10-01	120	t	Shop: payments and launch
24	yusuf@lanterne.example	2026-10-02	120	t	Shop: payments and launch
25	yusuf@lanterne.example	2026-10-05	120	t	Shop: payments and launch
26	yusuf@lanterne.example	2026-10-06	120	t	Shop: payments and launch
27	yusuf@lanterne.example	2026-10-07	120	t	Shop: payments and launch
28	yusuf@lanterne.example	2026-10-08	120	t	Shop: payments and launch
29	yusuf@lanterne.example	2026-10-09	120	t	Shop: payments and launch
30	yusuf@lanterne.example	2026-10-12	60	t	Shop: care and handover
31	yusuf@lanterne.example	2026-10-13	60	t	Shop: care and handover
32	yusuf@lanterne.example	2026-10-14	60	t	Shop: care and handover
33	yusuf@lanterne.example	2026-10-15	60	t	Shop: care and handover
34	yusuf@lanterne.example	2026-10-16	60	t	Shop: care and handover
35	yusuf@lanterne.example	2026-10-19	60	t	Shop: care and handover
36	yusuf@lanterne.example	2026-10-20	60	t	Shop: care and handover
37	yusuf@lanterne.example	2026-10-21	60	t	Shop: care and handover
38	yusuf@lanterne.example	2026-10-22	60	t	Shop: care and handover
39	yusuf@lanterne.example	2026-10-23	60	t	Shop: care and handover
40	yusuf@lanterne.example	2026-10-12	60	t	Microsite: architecture
41	yusuf@lanterne.example	2026-10-13	60	t	Microsite: architecture
42	yusuf@lanterne.example	2026-10-14	60	t	Microsite: architecture
43	yusuf@lanterne.example	2026-10-15	60	t	Microsite: architecture
44	yusuf@lanterne.example	2026-10-16	60	t	Microsite: architecture
45	yusuf@lanterne.example	2026-10-19	60	t	Microsite: architecture
46	yusuf@lanterne.example	2026-10-20	60	t	Microsite: architecture
47	yusuf@lanterne.example	2026-10-21	60	t	Microsite: architecture
48	yusuf@lanterne.example	2026-10-22	60	t	Microsite: architecture
49	yusuf@lanterne.example	2026-10-23	60	t	Microsite: architecture
50	yusuf@lanterne.example	2026-09-01	300	f	Web circle: reviews, hosting and Inès's onboarding
51	yusuf@lanterne.example	2026-09-02	300	f	Web circle: reviews, hosting and Inès's onboarding
52	yusuf@lanterne.example	2026-09-03	300	f	Web circle: reviews, hosting and Inès's onboarding
53	yusuf@lanterne.example	2026-09-04	300	f	Web circle: reviews, hosting and Inès's onboarding
54	yusuf@lanterne.example	2026-09-07	300	f	Web circle: reviews, hosting and Inès's onboarding
55	yusuf@lanterne.example	2026-09-08	300	f	Web circle: reviews, hosting and Inès's onboarding
56	yusuf@lanterne.example	2026-09-09	300	f	Web circle: reviews, hosting and Inès's onboarding
57	yusuf@lanterne.example	2026-09-10	300	f	Web circle: reviews, hosting and Inès's onboarding
58	yusuf@lanterne.example	2026-09-11	300	f	Web circle: reviews, hosting and Inès's onboarding
59	yusuf@lanterne.example	2026-09-14	300	f	Web circle: reviews, hosting and Inès's onboarding
60	yusuf@lanterne.example	2026-09-15	300	f	Web circle: reviews, hosting and Inès's onboarding
61	yusuf@lanterne.example	2026-09-16	300	f	Web circle: reviews, hosting and Inès's onboarding
62	yusuf@lanterne.example	2026-09-17	300	f	Web circle: reviews, hosting and Inès's onboarding
63	yusuf@lanterne.example	2026-09-18	300	f	Web circle: reviews, hosting and Inès's onboarding
64	yusuf@lanterne.example	2026-09-21	300	f	Web circle: reviews, hosting and Inès's onboarding
65	yusuf@lanterne.example	2026-09-22	300	f	Web circle: reviews, hosting and Inès's onboarding
66	yusuf@lanterne.example	2026-09-23	300	f	Web circle: reviews, hosting and Inès's onboarding
67	yusuf@lanterne.example	2026-09-24	300	f	Web circle: reviews, hosting and Inès's onboarding
68	yusuf@lanterne.example	2026-09-25	300	f	Web circle: reviews, hosting and Inès's onboarding
69	yusuf@lanterne.example	2026-09-28	300	f	Web circle: reviews, hosting and Inès's onboarding
70	yusuf@lanterne.example	2026-09-29	300	f	Web circle: reviews, hosting and Inès's onboarding
71	yusuf@lanterne.example	2026-09-30	300	f	Web circle: reviews, hosting and Inès's onboarding
72	yusuf@lanterne.example	2026-10-01	300	f	Web circle: reviews, hosting and Inès's onboarding
73	yusuf@lanterne.example	2026-10-02	300	f	Web circle: reviews, hosting and Inès's onboarding
74	yusuf@lanterne.example	2026-10-05	300	f	Web circle: reviews, hosting and Inès's onboarding
75	yusuf@lanterne.example	2026-10-06	300	f	Web circle: reviews, hosting and Inès's onboarding
76	yusuf@lanterne.example	2026-10-07	300	f	Web circle: reviews, hosting and Inès's onboarding
77	yusuf@lanterne.example	2026-10-08	300	f	Web circle: reviews, hosting and Inès's onboarding
78	yusuf@lanterne.example	2026-10-09	300	f	Web circle: reviews, hosting and Inès's onboarding
79	yusuf@lanterne.example	2026-10-12	300	f	Web circle: reviews, hosting and Inès's onboarding
80	yusuf@lanterne.example	2026-10-13	300	f	Web circle: reviews, hosting and Inès's onboarding
81	yusuf@lanterne.example	2026-10-14	300	f	Web circle: reviews, hosting and Inès's onboarding
82	yusuf@lanterne.example	2026-10-15	300	f	Web circle: reviews, hosting and Inès's onboarding
83	yusuf@lanterne.example	2026-10-16	300	f	Web circle: reviews, hosting and Inès's onboarding
84	yusuf@lanterne.example	2026-10-19	300	f	Web circle: reviews, hosting and Inès's onboarding
85	yusuf@lanterne.example	2026-10-20	300	f	Web circle: reviews, hosting and Inès's onboarding
86	yusuf@lanterne.example	2026-10-21	300	f	Web circle: reviews, hosting and Inès's onboarding
87	yusuf@lanterne.example	2026-10-22	300	f	Web circle: reviews, hosting and Inès's onboarding
88	yusuf@lanterne.example	2026-10-23	300	f	Web circle: reviews, hosting and Inès's onboarding
89	thomas@lanterne.example	2026-09-01	150	t	Shop: checkout and catalogue
90	thomas@lanterne.example	2026-09-02	150	t	Shop: checkout and catalogue
91	thomas@lanterne.example	2026-09-03	150	t	Shop: checkout and catalogue
92	thomas@lanterne.example	2026-09-04	150	t	Shop: checkout and catalogue
93	thomas@lanterne.example	2026-09-07	150	t	Shop: checkout and catalogue
94	thomas@lanterne.example	2026-09-08	150	t	Shop: checkout and catalogue
95	thomas@lanterne.example	2026-09-09	150	t	Shop: checkout and catalogue
96	thomas@lanterne.example	2026-09-10	150	t	Shop: checkout and catalogue
97	thomas@lanterne.example	2026-09-11	150	t	Shop: checkout and catalogue
98	thomas@lanterne.example	2026-09-14	150	t	Shop: checkout and catalogue
99	thomas@lanterne.example	2026-09-15	150	t	Shop: checkout and catalogue
100	thomas@lanterne.example	2026-09-16	150	t	Shop: checkout and catalogue
101	thomas@lanterne.example	2026-09-17	150	t	Shop: checkout and catalogue
102	thomas@lanterne.example	2026-09-18	150	t	Shop: checkout and catalogue
103	thomas@lanterne.example	2026-09-21	150	t	Shop: checkout and catalogue
104	thomas@lanterne.example	2026-09-22	150	t	Shop: checkout and catalogue
105	thomas@lanterne.example	2026-09-23	150	t	Shop: checkout and catalogue
106	thomas@lanterne.example	2026-09-24	150	t	Shop: checkout and catalogue
107	thomas@lanterne.example	2026-09-25	150	t	Shop: checkout and catalogue
108	thomas@lanterne.example	2026-09-28	150	t	Shop: checkout and catalogue
109	thomas@lanterne.example	2026-09-29	150	t	Shop: checkout and catalogue
110	thomas@lanterne.example	2026-09-30	150	t	Shop: checkout and catalogue
111	thomas@lanterne.example	2026-10-01	150	t	Shop: checkout and catalogue
112	thomas@lanterne.example	2026-10-02	150	t	Shop: checkout and catalogue
113	thomas@lanterne.example	2026-10-05	150	t	Shop: checkout and catalogue
114	thomas@lanterne.example	2026-10-06	150	t	Shop: checkout and catalogue
115	thomas@lanterne.example	2026-10-07	150	t	Shop: checkout and catalogue
116	thomas@lanterne.example	2026-10-08	150	t	Shop: checkout and catalogue
117	thomas@lanterne.example	2026-10-09	150	t	Shop: checkout and catalogue
118	thomas@lanterne.example	2026-10-12	90	t	Shop: VAT fixes
119	thomas@lanterne.example	2026-10-13	90	t	Shop: VAT fixes
120	thomas@lanterne.example	2026-10-14	90	t	Shop: VAT fixes
121	thomas@lanterne.example	2026-10-15	90	t	Shop: VAT fixes
122	thomas@lanterne.example	2026-10-16	90	t	Shop: VAT fixes
123	thomas@lanterne.example	2026-10-19	90	t	Shop: VAT fixes
124	thomas@lanterne.example	2026-10-20	90	t	Shop: VAT fixes
125	thomas@lanterne.example	2026-10-21	90	t	Shop: VAT fixes
126	thomas@lanterne.example	2026-10-22	90	t	Shop: VAT fixes
127	thomas@lanterne.example	2026-10-23	90	t	Shop: VAT fixes
128	thomas@lanterne.example	2026-09-01	270	f	Maintenance and hosting
129	thomas@lanterne.example	2026-09-02	270	f	Maintenance and hosting
130	thomas@lanterne.example	2026-09-03	270	f	Maintenance and hosting
131	thomas@lanterne.example	2026-09-04	270	f	Maintenance and hosting
132	thomas@lanterne.example	2026-09-07	270	f	Maintenance and hosting
133	thomas@lanterne.example	2026-09-08	270	f	Maintenance and hosting
134	thomas@lanterne.example	2026-09-09	270	f	Maintenance and hosting
135	thomas@lanterne.example	2026-09-10	270	f	Maintenance and hosting
136	thomas@lanterne.example	2026-09-11	270	f	Maintenance and hosting
137	thomas@lanterne.example	2026-09-14	270	f	Maintenance and hosting
138	thomas@lanterne.example	2026-09-15	270	f	Maintenance and hosting
139	thomas@lanterne.example	2026-09-16	270	f	Maintenance and hosting
140	thomas@lanterne.example	2026-09-17	270	f	Maintenance and hosting
141	thomas@lanterne.example	2026-09-18	270	f	Maintenance and hosting
142	thomas@lanterne.example	2026-09-21	270	f	Maintenance and hosting
143	thomas@lanterne.example	2026-09-22	270	f	Maintenance and hosting
144	thomas@lanterne.example	2026-09-23	270	f	Maintenance and hosting
145	thomas@lanterne.example	2026-09-24	270	f	Maintenance and hosting
146	thomas@lanterne.example	2026-09-25	270	f	Maintenance and hosting
147	thomas@lanterne.example	2026-09-28	270	f	Maintenance and hosting
148	thomas@lanterne.example	2026-09-29	270	f	Maintenance and hosting
149	thomas@lanterne.example	2026-09-30	270	f	Maintenance and hosting
150	thomas@lanterne.example	2026-10-01	270	f	Maintenance and hosting
151	thomas@lanterne.example	2026-10-02	270	f	Maintenance and hosting
152	thomas@lanterne.example	2026-10-05	270	f	Maintenance and hosting
153	thomas@lanterne.example	2026-10-06	270	f	Maintenance and hosting
154	thomas@lanterne.example	2026-10-07	270	f	Maintenance and hosting
155	thomas@lanterne.example	2026-10-08	270	f	Maintenance and hosting
156	thomas@lanterne.example	2026-10-09	270	f	Maintenance and hosting
157	thomas@lanterne.example	2026-10-12	270	f	Maintenance and hosting
158	thomas@lanterne.example	2026-10-13	270	f	Maintenance and hosting
159	thomas@lanterne.example	2026-10-14	270	f	Maintenance and hosting
160	thomas@lanterne.example	2026-10-15	270	f	Maintenance and hosting
161	thomas@lanterne.example	2026-10-16	270	f	Maintenance and hosting
162	thomas@lanterne.example	2026-10-19	270	f	Maintenance and hosting
163	thomas@lanterne.example	2026-10-20	270	f	Maintenance and hosting
164	thomas@lanterne.example	2026-10-21	270	f	Maintenance and hosting
165	thomas@lanterne.example	2026-10-22	270	f	Maintenance and hosting
166	thomas@lanterne.example	2026-10-23	270	f	Maintenance and hosting
167	thomas@lanterne.example	2026-10-12	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
168	thomas@lanterne.example	2026-10-13	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
169	thomas@lanterne.example	2026-10-14	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
170	thomas@lanterne.example	2026-10-15	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
171	thomas@lanterne.example	2026-10-16	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
172	thomas@lanterne.example	2026-10-19	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
173	thomas@lanterne.example	2026-10-20	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
174	thomas@lanterne.example	2026-10-21	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
175	thomas@lanterne.example	2026-10-22	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
176	thomas@lanterne.example	2026-10-23	60	f	Plugin updates on Atelier Ondine's shop, under its care plan
177	amina@lanterne.example	2026-09-01	60	t	Shop: product import
178	amina@lanterne.example	2026-09-02	60	t	Shop: product import
179	amina@lanterne.example	2026-09-03	60	t	Shop: product import
180	amina@lanterne.example	2026-09-04	60	t	Shop: product import
181	amina@lanterne.example	2026-09-07	60	t	Shop: product import
182	amina@lanterne.example	2026-09-08	60	t	Shop: product import
183	amina@lanterne.example	2026-09-09	60	t	Shop: product import
184	amina@lanterne.example	2026-09-10	60	t	Shop: product import
185	amina@lanterne.example	2026-09-11	60	t	Shop: product import
186	amina@lanterne.example	2026-09-14	60	t	Shop: product import
187	amina@lanterne.example	2026-09-15	60	t	Shop: product import
188	amina@lanterne.example	2026-09-16	60	t	Shop: product import
189	amina@lanterne.example	2026-09-17	60	t	Shop: product import
190	amina@lanterne.example	2026-09-18	60	t	Shop: product import
191	amina@lanterne.example	2026-09-21	60	t	Shop: product import
192	amina@lanterne.example	2026-09-22	60	t	Shop: product import
193	amina@lanterne.example	2026-09-23	60	t	Shop: product import
194	amina@lanterne.example	2026-09-24	60	t	Shop: product import
195	amina@lanterne.example	2026-09-25	60	t	Shop: product import
196	amina@lanterne.example	2026-09-28	60	t	Shop: product import
197	amina@lanterne.example	2026-09-29	60	t	Shop: product import
198	amina@lanterne.example	2026-09-30	60	t	Shop: product import
199	amina@lanterne.example	2026-10-01	60	t	Shop: product import
200	amina@lanterne.example	2026-10-02	60	t	Shop: product import
201	amina@lanterne.example	2026-10-05	60	t	Shop: product import
202	amina@lanterne.example	2026-10-06	60	t	Shop: product import
203	amina@lanterne.example	2026-10-07	60	t	Shop: product import
204	amina@lanterne.example	2026-10-08	60	t	Shop: product import
205	amina@lanterne.example	2026-10-09	60	t	Shop: product import
206	amina@lanterne.example	2026-10-12	90	t	Shop: back-office training
207	amina@lanterne.example	2026-10-13	90	t	Shop: back-office training
208	amina@lanterne.example	2026-10-14	90	t	Shop: back-office training
209	amina@lanterne.example	2026-10-15	90	t	Shop: back-office training
210	amina@lanterne.example	2026-10-16	90	t	Shop: back-office training
211	amina@lanterne.example	2026-10-19	90	t	Shop: back-office training
212	amina@lanterne.example	2026-10-20	90	t	Shop: back-office training
213	amina@lanterne.example	2026-10-21	90	t	Shop: back-office training
214	amina@lanterne.example	2026-10-22	90	t	Shop: back-office training
215	amina@lanterne.example	2026-10-23	90	t	Shop: back-office training
216	amina@lanterne.example	2026-10-12	120	t	Microsite: build set-up
217	amina@lanterne.example	2026-10-13	120	t	Microsite: build set-up
218	amina@lanterne.example	2026-10-14	120	t	Microsite: build set-up
219	amina@lanterne.example	2026-10-15	120	t	Microsite: build set-up
220	amina@lanterne.example	2026-10-16	120	t	Microsite: build set-up
221	amina@lanterne.example	2026-10-19	120	t	Microsite: build set-up
222	amina@lanterne.example	2026-10-20	120	t	Microsite: build set-up
223	amina@lanterne.example	2026-10-21	120	t	Microsite: build set-up
224	amina@lanterne.example	2026-10-22	120	t	Microsite: build set-up
225	amina@lanterne.example	2026-10-23	120	t	Microsite: build set-up
226	amina@lanterne.example	2026-09-01	360	f	Back-end tooling and the studio's servers
227	amina@lanterne.example	2026-09-02	360	f	Back-end tooling and the studio's servers
228	amina@lanterne.example	2026-09-03	360	f	Back-end tooling and the studio's servers
229	amina@lanterne.example	2026-09-04	360	f	Back-end tooling and the studio's servers
230	amina@lanterne.example	2026-09-07	360	f	Back-end tooling and the studio's servers
231	amina@lanterne.example	2026-09-08	360	f	Back-end tooling and the studio's servers
232	amina@lanterne.example	2026-09-09	360	f	Back-end tooling and the studio's servers
233	amina@lanterne.example	2026-09-10	360	f	Back-end tooling and the studio's servers
234	amina@lanterne.example	2026-09-11	360	f	Back-end tooling and the studio's servers
235	amina@lanterne.example	2026-09-14	360	f	Back-end tooling and the studio's servers
236	amina@lanterne.example	2026-09-15	360	f	Back-end tooling and the studio's servers
237	amina@lanterne.example	2026-09-16	360	f	Back-end tooling and the studio's servers
238	amina@lanterne.example	2026-09-17	360	f	Back-end tooling and the studio's servers
239	amina@lanterne.example	2026-09-18	360	f	Back-end tooling and the studio's servers
240	amina@lanterne.example	2026-09-21	360	f	Back-end tooling and the studio's servers
241	amina@lanterne.example	2026-09-22	360	f	Back-end tooling and the studio's servers
242	amina@lanterne.example	2026-09-23	360	f	Back-end tooling and the studio's servers
243	amina@lanterne.example	2026-09-24	360	f	Back-end tooling and the studio's servers
244	amina@lanterne.example	2026-09-25	360	f	Back-end tooling and the studio's servers
245	amina@lanterne.example	2026-09-28	360	f	Back-end tooling and the studio's servers
246	amina@lanterne.example	2026-09-29	360	f	Back-end tooling and the studio's servers
247	amina@lanterne.example	2026-09-30	360	f	Back-end tooling and the studio's servers
248	amina@lanterne.example	2026-10-01	360	f	Back-end tooling and the studio's servers
249	amina@lanterne.example	2026-10-02	360	f	Back-end tooling and the studio's servers
250	amina@lanterne.example	2026-10-05	360	f	Back-end tooling and the studio's servers
251	amina@lanterne.example	2026-10-06	360	f	Back-end tooling and the studio's servers
252	amina@lanterne.example	2026-10-07	360	f	Back-end tooling and the studio's servers
253	amina@lanterne.example	2026-10-08	360	f	Back-end tooling and the studio's servers
254	amina@lanterne.example	2026-10-09	360	f	Back-end tooling and the studio's servers
255	amina@lanterne.example	2026-10-12	210	f	Back-end tooling and the studio's servers
256	amina@lanterne.example	2026-10-13	210	f	Back-end tooling and the studio's servers
257	amina@lanterne.example	2026-10-14	210	f	Back-end tooling and the studio's servers
258	amina@lanterne.example	2026-10-15	210	f	Back-end tooling and the studio's servers
259	amina@lanterne.example	2026-10-16	210	f	Back-end tooling and the studio's servers
260	amina@lanterne.example	2026-10-19	210	f	Back-end tooling and the studio's servers
261	amina@lanterne.example	2026-10-20	210	f	Back-end tooling and the studio's servers
262	amina@lanterne.example	2026-10-21	210	f	Back-end tooling and the studio's servers
263	amina@lanterne.example	2026-10-22	210	f	Back-end tooling and the studio's servers
264	amina@lanterne.example	2026-10-23	210	f	Back-end tooling and the studio's servers
265	lea@lanterne.example	2026-09-01	300	t	Lot 2: templates and RGAA fixes
266	lea@lanterne.example	2026-09-02	300	t	Lot 2: templates and RGAA fixes
267	lea@lanterne.example	2026-09-03	300	t	Lot 2: templates and RGAA fixes
268	lea@lanterne.example	2026-09-04	300	t	Lot 2: templates and RGAA fixes
269	lea@lanterne.example	2026-09-14	90	t	Microsite: research and wireframes
270	lea@lanterne.example	2026-09-15	90	t	Microsite: research and wireframes
271	lea@lanterne.example	2026-09-16	90	t	Microsite: research and wireframes
272	lea@lanterne.example	2026-09-17	90	t	Microsite: research and wireframes
273	lea@lanterne.example	2026-09-18	90	t	Microsite: research and wireframes
274	lea@lanterne.example	2026-09-21	90	t	Microsite: research and wireframes
275	lea@lanterne.example	2026-09-22	90	t	Microsite: research and wireframes
276	lea@lanterne.example	2026-09-23	90	t	Microsite: research and wireframes
277	lea@lanterne.example	2026-09-24	90	t	Microsite: research and wireframes
278	lea@lanterne.example	2026-09-25	90	t	Microsite: research and wireframes
279	lea@lanterne.example	2026-09-28	90	t	Microsite: research and wireframes
280	lea@lanterne.example	2026-09-29	90	t	Microsite: research and wireframes
281	lea@lanterne.example	2026-09-30	90	t	Microsite: research and wireframes
282	lea@lanterne.example	2026-10-01	90	t	Microsite: research and wireframes
283	lea@lanterne.example	2026-10-02	90	t	Microsite: research and wireframes
284	lea@lanterne.example	2026-10-05	90	t	Microsite: research and wireframes
285	lea@lanterne.example	2026-10-06	90	t	Microsite: research and wireframes
286	lea@lanterne.example	2026-10-07	90	t	Microsite: research and wireframes
287	lea@lanterne.example	2026-10-08	90	t	Microsite: research and wireframes
288	lea@lanterne.example	2026-10-09	90	t	Microsite: research and wireframes
289	lea@lanterne.example	2026-10-12	180	t	Microsite: design
290	lea@lanterne.example	2026-10-13	180	t	Microsite: design
291	lea@lanterne.example	2026-10-14	180	t	Microsite: design
292	lea@lanterne.example	2026-10-15	180	t	Microsite: design
293	lea@lanterne.example	2026-10-16	180	t	Microsite: design
294	lea@lanterne.example	2026-10-19	180	t	Microsite: design
295	lea@lanterne.example	2026-10-20	180	t	Microsite: design
296	lea@lanterne.example	2026-10-21	180	t	Microsite: design
297	lea@lanterne.example	2026-10-22	180	t	Microsite: design
298	lea@lanterne.example	2026-10-23	180	t	Microsite: design
299	lea@lanterne.example	2026-09-01	120	f	Design system and Lanterne's own site
300	lea@lanterne.example	2026-09-02	120	f	Design system and Lanterne's own site
301	lea@lanterne.example	2026-09-03	120	f	Design system and Lanterne's own site
302	lea@lanterne.example	2026-09-04	120	f	Design system and Lanterne's own site
303	lea@lanterne.example	2026-09-07	420	f	Design system and Lanterne's own site
304	lea@lanterne.example	2026-09-08	420	f	Design system and Lanterne's own site
305	lea@lanterne.example	2026-09-09	420	f	Design system and Lanterne's own site
306	lea@lanterne.example	2026-09-10	420	f	Design system and Lanterne's own site
307	lea@lanterne.example	2026-09-11	420	f	Design system and Lanterne's own site
308	lea@lanterne.example	2026-09-14	330	f	Design system and Lanterne's own site
309	lea@lanterne.example	2026-09-15	330	f	Design system and Lanterne's own site
310	lea@lanterne.example	2026-09-16	330	f	Design system and Lanterne's own site
311	lea@lanterne.example	2026-09-17	330	f	Design system and Lanterne's own site
312	lea@lanterne.example	2026-09-18	330	f	Design system and Lanterne's own site
313	lea@lanterne.example	2026-09-21	330	f	Design system and Lanterne's own site
314	lea@lanterne.example	2026-09-22	330	f	Design system and Lanterne's own site
315	lea@lanterne.example	2026-09-23	330	f	Design system and Lanterne's own site
316	lea@lanterne.example	2026-09-24	330	f	Design system and Lanterne's own site
317	lea@lanterne.example	2026-09-25	330	f	Design system and Lanterne's own site
318	lea@lanterne.example	2026-09-28	330	f	Design system and Lanterne's own site
319	lea@lanterne.example	2026-09-29	330	f	Design system and Lanterne's own site
320	lea@lanterne.example	2026-09-30	330	f	Design system and Lanterne's own site
321	lea@lanterne.example	2026-10-01	330	f	Design system and Lanterne's own site
322	lea@lanterne.example	2026-10-02	330	f	Design system and Lanterne's own site
323	lea@lanterne.example	2026-10-05	330	f	Design system and Lanterne's own site
324	lea@lanterne.example	2026-10-06	330	f	Design system and Lanterne's own site
325	lea@lanterne.example	2026-10-07	330	f	Design system and Lanterne's own site
326	lea@lanterne.example	2026-10-08	330	f	Design system and Lanterne's own site
327	lea@lanterne.example	2026-10-09	330	f	Design system and Lanterne's own site
328	lea@lanterne.example	2026-10-12	240	f	Design system and Lanterne's own site
329	lea@lanterne.example	2026-10-13	240	f	Design system and Lanterne's own site
330	lea@lanterne.example	2026-10-14	240	f	Design system and Lanterne's own site
331	lea@lanterne.example	2026-10-15	240	f	Design system and Lanterne's own site
332	lea@lanterne.example	2026-10-16	240	f	Design system and Lanterne's own site
333	lea@lanterne.example	2026-10-19	240	f	Design system and Lanterne's own site
334	lea@lanterne.example	2026-10-20	240	f	Design system and Lanterne's own site
335	lea@lanterne.example	2026-10-21	240	f	Design system and Lanterne's own site
336	lea@lanterne.example	2026-10-22	240	f	Design system and Lanterne's own site
337	lea@lanterne.example	2026-10-23	240	f	Design system and Lanterne's own site
338	hugo@lanterne.example	2026-09-01	120	t	Identity: logo and guidelines
339	hugo@lanterne.example	2026-09-02	120	t	Identity: logo and guidelines
340	hugo@lanterne.example	2026-09-03	120	t	Identity: logo and guidelines
341	hugo@lanterne.example	2026-09-04	120	t	Identity: logo and guidelines
342	hugo@lanterne.example	2026-09-07	120	t	Identity: logo and guidelines
343	hugo@lanterne.example	2026-09-08	120	t	Identity: logo and guidelines
344	hugo@lanterne.example	2026-09-09	120	t	Identity: logo and guidelines
345	hugo@lanterne.example	2026-09-10	120	t	Identity: logo and guidelines
346	hugo@lanterne.example	2026-09-11	120	t	Identity: logo and guidelines
347	hugo@lanterne.example	2026-09-01	180	t	Packaging: range and print files
348	hugo@lanterne.example	2026-09-02	180	t	Packaging: range and print files
349	hugo@lanterne.example	2026-09-03	180	t	Packaging: range and print files
350	hugo@lanterne.example	2026-09-04	180	t	Packaging: range and print files
351	hugo@lanterne.example	2026-09-07	180	t	Packaging: range and print files
352	hugo@lanterne.example	2026-09-08	180	t	Packaging: range and print files
353	hugo@lanterne.example	2026-09-09	180	t	Packaging: range and print files
354	hugo@lanterne.example	2026-09-10	180	t	Packaging: range and print files
355	hugo@lanterne.example	2026-09-11	180	t	Packaging: range and print files
356	hugo@lanterne.example	2026-09-14	180	t	Packaging: range and print files
357	hugo@lanterne.example	2026-09-15	180	t	Packaging: range and print files
358	hugo@lanterne.example	2026-09-16	180	t	Packaging: range and print files
359	hugo@lanterne.example	2026-09-17	180	t	Packaging: range and print files
360	hugo@lanterne.example	2026-09-18	180	t	Packaging: range and print files
361	hugo@lanterne.example	2026-09-21	180	t	Packaging: range and print files
362	hugo@lanterne.example	2026-09-22	180	t	Packaging: range and print files
363	hugo@lanterne.example	2026-09-23	180	t	Packaging: range and print files
364	hugo@lanterne.example	2026-09-24	180	t	Packaging: range and print files
365	hugo@lanterne.example	2026-09-25	180	t	Packaging: range and print files
366	hugo@lanterne.example	2026-09-28	60	t	Packaging: proofs and press check
367	hugo@lanterne.example	2026-09-29	60	t	Packaging: proofs and press check
368	hugo@lanterne.example	2026-09-30	60	t	Packaging: proofs and press check
369	hugo@lanterne.example	2026-10-01	60	t	Packaging: proofs and press check
370	hugo@lanterne.example	2026-10-02	60	t	Packaging: proofs and press check
371	hugo@lanterne.example	2026-10-05	60	t	Packaging: proofs and press check
372	hugo@lanterne.example	2026-10-06	60	t	Packaging: proofs and press check
373	hugo@lanterne.example	2026-10-07	60	t	Packaging: proofs and press check
374	hugo@lanterne.example	2026-10-08	60	t	Packaging: proofs and press check
375	hugo@lanterne.example	2026-10-09	60	t	Packaging: proofs and press check
376	hugo@lanterne.example	2026-10-12	60	t	Packaging: proofs and press check
377	hugo@lanterne.example	2026-10-13	60	t	Packaging: proofs and press check
378	hugo@lanterne.example	2026-10-14	60	t	Packaging: proofs and press check
379	hugo@lanterne.example	2026-10-15	60	t	Packaging: proofs and press check
380	hugo@lanterne.example	2026-10-16	60	t	Packaging: proofs and press check
381	hugo@lanterne.example	2026-10-19	60	t	Packaging: proofs and press check
382	hugo@lanterne.example	2026-10-20	60	t	Packaging: proofs and press check
383	hugo@lanterne.example	2026-10-21	60	t	Packaging: proofs and press check
384	hugo@lanterne.example	2026-10-22	60	t	Packaging: proofs and press check
385	hugo@lanterne.example	2026-10-23	60	t	Packaging: proofs and press check
386	hugo@lanterne.example	2026-09-14	30	t	Report: art direction
387	hugo@lanterne.example	2026-09-15	30	t	Report: art direction
388	hugo@lanterne.example	2026-09-16	30	t	Report: art direction
389	hugo@lanterne.example	2026-09-17	30	t	Report: art direction
390	hugo@lanterne.example	2026-09-18	30	t	Report: art direction
391	hugo@lanterne.example	2026-09-21	30	t	Report: art direction
392	hugo@lanterne.example	2026-09-22	30	t	Report: art direction
393	hugo@lanterne.example	2026-09-23	30	t	Report: art direction
394	hugo@lanterne.example	2026-09-24	30	t	Report: art direction
395	hugo@lanterne.example	2026-09-25	30	t	Report: art direction
396	hugo@lanterne.example	2026-09-28	30	t	Report: art direction
397	hugo@lanterne.example	2026-09-29	30	t	Report: art direction
398	hugo@lanterne.example	2026-09-30	30	t	Report: art direction
399	hugo@lanterne.example	2026-10-01	30	t	Report: art direction
400	hugo@lanterne.example	2026-10-02	30	t	Report: art direction
401	hugo@lanterne.example	2026-10-05	30	t	Report: art direction
402	hugo@lanterne.example	2026-10-06	30	t	Report: art direction
403	hugo@lanterne.example	2026-10-07	30	t	Report: art direction
404	hugo@lanterne.example	2026-10-08	30	t	Report: art direction
405	hugo@lanterne.example	2026-10-09	30	t	Report: art direction
406	hugo@lanterne.example	2026-10-12	30	t	Report: art direction
407	hugo@lanterne.example	2026-10-13	30	t	Report: art direction
408	hugo@lanterne.example	2026-10-14	30	t	Report: art direction
409	hugo@lanterne.example	2026-10-15	30	t	Report: art direction
410	hugo@lanterne.example	2026-10-16	30	t	Report: art direction
411	hugo@lanterne.example	2026-09-01	120	f	Brand circle: reviews and pitches
412	hugo@lanterne.example	2026-09-02	120	f	Brand circle: reviews and pitches
413	hugo@lanterne.example	2026-09-03	120	f	Brand circle: reviews and pitches
414	hugo@lanterne.example	2026-09-04	120	f	Brand circle: reviews and pitches
415	hugo@lanterne.example	2026-09-07	120	f	Brand circle: reviews and pitches
416	hugo@lanterne.example	2026-09-08	120	f	Brand circle: reviews and pitches
417	hugo@lanterne.example	2026-09-09	120	f	Brand circle: reviews and pitches
418	hugo@lanterne.example	2026-09-10	120	f	Brand circle: reviews and pitches
419	hugo@lanterne.example	2026-09-11	120	f	Brand circle: reviews and pitches
420	hugo@lanterne.example	2026-09-14	210	f	Brand circle: reviews and pitches
421	hugo@lanterne.example	2026-09-15	210	f	Brand circle: reviews and pitches
422	hugo@lanterne.example	2026-09-16	210	f	Brand circle: reviews and pitches
423	hugo@lanterne.example	2026-09-17	210	f	Brand circle: reviews and pitches
424	hugo@lanterne.example	2026-09-18	210	f	Brand circle: reviews and pitches
425	hugo@lanterne.example	2026-09-21	210	f	Brand circle: reviews and pitches
426	hugo@lanterne.example	2026-09-22	210	f	Brand circle: reviews and pitches
427	hugo@lanterne.example	2026-09-23	210	f	Brand circle: reviews and pitches
428	hugo@lanterne.example	2026-09-24	210	f	Brand circle: reviews and pitches
429	hugo@lanterne.example	2026-09-25	210	f	Brand circle: reviews and pitches
430	hugo@lanterne.example	2026-09-28	330	f	Brand circle: reviews and pitches
431	hugo@lanterne.example	2026-09-29	330	f	Brand circle: reviews and pitches
432	hugo@lanterne.example	2026-09-30	330	f	Brand circle: reviews and pitches
433	hugo@lanterne.example	2026-10-01	330	f	Brand circle: reviews and pitches
434	hugo@lanterne.example	2026-10-02	330	f	Brand circle: reviews and pitches
435	hugo@lanterne.example	2026-10-05	330	f	Brand circle: reviews and pitches
436	hugo@lanterne.example	2026-10-06	330	f	Brand circle: reviews and pitches
437	hugo@lanterne.example	2026-10-07	330	f	Brand circle: reviews and pitches
438	hugo@lanterne.example	2026-10-08	330	f	Brand circle: reviews and pitches
439	hugo@lanterne.example	2026-10-09	330	f	Brand circle: reviews and pitches
440	hugo@lanterne.example	2026-10-12	330	f	Brand circle: reviews and pitches
441	hugo@lanterne.example	2026-10-13	330	f	Brand circle: reviews and pitches
442	hugo@lanterne.example	2026-10-14	330	f	Brand circle: reviews and pitches
443	hugo@lanterne.example	2026-10-15	330	f	Brand circle: reviews and pitches
444	hugo@lanterne.example	2026-10-16	330	f	Brand circle: reviews and pitches
445	hugo@lanterne.example	2026-10-19	360	f	Brand circle: reviews and pitches
446	hugo@lanterne.example	2026-10-20	360	f	Brand circle: reviews and pitches
447	hugo@lanterne.example	2026-10-21	360	f	Brand circle: reviews and pitches
448	hugo@lanterne.example	2026-10-22	360	f	Brand circle: reviews and pitches
449	hugo@lanterne.example	2026-10-23	360	f	Brand circle: reviews and pitches
450	sofia@lanterne.example	2026-09-01	150	t	Identity: guidelines and illustrations
451	sofia@lanterne.example	2026-09-02	150	t	Identity: guidelines and illustrations
452	sofia@lanterne.example	2026-09-03	150	t	Identity: guidelines and illustrations
453	sofia@lanterne.example	2026-09-04	150	t	Identity: guidelines and illustrations
454	sofia@lanterne.example	2026-09-07	150	t	Identity: guidelines and illustrations
455	sofia@lanterne.example	2026-09-08	150	t	Identity: guidelines and illustrations
456	sofia@lanterne.example	2026-09-09	150	t	Identity: guidelines and illustrations
457	sofia@lanterne.example	2026-09-10	150	t	Identity: guidelines and illustrations
458	sofia@lanterne.example	2026-09-11	150	t	Identity: guidelines and illustrations
459	sofia@lanterne.example	2026-09-01	210	t	Packaging: die lines and illustrations
460	sofia@lanterne.example	2026-09-02	210	t	Packaging: die lines and illustrations
461	sofia@lanterne.example	2026-09-03	210	t	Packaging: die lines and illustrations
462	sofia@lanterne.example	2026-09-04	210	t	Packaging: die lines and illustrations
463	sofia@lanterne.example	2026-09-07	210	t	Packaging: die lines and illustrations
464	sofia@lanterne.example	2026-09-08	210	t	Packaging: die lines and illustrations
465	sofia@lanterne.example	2026-09-09	210	t	Packaging: die lines and illustrations
466	sofia@lanterne.example	2026-09-10	210	t	Packaging: die lines and illustrations
467	sofia@lanterne.example	2026-09-11	210	t	Packaging: die lines and illustrations
468	sofia@lanterne.example	2026-09-14	210	t	Packaging: die lines and illustrations
469	sofia@lanterne.example	2026-09-15	210	t	Packaging: die lines and illustrations
470	sofia@lanterne.example	2026-09-16	210	t	Packaging: die lines and illustrations
471	sofia@lanterne.example	2026-09-17	210	t	Packaging: die lines and illustrations
472	sofia@lanterne.example	2026-09-18	210	t	Packaging: die lines and illustrations
473	sofia@lanterne.example	2026-09-21	210	t	Packaging: die lines and illustrations
474	sofia@lanterne.example	2026-09-22	210	t	Packaging: die lines and illustrations
475	sofia@lanterne.example	2026-09-23	210	t	Packaging: die lines and illustrations
476	sofia@lanterne.example	2026-09-24	210	t	Packaging: die lines and illustrations
477	sofia@lanterne.example	2026-09-25	210	t	Packaging: die lines and illustrations
478	sofia@lanterne.example	2026-09-28	180	t	Report: layout and infographics
479	sofia@lanterne.example	2026-09-29	180	t	Report: layout and infographics
480	sofia@lanterne.example	2026-09-30	180	t	Report: layout and infographics
481	sofia@lanterne.example	2026-10-01	180	t	Report: layout and infographics
482	sofia@lanterne.example	2026-10-02	180	t	Report: layout and infographics
483	sofia@lanterne.example	2026-10-05	180	t	Report: layout and infographics
484	sofia@lanterne.example	2026-10-06	180	t	Report: layout and infographics
485	sofia@lanterne.example	2026-10-07	180	t	Report: layout and infographics
486	sofia@lanterne.example	2026-10-08	180	t	Report: layout and infographics
487	sofia@lanterne.example	2026-10-09	180	t	Report: layout and infographics
488	sofia@lanterne.example	2026-10-12	180	t	Report: layout and infographics
489	sofia@lanterne.example	2026-10-13	180	t	Report: layout and infographics
490	sofia@lanterne.example	2026-10-14	180	t	Report: layout and infographics
491	sofia@lanterne.example	2026-10-15	180	t	Report: layout and infographics
492	sofia@lanterne.example	2026-10-16	180	t	Report: layout and infographics
493	sofia@lanterne.example	2026-09-01	60	f	Motion reel and portfolio
494	sofia@lanterne.example	2026-09-02	60	f	Motion reel and portfolio
495	sofia@lanterne.example	2026-09-03	60	f	Motion reel and portfolio
496	sofia@lanterne.example	2026-09-04	60	f	Motion reel and portfolio
497	sofia@lanterne.example	2026-09-07	60	f	Motion reel and portfolio
498	sofia@lanterne.example	2026-09-08	60	f	Motion reel and portfolio
499	sofia@lanterne.example	2026-09-09	60	f	Motion reel and portfolio
500	sofia@lanterne.example	2026-09-10	60	f	Motion reel and portfolio
501	sofia@lanterne.example	2026-09-11	60	f	Motion reel and portfolio
502	sofia@lanterne.example	2026-09-14	210	f	Motion reel and portfolio
503	sofia@lanterne.example	2026-09-15	210	f	Motion reel and portfolio
504	sofia@lanterne.example	2026-09-16	210	f	Motion reel and portfolio
505	sofia@lanterne.example	2026-09-17	210	f	Motion reel and portfolio
506	sofia@lanterne.example	2026-09-18	210	f	Motion reel and portfolio
507	sofia@lanterne.example	2026-09-21	210	f	Motion reel and portfolio
508	sofia@lanterne.example	2026-09-22	210	f	Motion reel and portfolio
509	sofia@lanterne.example	2026-09-23	210	f	Motion reel and portfolio
510	sofia@lanterne.example	2026-09-24	210	f	Motion reel and portfolio
511	sofia@lanterne.example	2026-09-25	210	f	Motion reel and portfolio
512	sofia@lanterne.example	2026-09-28	240	f	Motion reel and portfolio
513	sofia@lanterne.example	2026-09-29	240	f	Motion reel and portfolio
514	sofia@lanterne.example	2026-09-30	240	f	Motion reel and portfolio
515	sofia@lanterne.example	2026-10-01	240	f	Motion reel and portfolio
516	sofia@lanterne.example	2026-10-02	240	f	Motion reel and portfolio
517	sofia@lanterne.example	2026-10-05	240	f	Motion reel and portfolio
518	sofia@lanterne.example	2026-10-06	240	f	Motion reel and portfolio
519	sofia@lanterne.example	2026-10-07	240	f	Motion reel and portfolio
520	sofia@lanterne.example	2026-10-08	240	f	Motion reel and portfolio
521	sofia@lanterne.example	2026-10-09	240	f	Motion reel and portfolio
522	sofia@lanterne.example	2026-10-12	240	f	Motion reel and portfolio
523	sofia@lanterne.example	2026-10-13	240	f	Motion reel and portfolio
524	sofia@lanterne.example	2026-10-14	240	f	Motion reel and portfolio
525	sofia@lanterne.example	2026-10-15	240	f	Motion reel and portfolio
526	sofia@lanterne.example	2026-10-16	240	f	Motion reel and portfolio
527	sofia@lanterne.example	2026-10-19	420	f	Motion reel and portfolio
528	sofia@lanterne.example	2026-10-20	420	f	Motion reel and portfolio
529	sofia@lanterne.example	2026-10-21	420	f	Motion reel and portfolio
530	sofia@lanterne.example	2026-10-22	420	f	Motion reel and portfolio
531	sofia@lanterne.example	2026-10-23	420	f	Motion reel and portfolio
532	camille@lanterne.example	2026-09-01	90	t	Packaging: brand strategy
533	camille@lanterne.example	2026-09-02	90	t	Packaging: brand strategy
534	camille@lanterne.example	2026-09-03	90	t	Packaging: brand strategy
535	camille@lanterne.example	2026-09-04	90	t	Packaging: brand strategy
536	camille@lanterne.example	2026-09-07	90	t	Packaging: brand strategy
537	camille@lanterne.example	2026-09-08	90	t	Packaging: brand strategy
538	camille@lanterne.example	2026-09-09	90	t	Packaging: brand strategy
539	camille@lanterne.example	2026-09-10	90	t	Packaging: brand strategy
540	camille@lanterne.example	2026-09-11	90	t	Packaging: brand strategy
541	camille@lanterne.example	2026-09-14	90	t	Packaging: brand strategy
542	camille@lanterne.example	2026-09-15	90	t	Packaging: brand strategy
543	camille@lanterne.example	2026-09-16	90	t	Packaging: brand strategy
544	camille@lanterne.example	2026-09-17	90	t	Packaging: brand strategy
545	camille@lanterne.example	2026-09-18	90	t	Packaging: brand strategy
546	camille@lanterne.example	2026-09-21	90	t	Packaging: brand strategy
547	camille@lanterne.example	2026-09-22	90	t	Packaging: brand strategy
548	camille@lanterne.example	2026-09-23	90	t	Packaging: brand strategy
549	camille@lanterne.example	2026-09-24	90	t	Packaging: brand strategy
550	camille@lanterne.example	2026-09-25	90	t	Packaging: brand strategy
551	camille@lanterne.example	2026-09-28	90	t	Report: editorial
552	camille@lanterne.example	2026-09-29	90	t	Report: editorial
553	camille@lanterne.example	2026-09-30	90	t	Report: editorial
554	camille@lanterne.example	2026-10-01	90	t	Report: editorial
555	camille@lanterne.example	2026-10-02	90	t	Report: editorial
556	camille@lanterne.example	2026-10-05	90	t	Report: editorial
557	camille@lanterne.example	2026-10-06	90	t	Report: editorial
558	camille@lanterne.example	2026-10-07	90	t	Report: editorial
559	camille@lanterne.example	2026-10-08	90	t	Report: editorial
560	camille@lanterne.example	2026-10-09	90	t	Report: editorial
561	camille@lanterne.example	2026-10-12	90	t	Report: editorial
562	camille@lanterne.example	2026-10-13	90	t	Report: editorial
563	camille@lanterne.example	2026-10-14	90	t	Report: editorial
564	camille@lanterne.example	2026-10-15	90	t	Report: editorial
565	camille@lanterne.example	2026-10-16	90	t	Report: editorial
566	camille@lanterne.example	2026-09-01	330	f	Management: contracts, the assembly and the rate card
567	camille@lanterne.example	2026-09-02	330	f	Management: contracts, the assembly and the rate card
568	camille@lanterne.example	2026-09-03	330	f	Management: contracts, the assembly and the rate card
569	camille@lanterne.example	2026-09-04	330	f	Management: contracts, the assembly and the rate card
570	camille@lanterne.example	2026-09-07	330	f	Management: contracts, the assembly and the rate card
571	camille@lanterne.example	2026-09-08	330	f	Management: contracts, the assembly and the rate card
572	camille@lanterne.example	2026-09-09	330	f	Management: contracts, the assembly and the rate card
573	camille@lanterne.example	2026-09-10	330	f	Management: contracts, the assembly and the rate card
574	camille@lanterne.example	2026-09-11	330	f	Management: contracts, the assembly and the rate card
575	camille@lanterne.example	2026-09-14	330	f	Management: contracts, the assembly and the rate card
576	camille@lanterne.example	2026-09-15	330	f	Management: contracts, the assembly and the rate card
577	camille@lanterne.example	2026-09-16	330	f	Management: contracts, the assembly and the rate card
578	camille@lanterne.example	2026-09-17	330	f	Management: contracts, the assembly and the rate card
579	camille@lanterne.example	2026-09-18	330	f	Management: contracts, the assembly and the rate card
580	camille@lanterne.example	2026-09-21	330	f	Management: contracts, the assembly and the rate card
581	camille@lanterne.example	2026-09-22	330	f	Management: contracts, the assembly and the rate card
582	camille@lanterne.example	2026-09-23	330	f	Management: contracts, the assembly and the rate card
583	camille@lanterne.example	2026-09-24	330	f	Management: contracts, the assembly and the rate card
584	camille@lanterne.example	2026-09-25	330	f	Management: contracts, the assembly and the rate card
585	camille@lanterne.example	2026-09-28	330	f	Management: contracts, the assembly and the rate card
586	camille@lanterne.example	2026-09-29	330	f	Management: contracts, the assembly and the rate card
587	camille@lanterne.example	2026-09-30	330	f	Management: contracts, the assembly and the rate card
588	camille@lanterne.example	2026-10-01	330	f	Management: contracts, the assembly and the rate card
589	camille@lanterne.example	2026-10-02	330	f	Management: contracts, the assembly and the rate card
590	camille@lanterne.example	2026-10-05	330	f	Management: contracts, the assembly and the rate card
591	camille@lanterne.example	2026-10-06	330	f	Management: contracts, the assembly and the rate card
592	camille@lanterne.example	2026-10-07	330	f	Management: contracts, the assembly and the rate card
593	camille@lanterne.example	2026-10-08	330	f	Management: contracts, the assembly and the rate card
594	camille@lanterne.example	2026-10-09	330	f	Management: contracts, the assembly and the rate card
595	camille@lanterne.example	2026-10-12	330	f	Management: contracts, the assembly and the rate card
596	camille@lanterne.example	2026-10-13	330	f	Management: contracts, the assembly and the rate card
597	camille@lanterne.example	2026-10-14	330	f	Management: contracts, the assembly and the rate card
598	camille@lanterne.example	2026-10-15	330	f	Management: contracts, the assembly and the rate card
599	camille@lanterne.example	2026-10-16	330	f	Management: contracts, the assembly and the rate card
600	camille@lanterne.example	2026-10-19	420	f	Management: contracts, the assembly and the rate card
601	camille@lanterne.example	2026-10-20	420	f	Management: contracts, the assembly and the rate card
602	camille@lanterne.example	2026-10-21	420	f	Management: contracts, the assembly and the rate card
603	camille@lanterne.example	2026-10-22	420	f	Management: contracts, the assembly and the rate card
604	camille@lanterne.example	2026-10-23	420	f	Management: contracts, the assembly and the rate card
605	malik@lanterne.example	2026-09-01	90	t	Retainer: strategy and reporting
606	malik@lanterne.example	2026-09-02	90	t	Retainer: strategy and reporting
607	malik@lanterne.example	2026-09-03	90	t	Retainer: strategy and reporting
608	malik@lanterne.example	2026-09-04	90	t	Retainer: strategy and reporting
609	malik@lanterne.example	2026-09-07	90	t	Retainer: strategy and reporting
610	malik@lanterne.example	2026-09-08	90	t	Retainer: strategy and reporting
611	malik@lanterne.example	2026-09-09	90	t	Retainer: strategy and reporting
612	malik@lanterne.example	2026-09-10	90	t	Retainer: strategy and reporting
613	malik@lanterne.example	2026-09-11	90	t	Retainer: strategy and reporting
614	malik@lanterne.example	2026-09-14	90	t	Retainer: strategy and reporting
615	malik@lanterne.example	2026-09-15	90	t	Retainer: strategy and reporting
616	malik@lanterne.example	2026-09-16	90	t	Retainer: strategy and reporting
617	malik@lanterne.example	2026-09-17	90	t	Retainer: strategy and reporting
618	malik@lanterne.example	2026-09-18	90	t	Retainer: strategy and reporting
619	malik@lanterne.example	2026-09-21	90	t	Retainer: strategy and reporting
620	malik@lanterne.example	2026-09-22	90	t	Retainer: strategy and reporting
621	malik@lanterne.example	2026-09-23	90	t	Retainer: strategy and reporting
622	malik@lanterne.example	2026-09-24	90	t	Retainer: strategy and reporting
623	malik@lanterne.example	2026-09-25	90	t	Retainer: strategy and reporting
624	malik@lanterne.example	2026-09-28	90	t	Retainer: strategy and reporting
625	malik@lanterne.example	2026-09-29	90	t	Retainer: strategy and reporting
626	malik@lanterne.example	2026-09-30	90	t	Retainer: strategy and reporting
627	malik@lanterne.example	2026-10-01	90	t	Retainer: strategy and reporting
628	malik@lanterne.example	2026-10-02	90	t	Retainer: strategy and reporting
629	malik@lanterne.example	2026-10-05	90	t	Retainer: strategy and reporting
630	malik@lanterne.example	2026-10-06	90	t	Retainer: strategy and reporting
631	malik@lanterne.example	2026-10-07	90	t	Retainer: strategy and reporting
632	malik@lanterne.example	2026-10-08	90	t	Retainer: strategy and reporting
633	malik@lanterne.example	2026-10-09	90	t	Retainer: strategy and reporting
634	malik@lanterne.example	2026-10-12	90	t	Retainer: strategy and reporting
635	malik@lanterne.example	2026-10-13	90	t	Retainer: strategy and reporting
636	malik@lanterne.example	2026-10-14	90	t	Retainer: strategy and reporting
637	malik@lanterne.example	2026-10-15	90	t	Retainer: strategy and reporting
638	malik@lanterne.example	2026-10-16	90	t	Retainer: strategy and reporting
639	malik@lanterne.example	2026-10-19	90	t	Retainer: strategy and reporting
640	malik@lanterne.example	2026-10-20	90	t	Retainer: strategy and reporting
641	malik@lanterne.example	2026-10-21	90	t	Retainer: strategy and reporting
642	malik@lanterne.example	2026-10-22	90	t	Retainer: strategy and reporting
643	malik@lanterne.example	2026-10-23	90	t	Retainer: strategy and reporting
644	malik@lanterne.example	2026-09-01	330	f	Marketing circle, pitches and the 2027 rate card
645	malik@lanterne.example	2026-09-02	330	f	Marketing circle, pitches and the 2027 rate card
646	malik@lanterne.example	2026-09-03	330	f	Marketing circle, pitches and the 2027 rate card
647	malik@lanterne.example	2026-09-04	330	f	Marketing circle, pitches and the 2027 rate card
648	malik@lanterne.example	2026-09-07	330	f	Marketing circle, pitches and the 2027 rate card
649	malik@lanterne.example	2026-09-08	330	f	Marketing circle, pitches and the 2027 rate card
650	malik@lanterne.example	2026-09-09	330	f	Marketing circle, pitches and the 2027 rate card
651	malik@lanterne.example	2026-09-10	330	f	Marketing circle, pitches and the 2027 rate card
652	malik@lanterne.example	2026-09-11	330	f	Marketing circle, pitches and the 2027 rate card
653	malik@lanterne.example	2026-09-14	330	f	Marketing circle, pitches and the 2027 rate card
654	malik@lanterne.example	2026-09-15	330	f	Marketing circle, pitches and the 2027 rate card
655	malik@lanterne.example	2026-09-16	330	f	Marketing circle, pitches and the 2027 rate card
656	malik@lanterne.example	2026-09-17	330	f	Marketing circle, pitches and the 2027 rate card
657	malik@lanterne.example	2026-09-18	330	f	Marketing circle, pitches and the 2027 rate card
658	malik@lanterne.example	2026-09-21	330	f	Marketing circle, pitches and the 2027 rate card
659	malik@lanterne.example	2026-09-22	330	f	Marketing circle, pitches and the 2027 rate card
660	malik@lanterne.example	2026-09-23	330	f	Marketing circle, pitches and the 2027 rate card
661	malik@lanterne.example	2026-09-24	330	f	Marketing circle, pitches and the 2027 rate card
662	malik@lanterne.example	2026-09-25	330	f	Marketing circle, pitches and the 2027 rate card
663	malik@lanterne.example	2026-09-28	330	f	Marketing circle, pitches and the 2027 rate card
664	malik@lanterne.example	2026-09-29	330	f	Marketing circle, pitches and the 2027 rate card
665	malik@lanterne.example	2026-09-30	330	f	Marketing circle, pitches and the 2027 rate card
666	malik@lanterne.example	2026-10-01	330	f	Marketing circle, pitches and the 2027 rate card
667	malik@lanterne.example	2026-10-02	330	f	Marketing circle, pitches and the 2027 rate card
668	malik@lanterne.example	2026-10-05	330	f	Marketing circle, pitches and the 2027 rate card
669	malik@lanterne.example	2026-10-06	330	f	Marketing circle, pitches and the 2027 rate card
670	malik@lanterne.example	2026-10-07	330	f	Marketing circle, pitches and the 2027 rate card
671	malik@lanterne.example	2026-10-08	330	f	Marketing circle, pitches and the 2027 rate card
672	malik@lanterne.example	2026-10-09	330	f	Marketing circle, pitches and the 2027 rate card
673	malik@lanterne.example	2026-10-12	330	f	Marketing circle, pitches and the 2027 rate card
674	malik@lanterne.example	2026-10-13	330	f	Marketing circle, pitches and the 2027 rate card
675	malik@lanterne.example	2026-10-14	330	f	Marketing circle, pitches and the 2027 rate card
676	malik@lanterne.example	2026-10-15	330	f	Marketing circle, pitches and the 2027 rate card
677	malik@lanterne.example	2026-10-16	330	f	Marketing circle, pitches and the 2027 rate card
678	malik@lanterne.example	2026-10-19	330	f	Marketing circle, pitches and the 2027 rate card
679	malik@lanterne.example	2026-10-20	330	f	Marketing circle, pitches and the 2027 rate card
680	malik@lanterne.example	2026-10-21	330	f	Marketing circle, pitches and the 2027 rate card
681	malik@lanterne.example	2026-10-22	330	f	Marketing circle, pitches and the 2027 rate card
682	malik@lanterne.example	2026-10-23	330	f	Marketing circle, pitches and the 2027 rate card
683	chloe@lanterne.example	2026-09-01	90	t	Retainer: content and social media
684	chloe@lanterne.example	2026-09-02	90	t	Retainer: content and social media
685	chloe@lanterne.example	2026-09-03	90	t	Retainer: content and social media
686	chloe@lanterne.example	2026-09-04	90	t	Retainer: content and social media
687	chloe@lanterne.example	2026-09-07	90	t	Retainer: content and social media
688	chloe@lanterne.example	2026-09-08	90	t	Retainer: content and social media
689	chloe@lanterne.example	2026-09-09	90	t	Retainer: content and social media
690	chloe@lanterne.example	2026-09-10	90	t	Retainer: content and social media
691	chloe@lanterne.example	2026-09-11	90	t	Retainer: content and social media
692	chloe@lanterne.example	2026-09-14	90	t	Retainer: content and social media
693	chloe@lanterne.example	2026-09-15	90	t	Retainer: content and social media
694	chloe@lanterne.example	2026-09-16	90	t	Retainer: content and social media
695	chloe@lanterne.example	2026-09-17	90	t	Retainer: content and social media
696	chloe@lanterne.example	2026-09-18	90	t	Retainer: content and social media
697	chloe@lanterne.example	2026-09-21	90	t	Retainer: content and social media
698	chloe@lanterne.example	2026-09-22	90	t	Retainer: content and social media
699	chloe@lanterne.example	2026-09-23	90	t	Retainer: content and social media
700	chloe@lanterne.example	2026-09-24	90	t	Retainer: content and social media
701	chloe@lanterne.example	2026-09-25	90	t	Retainer: content and social media
702	chloe@lanterne.example	2026-09-28	90	t	Retainer: content and social media
703	chloe@lanterne.example	2026-09-29	90	t	Retainer: content and social media
704	chloe@lanterne.example	2026-09-30	90	t	Retainer: content and social media
705	chloe@lanterne.example	2026-10-01	90	t	Retainer: content and social media
706	chloe@lanterne.example	2026-10-02	90	t	Retainer: content and social media
707	chloe@lanterne.example	2026-10-05	90	t	Retainer: content and social media
708	chloe@lanterne.example	2026-10-06	90	t	Retainer: content and social media
709	chloe@lanterne.example	2026-10-07	90	t	Retainer: content and social media
710	chloe@lanterne.example	2026-10-08	90	t	Retainer: content and social media
711	chloe@lanterne.example	2026-10-09	90	t	Retainer: content and social media
712	chloe@lanterne.example	2026-10-12	90	t	Retainer: content and social media
713	chloe@lanterne.example	2026-10-13	90	t	Retainer: content and social media
714	chloe@lanterne.example	2026-10-14	90	t	Retainer: content and social media
715	chloe@lanterne.example	2026-10-15	90	t	Retainer: content and social media
716	chloe@lanterne.example	2026-10-16	90	t	Retainer: content and social media
717	chloe@lanterne.example	2026-10-19	90	t	Retainer: content and social media
718	chloe@lanterne.example	2026-10-20	90	t	Retainer: content and social media
719	chloe@lanterne.example	2026-10-21	90	t	Retainer: content and social media
720	chloe@lanterne.example	2026-10-22	90	t	Retainer: content and social media
721	chloe@lanterne.example	2026-10-23	90	t	Retainer: content and social media
722	chloe@lanterne.example	2026-09-01	330	f	Lanterne's own content and social media
723	chloe@lanterne.example	2026-09-02	330	f	Lanterne's own content and social media
724	chloe@lanterne.example	2026-09-03	330	f	Lanterne's own content and social media
725	chloe@lanterne.example	2026-09-04	330	f	Lanterne's own content and social media
726	chloe@lanterne.example	2026-09-07	330	f	Lanterne's own content and social media
727	chloe@lanterne.example	2026-09-08	330	f	Lanterne's own content and social media
728	chloe@lanterne.example	2026-09-09	330	f	Lanterne's own content and social media
729	chloe@lanterne.example	2026-09-10	330	f	Lanterne's own content and social media
730	chloe@lanterne.example	2026-09-11	330	f	Lanterne's own content and social media
731	chloe@lanterne.example	2026-09-14	330	f	Lanterne's own content and social media
732	chloe@lanterne.example	2026-09-15	330	f	Lanterne's own content and social media
733	chloe@lanterne.example	2026-09-16	330	f	Lanterne's own content and social media
734	chloe@lanterne.example	2026-09-17	330	f	Lanterne's own content and social media
735	chloe@lanterne.example	2026-09-18	330	f	Lanterne's own content and social media
736	chloe@lanterne.example	2026-09-21	330	f	Lanterne's own content and social media
737	chloe@lanterne.example	2026-09-22	330	f	Lanterne's own content and social media
738	chloe@lanterne.example	2026-09-23	330	f	Lanterne's own content and social media
739	chloe@lanterne.example	2026-09-24	330	f	Lanterne's own content and social media
740	chloe@lanterne.example	2026-09-25	330	f	Lanterne's own content and social media
741	chloe@lanterne.example	2026-09-28	330	f	Lanterne's own content and social media
742	chloe@lanterne.example	2026-09-29	330	f	Lanterne's own content and social media
743	chloe@lanterne.example	2026-09-30	330	f	Lanterne's own content and social media
744	chloe@lanterne.example	2026-10-01	330	f	Lanterne's own content and social media
745	chloe@lanterne.example	2026-10-02	330	f	Lanterne's own content and social media
746	chloe@lanterne.example	2026-10-05	330	f	Lanterne's own content and social media
747	chloe@lanterne.example	2026-10-06	330	f	Lanterne's own content and social media
748	chloe@lanterne.example	2026-10-07	330	f	Lanterne's own content and social media
749	chloe@lanterne.example	2026-10-08	330	f	Lanterne's own content and social media
750	chloe@lanterne.example	2026-10-09	330	f	Lanterne's own content and social media
751	chloe@lanterne.example	2026-10-12	330	f	Lanterne's own content and social media
752	chloe@lanterne.example	2026-10-13	330	f	Lanterne's own content and social media
753	chloe@lanterne.example	2026-10-14	330	f	Lanterne's own content and social media
754	chloe@lanterne.example	2026-10-15	330	f	Lanterne's own content and social media
755	chloe@lanterne.example	2026-10-16	330	f	Lanterne's own content and social media
756	chloe@lanterne.example	2026-10-19	330	f	Lanterne's own content and social media
757	chloe@lanterne.example	2026-10-20	330	f	Lanterne's own content and social media
758	chloe@lanterne.example	2026-10-21	330	f	Lanterne's own content and social media
759	chloe@lanterne.example	2026-10-22	330	f	Lanterne's own content and social media
760	chloe@lanterne.example	2026-10-23	330	f	Lanterne's own content and social media
761	julien@lanterne.example	2026-09-01	420	f	Books, invoicing, payroll and contracts
762	julien@lanterne.example	2026-09-02	420	f	Books, invoicing, payroll and contracts
763	julien@lanterne.example	2026-09-03	420	f	Books, invoicing, payroll and contracts
764	julien@lanterne.example	2026-09-04	420	f	Books, invoicing, payroll and contracts
765	julien@lanterne.example	2026-09-07	420	f	Books, invoicing, payroll and contracts
766	julien@lanterne.example	2026-09-08	420	f	Books, invoicing, payroll and contracts
767	julien@lanterne.example	2026-09-09	420	f	Books, invoicing, payroll and contracts
768	julien@lanterne.example	2026-09-10	420	f	Books, invoicing, payroll and contracts
769	julien@lanterne.example	2026-09-11	420	f	Books, invoicing, payroll and contracts
770	julien@lanterne.example	2026-09-14	420	f	Books, invoicing, payroll and contracts
771	julien@lanterne.example	2026-09-15	420	f	Books, invoicing, payroll and contracts
772	julien@lanterne.example	2026-09-16	420	f	Books, invoicing, payroll and contracts
773	julien@lanterne.example	2026-09-17	420	f	Books, invoicing, payroll and contracts
774	julien@lanterne.example	2026-09-18	420	f	Books, invoicing, payroll and contracts
775	julien@lanterne.example	2026-09-21	420	f	Books, invoicing, payroll and contracts
776	julien@lanterne.example	2026-09-22	420	f	Books, invoicing, payroll and contracts
777	julien@lanterne.example	2026-09-23	420	f	Books, invoicing, payroll and contracts
778	julien@lanterne.example	2026-09-24	420	f	Books, invoicing, payroll and contracts
779	julien@lanterne.example	2026-09-25	420	f	Books, invoicing, payroll and contracts
780	julien@lanterne.example	2026-09-28	420	f	Books, invoicing, payroll and contracts
781	julien@lanterne.example	2026-09-29	420	f	Books, invoicing, payroll and contracts
782	julien@lanterne.example	2026-09-30	420	f	Books, invoicing, payroll and contracts
783	julien@lanterne.example	2026-10-01	420	f	Books, invoicing, payroll and contracts
784	julien@lanterne.example	2026-10-02	420	f	Books, invoicing, payroll and contracts
785	julien@lanterne.example	2026-10-05	420	f	Books, invoicing, payroll and contracts
786	julien@lanterne.example	2026-10-06	420	f	Books, invoicing, payroll and contracts
787	julien@lanterne.example	2026-10-07	420	f	Books, invoicing, payroll and contracts
788	julien@lanterne.example	2026-10-08	420	f	Books, invoicing, payroll and contracts
789	julien@lanterne.example	2026-10-09	420	f	Books, invoicing, payroll and contracts
790	julien@lanterne.example	2026-10-12	420	f	Books, invoicing, payroll and contracts
791	julien@lanterne.example	2026-10-13	420	f	Books, invoicing, payroll and contracts
792	julien@lanterne.example	2026-10-14	420	f	Books, invoicing, payroll and contracts
793	julien@lanterne.example	2026-10-15	420	f	Books, invoicing, payroll and contracts
794	julien@lanterne.example	2026-10-16	420	f	Books, invoicing, payroll and contracts
795	julien@lanterne.example	2026-10-19	420	f	Books, invoicing, payroll and contracts
796	julien@lanterne.example	2026-10-20	420	f	Books, invoicing, payroll and contracts
797	julien@lanterne.example	2026-10-21	420	f	Books, invoicing, payroll and contracts
798	julien@lanterne.example	2026-10-22	420	f	Books, invoicing, payroll and contracts
799	julien@lanterne.example	2026-10-23	420	f	Books, invoicing, payroll and contracts
800	ines@lanterne.example	2026-09-01	420	f	Web circle: code reviews, internal tools and training
801	ines@lanterne.example	2026-09-02	420	f	Web circle: code reviews, internal tools and training
802	ines@lanterne.example	2026-09-03	420	f	Web circle: code reviews, internal tools and training
803	ines@lanterne.example	2026-09-04	420	f	Web circle: code reviews, internal tools and training
804	ines@lanterne.example	2026-09-07	420	f	Web circle: code reviews, internal tools and training
805	ines@lanterne.example	2026-09-08	420	f	Web circle: code reviews, internal tools and training
806	ines@lanterne.example	2026-09-09	420	f	Web circle: code reviews, internal tools and training
807	ines@lanterne.example	2026-09-10	420	f	Web circle: code reviews, internal tools and training
808	ines@lanterne.example	2026-09-11	420	f	Web circle: code reviews, internal tools and training
809	ines@lanterne.example	2026-09-14	420	f	Web circle: code reviews, internal tools and training
810	ines@lanterne.example	2026-09-15	420	f	Web circle: code reviews, internal tools and training
811	ines@lanterne.example	2026-09-16	420	f	Web circle: code reviews, internal tools and training
812	ines@lanterne.example	2026-09-17	420	f	Web circle: code reviews, internal tools and training
813	ines@lanterne.example	2026-09-18	420	f	Web circle: code reviews, internal tools and training
814	ines@lanterne.example	2026-09-21	420	f	Web circle: code reviews, internal tools and training
815	ines@lanterne.example	2026-09-22	420	f	Web circle: code reviews, internal tools and training
816	ines@lanterne.example	2026-09-23	420	f	Web circle: code reviews, internal tools and training
817	ines@lanterne.example	2026-09-24	420	f	Web circle: code reviews, internal tools and training
818	ines@lanterne.example	2026-09-25	420	f	Web circle: code reviews, internal tools and training
819	ines@lanterne.example	2026-09-28	420	f	Web circle: code reviews, internal tools and training
820	ines@lanterne.example	2026-09-29	420	f	Web circle: code reviews, internal tools and training
821	ines@lanterne.example	2026-09-30	420	f	Web circle: code reviews, internal tools and training
822	ines@lanterne.example	2026-10-01	420	f	Web circle: code reviews, internal tools and training
823	ines@lanterne.example	2026-10-02	420	f	Web circle: code reviews, internal tools and training
824	ines@lanterne.example	2026-10-05	420	f	Web circle: code reviews, internal tools and training
825	ines@lanterne.example	2026-10-06	420	f	Web circle: code reviews, internal tools and training
826	ines@lanterne.example	2026-10-07	420	f	Web circle: code reviews, internal tools and training
827	ines@lanterne.example	2026-10-08	420	f	Web circle: code reviews, internal tools and training
828	ines@lanterne.example	2026-10-09	420	f	Web circle: code reviews, internal tools and training
829	ines@lanterne.example	2026-10-12	420	f	Web circle: code reviews, internal tools and training
830	ines@lanterne.example	2026-10-13	420	f	Web circle: code reviews, internal tools and training
831	ines@lanterne.example	2026-10-14	420	f	Web circle: code reviews, internal tools and training
832	ines@lanterne.example	2026-10-15	420	f	Web circle: code reviews, internal tools and training
833	ines@lanterne.example	2026-10-16	420	f	Web circle: code reviews, internal tools and training
834	ines@lanterne.example	2026-10-19	420	f	Web circle: code reviews, internal tools and training
835	ines@lanterne.example	2026-10-20	420	f	Web circle: code reviews, internal tools and training
836	ines@lanterne.example	2026-10-21	420	f	Web circle: code reviews, internal tools and training
837	ines@lanterne.example	2026-10-22	420	f	Web circle: code reviews, internal tools and training
838	ines@lanterne.example	2026-10-23	420	f	Web circle: code reviews, internal tools and training
\.


--
-- Data for Name: period; Type: TABLE DATA; Schema: timesheet; Owner: -
--

COPY timesheet.period (member, month, submitted, approved, approver) FROM stdin;
yusuf@lanterne.example	2026-10	\N	\N	\N
thomas@lanterne.example	2026-10	\N	\N	\N
amina@lanterne.example	2026-10	\N	\N	\N
lea@lanterne.example	2026-10	\N	\N	\N
hugo@lanterne.example	2026-10	\N	\N	\N
sofia@lanterne.example	2026-10	\N	\N	\N
camille@lanterne.example	2026-10	\N	\N	\N
malik@lanterne.example	2026-10	\N	\N	\N
chloe@lanterne.example	2026-10	\N	\N	\N
julien@lanterne.example	2026-10	\N	\N	\N
ines@lanterne.example	2026-10	\N	\N	\N
yusuf@lanterne.example	2026-09	2026-10-01	2026-10-05	julien@lanterne.example
thomas@lanterne.example	2026-09	2026-10-01	2026-10-02	yusuf@lanterne.example
amina@lanterne.example	2026-09	2026-10-02	2026-10-02	yusuf@lanterne.example
lea@lanterne.example	2026-09	2026-10-01	2026-10-02	yusuf@lanterne.example
hugo@lanterne.example	2026-09	2026-10-01	2026-10-05	julien@lanterne.example
sofia@lanterne.example	2026-09	2026-10-01	2026-10-01	hugo@lanterne.example
camille@lanterne.example	2026-09	2026-10-02	2026-10-05	hugo@lanterne.example
malik@lanterne.example	2026-09	2026-10-01	2026-10-05	julien@lanterne.example
chloe@lanterne.example	2026-09	2026-10-01	2026-10-01	malik@lanterne.example
julien@lanterne.example	2026-09	2026-10-01	2026-10-05	camille@lanterne.example
ines@lanterne.example	2026-09	2026-10-01	2026-10-05	julien@lanterne.example
\.


--
-- Data for Name: entry; Type: TABLE DATA; Schema: transaction; Owner: -
--

COPY transaction.entry (id, date, label, corrects, receipt) FROM stdin;
je-0001	2026-07-01	Opening balances carried over from the previous accounting tool	\N	\N
je-0002	2026-07-03	Invoice F-2026-0041	\N	\N
je-0003	2026-07-05	Studio rent, 2026-07	\N	\N
je-0004	2026-07-06	Invoice F-2026-0042	\N	\N
je-0005	2026-07-10	Software and connectivity, 2026-07	\N	\N
je-0006	2026-07-15	Invoice F-2026-0043	\N	\N
je-0007	2026-07-21	Invoice F-2026-0044	\N	\N
je-0008	2026-07-28	Invoice F-2026-0045	\N	\N
je-0009	2026-07-28	Payroll, 2026-07	\N	\N
je-0010	2026-07-29	Payment of F-2026-0041	\N	\N
je-0011	2026-07-31	Payment of F-2026-0042	\N	\N
je-0012	2026-08-03	Invoice F-2026-0046	\N	\N
je-0013	2026-08-05	Studio rent, 2026-08	\N	\N
je-0014	2026-08-10	Software and connectivity, 2026-08	\N	\N
je-0015	2026-08-19	VAT return, 2026-07	\N	\N
je-0016	2026-08-24	Payment of F-2026-0045	\N	\N
je-0017	2026-08-27	Invoice F-2026-0047	\N	\N
je-0018	2026-08-28	Payment of F-2026-0046	\N	\N
je-0019	2026-08-28	Payroll, 2026-08	\N	\N
je-0020	2026-09-01	Invoice F-2026-0048	\N	\N
je-0021	2026-09-04	Invoice F-2026-0049	\N	\N
je-0022	2026-09-05	Studio rent, 2026-09	\N	\N
je-0023	2026-09-08	Payment of F-2026-0043	\N	\N
je-0024	2026-09-10	Software and connectivity, 2026-09	\N	\N
je-0025	2026-09-11	Invoice F-2026-0050	\N	\N
je-0026	2026-09-12	Credit note for F-2026-0050, voided	\N	\N
je-0027	2026-09-12	Invoice F-2026-0051	\N	\N
je-0028	2026-09-19	VAT return, 2026-08	\N	\N
je-0029	2026-09-24	Payment of F-2026-0047	\N	\N
je-0030	2026-09-25	Invoice F-2026-0052	\N	\N
je-0031	2026-09-28	Payroll, 2026-09	\N	\N
je-0032	2026-09-29	Payment of F-2026-0048	\N	\N
je-0033	2026-10-01	Invoice F-2026-0053	\N	\N
je-0034	2026-10-05	Payment of F-2026-0051	\N	\N
je-0035	2026-10-05	Studio rent, 2026-10	\N	\N
je-0036	2026-10-08	Invoice F-2026-0054	\N	\N
je-0037	2026-10-10	Software and connectivity, 2026-10	\N	\N
je-0038	2026-10-16	Invoice F-2026-0055	\N	\N
je-0039	2026-10-19	VAT return, 2026-09	\N	\N
je-0040	2026-10-20	Payment of F-2026-0049	\N	\N
je-0041	2026-11-07	Capital to repay, chloe@lanterne.example	\N	68
\.


--
-- Data for Name: journal; Type: TABLE DATA; Schema: transaction; Owner: -
--

COPY transaction.journal (one, last) FROM stdin;
t	41
\.


--
-- Data for Name: line; Type: TABLE DATA; Schema: transaction; Owner: -
--

COPY transaction.line (entry, n, account, side, amount) FROM stdin;
je-0001	1	512	debit	92000.00
je-0001	2	101301	credit	2000.00
je-0001	3	101302	credit	2000.00
je-0001	4	101303	credit	2000.00
je-0001	5	101304	credit	1000.00
je-0001	6	101305	credit	1000.00
je-0001	7	101306	credit	1000.00
je-0001	8	101307	credit	1000.00
je-0001	9	101308	credit	1000.00
je-0001	10	101309	credit	1000.00
je-0001	11	101310	credit	1000.00
je-0001	12	4567	credit	1500.00
je-0001	13	1061	credit	9000.00
je-0001	14	1068	credit	7100.00
je-0001	15	120	credit	61400.00
je-0002	1	411	debit	14400.00
je-0002	2	706	credit	12000.00
je-0002	3	44571	credit	2400.00
je-0003	1	613	debit	2400.00
je-0003	2	44566	debit	480.00
je-0003	3	512	credit	2880.00
je-0004	1	411	debit	5760.00
je-0004	2	706	credit	4800.00
je-0004	3	44571	credit	960.00
je-0005	1	626	debit	620.00
je-0005	2	44566	debit	124.00
je-0005	3	512	credit	744.00
je-0006	1	411	debit	14400.00
je-0006	2	706	credit	12000.00
je-0006	3	44571	credit	2400.00
je-0007	1	411	debit	7440.00
je-0007	2	706	credit	6200.00
je-0007	3	44571	credit	1240.00
je-0008	1	411	debit	11400.00
je-0008	2	706	credit	9500.00
je-0008	3	44571	credit	1900.00
je-0009	1	641	debit	26000.00
je-0009	2	645	debit	10400.00
je-0009	3	512	credit	36400.00
je-0010	1	512	debit	14400.00
je-0010	2	411	credit	14400.00
je-0011	1	512	debit	5760.00
je-0011	2	411	credit	5760.00
je-0012	1	411	debit	5760.00
je-0012	2	706	credit	4800.00
je-0012	3	44571	credit	960.00
je-0013	1	613	debit	2400.00
je-0013	2	44566	debit	480.00
je-0013	3	512	credit	2880.00
je-0014	1	626	debit	620.00
je-0014	2	44566	debit	124.00
je-0014	3	512	credit	744.00
je-0015	1	44571	debit	8900.00
je-0015	2	44566	credit	604.00
je-0015	3	512	credit	8296.00
je-0016	1	512	debit	11400.00
je-0016	2	411	credit	11400.00
je-0017	1	411	debit	14400.00
je-0017	2	706	credit	12000.00
je-0017	3	44571	credit	2400.00
je-0018	1	512	debit	5760.00
je-0018	2	411	credit	5760.00
je-0019	1	641	debit	26000.00
je-0019	2	645	debit	10400.00
je-0019	3	512	credit	36400.00
je-0020	1	411	debit	5760.00
je-0020	2	706	credit	4800.00
je-0020	3	44571	credit	960.00
je-0021	1	411	debit	14400.00
je-0021	2	706	credit	12000.00
je-0021	3	44571	credit	2400.00
je-0022	1	613	debit	2400.00
je-0022	2	44566	debit	480.00
je-0022	3	512	credit	2880.00
je-0023	1	512	debit	14400.00
je-0023	2	411	credit	14400.00
je-0024	1	626	debit	620.00
je-0024	2	44566	debit	124.00
je-0024	3	512	credit	744.00
je-0025	1	411	debit	4560.00
je-0025	2	706	credit	3800.00
je-0025	3	44571	credit	760.00
je-0026	1	706	debit	3800.00
je-0026	2	44571	debit	760.00
je-0026	3	411	credit	4560.00
je-0027	1	411	debit	3960.00
je-0027	2	706	credit	3300.00
je-0027	3	44571	credit	660.00
je-0028	1	44571	debit	3360.00
je-0028	2	44566	credit	604.00
je-0028	3	512	credit	2756.00
je-0029	1	512	debit	14400.00
je-0029	2	411	credit	14400.00
je-0030	1	411	debit	16800.00
je-0030	2	706	credit	14000.00
je-0030	3	44571	credit	2800.00
je-0031	1	641	debit	26000.00
je-0031	2	645	debit	10400.00
je-0031	3	512	credit	36400.00
je-0032	1	512	debit	5760.00
je-0032	2	411	credit	5760.00
je-0033	1	411	debit	5760.00
je-0033	2	706	credit	4800.00
je-0033	3	44571	credit	960.00
je-0034	1	512	debit	1980.00
je-0034	2	411	credit	1980.00
je-0035	1	613	debit	2400.00
je-0035	2	44566	debit	480.00
je-0035	3	512	credit	2880.00
je-0036	1	411	debit	14400.00
je-0036	2	706	credit	12000.00
je-0036	3	44571	credit	2400.00
je-0037	1	626	debit	620.00
je-0037	2	44566	debit	124.00
je-0037	3	512	credit	744.00
je-0038	1	411	debit	10800.00
je-0038	2	706	credit	9000.00
je-0038	3	44571	credit	1800.00
je-0039	1	44571	debit	6820.00
je-0039	2	44566	credit	604.00
je-0039	3	512	credit	6216.00
je-0040	1	512	debit	14400.00
je-0040	2	411	credit	14400.00
je-0041	1	101310	debit	1000.00
je-0041	2	4567	credit	1000.00
\.


--
-- Data for Name: erased; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.erased (subject, class, receipt, date, restricted) FROM stdin;
halles-roux	contact	49	2026-10-24	f
lea@lanterne.example	contact	53	2026-10-24	f
chloe@lanterne.example	contact	80	2026-11-22	f
chloe@lanterne.example	profile	80	2026-11-22	f
chloe@lanterne.example	payroll	80	2026-11-22	f
chloe@lanterne.example	books	80	2026-11-22	f
chloe@lanterne.example	expense-receipt	80	2026-11-22	f
\.


--
-- Data for Name: key; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.key (subject, class, year, sealed, restricted) FROM stdin;
hugo@lanterne.example	contact	2026	\\x8944491ac5e4e127dc583da9fca1e5ee8a074508fbad808b111391f3faf9fed7e8332fd62215c31b2c4f4a32b7848f53effe0bec1af218668e8142bd0a41ee6a12d1151d9e7b9c92	\N
\.


--
-- Data for Name: secret; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secret (commitment, receipt, subject, class, year, field, salt, sealed) FROM stdin;
\\x209043bb17fdbaa9238a0abf8d531d1058e236b46eb3037fcd0f5edaa0bc7908	81	hugo@lanterne.example	contact	2026	person.person.email	\\x94b3eedf05c3f1a66f64cdeb2e84fd8b69dc9ce77d914838ca5ea6ac647192e7	\\x08012eb3c5f930641b4b94c1f342f8f624dca6805e6f2c253d10b890e58b12c2ef4c1bc80c175ca7580f5330a3bd8515884d9f5c2476428c19d52b2598
\\xdc8128ff3c61b5926193b489e19021976f6ac00fb6dbdaade7708a4625c5c6fe	81	hugo@lanterne.example	contact	2026	person.person.phone	\\x5b7efba9eb2356683ede8153d57de0e613a2f728a86d3c656bb4a4e6b8216e3f	\\x8e4e8cc6c247a7f14914d2f7e59632c3902d5f311e4fb56e5a8ca0e508d3e68a9280711195900ec674ad617e9c7b1a42408cd688f0cc1e83dc6475
\.


--
-- Data for Name: swept; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.swept (subject, class, year, date) FROM stdin;
chloe@lanterne.example	expense-receipt	2026	2037-01-01
\.


--
-- Name: receipt_seq; Type: SEQUENCE SET; Schema: cella; Owner: -
--

SELECT pg_catalog.setval('cella.receipt_seq', 81, true);


--
-- Name: mandate_id_seq; Type: SEQUENCE SET; Schema: circle; Owner: -
--

SELECT pg_catalog.setval('circle.mandate_id_seq', 34, true);


--
-- Name: position_id_seq; Type: SEQUENCE SET; Schema: circle_membership; Owner: -
--

SELECT pg_catalog.setval('circle_membership.position_id_seq', 30, true);


--
-- Name: comment_id_seq; Type: SEQUENCE SET; Schema: document; Owner: -
--

SELECT pg_catalog.setval('document.comment_id_seq', 1, true);


--
-- Name: number; Type: SEQUENCE SET; Schema: expense; Owner: -
--

SELECT pg_catalog.setval('expense.number', 6, true);


--
-- Name: number; Type: SEQUENCE SET; Schema: file; Owner: -
--

SELECT pg_catalog.setval('file.number', 5, true);


--
-- Name: number; Type: SEQUENCE SET; Schema: import; Owner: -
--

SELECT pg_catalog.setval('import.number', 1, false);


--
-- Name: payment_id_seq; Type: SEQUENCE SET; Schema: invoice; Owner: -
--

SELECT pg_catalog.setval('invoice.payment_id_seq', 9, true);


--
-- Name: item_id_seq; Type: SEQUENCE SET; Schema: meeting; Owner: -
--

SELECT pg_catalog.setval('meeting.item_id_seq', 30, true);


--
-- Name: share_id_seq; Type: SEQUENCE SET; Schema: membership_project; Owner: -
--

SELECT pg_catalog.setval('membership_project.share_id_seq', 4, true);


--
-- Name: number; Type: SEQUENCE SET; Schema: task; Owner: -
--

SELECT pg_catalog.setval('task.number', 33, true);


--
-- Name: entry_id_seq; Type: SEQUENCE SET; Schema: timesheet; Owner: -
--

SELECT pg_catalog.setval('timesheet.entry_id_seq', 838, true);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (code);


--
-- Name: period period_pkey; Type: CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.period
    ADD CONSTRAINT period_pkey PRIMARY KEY (month);


--
-- Name: rubric rubric_pkey; Type: CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.rubric
    ADD CONSTRAINT rubric_pkey PRIMARY KEY (id);


--
-- Name: rubric rubric_sheet_n_key; Type: CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.rubric
    ADD CONSTRAINT rubric_sheet_n_key UNIQUE (sheet, n);


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: adoption adoption_pkey; Type: CONSTRAINT; Schema: account_decision; Owner: -
--

ALTER TABLE ONLY account_decision.adoption
    ADD CONSTRAINT adoption_pkey PRIMARY KEY (terms, decision);


--
-- Name: allowance allowance_pkey; Type: CONSTRAINT; Schema: account_membership; Owner: -
--

ALTER TABLE ONLY account_membership.allowance
    ADD CONSTRAINT allowance_pkey PRIMARY KEY (member);


--
-- Name: credit credit_pkey; Type: CONSTRAINT; Schema: account_membership_patronage_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_patronage_transaction.credit
    ADD CONSTRAINT credit_pkey PRIMARY KEY (distribution, member);


--
-- Name: plan plan_pkey; Type: CONSTRAINT; Schema: account_membership_payslip_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_payslip_transaction.plan
    ADD CONSTRAINT plan_pkey PRIMARY KEY (member);


--
-- Name: withheld withheld_pkey; Type: CONSTRAINT; Schema: account_membership_payslip_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_payslip_transaction.withheld
    ADD CONSTRAINT withheld_pkey PRIMARY KEY (month, member);


--
-- Name: draw draw_pkey; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.draw
    ADD CONSTRAINT draw_pkey PRIMARY KEY (entry);


--
-- Name: paid paid_pkey; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.paid
    ADD CONSTRAINT paid_pkey PRIMARY KEY (entry, member);


--
-- Name: repayment repayment_pkey; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.repayment
    ADD CONSTRAINT repayment_pkey PRIMARY KEY (member, n);


--
-- Name: subscription subscription_account_key; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.subscription
    ADD CONSTRAINT subscription_account_key UNIQUE (account);


--
-- Name: subscription subscription_entry_key; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.subscription
    ADD CONSTRAINT subscription_entry_key UNIQUE (entry);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE ONLY account_membership_transaction.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (member);


--
-- Name: authority authority_pkey; Type: CONSTRAINT; Schema: cella; Owner: -
--

ALTER TABLE ONLY cella.authority
    ADD CONSTRAINT authority_pkey PRIMARY KEY (one);


--
-- Name: reach reach_pkey; Type: CONSTRAINT; Schema: cella; Owner: -
--

ALTER TABLE ONLY cella.reach
    ADD CONSTRAINT reach_pkey PRIMARY KEY (what, fn);


--
-- Name: reading reading_what_key_power_key; Type: CONSTRAINT; Schema: cella; Owner: -
--

ALTER TABLE ONLY cella.reading
    ADD CONSTRAINT reading_what_key_power_key UNIQUE NULLS NOT DISTINCT (what, key, power);


--
-- Name: circle circle_pkey; Type: CONSTRAINT; Schema: circle; Owner: -
--

ALTER TABLE ONLY circle.circle
    ADD CONSTRAINT circle_pkey PRIMARY KEY (id);


--
-- Name: mandate mandate_pkey; Type: CONSTRAINT; Schema: circle; Owner: -
--

ALTER TABLE ONLY circle.mandate
    ADD CONSTRAINT mandate_pkey PRIMARY KEY (id);


--
-- Name: role role_pkey; Type: CONSTRAINT; Schema: circle; Owner: -
--

ALTER TABLE ONLY circle.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id);


--
-- Name: counted counted_pkey; Type: CONSTRAINT; Schema: circle_decision_membership; Owner: -
--

ALTER TABLE ONLY circle_decision_membership.counted
    ADD CONSTRAINT counted_pkey PRIMARY KEY (decision, member);


--
-- Name: roll roll_pkey; Type: CONSTRAINT; Schema: circle_decision_membership; Owner: -
--

ALTER TABLE ONLY circle_decision_membership.roll
    ADD CONSTRAINT roll_pkey PRIMARY KEY (decision, member);


--
-- Name: opener opener_pkey; Type: CONSTRAINT; Schema: circle_file_membership; Owner: -
--

ALTER TABLE ONLY circle_file_membership.opener
    ADD CONSTRAINT opener_pkey PRIMARY KEY (class, power);


--
-- Name: setting setting_pkey; Type: CONSTRAINT; Schema: circle_meeting; Owner: -
--

ALTER TABLE ONLY circle_meeting.setting
    ADD CONSTRAINT setting_pkey PRIMARY KEY (circle);


--
-- Name: position position_pkey; Type: CONSTRAINT; Schema: circle_membership; Owner: -
--

ALTER TABLE ONLY circle_membership."position"
    ADD CONSTRAINT position_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: client; Owner: -
--

ALTER TABLE ONLY client.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: billing billing_pkey; Type: CONSTRAINT; Schema: client_invoice; Owner: -
--

ALTER TABLE ONLY client_invoice.billing
    ADD CONSTRAINT billing_pkey PRIMARY KEY (invoice);


--
-- Name: commission commission_pkey; Type: CONSTRAINT; Schema: client_project; Owner: -
--

ALTER TABLE ONLY client_project.commission
    ADD CONSTRAINT commission_pkey PRIMARY KEY (project);


--
-- Name: cites cites_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.cites
    ADD CONSTRAINT cites_pkey PRIMARY KEY (op);


--
-- Name: decision decision_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.decision
    ADD CONSTRAINT decision_pkey PRIMARY KEY (id);


--
-- Name: kind kind_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.kind
    ADD CONSTRAINT kind_pkey PRIMARY KEY (kind);


--
-- Name: message message_decision_receipt_key; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.message
    ADD CONSTRAINT message_decision_receipt_key UNIQUE (decision, receipt);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (receipt);


--
-- Name: motion motion_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.motion
    ADD CONSTRAINT motion_pkey PRIMARY KEY (decision, n);


--
-- Name: procedure procedure_id_rule_key; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.procedure
    ADD CONSTRAINT procedure_id_rule_key UNIQUE (id, rule);


--
-- Name: procedure procedure_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.procedure
    ADD CONSTRAINT procedure_pkey PRIMARY KEY (id);


--
-- Name: vote vote_pkey; Type: CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.vote
    ADD CONSTRAINT vote_pkey PRIMARY KEY (receipt);


--
-- Name: adoption adoption_pkey; Type: CONSTRAINT; Schema: decision_document; Owner: -
--

ALTER TABLE ONLY decision_document.adoption
    ADD CONSTRAINT adoption_pkey PRIMARY KEY (decision, document);


--
-- Name: tabled tabled_pkey; Type: CONSTRAINT; Schema: decision_meeting; Owner: -
--

ALTER TABLE ONLY decision_meeting.tabled
    ADD CONSTRAINT tabled_pkey PRIMARY KEY (item);


--
-- Name: adoption adoption_pkey; Type: CONSTRAINT; Schema: decision_patronage; Owner: -
--

ALTER TABLE ONLY decision_patronage.adoption
    ADD CONSTRAINT adoption_pkey PRIMARY KEY (terms, decision);


--
-- Name: approval approval_pkey; Type: CONSTRAINT; Schema: decision_patronage; Owner: -
--

ALTER TABLE ONLY decision_patronage.approval
    ADD CONSTRAINT approval_pkey PRIMARY KEY (distribution);


--
-- Name: adoption adoption_pkey; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.adoption
    ADD CONSTRAINT adoption_pkey PRIMARY KEY (receipt);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (id);


--
-- Name: update update_pkey; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.update
    ADD CONSTRAINT update_pkey PRIMARY KEY (receipt);


--
-- Name: version version_document_n_key; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.version
    ADD CONSTRAINT version_document_n_key UNIQUE (document, n);


--
-- Name: version version_pkey; Type: CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.version
    ADD CONSTRAINT version_pkey PRIMARY KEY (id);


--
-- Name: minutes minutes_document_key; Type: CONSTRAINT; Schema: document_meeting; Owner: -
--

ALTER TABLE ONLY document_meeting.minutes
    ADD CONSTRAINT minutes_document_key UNIQUE (document);


--
-- Name: minutes minutes_pkey; Type: CONSTRAINT; Schema: document_meeting; Owner: -
--

ALTER TABLE ONLY document_meeting.minutes
    ADD CONSTRAINT minutes_pkey PRIMARY KEY (meeting);


--
-- Name: reading reading_pkey; Type: CONSTRAINT; Schema: document_membership; Owner: -
--

ALTER TABLE ONLY document_membership.reading
    ADD CONSTRAINT reading_pkey PRIMARY KEY (version, member);


--
-- Name: worker worker_pkey; Type: CONSTRAINT; Schema: employment; Owner: -
--

ALTER TABLE ONLY employment.worker
    ADD CONSTRAINT worker_pkey PRIMARY KEY (address);


--
-- Name: record record_file_key; Type: CONSTRAINT; Schema: employment_file; Owner: -
--

ALTER TABLE ONLY employment_file.record
    ADD CONSTRAINT record_file_key UNIQUE (file);


--
-- Name: record record_pkey; Type: CONSTRAINT; Schema: employment_file; Owner: -
--

ALTER TABLE ONLY employment_file.record
    ADD CONSTRAINT record_pkey PRIMARY KEY (worker, file);


--
-- Name: candidacy candidacy_pkey; Type: CONSTRAINT; Schema: employment_membership; Owner: -
--

ALTER TABLE ONLY employment_membership.candidacy
    ADD CONSTRAINT candidacy_pkey PRIMARY KEY (worker);


--
-- Name: expense expense_pkey; Type: CONSTRAINT; Schema: expense; Owner: -
--

ALTER TABLE ONLY expense.expense
    ADD CONSTRAINT expense_pkey PRIMARY KEY (id);


--
-- Name: receipt receipt_file_key; Type: CONSTRAINT; Schema: expense_file; Owner: -
--

ALTER TABLE ONLY expense_file.receipt
    ADD CONSTRAINT receipt_file_key UNIQUE (file);


--
-- Name: receipt receipt_pkey; Type: CONSTRAINT; Schema: expense_file; Owner: -
--

ALTER TABLE ONLY expense_file.receipt
    ADD CONSTRAINT receipt_pkey PRIMARY KEY (expense, file);


--
-- Name: threshold threshold_pkey; Type: CONSTRAINT; Schema: expense_invoice_project_timesheet; Owner: -
--

ALTER TABLE ONLY expense_invoice_project_timesheet.threshold
    ADD CONSTRAINT threshold_pkey PRIMARY KEY (since);


--
-- Name: rebill rebill_pkey; Type: CONSTRAINT; Schema: expense_project; Owner: -
--

ALTER TABLE ONLY expense_project.rebill
    ADD CONSTRAINT rebill_pkey PRIMARY KEY (expense);


--
-- Name: posting posting_expense_event_key; Type: CONSTRAINT; Schema: expense_transaction; Owner: -
--

ALTER TABLE ONLY expense_transaction.posting
    ADD CONSTRAINT posting_expense_event_key UNIQUE (expense, event);


--
-- Name: posting posting_pkey; Type: CONSTRAINT; Schema: expense_transaction; Owner: -
--

ALTER TABLE ONLY expense_transaction.posting
    ADD CONSTRAINT posting_pkey PRIMARY KEY (entry);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: file; Owner: -
--

ALTER TABLE ONLY file.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id, class);


--
-- Name: contract contract_pkey; Type: CONSTRAINT; Schema: file; Owner: -
--

ALTER TABLE ONLY file.contract
    ADD CONSTRAINT contract_pkey PRIMARY KEY (id, class);


--
-- Name: receipt receipt_pkey; Type: CONSTRAINT; Schema: file; Owner: -
--

ALTER TABLE ONLY file.receipt
    ADD CONSTRAINT receipt_pkey PRIMARY KEY (id, class);


--
-- Name: record record_pkey; Type: CONSTRAINT; Schema: file; Owner: -
--

ALTER TABLE ONLY file.record
    ADD CONSTRAINT record_pkey PRIMARY KEY (id, class);


--
-- Name: shared shared_pkey; Type: CONSTRAINT; Schema: file; Owner: -
--

ALTER TABLE ONLY file.shared
    ADD CONSTRAINT shared_pkey PRIMARY KEY (id, class);


--
-- Name: record record_file_key; Type: CONSTRAINT; Schema: file_membership; Owner: -
--

ALTER TABLE ONLY file_membership.record
    ADD CONSTRAINT record_file_key UNIQUE (file);


--
-- Name: record record_pkey; Type: CONSTRAINT; Schema: file_membership; Owner: -
--

ALTER TABLE ONLY file_membership.record
    ADD CONSTRAINT record_pkey PRIMARY KEY (member, file);


--
-- Name: run run_pkey; Type: CONSTRAINT; Schema: import; Owner: -
--

ALTER TABLE ONLY import.run
    ADD CONSTRAINT run_pkey PRIMARY KEY (id);


--
-- Name: invoice invoice_pkey; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (id);


--
-- Name: invoice invoice_series_number_key; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.invoice
    ADD CONSTRAINT invoice_series_number_key UNIQUE (series, number);


--
-- Name: line line_pkey; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.line
    ADD CONSTRAINT line_pkey PRIMARY KEY (invoice, n);


--
-- Name: payment payment_invoice_reference_key; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.payment
    ADD CONSTRAINT payment_invoice_reference_key UNIQUE (invoice, reference);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: payment payment_receipt_key; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.payment
    ADD CONSTRAINT payment_receipt_key UNIQUE (receipt);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (name);


--
-- Name: charge charge_pkey; Type: CONSTRAINT; Schema: invoice_project; Owner: -
--

ALTER TABLE ONLY invoice_project.charge
    ADD CONSTRAINT charge_pkey PRIMARY KEY (invoice);


--
-- Name: posting posting_payment_key; Type: CONSTRAINT; Schema: invoice_transaction; Owner: -
--

ALTER TABLE ONLY invoice_transaction.posting
    ADD CONSTRAINT posting_payment_key UNIQUE (payment);


--
-- Name: posting posting_pkey; Type: CONSTRAINT; Schema: invoice_transaction; Owner: -
--

ALTER TABLE ONLY invoice_transaction.posting
    ADD CONSTRAINT posting_pkey PRIMARY KEY (entry);


--
-- Name: item item_pkey; Type: CONSTRAINT; Schema: meeting; Owner: -
--

ALTER TABLE ONLY meeting.item
    ADD CONSTRAINT item_pkey PRIMARY KEY (id);


--
-- Name: meeting meeting_pkey; Type: CONSTRAINT; Schema: meeting; Owner: -
--

ALTER TABLE ONLY meeting.meeting
    ADD CONSTRAINT meeting_pkey PRIMARY KEY (id);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: meeting_membership; Owner: -
--

ALTER TABLE ONLY meeting_membership.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (meeting, member);


--
-- Name: invitation invitation_key_key; Type: CONSTRAINT; Schema: membership; Owner: -
--

ALTER TABLE ONLY membership.invitation
    ADD CONSTRAINT invitation_key_key UNIQUE (key);


--
-- Name: invitation invitation_pkey; Type: CONSTRAINT; Schema: membership; Owner: -
--

ALTER TABLE ONLY membership.invitation
    ADD CONSTRAINT invitation_pkey PRIMARY KEY (member);


--
-- Name: link link_pkey; Type: CONSTRAINT; Schema: membership; Owner: -
--

ALTER TABLE ONLY membership.link
    ADD CONSTRAINT link_pkey PRIMARY KEY (digest);


--
-- Name: member member_pkey; Type: CONSTRAINT; Schema: membership; Owner: -
--

ALTER TABLE ONLY membership.member
    ADD CONSTRAINT member_pkey PRIMARY KEY (address);


--
-- Name: share share_pkey; Type: CONSTRAINT; Schema: membership_project; Owner: -
--

ALTER TABLE ONLY membership_project.share
    ADD CONSTRAINT share_pkey PRIMARY KEY (id);


--
-- Name: assignment assignment_pkey; Type: CONSTRAINT; Schema: membership_task; Owner: -
--

ALTER TABLE ONLY membership_task.assignment
    ADD CONSTRAINT assignment_pkey PRIMARY KEY (task);


--
-- Name: applied applied_pkey; Type: CONSTRAINT; Schema: migration; Owner: -
--

ALTER TABLE ONLY migration.applied
    ADD CONSTRAINT applied_pkey PRIMARY KEY (path);


--
-- Name: distribution distribution_pkey; Type: CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.distribution
    ADD CONSTRAINT distribution_pkey PRIMARY KEY (id);


--
-- Name: distribution distribution_year_key; Type: CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.distribution
    ADD CONSTRAINT distribution_year_key UNIQUE (year);


--
-- Name: part part_pkey; Type: CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.part
    ADD CONSTRAINT part_pkey PRIMARY KEY (distribution, worker, basis);


--
-- Name: share share_pkey; Type: CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.share
    ADD CONSTRAINT share_pkey PRIMARY KEY (distribution, kind);


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (id);


--
-- Name: distribution distribution_entry_key; Type: CONSTRAINT; Schema: patronage_transaction; Owner: -
--

ALTER TABLE ONLY patronage_transaction.distribution
    ADD CONSTRAINT distribution_entry_key UNIQUE (entry);


--
-- Name: distribution distribution_pkey; Type: CONSTRAINT; Schema: patronage_transaction; Owner: -
--

ALTER TABLE ONLY patronage_transaction.distribution
    ADD CONSTRAINT distribution_pkey PRIMARY KEY (distribution);


--
-- Name: payslip payslip_pkey; Type: CONSTRAINT; Schema: payslip; Owner: -
--

ALTER TABLE ONLY payslip.payslip
    ADD CONSTRAINT payslip_pkey PRIMARY KEY (month, member);


--
-- Name: run run_pkey; Type: CONSTRAINT; Schema: payslip; Owner: -
--

ALTER TABLE ONLY payslip.run
    ADD CONSTRAINT run_pkey PRIMARY KEY (month);


--
-- Name: salary salary_pkey; Type: CONSTRAINT; Schema: payslip; Owner: -
--

ALTER TABLE ONLY payslip.salary
    ADD CONSTRAINT salary_pkey PRIMARY KEY (member, "from");


--
-- Name: terms terms_pkey; Type: CONSTRAINT; Schema: payslip; Owner: -
--

ALTER TABLE ONLY payslip.terms
    ADD CONSTRAINT terms_pkey PRIMARY KEY (one);


--
-- Name: posting posting_month_event_key; Type: CONSTRAINT; Schema: payslip_transaction; Owner: -
--

ALTER TABLE ONLY payslip_transaction.posting
    ADD CONSTRAINT posting_month_event_key UNIQUE (month, event);


--
-- Name: posting posting_pkey; Type: CONSTRAINT; Schema: payslip_transaction; Owner: -
--

ALTER TABLE ONLY payslip_transaction.posting
    ADD CONSTRAINT posting_pkey PRIMARY KEY (entry);


--
-- Name: device device_pkey; Type: CONSTRAINT; Schema: person; Owner: -
--

ALTER TABLE ONLY person.device
    ADD CONSTRAINT device_pkey PRIMARY KEY (key);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: person; Owner: -
--

ALTER TABLE ONLY person.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (address);


--
-- Name: milestone milestone_pkey; Type: CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY project.milestone
    ADD CONSTRAINT milestone_pkey PRIMARY KEY (project, n);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY project.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: filing filing_pkey; Type: CONSTRAINT; Schema: project_task; Owner: -
--

ALTER TABLE ONLY project_task.filing
    ADD CONSTRAINT filing_pkey PRIMARY KEY (task);


--
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: project_timesheet; Owner: -
--

ALTER TABLE ONLY project_timesheet.booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (entry);


--
-- Name: cost cost_pkey; Type: CONSTRAINT; Schema: project_timesheet; Owner: -
--

ALTER TABLE ONLY project_timesheet.cost
    ADD CONSTRAINT cost_pkey PRIMARY KEY (since);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: project_timesheet; Owner: -
--

ALTER TABLE ONLY project_timesheet.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (since);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: task; Owner: -
--

ALTER TABLE ONLY task.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: entry entry_pkey; Type: CONSTRAINT; Schema: timesheet; Owner: -
--

ALTER TABLE ONLY timesheet.entry
    ADD CONSTRAINT entry_pkey PRIMARY KEY (id);


--
-- Name: period period_pkey; Type: CONSTRAINT; Schema: timesheet; Owner: -
--

ALTER TABLE ONLY timesheet.period
    ADD CONSTRAINT period_pkey PRIMARY KEY (member, month);


--
-- Name: entry entry_pkey; Type: CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.entry
    ADD CONSTRAINT entry_pkey PRIMARY KEY (id);


--
-- Name: entry entry_receipt_key; Type: CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.entry
    ADD CONSTRAINT entry_receipt_key UNIQUE (receipt);


--
-- Name: journal journal_pkey; Type: CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.journal
    ADD CONSTRAINT journal_pkey PRIMARY KEY (one);


--
-- Name: line line_pkey; Type: CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.line
    ADD CONSTRAINT line_pkey PRIMARY KEY (entry, n);


--
-- Name: draw_member_idx; Type: INDEX; Schema: account_membership_transaction; Owner: -
--

CREATE INDEX draw_member_idx ON account_membership_transaction.draw USING btree (member);


--
-- Name: paid_member_idx; Type: INDEX; Schema: account_membership_transaction; Owner: -
--

CREATE INDEX paid_member_idx ON account_membership_transaction.paid USING btree (member);


--
-- Name: mandate_power_idx; Type: INDEX; Schema: circle; Owner: -
--

CREATE INDEX mandate_power_idx ON circle.mandate USING btree (power);


--
-- Name: mandate_role_idx; Type: INDEX; Schema: circle; Owner: -
--

CREATE INDEX mandate_role_idx ON circle.mandate USING btree (role);


--
-- Name: one_root; Type: INDEX; Schema: circle; Owner: -
--

CREATE UNIQUE INDEX one_root ON circle.circle USING btree ((true)) WHERE (parent IS NULL);


--
-- Name: position_circle_idx; Type: INDEX; Schema: circle_membership; Owner: -
--

CREATE INDEX position_circle_idx ON circle_membership."position" USING btree (circle);


--
-- Name: position_member_idx; Type: INDEX; Schema: circle_membership; Owner: -
--

CREATE INDEX position_member_idx ON circle_membership."position" USING btree (member);


--
-- Name: billing_client_idx; Type: INDEX; Schema: client_invoice; Owner: -
--

CREATE INDEX billing_client_idx ON client_invoice.billing USING btree (client);


--
-- Name: commission_client_idx; Type: INDEX; Schema: client_project; Owner: -
--

CREATE INDEX commission_client_idx ON client_project.commission USING btree (client);


--
-- Name: message_decision_idx; Type: INDEX; Schema: decision; Owner: -
--

CREATE INDEX message_decision_idx ON decision.message USING btree (decision);


--
-- Name: motion_kind_idx; Type: INDEX; Schema: decision; Owner: -
--

CREATE INDEX motion_kind_idx ON decision.motion USING btree (kind);


--
-- Name: vote_decision_idx; Type: INDEX; Schema: decision; Owner: -
--

CREATE INDEX vote_decision_idx ON decision.vote USING btree (decision);


--
-- Name: tabled_decision_idx; Type: INDEX; Schema: decision_meeting; Owner: -
--

CREATE INDEX tabled_decision_idx ON decision_meeting.tabled USING btree (decision);


--
-- Name: tabled_meeting_idx; Type: INDEX; Schema: decision_meeting; Owner: -
--

CREATE INDEX tabled_meeting_idx ON decision_meeting.tabled USING btree (meeting);


--
-- Name: adoption_document_idx; Type: INDEX; Schema: document; Owner: -
--

CREATE INDEX adoption_document_idx ON document.adoption USING btree (document);


--
-- Name: comment_version_idx; Type: INDEX; Schema: document; Owner: -
--

CREATE INDEX comment_version_idx ON document.comment USING btree (version);


--
-- Name: update_document_idx; Type: INDEX; Schema: document; Owner: -
--

CREATE INDEX update_document_idx ON document.update USING btree (document);


--
-- Name: expense_decider_decided_idx; Type: INDEX; Schema: expense; Owner: -
--

CREATE INDEX expense_decider_decided_idx ON expense.expense USING btree (decider, decided);


--
-- Name: expense_member_idx; Type: INDEX; Schema: expense; Owner: -
--

CREATE INDEX expense_member_idx ON expense.expense USING btree (member);


--
-- Name: rebill_project_idx; Type: INDEX; Schema: expense_project; Owner: -
--

CREATE INDEX rebill_project_idx ON expense_project.rebill USING btree (project);


--
-- Name: file_hash_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX file_hash_idx ON ONLY file.file USING btree (hash);


--
-- Name: contract_hash_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX contract_hash_idx ON file.contract USING btree (hash);


--
-- Name: file_subject_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX file_subject_idx ON ONLY file.file USING btree (subject);


--
-- Name: contract_subject_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX contract_subject_idx ON file.contract USING btree (subject);


--
-- Name: receipt_hash_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX receipt_hash_idx ON file.receipt USING btree (hash);


--
-- Name: receipt_subject_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX receipt_subject_idx ON file.receipt USING btree (subject);


--
-- Name: record_hash_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX record_hash_idx ON file.record USING btree (hash);


--
-- Name: record_subject_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX record_subject_idx ON file.record USING btree (subject);


--
-- Name: shared_hash_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX shared_hash_idx ON file.shared USING btree (hash);


--
-- Name: shared_subject_idx; Type: INDEX; Schema: file; Owner: -
--

CREATE INDEX shared_subject_idx ON file.shared USING btree (subject);


--
-- Name: charge_project_idx; Type: INDEX; Schema: invoice_project; Owner: -
--

CREATE INDEX charge_project_idx ON invoice_project.charge USING btree (project);


--
-- Name: posting_invoice_event_idx; Type: INDEX; Schema: invoice_transaction; Owner: -
--

CREATE UNIQUE INDEX posting_invoice_event_idx ON invoice_transaction.posting USING btree (invoice, event) WHERE (event <> 'payment'::text);


--
-- Name: item_meeting_pos_idx; Type: INDEX; Schema: meeting; Owner: -
--

CREATE INDEX item_meeting_pos_idx ON meeting.item USING btree (meeting, pos);


--
-- Name: meeting_circle_at_idx; Type: INDEX; Schema: meeting; Owner: -
--

CREATE INDEX meeting_circle_at_idx ON meeting.meeting USING btree (circle, at);


--
-- Name: attendance_member_idx; Type: INDEX; Schema: meeting_membership; Owner: -
--

CREATE INDEX attendance_member_idx ON meeting_membership.attendance USING btree (member);


--
-- Name: share_project_idx; Type: INDEX; Schema: membership_project; Owner: -
--

CREATE INDEX share_project_idx ON membership_project.share USING btree (project);


--
-- Name: assignment_member_idx; Type: INDEX; Schema: membership_task; Owner: -
--

CREATE INDEX assignment_member_idx ON membership_task.assignment USING btree (member);


--
-- Name: device_address_idx; Type: INDEX; Schema: person; Owner: -
--

CREATE INDEX device_address_idx ON person.device USING btree (address);


--
-- Name: filing_project_idx; Type: INDEX; Schema: project_task; Owner: -
--

CREATE INDEX filing_project_idx ON project_task.filing USING btree (project);


--
-- Name: booking_project_idx; Type: INDEX; Schema: project_timesheet; Owner: -
--

CREATE INDEX booking_project_idx ON project_timesheet.booking USING btree (project);


--
-- Name: entry_member_day_idx; Type: INDEX; Schema: timesheet; Owner: -
--

CREATE INDEX entry_member_day_idx ON timesheet.entry USING btree (member, day);


--
-- Name: entry_corrects_idx; Type: INDEX; Schema: transaction; Owner: -
--

CREATE INDEX entry_corrects_idx ON transaction.entry USING btree (corrects);


--
-- Name: line_account_idx; Type: INDEX; Schema: transaction; Owner: -
--

CREATE INDEX line_account_idx ON transaction.line USING btree (account);


--
-- Name: contract_hash_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_hash_idx ATTACH PARTITION file.contract_hash_idx;


--
-- Name: contract_pkey; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_pkey ATTACH PARTITION file.contract_pkey;


--
-- Name: contract_subject_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_subject_idx ATTACH PARTITION file.contract_subject_idx;


--
-- Name: receipt_hash_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_hash_idx ATTACH PARTITION file.receipt_hash_idx;


--
-- Name: receipt_pkey; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_pkey ATTACH PARTITION file.receipt_pkey;


--
-- Name: receipt_subject_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_subject_idx ATTACH PARTITION file.receipt_subject_idx;


--
-- Name: record_hash_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_hash_idx ATTACH PARTITION file.record_hash_idx;


--
-- Name: record_pkey; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_pkey ATTACH PARTITION file.record_pkey;


--
-- Name: record_subject_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_subject_idx ATTACH PARTITION file.record_subject_idx;


--
-- Name: shared_hash_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_hash_idx ATTACH PARTITION file.shared_hash_idx;


--
-- Name: shared_pkey; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_pkey ATTACH PARTITION file.shared_pkey;


--
-- Name: shared_subject_idx; Type: INDEX ATTACH; Schema: file; Owner: -
--

ALTER INDEX file.file_subject_idx ATTACH PARTITION file.shared_subject_idx;


--
-- Name: account held; Type: TRIGGER; Schema: account; Owner: -
--

CREATE TRIGGER held BEFORE INSERT OR UPDATE OF holder ON account.account FOR EACH ROW EXECUTE FUNCTION account_membership.held();


--
-- Name: terms stays_adopted; Type: TRIGGER; Schema: account; Owner: -
--

CREATE TRIGGER stays_adopted BEFORE DELETE OR UPDATE ON account.terms FOR EACH ROW EXECUTE FUNCTION account.stays_adopted();


--
-- Name: period stays_closed; Type: TRIGGER; Schema: account; Owner: -
--

CREATE TRIGGER stays_closed BEFORE UPDATE ON account.period FOR EACH ROW EXECUTE FUNCTION account.stays_closed();


--
-- Name: account stays_frozen; Type: TRIGGER; Schema: account; Owner: -
--

CREATE TRIGGER stays_frozen BEFORE UPDATE OF frozen ON account.account FOR EACH ROW EXECUTE FUNCTION account.stays_frozen();


--
-- Name: repayment stays_repaid; Type: TRIGGER; Schema: account_membership_transaction; Owner: -
--

CREATE TRIGGER stays_repaid BEFORE DELETE OR UPDATE ON account_membership_transaction.repayment FOR EACH ROW EXECUTE FUNCTION account_membership_transaction.stays_repaid();


--
-- Name: circle carried; Type: TRIGGER; Schema: circle; Owner: -
--

CREATE TRIGGER carried AFTER UPDATE OF parent ON circle.circle FOR EACH ROW WHEN ((old.parent IS DISTINCT FROM new.parent)) EXECUTE FUNCTION circle.carried();


--
-- Name: circle decides_by; Type: TRIGGER; Schema: circle; Owner: -
--

CREATE TRIGGER decides_by BEFORE INSERT OR UPDATE OF procedure ON circle.circle FOR EACH ROW EXECUTE FUNCTION circle_decision.decides_by();


--
-- Name: circle placed; Type: TRIGGER; Schema: circle; Owner: -
--

CREATE TRIGGER placed BEFORE INSERT OR UPDATE OF parent ON circle.circle FOR EACH ROW EXECUTE FUNCTION circle.placed();


--
-- Name: mandate stays_granted; Type: TRIGGER; Schema: circle; Owner: -
--

CREATE TRIGGER stays_granted BEFORE UPDATE ON circle.mandate FOR EACH ROW EXECUTE FUNCTION circle.stays_granted();


--
-- Name: setting resolves; Type: TRIGGER; Schema: circle_meeting; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON circle_meeting.setting FOR EACH ROW EXECUTE FUNCTION circle_meeting.resolves();


--
-- Name: client parent_is_company; Type: TRIGGER; Schema: client; Owner: -
--

CREATE TRIGGER parent_is_company BEFORE INSERT OR UPDATE OF parent ON client.client FOR EACH ROW EXECUTE FUNCTION client.parent_is_company();


--
-- Name: billing resolves; Type: TRIGGER; Schema: client_invoice; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON client_invoice.billing FOR EACH ROW EXECUTE FUNCTION client_invoice.resolves();


--
-- Name: commission resolves; Type: TRIGGER; Schema: client_project; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON client_project.commission FOR EACH ROW EXECUTE FUNCTION client_project.resolves();


--
-- Name: motion adopts; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER adopts AFTER INSERT ON decision.motion FOR EACH ROW EXECUTE FUNCTION decision_document.moved();


--
-- Name: motion adopts_patronage_terms; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER adopts_patronage_terms AFTER INSERT ON decision.motion FOR EACH ROW EXECUTE FUNCTION decision_patronage.moved();


--
-- Name: motion adopts_terms; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER adopts_terms AFTER INSERT ON decision.motion FOR EACH ROW EXECUTE FUNCTION account_decision.moved();


--
-- Name: cites attach; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER attach AFTER INSERT ON decision.cites FOR EACH ROW EXECUTE FUNCTION circle_decision_membership.attach();


--
-- Name: decision count_roll; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER count_roll AFTER UPDATE OF closed ON decision.decision FOR EACH ROW WHEN (((old.closed IS NULL) AND (new.closed IS NOT NULL))) EXECUTE FUNCTION circle_decision_membership.count_roll();


--
-- Name: decision fix_roll; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER fix_roll AFTER INSERT ON decision.decision FOR EACH ROW EXECUTE FUNCTION circle_decision_membership.fix_roll();


--
-- Name: motion moved_with_proposal; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER moved_with_proposal BEFORE INSERT ON decision.motion FOR EACH ROW EXECUTE FUNCTION decision.moved_with_proposal();


--
-- Name: message open_for_messages; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER open_for_messages BEFORE INSERT ON decision.message FOR EACH ROW EXECUTE FUNCTION decision.open_for_votes();


--
-- Name: vote open_for_votes; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER open_for_votes BEFORE INSERT ON decision.vote FOR EACH ROW EXECUTE FUNCTION decision.open_for_votes();


--
-- Name: procedure procedure_kept; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER procedure_kept BEFORE DELETE OR UPDATE ON decision.procedure FOR EACH ROW EXECUTE FUNCTION decision.procedure_kept();


--
-- Name: decision stays_closed; Type: TRIGGER; Schema: decision; Owner: -
--

CREATE TRIGGER stays_closed BEFORE UPDATE ON decision.decision FOR EACH ROW EXECUTE FUNCTION decision.stays_closed();


--
-- Name: tabled resolves; Type: TRIGGER; Schema: decision_meeting; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON decision_meeting.tabled FOR EACH ROW EXECUTE FUNCTION decision_meeting.resolves();


--
-- Name: version numbers; Type: TRIGGER; Schema: document; Owner: -
--

CREATE TRIGGER numbers BEFORE INSERT ON document.version FOR EACH ROW EXECUTE FUNCTION document.numbers();


--
-- Name: adoption permanent; Type: TRIGGER; Schema: document; Owner: -
--

CREATE TRIGGER permanent BEFORE DELETE OR UPDATE ON document.adoption FOR EACH ROW EXECUTE FUNCTION document.permanent();


--
-- Name: update permanent; Type: TRIGGER; Schema: document; Owner: -
--

CREATE TRIGGER permanent BEFORE DELETE OR UPDATE ON document.update FOR EACH ROW EXECUTE FUNCTION document.permanent();


--
-- Name: version permanent; Type: TRIGGER; Schema: document; Owner: -
--

CREATE TRIGGER permanent BEFORE DELETE OR UPDATE ON document.version FOR EACH ROW EXECUTE FUNCTION document.permanent();


--
-- Name: comment quotes; Type: TRIGGER; Schema: document; Owner: -
--

CREATE TRIGGER quotes BEFORE INSERT ON document.comment FOR EACH ROW EXECUTE FUNCTION document.quotes();


--
-- Name: minutes resolves; Type: TRIGGER; Schema: document_meeting; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON document_meeting.minutes FOR EACH ROW EXECUTE FUNCTION document_meeting.resolves();


--
-- Name: expense moves; Type: TRIGGER; Schema: expense; Owner: -
--

CREATE TRIGGER moves BEFORE UPDATE ON expense.expense FOR EACH ROW EXECUTE FUNCTION expense.moves();


--
-- Name: expense whose; Type: TRIGGER; Schema: expense; Owner: -
--

CREATE TRIGGER whose BEFORE INSERT ON expense.expense FOR EACH ROW EXECUTE FUNCTION expense_membership.whose();


--
-- Name: file fixed; Type: TRIGGER; Schema: file; Owner: -
--

CREATE TRIGGER fixed BEFORE UPDATE ON file.file FOR EACH ROW EXECUTE FUNCTION file.fixed();


--
-- Name: invoice adds_up; Type: TRIGGER; Schema: invoice; Owner: -
--

CREATE CONSTRAINT TRIGGER adds_up AFTER INSERT ON invoice.invoice DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION invoice.adds_up();


--
-- Name: line adds_up; Type: TRIGGER; Schema: invoice; Owner: -
--

CREATE CONSTRAINT TRIGGER adds_up AFTER INSERT ON invoice.line DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION invoice.adds_up();


--
-- Name: invoice stays_issued; Type: TRIGGER; Schema: invoice; Owner: -
--

CREATE TRIGGER stays_issued BEFORE UPDATE ON invoice.invoice FOR EACH ROW EXECUTE FUNCTION invoice.stays_issued();


--
-- Name: line stays_issued; Type: TRIGGER; Schema: invoice; Owner: -
--

CREATE TRIGGER stays_issued BEFORE DELETE OR UPDATE ON invoice.line FOR EACH ROW EXECUTE FUNCTION invoice.stays_issued();


--
-- Name: charge resolves; Type: TRIGGER; Schema: invoice_project; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON invoice_project.charge FOR EACH ROW EXECUTE FUNCTION invoice_project.resolves();


--
-- Name: item open_agenda; Type: TRIGGER; Schema: meeting; Owner: -
--

CREATE TRIGGER open_agenda BEFORE INSERT OR DELETE OR UPDATE ON meeting.item FOR EACH ROW EXECUTE FUNCTION meeting.open_agenda();


--
-- Name: meeting stays_settled; Type: TRIGGER; Schema: meeting; Owner: -
--

CREATE TRIGGER stays_settled BEFORE UPDATE ON meeting.meeting FOR EACH ROW EXECUTE FUNCTION meeting.stays_settled();


--
-- Name: attendance resolves; Type: TRIGGER; Schema: meeting_membership; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON meeting_membership.attendance FOR EACH ROW EXECUTE FUNCTION meeting_membership.resolves();


--
-- Name: member freezes; Type: TRIGGER; Schema: membership; Owner: -
--

CREATE TRIGGER freezes AFTER UPDATE OF status ON membership.member FOR EACH ROW EXECUTE FUNCTION account_membership.freezes();


--
-- Name: member moves; Type: TRIGGER; Schema: membership; Owner: -
--

CREATE TRIGGER moves BEFORE UPDATE OF status ON membership.member FOR EACH ROW EXECUTE FUNCTION membership.moves();


--
-- Name: member signs; Type: TRIGGER; Schema: membership; Owner: -
--

CREATE TRIGGER signs AFTER UPDATE OF status ON membership.member FOR EACH ROW WHEN (((old.status = 'invited'::text) AND (new.status = 'active'::text))) EXECUTE FUNCTION membership.signs();


--
-- Name: member subscribes; Type: TRIGGER; Schema: membership; Owner: -
--

CREATE TRIGGER subscribes AFTER UPDATE OF status ON membership.member FOR EACH ROW EXECUTE FUNCTION account_membership_transaction.subscribes();


--
-- Name: member withdraws; Type: TRIGGER; Schema: membership; Owner: -
--

CREATE TRIGGER withdraws AFTER UPDATE OF status ON membership.member FOR EACH ROW EXECUTE FUNCTION account_membership_transaction.withdraws();


--
-- Name: share within; Type: TRIGGER; Schema: membership_project; Owner: -
--

CREATE TRIGGER within BEFORE INSERT ON membership_project.share FOR EACH ROW EXECUTE FUNCTION membership_project.within();


--
-- Name: assignment resolves; Type: TRIGGER; Schema: membership_task; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON membership_task.assignment FOR EACH ROW EXECUTE FUNCTION membership_task.resolves();


--
-- Name: part part_fixed; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER part_fixed BEFORE INSERT OR DELETE OR UPDATE ON patronage.part FOR EACH ROW EXECUTE FUNCTION patronage.part_fixed();


--
-- Name: distribution parts_by_pay; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER parts_by_pay AFTER UPDATE OF approved ON patronage.distribution FOR EACH ROW EXECUTE FUNCTION patronage_payslip.parts();


--
-- Name: distribution parts_by_time; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER parts_by_time AFTER UPDATE OF approved ON patronage.distribution FOR EACH ROW EXECUTE FUNCTION patronage_timesheet.parts();


--
-- Name: share share_fixed; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER share_fixed BEFORE INSERT OR DELETE OR UPDATE ON patronage.share FOR EACH ROW EXECUTE FUNCTION patronage.share_fixed();


--
-- Name: terms stays_adopted; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER stays_adopted BEFORE DELETE OR UPDATE ON patronage.terms FOR EACH ROW EXECUTE FUNCTION patronage.stays_adopted();


--
-- Name: distribution stays_approved; Type: TRIGGER; Schema: patronage; Owner: -
--

CREATE TRIGGER stays_approved BEFORE UPDATE ON patronage.distribution FOR EACH ROW EXECUTE FUNCTION patronage.stays_approved();


--
-- Name: distribution employs; Type: TRIGGER; Schema: patronage_transaction; Owner: -
--

CREATE TRIGGER employs AFTER INSERT ON patronage_transaction.distribution FOR EACH ROW EXECUTE FUNCTION account_membership_patronage_transaction.employs();


--
-- Name: run once; Type: TRIGGER; Schema: payslip; Owner: -
--

CREATE TRIGGER once BEFORE INSERT ON payslip.run FOR EACH ROW EXECUTE FUNCTION payslip.once();


--
-- Name: payslip stays; Type: TRIGGER; Schema: payslip; Owner: -
--

CREATE TRIGGER stays BEFORE INSERT OR DELETE OR UPDATE ON payslip.payslip FOR EACH ROW EXECUTE FUNCTION payslip.stays();


--
-- Name: run stays; Type: TRIGGER; Schema: payslip; Owner: -
--

CREATE TRIGGER stays BEFORE UPDATE ON payslip.run FOR EACH ROW EXECUTE FUNCTION payslip.stays();


--
-- Name: payslip worker; Type: TRIGGER; Schema: payslip; Owner: -
--

CREATE TRIGGER worker BEFORE INSERT ON payslip.payslip FOR EACH ROW EXECUTE FUNCTION employment_payslip.whose();


--
-- Name: salary worker; Type: TRIGGER; Schema: payslip; Owner: -
--

CREATE TRIGGER worker BEFORE INSERT ON payslip.salary FOR EACH ROW EXECUTE FUNCTION employment_payslip.whose();


--
-- Name: posting withholds; Type: TRIGGER; Schema: payslip_transaction; Owner: -
--

CREATE TRIGGER withholds AFTER INSERT ON payslip_transaction.posting FOR EACH ROW EXECUTE FUNCTION account_membership_payslip_transaction.withholds();


--
-- Name: device stays; Type: TRIGGER; Schema: person; Owner: -
--

CREATE TRIGGER stays BEFORE UPDATE ON person.device FOR EACH ROW EXECUTE FUNCTION person.stays();


--
-- Name: milestone live; Type: TRIGGER; Schema: project; Owner: -
--

CREATE TRIGGER live BEFORE INSERT OR UPDATE ON project.milestone FOR EACH ROW EXECUTE FUNCTION project.live();


--
-- Name: project stays_archived; Type: TRIGGER; Schema: project; Owner: -
--

CREATE TRIGGER stays_archived BEFORE UPDATE ON project.project FOR EACH ROW EXECUTE FUNCTION project.stays_archived();


--
-- Name: filing resolves; Type: TRIGGER; Schema: project_task; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON project_task.filing FOR EACH ROW EXECUTE FUNCTION project_task.resolves();


--
-- Name: booking resolves; Type: TRIGGER; Schema: project_timesheet; Owner: -
--

CREATE TRIGGER resolves BEFORE INSERT OR UPDATE ON project_timesheet.booking FOR EACH ROW EXECUTE FUNCTION project_timesheet.resolves();


--
-- Name: entry open_period; Type: TRIGGER; Schema: timesheet; Owner: -
--

CREATE TRIGGER open_period BEFORE INSERT ON timesheet.entry FOR EACH ROW EXECUTE FUNCTION timesheet.open_period();


--
-- Name: period stays_approved; Type: TRIGGER; Schema: timesheet; Owner: -
--

CREATE TRIGGER stays_approved BEFORE UPDATE ON timesheet.period FOR EACH ROW EXECUTE FUNCTION timesheet.stays_approved();


--
-- Name: entry whose; Type: TRIGGER; Schema: timesheet; Owner: -
--

CREATE TRIGGER whose BEFORE INSERT ON timesheet.entry FOR EACH ROW EXECUTE FUNCTION membership_timesheet.whose();


--
-- Name: entry worker; Type: TRIGGER; Schema: timesheet; Owner: -
--

CREATE TRIGGER worker BEFORE INSERT ON timesheet.entry FOR EACH ROW EXECUTE FUNCTION employment_timesheet.whose();


--
-- Name: entry balances; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE CONSTRAINT TRIGGER balances AFTER INSERT ON transaction.entry DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION transaction.balances();


--
-- Name: line balances; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE CONSTRAINT TRIGGER balances AFTER INSERT ON transaction.line DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION transaction.balances();


--
-- Name: entry numbers; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE TRIGGER numbers BEFORE INSERT ON transaction.entry FOR EACH ROW EXECUTE FUNCTION transaction.numbers();


--
-- Name: entry permanent; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE TRIGGER permanent BEFORE DELETE OR UPDATE ON transaction.entry FOR EACH ROW EXECUTE FUNCTION transaction.permanent();


--
-- Name: line permanent; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE TRIGGER permanent BEFORE DELETE OR UPDATE ON transaction.line FOR EACH ROW EXECUTE FUNCTION transaction.permanent();


--
-- Name: line posts; Type: TRIGGER; Schema: transaction; Owner: -
--

CREATE TRIGGER posts BEFORE INSERT ON transaction.line FOR EACH ROW EXECUTE FUNCTION account_transaction.posts();


--
-- Name: account account_parent_fkey; Type: FK CONSTRAINT; Schema: account; Owner: -
--

ALTER TABLE ONLY account.account
    ADD CONSTRAINT account_parent_fkey FOREIGN KEY (parent) REFERENCES account.account(code);


--
-- Name: circle circle_parent_fkey; Type: FK CONSTRAINT; Schema: circle; Owner: -
--

ALTER TABLE ONLY circle.circle
    ADD CONSTRAINT circle_parent_fkey FOREIGN KEY (parent) REFERENCES circle.circle(id);


--
-- Name: mandate mandate_role_fkey; Type: FK CONSTRAINT; Schema: circle; Owner: -
--

ALTER TABLE ONLY circle.mandate
    ADD CONSTRAINT mandate_role_fkey FOREIGN KEY (role) REFERENCES circle.role(id);


--
-- Name: client client_parent_fkey; Type: FK CONSTRAINT; Schema: client; Owner: -
--

ALTER TABLE ONLY client.client
    ADD CONSTRAINT client_parent_fkey FOREIGN KEY (parent) REFERENCES client.client(id);


--
-- Name: decision decision_procedure_rule_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.decision
    ADD CONSTRAINT decision_procedure_rule_fkey FOREIGN KEY (procedure, rule) REFERENCES decision.procedure(id, rule);


--
-- Name: message message_decision_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.message
    ADD CONSTRAINT message_decision_fkey FOREIGN KEY (decision) REFERENCES decision.decision(id);


--
-- Name: message message_decision_reply_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.message
    ADD CONSTRAINT message_decision_reply_fkey FOREIGN KEY (decision, reply) REFERENCES decision.message(decision, receipt);


--
-- Name: motion motion_decision_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.motion
    ADD CONSTRAINT motion_decision_fkey FOREIGN KEY (decision) REFERENCES decision.decision(id);


--
-- Name: motion motion_kind_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.motion
    ADD CONSTRAINT motion_kind_fkey FOREIGN KEY (kind) REFERENCES decision.kind(kind);


--
-- Name: vote vote_decision_fkey; Type: FK CONSTRAINT; Schema: decision; Owner: -
--

ALTER TABLE ONLY decision.vote
    ADD CONSTRAINT vote_decision_fkey FOREIGN KEY (decision) REFERENCES decision.decision(id);


--
-- Name: adoption adoption_document_fkey; Type: FK CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.adoption
    ADD CONSTRAINT adoption_document_fkey FOREIGN KEY (document) REFERENCES document.document(id);


--
-- Name: comment comment_version_fkey; Type: FK CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.comment
    ADD CONSTRAINT comment_version_fkey FOREIGN KEY (version) REFERENCES document.version(id);


--
-- Name: update update_document_fkey; Type: FK CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.update
    ADD CONSTRAINT update_document_fkey FOREIGN KEY (document) REFERENCES document.document(id);


--
-- Name: version version_document_fkey; Type: FK CONSTRAINT; Schema: document; Owner: -
--

ALTER TABLE ONLY document.version
    ADD CONSTRAINT version_document_fkey FOREIGN KEY (document) REFERENCES document.document(id);


--
-- Name: invoice invoice_series_fkey; Type: FK CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.invoice
    ADD CONSTRAINT invoice_series_fkey FOREIGN KEY (series) REFERENCES invoice.series(name);


--
-- Name: line line_invoice_fkey; Type: FK CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.line
    ADD CONSTRAINT line_invoice_fkey FOREIGN KEY (invoice) REFERENCES invoice.invoice(id);


--
-- Name: payment payment_invoice_fkey; Type: FK CONSTRAINT; Schema: invoice; Owner: -
--

ALTER TABLE ONLY invoice.payment
    ADD CONSTRAINT payment_invoice_fkey FOREIGN KEY (invoice) REFERENCES invoice.invoice(id);


--
-- Name: item item_meeting_fkey; Type: FK CONSTRAINT; Schema: meeting; Owner: -
--

ALTER TABLE ONLY meeting.item
    ADD CONSTRAINT item_meeting_fkey FOREIGN KEY (meeting) REFERENCES meeting.meeting(id);


--
-- Name: link link_member_fkey; Type: FK CONSTRAINT; Schema: membership; Owner: -
--

ALTER TABLE ONLY membership.link
    ADD CONSTRAINT link_member_fkey FOREIGN KEY (member) REFERENCES membership.member(address);


--
-- Name: part part_distribution_fkey; Type: FK CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.part
    ADD CONSTRAINT part_distribution_fkey FOREIGN KEY (distribution) REFERENCES patronage.distribution(id);


--
-- Name: share share_distribution_fkey; Type: FK CONSTRAINT; Schema: patronage; Owner: -
--

ALTER TABLE ONLY patronage.share
    ADD CONSTRAINT share_distribution_fkey FOREIGN KEY (distribution) REFERENCES patronage.distribution(id);


--
-- Name: payslip payslip_month_fkey; Type: FK CONSTRAINT; Schema: payslip; Owner: -
--

ALTER TABLE ONLY payslip.payslip
    ADD CONSTRAINT payslip_month_fkey FOREIGN KEY (month) REFERENCES payslip.run(month);


--
-- Name: device device_enrolled_by_fkey; Type: FK CONSTRAINT; Schema: person; Owner: -
--

ALTER TABLE ONLY person.device
    ADD CONSTRAINT device_enrolled_by_fkey FOREIGN KEY (enrolled_by) REFERENCES person.device(key);


--
-- Name: milestone milestone_project_fkey; Type: FK CONSTRAINT; Schema: project; Owner: -
--

ALTER TABLE ONLY project.milestone
    ADD CONSTRAINT milestone_project_fkey FOREIGN KEY (project) REFERENCES project.project(id);


--
-- Name: entry entry_corrects_fkey; Type: FK CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.entry
    ADD CONSTRAINT entry_corrects_fkey FOREIGN KEY (corrects) REFERENCES transaction.entry(id);


--
-- Name: line line_entry_fkey; Type: FK CONSTRAINT; Schema: transaction; Owner: -
--

ALTER TABLE ONLY transaction.line
    ADD CONSTRAINT line_entry_fkey FOREIGN KEY (entry) REFERENCES transaction.entry(id);


--
-- Name: account; Type: ROW SECURITY; Schema: account; Owner: -
--

ALTER TABLE account.account ENABLE ROW LEVEL SECURITY;

--
-- Name: account changes; Type: POLICY; Schema: account; Owner: -
--

CREATE POLICY changes ON account.account FOR UPDATE TO cella_app USING (true);


--
-- Name: account reads; Type: POLICY; Schema: account; Owner: -
--

CREATE POLICY reads ON account.account FOR SELECT TO cella_app USING (((holder IS NULL) OR ( SELECT cella.sees('account'::text) AS sees) OR (holder = cella.reader()) OR cella.reaches('account'::text, holder)));


--
-- Name: account rules; Type: POLICY; Schema: account; Owner: -
--

CREATE POLICY rules ON account.account FOR SELECT TO cella_rules USING (true);


--
-- Name: account writes; Type: POLICY; Schema: account; Owner: -
--

CREATE POLICY writes ON account.account FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: allowance; Type: ROW SECURITY; Schema: account_membership; Owner: -
--

ALTER TABLE account_membership.allowance ENABLE ROW LEVEL SECURITY;

--
-- Name: allowance reads; Type: POLICY; Schema: account_membership; Owner: -
--

CREATE POLICY reads ON account_membership.allowance FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: allowance rules; Type: POLICY; Schema: account_membership; Owner: -
--

CREATE POLICY rules ON account_membership.allowance FOR SELECT TO cella_rules USING (true);


--
-- Name: credit; Type: ROW SECURITY; Schema: account_membership_patronage_transaction; Owner: -
--

ALTER TABLE account_membership_patronage_transaction.credit ENABLE ROW LEVEL SECURITY;

--
-- Name: credit reads; Type: POLICY; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_patronage_transaction.credit FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: credit rules; Type: POLICY; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_patronage_transaction.credit FOR SELECT TO cella_rules USING (true);


--
-- Name: credit writes; Type: POLICY; Schema: account_membership_patronage_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_patronage_transaction.credit FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: plan changes; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY changes ON account_membership_payslip_transaction.plan FOR UPDATE TO cella_app USING (true);


--
-- Name: plan; Type: ROW SECURITY; Schema: account_membership_payslip_transaction; Owner: -
--

ALTER TABLE account_membership_payslip_transaction.plan ENABLE ROW LEVEL SECURITY;

--
-- Name: plan reads; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_payslip_transaction.plan FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: withheld reads; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_payslip_transaction.withheld FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: plan rules; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_payslip_transaction.plan FOR SELECT TO cella_rules USING (true);


--
-- Name: withheld rules; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_payslip_transaction.withheld FOR SELECT TO cella_rules USING (true);


--
-- Name: withheld; Type: ROW SECURITY; Schema: account_membership_payslip_transaction; Owner: -
--

ALTER TABLE account_membership_payslip_transaction.withheld ENABLE ROW LEVEL SECURITY;

--
-- Name: plan writes; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_payslip_transaction.plan FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: withheld writes; Type: POLICY; Schema: account_membership_payslip_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_payslip_transaction.withheld FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: repayment changes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY changes ON account_membership_transaction.repayment FOR UPDATE TO cella_app USING (true);


--
-- Name: subscription changes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY changes ON account_membership_transaction.subscription FOR UPDATE TO cella_app USING (true);


--
-- Name: draw; Type: ROW SECURITY; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE account_membership_transaction.draw ENABLE ROW LEVEL SECURITY;

--
-- Name: paid; Type: ROW SECURITY; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE account_membership_transaction.paid ENABLE ROW LEVEL SECURITY;

--
-- Name: draw reads; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_transaction.draw FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: paid reads; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_transaction.paid FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: repayment reads; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_transaction.repayment FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: subscription reads; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY reads ON account_membership_transaction.subscription FOR SELECT TO cella_app USING ((( SELECT cella.sees('account'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('account'::text, member)));


--
-- Name: repayment; Type: ROW SECURITY; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE account_membership_transaction.repayment ENABLE ROW LEVEL SECURITY;

--
-- Name: draw rules; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_transaction.draw FOR SELECT TO cella_rules USING (true);


--
-- Name: paid rules; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_transaction.paid FOR SELECT TO cella_rules USING (true);


--
-- Name: repayment rules; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_transaction.repayment FOR SELECT TO cella_rules USING (true);


--
-- Name: subscription rules; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY rules ON account_membership_transaction.subscription FOR SELECT TO cella_rules USING (true);


--
-- Name: subscription; Type: ROW SECURITY; Schema: account_membership_transaction; Owner: -
--

ALTER TABLE account_membership_transaction.subscription ENABLE ROW LEVEL SECURITY;

--
-- Name: draw writes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_transaction.draw FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: paid writes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_transaction.paid FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: repayment writes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_transaction.repayment FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: subscription writes; Type: POLICY; Schema: account_membership_transaction; Owner: -
--

CREATE POLICY writes ON account_membership_transaction.subscription FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: file; Type: ROW SECURITY; Schema: file; Owner: -
--

ALTER TABLE file.file ENABLE ROW LEVEL SECURITY;

--
-- Name: file reads; Type: POLICY; Schema: file; Owner: -
--

CREATE POLICY reads ON file.file FOR SELECT TO cella_app USING (((class = 'none'::text) OR ( SELECT cella.sees('file'::text) AS sees) OR ((cella.reader() = subject) OR (cella.reader() = uploader)) OR cella.reaches('file'::text, class)));


--
-- Name: file rules; Type: POLICY; Schema: file; Owner: -
--

CREATE POLICY rules ON file.file FOR SELECT TO cella_rules USING (true);


--
-- Name: file writes; Type: POLICY; Schema: file; Owner: -
--

CREATE POLICY writes ON file.file FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: part; Type: ROW SECURITY; Schema: patronage; Owner: -
--

ALTER TABLE patronage.part ENABLE ROW LEVEL SECURITY;

--
-- Name: part reads; Type: POLICY; Schema: patronage; Owner: -
--

CREATE POLICY reads ON patronage.part FOR SELECT TO cella_app USING ((( SELECT cella.sees('patronage'::text) AS sees) OR (worker = cella.reader()) OR cella.reaches('patronage'::text, worker)));


--
-- Name: part rules; Type: POLICY; Schema: patronage; Owner: -
--

CREATE POLICY rules ON patronage.part FOR SELECT TO cella_rules USING (true);


--
-- Name: part writes; Type: POLICY; Schema: patronage; Owner: -
--

CREATE POLICY writes ON patronage.part FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: payslip changes; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY changes ON payslip.payslip FOR UPDATE TO cella_app USING (true);


--
-- Name: run changes; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY changes ON payslip.run FOR UPDATE TO cella_app USING (true);


--
-- Name: payslip; Type: ROW SECURITY; Schema: payslip; Owner: -
--

ALTER TABLE payslip.payslip ENABLE ROW LEVEL SECURITY;

--
-- Name: payslip reads; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY reads ON payslip.payslip FOR SELECT TO cella_app USING ((( SELECT cella.sees('payslip'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('payslip'::text, member)));


--
-- Name: run reads; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY reads ON payslip.run FOR SELECT TO cella_app USING ((( SELECT cella.sees('payslip'::text) AS sees) OR (EXISTS ( SELECT
   FROM payslip.payslip p
  WHERE ((p.month = run.month) AND (p.member = cella.reader()))))));


--
-- Name: salary reads; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY reads ON payslip.salary FOR SELECT TO cella_app USING ((( SELECT cella.sees('payslip'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('payslip'::text, member)));


--
-- Name: payslip rules; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY rules ON payslip.payslip FOR SELECT TO cella_rules USING (true);


--
-- Name: run rules; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY rules ON payslip.run FOR SELECT TO cella_rules USING (true);


--
-- Name: salary rules; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY rules ON payslip.salary FOR SELECT TO cella_rules USING (true);


--
-- Name: run; Type: ROW SECURITY; Schema: payslip; Owner: -
--

ALTER TABLE payslip.run ENABLE ROW LEVEL SECURITY;

--
-- Name: salary; Type: ROW SECURITY; Schema: payslip; Owner: -
--

ALTER TABLE payslip.salary ENABLE ROW LEVEL SECURITY;

--
-- Name: payslip writes; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY writes ON payslip.payslip FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: run writes; Type: POLICY; Schema: payslip; Owner: -
--

CREATE POLICY writes ON payslip.run FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: period changes; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY changes ON timesheet.period FOR UPDATE TO cella_app USING (true);


--
-- Name: entry; Type: ROW SECURITY; Schema: timesheet; Owner: -
--

ALTER TABLE timesheet.entry ENABLE ROW LEVEL SECURITY;

--
-- Name: period; Type: ROW SECURITY; Schema: timesheet; Owner: -
--

ALTER TABLE timesheet.period ENABLE ROW LEVEL SECURITY;

--
-- Name: entry reads; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY reads ON timesheet.entry FOR SELECT TO cella_app USING ((( SELECT cella.sees('timesheet'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('timesheet'::text, member)));


--
-- Name: period reads; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY reads ON timesheet.period FOR SELECT TO cella_app USING ((( SELECT cella.sees('timesheet'::text) AS sees) OR (member = cella.reader()) OR cella.reaches('timesheet'::text, member)));


--
-- Name: entry rules; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY rules ON timesheet.entry FOR SELECT TO cella_rules USING (true);


--
-- Name: period rules; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY rules ON timesheet.period FOR SELECT TO cella_rules USING (true);


--
-- Name: entry writes; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY writes ON timesheet.entry FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: period writes; Type: POLICY; Schema: timesheet; Owner: -
--

CREATE POLICY writes ON timesheet.period FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: entry; Type: ROW SECURITY; Schema: transaction; Owner: -
--

ALTER TABLE transaction.entry ENABLE ROW LEVEL SECURITY;

--
-- Name: line; Type: ROW SECURITY; Schema: transaction; Owner: -
--

ALTER TABLE transaction.line ENABLE ROW LEVEL SECURITY;

--
-- Name: entry reads; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY reads ON transaction.entry FOR SELECT TO cella_app USING ((( SELECT cella.sees('transaction'::text) AS sees) OR (EXISTS ( SELECT
   FROM transaction.line l
  WHERE (l.entry = entry.id)))));


--
-- Name: line reads; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY reads ON transaction.line FOR SELECT TO cella_app USING ((( SELECT cella.sees('transaction'::text) AS sees) OR cella.reaches('transaction'::text, account)));


--
-- Name: entry rules; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY rules ON transaction.entry FOR SELECT TO cella_rules USING (true);


--
-- Name: line rules; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY rules ON transaction.line FOR SELECT TO cella_rules USING (true);


--
-- Name: entry writes; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY writes ON transaction.entry FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: line writes; Type: POLICY; Schema: transaction; Owner: -
--

CREATE POLICY writes ON transaction.line FOR INSERT TO cella_app WITH CHECK (true);


--
-- Name: SCHEMA account; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account TO cella_app;
GRANT USAGE ON SCHEMA account TO cella_rules;


--
-- Name: SCHEMA account_decision; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_decision TO cella_app;
GRANT USAGE ON SCHEMA account_decision TO cella_rules;


--
-- Name: SCHEMA account_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_membership TO cella_app;
GRANT USAGE ON SCHEMA account_membership TO cella_rules;


--
-- Name: SCHEMA account_membership_patronage; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_membership_patronage TO cella_app;
GRANT USAGE ON SCHEMA account_membership_patronage TO cella_rules;


--
-- Name: SCHEMA account_membership_patronage_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_membership_patronage_transaction TO cella_app;
GRANT USAGE ON SCHEMA account_membership_patronage_transaction TO cella_rules;


--
-- Name: SCHEMA account_membership_payslip_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_membership_payslip_transaction TO cella_app;
GRANT USAGE ON SCHEMA account_membership_payslip_transaction TO cella_rules;


--
-- Name: SCHEMA account_membership_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_membership_transaction TO cella_app;
GRANT USAGE ON SCHEMA account_membership_transaction TO cella_rules;


--
-- Name: SCHEMA account_patronage; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_patronage TO cella_app;
GRANT USAGE ON SCHEMA account_patronage TO cella_rules;


--
-- Name: SCHEMA account_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA account_transaction TO cella_app;
GRANT USAGE ON SCHEMA account_transaction TO cella_rules;


--
-- Name: SCHEMA cella; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA cella TO cella_app;
GRANT USAGE ON SCHEMA cella TO cella_rules;


--
-- Name: SCHEMA circle; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle TO cella_app;
GRANT USAGE ON SCHEMA circle TO cella_rules;


--
-- Name: SCHEMA circle_decision; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_decision TO cella_app;
GRANT USAGE ON SCHEMA circle_decision TO cella_rules;


--
-- Name: SCHEMA circle_decision_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_decision_membership TO cella_app;
GRANT USAGE ON SCHEMA circle_decision_membership TO cella_rules;


--
-- Name: SCHEMA circle_expense_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_expense_membership TO cella_app;
GRANT USAGE ON SCHEMA circle_expense_membership TO cella_rules;


--
-- Name: SCHEMA circle_file_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_file_membership TO cella_app;
GRANT USAGE ON SCHEMA circle_file_membership TO cella_rules;


--
-- Name: SCHEMA circle_meeting; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_meeting TO cella_app;
GRANT USAGE ON SCHEMA circle_meeting TO cella_rules;


--
-- Name: SCHEMA circle_meeting_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_meeting_membership TO cella_app;
GRANT USAGE ON SCHEMA circle_meeting_membership TO cella_rules;


--
-- Name: SCHEMA circle_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_membership TO cella_app;
GRANT USAGE ON SCHEMA circle_membership TO cella_rules;


--
-- Name: SCHEMA circle_membership_project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_membership_project TO cella_app;
GRANT USAGE ON SCHEMA circle_membership_project TO cella_rules;


--
-- Name: SCHEMA circle_membership_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA circle_membership_timesheet TO cella_app;
GRANT USAGE ON SCHEMA circle_membership_timesheet TO cella_rules;


--
-- Name: SCHEMA client; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA client TO cella_app;
GRANT USAGE ON SCHEMA client TO cella_rules;


--
-- Name: SCHEMA client_invoice; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA client_invoice TO cella_app;
GRANT USAGE ON SCHEMA client_invoice TO cella_rules;


--
-- Name: SCHEMA client_project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA client_project TO cella_app;
GRANT USAGE ON SCHEMA client_project TO cella_rules;


--
-- Name: SCHEMA decision; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision TO cella_app;
GRANT USAGE ON SCHEMA decision TO cella_rules;


--
-- Name: SCHEMA decision_document; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision_document TO cella_app;
GRANT USAGE ON SCHEMA decision_document TO cella_rules;


--
-- Name: SCHEMA decision_employment_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision_employment_membership TO cella_app;
GRANT USAGE ON SCHEMA decision_employment_membership TO cella_rules;


--
-- Name: SCHEMA decision_meeting; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision_meeting TO cella_app;
GRANT USAGE ON SCHEMA decision_meeting TO cella_rules;


--
-- Name: SCHEMA decision_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision_membership TO cella_app;
GRANT USAGE ON SCHEMA decision_membership TO cella_rules;


--
-- Name: SCHEMA decision_patronage; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA decision_patronage TO cella_app;
GRANT USAGE ON SCHEMA decision_patronage TO cella_rules;


--
-- Name: SCHEMA document; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA document TO cella_app;
GRANT USAGE ON SCHEMA document TO cella_rules;


--
-- Name: SCHEMA document_meeting; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA document_meeting TO cella_app;
GRANT USAGE ON SCHEMA document_meeting TO cella_rules;


--
-- Name: SCHEMA document_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA document_membership TO cella_app;
GRANT USAGE ON SCHEMA document_membership TO cella_rules;


--
-- Name: SCHEMA employment; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment TO cella_app;
GRANT USAGE ON SCHEMA employment TO cella_rules;


--
-- Name: SCHEMA employment_file; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment_file TO cella_app;
GRANT USAGE ON SCHEMA employment_file TO cella_rules;


--
-- Name: SCHEMA employment_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment_membership TO cella_app;
GRANT USAGE ON SCHEMA employment_membership TO cella_rules;


--
-- Name: SCHEMA employment_payslip; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment_payslip TO cella_app;
GRANT USAGE ON SCHEMA employment_payslip TO cella_rules;


--
-- Name: SCHEMA employment_project_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment_project_timesheet TO cella_app;
GRANT USAGE ON SCHEMA employment_project_timesheet TO cella_rules;


--
-- Name: SCHEMA employment_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA employment_timesheet TO cella_app;
GRANT USAGE ON SCHEMA employment_timesheet TO cella_rules;


--
-- Name: SCHEMA expense; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense TO cella_app;
GRANT USAGE ON SCHEMA expense TO cella_rules;


--
-- Name: SCHEMA expense_file; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense_file TO cella_app;
GRANT USAGE ON SCHEMA expense_file TO cella_rules;


--
-- Name: SCHEMA expense_invoice_project_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense_invoice_project_timesheet TO cella_app;
GRANT USAGE ON SCHEMA expense_invoice_project_timesheet TO cella_rules;


--
-- Name: SCHEMA expense_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense_membership TO cella_app;
GRANT USAGE ON SCHEMA expense_membership TO cella_rules;


--
-- Name: SCHEMA expense_project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense_project TO cella_app;
GRANT USAGE ON SCHEMA expense_project TO cella_rules;


--
-- Name: SCHEMA expense_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA expense_transaction TO cella_app;
GRANT USAGE ON SCHEMA expense_transaction TO cella_rules;


--
-- Name: SCHEMA file; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA file TO cella_app;
GRANT USAGE ON SCHEMA file TO cella_rules;


--
-- Name: SCHEMA file_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA file_membership TO cella_app;
GRANT USAGE ON SCHEMA file_membership TO cella_rules;


--
-- Name: SCHEMA import; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA import TO cella_app;
GRANT USAGE ON SCHEMA import TO cella_rules;


--
-- Name: SCHEMA invoice; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA invoice TO cella_app;
GRANT USAGE ON SCHEMA invoice TO cella_rules;


--
-- Name: SCHEMA invoice_project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA invoice_project TO cella_app;
GRANT USAGE ON SCHEMA invoice_project TO cella_rules;


--
-- Name: SCHEMA invoice_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA invoice_transaction TO cella_app;
GRANT USAGE ON SCHEMA invoice_transaction TO cella_rules;


--
-- Name: SCHEMA meeting; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA meeting TO cella_app;
GRANT USAGE ON SCHEMA meeting TO cella_rules;


--
-- Name: SCHEMA meeting_membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA meeting_membership TO cella_app;
GRANT USAGE ON SCHEMA meeting_membership TO cella_rules;


--
-- Name: SCHEMA membership; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA membership TO cella_app;
GRANT USAGE ON SCHEMA membership TO cella_rules;


--
-- Name: SCHEMA membership_project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA membership_project TO cella_app;
GRANT USAGE ON SCHEMA membership_project TO cella_rules;


--
-- Name: SCHEMA membership_task; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA membership_task TO cella_app;
GRANT USAGE ON SCHEMA membership_task TO cella_rules;


--
-- Name: SCHEMA membership_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA membership_timesheet TO cella_app;
GRANT USAGE ON SCHEMA membership_timesheet TO cella_rules;


--
-- Name: SCHEMA patronage; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA patronage TO cella_app;
GRANT USAGE ON SCHEMA patronage TO cella_rules;


--
-- Name: SCHEMA patronage_payslip; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA patronage_payslip TO cella_app;
GRANT USAGE ON SCHEMA patronage_payslip TO cella_rules;


--
-- Name: SCHEMA patronage_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA patronage_timesheet TO cella_app;
GRANT USAGE ON SCHEMA patronage_timesheet TO cella_rules;


--
-- Name: SCHEMA patronage_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA patronage_transaction TO cella_app;
GRANT USAGE ON SCHEMA patronage_transaction TO cella_rules;


--
-- Name: SCHEMA payslip; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA payslip TO cella_app;
GRANT USAGE ON SCHEMA payslip TO cella_rules;


--
-- Name: SCHEMA payslip_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA payslip_timesheet TO cella_app;
GRANT USAGE ON SCHEMA payslip_timesheet TO cella_rules;


--
-- Name: SCHEMA payslip_transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA payslip_transaction TO cella_app;
GRANT USAGE ON SCHEMA payslip_transaction TO cella_rules;


--
-- Name: SCHEMA person; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA person TO cella_app;
GRANT USAGE ON SCHEMA person TO cella_rules;


--
-- Name: SCHEMA project; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA project TO cella_app;
GRANT USAGE ON SCHEMA project TO cella_rules;


--
-- Name: SCHEMA project_task; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA project_task TO cella_app;
GRANT USAGE ON SCHEMA project_task TO cella_rules;


--
-- Name: SCHEMA project_timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA project_timesheet TO cella_app;
GRANT USAGE ON SCHEMA project_timesheet TO cella_rules;


--
-- Name: SCHEMA task; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA task TO cella_app;
GRANT USAGE ON SCHEMA task TO cella_rules;


--
-- Name: SCHEMA timesheet; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA timesheet TO cella_app;
GRANT USAGE ON SCHEMA timesheet TO cella_rules;


--
-- Name: SCHEMA transaction; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA transaction TO cella_app;
GRANT USAGE ON SCHEMA transaction TO cella_rules;


--
-- Name: TABLE terms; Type: ACL; Schema: account; Owner: -
--

GRANT SELECT ON TABLE account.terms TO cella_app;
GRANT SELECT ON TABLE account.terms TO cella_rules;


--
-- Name: COLUMN terms.adopted; Type: ACL; Schema: account; Owner: -
--

GRANT UPDATE(adopted) ON TABLE account.terms TO cella_app;


--
-- Name: TABLE period; Type: ACL; Schema: account; Owner: -
--

GRANT SELECT ON TABLE account.period TO cella_app;
GRANT SELECT ON TABLE account.period TO cella_rules;


--
-- Name: COLUMN period.closed; Type: ACL; Schema: account; Owner: -
--

GRANT UPDATE(closed) ON TABLE account.period TO cella_app;


--
-- Name: TABLE rubric; Type: ACL; Schema: account; Owner: -
--

GRANT SELECT ON TABLE account.rubric TO cella_app;
GRANT SELECT ON TABLE account.rubric TO cella_rules;


--
-- Name: TABLE adoption; Type: ACL; Schema: account_decision; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_decision.adoption TO cella_app;
GRANT SELECT ON TABLE account_decision.adoption TO cella_rules;


--
-- Name: TABLE decision; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE decision.decision TO cella_app;
GRANT SELECT ON TABLE decision.decision TO cella_rules;


--
-- Name: TABLE motion; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision.motion TO cella_app;
GRANT SELECT ON TABLE decision.motion TO cella_rules;


--
-- Name: TABLE credit; Type: ACL; Schema: account_membership_patronage_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_patronage_transaction.credit TO cella_app;
GRANT SELECT ON TABLE account_membership_patronage_transaction.credit TO cella_rules;


--
-- Name: TABLE terms; Type: ACL; Schema: patronage; Owner: -
--

GRANT SELECT ON TABLE patronage.terms TO cella_app;
GRANT SELECT ON TABLE patronage.terms TO cella_rules;


--
-- Name: COLUMN terms.adopted; Type: ACL; Schema: patronage; Owner: -
--

GRANT UPDATE(adopted) ON TABLE patronage.terms TO cella_app;


--
-- Name: TABLE distribution; Type: ACL; Schema: patronage; Owner: -
--

GRANT SELECT ON TABLE patronage.distribution TO cella_app;
GRANT SELECT ON TABLE patronage.distribution TO cella_rules;


--
-- Name: COLUMN distribution.approved; Type: ACL; Schema: patronage; Owner: -
--

GRANT UPDATE(approved) ON TABLE patronage.distribution TO cella_app;


--
-- Name: COLUMN distribution.distributed; Type: ACL; Schema: patronage; Owner: -
--

GRANT UPDATE(distributed) ON TABLE patronage.distribution TO cella_app;


--
-- Name: TABLE share; Type: ACL; Schema: patronage; Owner: -
--

GRANT SELECT ON TABLE patronage.share TO cella_app;
GRANT SELECT ON TABLE patronage.share TO cella_rules;


--
-- Name: TABLE account; Type: ACL; Schema: account; Owner: -
--

GRANT SELECT,INSERT ON TABLE account.account TO cella_app;
GRANT SELECT ON TABLE account.account TO cella_rules;


--
-- Name: COLUMN account.frozen; Type: ACL; Schema: account; Owner: -
--

GRANT UPDATE(frozen) ON TABLE account.account TO cella_app;


--
-- Name: TABLE member; Type: ACL; Schema: membership; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE membership.member TO cella_app;
GRANT SELECT ON TABLE membership.member TO cella_rules;


--
-- Name: TABLE part; Type: ACL; Schema: patronage; Owner: -
--

GRANT SELECT,INSERT ON TABLE patronage.part TO cella_app;
GRANT SELECT ON TABLE patronage.part TO cella_rules;


--
-- Name: TABLE statement; Type: ACL; Schema: patronage; Owner: -
--

GRANT SELECT ON TABLE patronage.statement TO cella_app;
GRANT SELECT ON TABLE patronage.statement TO cella_rules;


--
-- Name: TABLE split; Type: ACL; Schema: account_membership_patronage; Owner: -
--

GRANT SELECT ON TABLE account_membership_patronage.split TO cella_app;
GRANT SELECT ON TABLE account_membership_patronage.split TO cella_rules;


--
-- Name: TABLE distribution; Type: ACL; Schema: patronage_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE patronage_transaction.distribution TO cella_app;
GRANT SELECT ON TABLE patronage_transaction.distribution TO cella_rules;


--
-- Name: TABLE line; Type: ACL; Schema: transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE transaction.line TO cella_app;
GRANT SELECT ON TABLE transaction.line TO cella_rules;


--
-- Name: TABLE reading; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT ON TABLE cella.reading TO PUBLIC;


--
-- Name: TABLE entry; Type: ACL; Schema: transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE transaction.entry TO cella_app;
GRANT SELECT ON TABLE transaction.entry TO cella_rules;


--
-- Name: TABLE allowance; Type: ACL; Schema: account_membership; Owner: -
--

GRANT SELECT ON TABLE account_membership.allowance TO cella_app;
GRANT SELECT ON TABLE account_membership.allowance TO cella_rules;


--
-- Name: TABLE person; Type: ACL; Schema: person; Owner: -
--

GRANT SELECT,INSERT ON TABLE person.person TO cella_app;
GRANT SELECT ON TABLE person.person TO cella_rules;


--
-- Name: COLUMN person.name; Type: ACL; Schema: person; Owner: -
--

GRANT UPDATE(name) ON TABLE person.person TO cella_app;


--
-- Name: COLUMN person.email; Type: ACL; Schema: person; Owner: -
--

GRANT UPDATE(email) ON TABLE person.person TO cella_app;


--
-- Name: COLUMN person.phone; Type: ACL; Schema: person; Owner: -
--

GRANT UPDATE(phone) ON TABLE person.person TO cella_app;


--
-- Name: TABLE capital; Type: ACL; Schema: account_membership; Owner: -
--

GRANT SELECT ON TABLE account_membership.capital TO cella_app;
GRANT SELECT ON TABLE account_membership.capital TO cella_rules;


--
-- Name: TABLE balance; Type: ACL; Schema: account_transaction; Owner: -
--

GRANT SELECT ON TABLE account_transaction.balance TO cella_app;
GRANT SELECT ON TABLE account_transaction.balance TO cella_rules;


--
-- Name: TABLE plan; Type: ACL; Schema: account_membership_payslip_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_payslip_transaction.plan TO cella_app;
GRANT SELECT ON TABLE account_membership_payslip_transaction.plan TO cella_rules;


--
-- Name: COLUMN plan.instalments; Type: ACL; Schema: account_membership_payslip_transaction; Owner: -
--

GRANT UPDATE(instalments) ON TABLE account_membership_payslip_transaction.plan TO cella_app;


--
-- Name: COLUMN plan.each; Type: ACL; Schema: account_membership_payslip_transaction; Owner: -
--

GRANT UPDATE(each) ON TABLE account_membership_payslip_transaction.plan TO cella_app;


--
-- Name: COLUMN plan.since; Type: ACL; Schema: account_membership_payslip_transaction; Owner: -
--

GRANT UPDATE(since) ON TABLE account_membership_payslip_transaction.plan TO cella_app;


--
-- Name: TABLE withheld; Type: ACL; Schema: account_membership_payslip_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_payslip_transaction.withheld TO cella_app;
GRANT SELECT ON TABLE account_membership_payslip_transaction.withheld TO cella_rules;


--
-- Name: TABLE paid; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_transaction.paid TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.paid TO cella_rules;


--
-- Name: TABLE subscription; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_transaction.subscription TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.subscription TO cella_rules;


--
-- Name: COLUMN subscription.amount; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT UPDATE(amount) ON TABLE account_membership_transaction.subscription TO cella_app;


--
-- Name: COLUMN subscription.cancelled; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT UPDATE(cancelled) ON TABLE account_membership_transaction.subscription TO cella_app;


--
-- Name: TABLE called; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT ON TABLE account_membership_transaction.called TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.called TO cella_rules;


--
-- Name: TABLE payslip; Type: ACL; Schema: payslip; Owner: -
--

GRANT SELECT,INSERT ON TABLE payslip.payslip TO cella_app;
GRANT SELECT ON TABLE payslip.payslip TO cella_rules;


--
-- Name: COLUMN payslip.minutes; Type: ACL; Schema: payslip; Owner: -
--

GRANT UPDATE(minutes) ON TABLE payslip.payslip TO cella_app;


--
-- Name: TABLE posting; Type: ACL; Schema: payslip_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE payslip_transaction.posting TO cella_app;
GRANT SELECT ON TABLE payslip_transaction.posting TO cella_rules;


--
-- Name: TABLE draw; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_transaction.draw TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.draw TO cella_rules;


--
-- Name: TABLE drawn; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT ON TABLE account_membership_transaction.drawn TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.drawn TO cella_rules;


--
-- Name: TABLE repayment; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE account_membership_transaction.repayment TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.repayment TO cella_rules;


--
-- Name: COLUMN repayment.entry; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT UPDATE(entry) ON TABLE account_membership_transaction.repayment TO cella_app;


--
-- Name: COLUMN repayment.paid; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT UPDATE(paid) ON TABLE account_membership_transaction.repayment TO cella_app;


--
-- Name: FUNCTION disclosed(n bigint); Type: ACL; Schema: cella; Owner: -
--

REVOKE ALL ON FUNCTION cella.disclosed(n bigint) FROM PUBLIC;
GRANT ALL ON FUNCTION cella.disclosed(n bigint) TO cella_app;


--
-- Name: FUNCTION opened(n bigint); Type: ACL; Schema: cella; Owner: -
--

REVOKE ALL ON FUNCTION cella.opened(n bigint) FROM PUBLIC;


--
-- Name: FUNCTION receipt(); Type: ACL; Schema: cella; Owner: -
--

REVOKE ALL ON FUNCTION cella.receipt() FROM PUBLIC;
GRANT ALL ON FUNCTION cella.receipt() TO cella_app;


--
-- Name: FUNCTION submit(op text, payload jsonb, actor text, signed jsonb); Type: ACL; Schema: cella; Owner: -
--

REVOKE ALL ON FUNCTION cella.submit(op text, payload jsonb, actor text, signed jsonb) FROM PUBLIC;
GRANT ALL ON FUNCTION cella.submit(op text, payload jsonb, actor text, signed jsonb) TO cella_app;


--
-- Name: FUNCTION vault_sweep(); Type: ACL; Schema: cella; Owner: -
--

REVOKE ALL ON FUNCTION cella.vault_sweep() FROM PUBLIC;


--
-- Name: TABLE circle; Type: ACL; Schema: circle; Owner: -
--

GRANT SELECT ON TABLE circle.circle TO cella_app;
GRANT SELECT ON TABLE circle.circle TO cella_rules;


--
-- Name: COLUMN circle.parent; Type: ACL; Schema: circle; Owner: -
--

GRANT UPDATE(parent) ON TABLE circle.circle TO cella_app;


--
-- Name: COLUMN circle.path; Type: ACL; Schema: circle; Owner: -
--

GRANT UPDATE(path) ON TABLE circle.circle TO cella_app;


--
-- Name: TABLE mandate; Type: ACL; Schema: circle; Owner: -
--

GRANT SELECT,INSERT ON TABLE circle.mandate TO cella_app;
GRANT SELECT ON TABLE circle.mandate TO cella_rules;


--
-- Name: COLUMN mandate.revoked; Type: ACL; Schema: circle; Owner: -
--

GRANT UPDATE(revoked) ON TABLE circle.mandate TO cella_app;


--
-- Name: TABLE role; Type: ACL; Schema: circle; Owner: -
--

GRANT SELECT ON TABLE circle.role TO cella_app;
GRANT SELECT ON TABLE circle.role TO cella_rules;


--
-- Name: TABLE motion; Type: ACL; Schema: circle_decision; Owner: -
--

GRANT SELECT ON TABLE circle_decision.motion TO cella_app;
GRANT SELECT ON TABLE circle_decision.motion TO cella_rules;


--
-- Name: TABLE "position"; Type: ACL; Schema: circle_membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE circle_membership."position" TO cella_app;
GRANT SELECT ON TABLE circle_membership."position" TO cella_rules;


--
-- Name: COLUMN "position".until; Type: ACL; Schema: circle_membership; Owner: -
--

GRANT UPDATE(until) ON TABLE circle_membership."position" TO cella_app;


--
-- Name: TABLE motion; Type: ACL; Schema: decision_membership; Owner: -
--

GRANT SELECT ON TABLE decision_membership.motion TO cella_app;
GRANT SELECT ON TABLE decision_membership.motion TO cella_rules;


--
-- Name: TABLE counted; Type: ACL; Schema: circle_decision_membership; Owner: -
--

GRANT SELECT ON TABLE circle_decision_membership.counted TO cella_app;
GRANT SELECT ON TABLE circle_decision_membership.counted TO cella_rules;


--
-- Name: TABLE roll; Type: ACL; Schema: circle_decision_membership; Owner: -
--

GRANT SELECT ON TABLE circle_decision_membership.roll TO cella_app;
GRANT SELECT ON TABLE circle_decision_membership.roll TO cella_rules;


--
-- Name: TABLE vote; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision.vote TO cella_app;
GRANT SELECT ON TABLE decision.vote TO cella_rules;


--
-- Name: TABLE procedure; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT ON TABLE decision.procedure TO cella_app;
GRANT SELECT ON TABLE decision.procedure TO cella_rules;


--
-- Name: TABLE seating; Type: ACL; Schema: circle_decision_membership; Owner: -
--

GRANT SELECT ON TABLE circle_decision_membership.seating TO cella_app;
GRANT SELECT ON TABLE circle_decision_membership.seating TO cella_rules;


--
-- Name: SEQUENCE number; Type: ACL; Schema: expense; Owner: -
--

GRANT USAGE ON SEQUENCE expense.number TO cella_app;


--
-- Name: TABLE expense; Type: ACL; Schema: expense; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE expense.expense TO cella_app;
GRANT SELECT ON TABLE expense.expense TO cella_rules;


--
-- Name: TABLE opener; Type: ACL; Schema: circle_file_membership; Owner: -
--

GRANT SELECT ON TABLE circle_file_membership.opener TO cella_app;
GRANT SELECT ON TABLE circle_file_membership.opener TO cella_rules;


--
-- Name: SEQUENCE number; Type: ACL; Schema: file; Owner: -
--

GRANT USAGE ON SEQUENCE file.number TO cella_app;


--
-- Name: TABLE file; Type: ACL; Schema: file; Owner: -
--

GRANT SELECT,INSERT ON TABLE file.file TO cella_app;
GRANT SELECT ON TABLE file.file TO cella_rules;


--
-- Name: TABLE meeting; Type: ACL; Schema: meeting; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE meeting.meeting TO cella_app;
GRANT SELECT ON TABLE meeting.meeting TO cella_rules;


--
-- Name: TABLE project; Type: ACL; Schema: project; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE project.project TO cella_app;
GRANT SELECT ON TABLE project.project TO cella_rules;


--
-- Name: TABLE client; Type: ACL; Schema: client; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE client.client TO cella_app;
GRANT SELECT ON TABLE client.client TO cella_rules;


--
-- Name: TABLE message; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision.message TO cella_app;
GRANT SELECT ON TABLE decision.message TO cella_rules;


--
-- Name: TABLE adoption; Type: ACL; Schema: decision_document; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision_document.adoption TO cella_app;
GRANT SELECT ON TABLE decision_document.adoption TO cella_rules;


--
-- Name: TABLE version; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT,INSERT ON TABLE document.version TO cella_app;
GRANT SELECT ON TABLE document.version TO cella_rules;


--
-- Name: TABLE document; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT,INSERT ON TABLE document.document TO cella_app;
GRANT SELECT ON TABLE document.document TO cella_rules;


--
-- Name: TABLE adoption; Type: ACL; Schema: decision_patronage; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision_patronage.adoption TO cella_app;
GRANT SELECT ON TABLE decision_patronage.adoption TO cella_rules;


--
-- Name: TABLE approval; Type: ACL; Schema: decision_patronage; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision_patronage.approval TO cella_app;
GRANT SELECT ON TABLE decision_patronage.approval TO cella_rules;


--
-- Name: TABLE adoption; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT,INSERT ON TABLE document.adoption TO cella_app;
GRANT SELECT ON TABLE document.adoption TO cella_rules;


--
-- Name: TABLE minutes; Type: ACL; Schema: document_meeting; Owner: -
--

GRANT SELECT,INSERT ON TABLE document_meeting.minutes TO cella_app;
GRANT SELECT ON TABLE document_meeting.minutes TO cella_rules;


--
-- Name: TABLE reading; Type: ACL; Schema: document_membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE document_membership.reading TO cella_app;
GRANT SELECT ON TABLE document_membership.reading TO cella_rules;


--
-- Name: COLUMN reading.read; Type: ACL; Schema: document_membership; Owner: -
--

GRANT UPDATE(read) ON TABLE document_membership.reading TO cella_app;


--
-- Name: TABLE device; Type: ACL; Schema: person; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE person.device TO cella_app;
GRANT SELECT ON TABLE person.device TO cella_rules;


--
-- Name: TABLE worker; Type: ACL; Schema: employment; Owner: -
--

GRANT SELECT,INSERT ON TABLE employment.worker TO cella_app;
GRANT SELECT ON TABLE employment.worker TO cella_rules;


--
-- Name: TABLE record; Type: ACL; Schema: employment_file; Owner: -
--

GRANT SELECT,INSERT ON TABLE employment_file.record TO cella_app;
GRANT SELECT ON TABLE employment_file.record TO cella_rules;


--
-- Name: TABLE candidacy; Type: ACL; Schema: employment_membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE employment_membership.candidacy TO cella_app;
GRANT SELECT ON TABLE employment_membership.candidacy TO cella_rules;


--
-- Name: TABLE receipt; Type: ACL; Schema: expense_file; Owner: -
--

GRANT SELECT,INSERT ON TABLE expense_file.receipt TO cella_app;
GRANT SELECT ON TABLE expense_file.receipt TO cella_rules;


--
-- Name: TABLE milestone; Type: ACL; Schema: project; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE project.milestone TO cella_app;
GRANT SELECT ON TABLE project.milestone TO cella_rules;


--
-- Name: TABLE progress; Type: ACL; Schema: project; Owner: -
--

GRANT SELECT ON TABLE project.progress TO cella_app;
GRANT SELECT ON TABLE project.progress TO cella_rules;


--
-- Name: TABLE booking; Type: ACL; Schema: project_timesheet; Owner: -
--

GRANT SELECT,INSERT ON TABLE project_timesheet.booking TO cella_app;
GRANT SELECT ON TABLE project_timesheet.booking TO cella_rules;


--
-- Name: TABLE cost; Type: ACL; Schema: project_timesheet; Owner: -
--

GRANT SELECT ON TABLE project_timesheet.cost TO cella_app;
GRANT SELECT ON TABLE project_timesheet.cost TO cella_rules;


--
-- Name: TABLE rate; Type: ACL; Schema: project_timesheet; Owner: -
--

GRANT SELECT ON TABLE project_timesheet.rate TO cella_app;
GRANT SELECT ON TABLE project_timesheet.rate TO cella_rules;


--
-- Name: TABLE entry; Type: ACL; Schema: timesheet; Owner: -
--

GRANT SELECT,INSERT ON TABLE timesheet.entry TO cella_app;
GRANT SELECT ON TABLE timesheet.entry TO cella_rules;


--
-- Name: TABLE costed; Type: ACL; Schema: project_timesheet; Owner: -
--

GRANT SELECT ON TABLE project_timesheet.costed TO cella_app;
GRANT SELECT ON TABLE project_timesheet.costed TO cella_rules;


--
-- Name: TABLE burn; Type: ACL; Schema: project_timesheet; Owner: -
--

GRANT SELECT ON TABLE project_timesheet.burn TO cella_app;
GRANT SELECT ON TABLE project_timesheet.burn TO cella_rules;


--
-- Name: TABLE threshold; Type: ACL; Schema: expense_invoice_project_timesheet; Owner: -
--

GRANT SELECT ON TABLE expense_invoice_project_timesheet.threshold TO cella_app;
GRANT SELECT ON TABLE expense_invoice_project_timesheet.threshold TO cella_rules;


--
-- Name: TABLE rebill; Type: ACL; Schema: expense_project; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE expense_project.rebill TO cella_app;
GRANT SELECT ON TABLE expense_project.rebill TO cella_rules;


--
-- Name: TABLE spent; Type: ACL; Schema: expense_project; Owner: -
--

GRANT SELECT ON TABLE expense_project.spent TO cella_app;
GRANT SELECT ON TABLE expense_project.spent TO cella_rules;


--
-- Name: TABLE invoice; Type: ACL; Schema: invoice; Owner: -
--

GRANT SELECT,INSERT ON TABLE invoice.invoice TO cella_app;
GRANT SELECT ON TABLE invoice.invoice TO cella_rules;


--
-- Name: COLUMN invoice.sent; Type: ACL; Schema: invoice; Owner: -
--

GRANT UPDATE(sent) ON TABLE invoice.invoice TO cella_app;


--
-- Name: COLUMN invoice.voided; Type: ACL; Schema: invoice; Owner: -
--

GRANT UPDATE(voided) ON TABLE invoice.invoice TO cella_app;


--
-- Name: COLUMN invoice.reason; Type: ACL; Schema: invoice; Owner: -
--

GRANT UPDATE(reason) ON TABLE invoice.invoice TO cella_app;


--
-- Name: TABLE charge; Type: ACL; Schema: invoice_project; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE invoice_project.charge TO cella_app;
GRANT SELECT ON TABLE invoice_project.charge TO cella_rules;


--
-- Name: TABLE invoiced; Type: ACL; Schema: invoice_project; Owner: -
--

GRANT SELECT ON TABLE invoice_project.invoiced TO cella_app;
GRANT SELECT ON TABLE invoice_project.invoiced TO cella_rules;


--
-- Name: TABLE posting; Type: ACL; Schema: expense_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE expense_transaction.posting TO cella_app;
GRANT SELECT ON TABLE expense_transaction.posting TO cella_rules;


--
-- Name: TABLE record; Type: ACL; Schema: file_membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE file_membership.record TO cella_app;
GRANT SELECT ON TABLE file_membership.record TO cella_rules;


--
-- Name: SEQUENCE number; Type: ACL; Schema: import; Owner: -
--

GRANT USAGE ON SEQUENCE import.number TO cella_app;


--
-- Name: TABLE run; Type: ACL; Schema: import; Owner: -
--

GRANT SELECT,INSERT ON TABLE import.run TO cella_app;
GRANT SELECT ON TABLE import.run TO cella_rules;


--
-- Name: TABLE series; Type: ACL; Schema: invoice; Owner: -
--

GRANT SELECT ON TABLE invoice.series TO cella_app;
GRANT SELECT ON TABLE invoice.series TO cella_rules;


--
-- Name: COLUMN series.next; Type: ACL; Schema: invoice; Owner: -
--

GRANT UPDATE(next) ON TABLE invoice.series TO cella_app;


--
-- Name: TABLE payment; Type: ACL; Schema: invoice; Owner: -
--

GRANT SELECT,INSERT ON TABLE invoice.payment TO cella_app;
GRANT SELECT ON TABLE invoice.payment TO cella_rules;


--
-- Name: TABLE posting; Type: ACL; Schema: invoice_transaction; Owner: -
--

GRANT SELECT,INSERT ON TABLE invoice_transaction.posting TO cella_app;
GRANT SELECT ON TABLE invoice_transaction.posting TO cella_rules;


--
-- Name: TABLE invitation; Type: ACL; Schema: membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE membership.invitation TO cella_app;
GRANT SELECT ON TABLE membership.invitation TO cella_rules;


--
-- Name: TABLE link; Type: ACL; Schema: membership; Owner: -
--

GRANT SELECT,INSERT ON TABLE membership.link TO cella_app;
GRANT SELECT ON TABLE membership.link TO cella_rules;


--
-- Name: TABLE share; Type: ACL; Schema: membership_project; Owner: -
--

GRANT SELECT,INSERT ON TABLE membership_project.share TO cella_app;
GRANT SELECT ON TABLE membership_project.share TO cella_rules;


--
-- Name: TABLE pot; Type: ACL; Schema: membership_project; Owner: -
--

GRANT SELECT ON TABLE membership_project.pot TO cella_app;
GRANT SELECT ON TABLE membership_project.pot TO cella_rules;


--
-- Name: TABLE salary; Type: ACL; Schema: payslip; Owner: -
--

GRANT SELECT ON TABLE payslip.salary TO cella_app;
GRANT SELECT ON TABLE payslip.salary TO cella_rules;


--
-- Name: TABLE period; Type: ACL; Schema: timesheet; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE timesheet.period TO cella_app;
GRANT SELECT ON TABLE timesheet.period TO cella_rules;


--
-- Name: TABLE terms; Type: ACL; Schema: payslip; Owner: -
--

GRANT SELECT ON TABLE payslip.terms TO cella_app;
GRANT SELECT ON TABLE payslip.terms TO cella_rules;


--
-- Name: TABLE run; Type: ACL; Schema: payslip; Owner: -
--

GRANT SELECT,INSERT ON TABLE payslip.run TO cella_app;
GRANT SELECT ON TABLE payslip.run TO cella_rules;


--
-- Name: COLUMN run.generated; Type: ACL; Schema: payslip; Owner: -
--

GRANT UPDATE(generated) ON TABLE payslip.run TO cella_app;


--
-- Name: COLUMN run.approved; Type: ACL; Schema: payslip; Owner: -
--

GRANT UPDATE(approved) ON TABLE payslip.run TO cella_app;


--
-- Name: COLUMN run.approver; Type: ACL; Schema: payslip; Owner: -
--

GRANT UPDATE(approver) ON TABLE payslip.run TO cella_app;


--
-- Name: COLUMN run.paid; Type: ACL; Schema: payslip; Owner: -
--

GRANT UPDATE(paid) ON TABLE payslip.run TO cella_app;


--
-- Name: TABLE sheet; Type: ACL; Schema: timesheet; Owner: -
--

GRANT SELECT ON TABLE timesheet.sheet TO cella_app;
GRANT SELECT ON TABLE timesheet.sheet TO cella_rules;


--
-- Name: TABLE report; Type: ACL; Schema: account; Owner: -
--

GRANT SELECT ON TABLE account.report TO cella_app;
GRANT SELECT ON TABLE account.report TO cella_rules;


--
-- Name: TABLE owed; Type: ACL; Schema: account_membership_transaction; Owner: -
--

GRANT SELECT ON TABLE account_membership_transaction.owed TO cella_app;
GRANT SELECT ON TABLE account_membership_transaction.owed TO cella_rules;


--
-- Name: TABLE authority; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT ON TABLE cella.authority TO PUBLIC;


--
-- Name: TABLE log; Type: ACL; Schema: cella; Owner: -
--

REVOKE SELECT ON TABLE cella.log FROM PUBLIC;


--
-- Name: COLUMN log.n; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(n) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.op; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(op) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.actor; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(actor) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.date; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(date) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.payload; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(payload) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.receipt; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(receipt) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.rules; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(rules) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.prev; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(prev) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.hash; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(hash) ON TABLE cella.log TO PUBLIC;


--
-- Name: COLUMN log.sig; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT(sig) ON TABLE cella.log TO PUBLIC;


--
-- Name: TABLE reach; Type: ACL; Schema: cella; Owner: -
--

GRANT SELECT ON TABLE cella.reach TO PUBLIC;


--
-- Name: TABLE setting; Type: ACL; Schema: circle_meeting; Owner: -
--

GRANT SELECT ON TABLE circle_meeting.setting TO cella_app;
GRANT SELECT ON TABLE circle_meeting.setting TO cella_rules;


--
-- Name: TABLE attendance; Type: ACL; Schema: meeting_membership; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE meeting_membership.attendance TO cella_app;
GRANT SELECT ON TABLE meeting_membership.attendance TO cella_rules;


--
-- Name: TABLE roll; Type: ACL; Schema: circle_meeting_membership; Owner: -
--

GRANT SELECT ON TABLE circle_meeting_membership.roll TO cella_app;
GRANT SELECT ON TABLE circle_meeting_membership.roll TO cella_rules;


--
-- Name: TABLE quorum; Type: ACL; Schema: circle_meeting_membership; Owner: -
--

GRANT SELECT ON TABLE circle_meeting_membership.quorum TO cella_app;
GRANT SELECT ON TABLE circle_meeting_membership.quorum TO cella_rules;


--
-- Name: TABLE billing; Type: ACL; Schema: client_invoice; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE client_invoice.billing TO cella_app;
GRANT SELECT ON TABLE client_invoice.billing TO cella_rules;


--
-- Name: TABLE standing; Type: ACL; Schema: invoice; Owner: -
--

GRANT SELECT ON TABLE invoice.standing TO cella_app;
GRANT SELECT ON TABLE invoice.standing TO cella_rules;


--
-- Name: TABLE standing; Type: ACL; Schema: client_invoice; Owner: -
--

GRANT SELECT ON TABLE client_invoice.standing TO cella_app;
GRANT SELECT ON TABLE client_invoice.standing TO cella_rules;


--
-- Name: TABLE commission; Type: ACL; Schema: client_project; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE client_project.commission TO cella_app;
GRANT SELECT ON TABLE client_project.commission TO cella_rules;


--
-- Name: TABLE cites; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT ON TABLE decision.cites TO cella_app;
GRANT SELECT ON TABLE decision.cites TO cella_rules;


--
-- Name: TABLE kind; Type: ACL; Schema: decision; Owner: -
--

GRANT SELECT ON TABLE decision.kind TO cella_app;
GRANT SELECT ON TABLE decision.kind TO cella_rules;


--
-- Name: TABLE path; Type: ACL; Schema: employment_membership; Owner: -
--

GRANT SELECT ON TABLE employment_membership.path TO cella_app;
GRANT SELECT ON TABLE employment_membership.path TO cella_rules;


--
-- Name: TABLE admission; Type: ACL; Schema: decision_employment_membership; Owner: -
--

GRANT SELECT ON TABLE decision_employment_membership.admission TO cella_app;
GRANT SELECT ON TABLE decision_employment_membership.admission TO cella_rules;


--
-- Name: TABLE tabled; Type: ACL; Schema: decision_meeting; Owner: -
--

GRANT SELECT,INSERT ON TABLE decision_meeting.tabled TO cella_app;
GRANT SELECT ON TABLE decision_meeting.tabled TO cella_rules;


--
-- Name: TABLE mention; Type: ACL; Schema: decision_membership; Owner: -
--

GRANT SELECT ON TABLE decision_membership.mention TO cella_app;
GRANT SELECT ON TABLE decision_membership.mention TO cella_rules;


--
-- Name: TABLE adopted; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT ON TABLE document.adopted TO cella_app;
GRANT SELECT ON TABLE document.adopted TO cella_rules;


--
-- Name: TABLE comment; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT,INSERT ON TABLE document.comment TO cella_app;
GRANT SELECT ON TABLE document.comment TO cella_rules;


--
-- Name: COLUMN comment.resolved; Type: ACL; Schema: document; Owner: -
--

GRANT UPDATE(resolved) ON TABLE document.comment TO cella_app;


--
-- Name: TABLE update; Type: ACL; Schema: document; Owner: -
--

GRANT SELECT,INSERT ON TABLE document.update TO cella_app;
GRANT SELECT ON TABLE document.update TO cella_rules;


--
-- Name: TABLE texts; Type: ACL; Schema: document_membership; Owner: -
--

GRANT SELECT ON TABLE document_membership.texts TO cella_app;
GRANT SELECT ON TABLE document_membership.texts TO cella_rules;


--
-- Name: TABLE slip; Type: ACL; Schema: employment_payslip; Owner: -
--

GRANT SELECT ON TABLE employment_payslip.slip TO cella_app;
GRANT SELECT ON TABLE employment_payslip.slip TO cella_rules;


--
-- Name: TABLE sheet; Type: ACL; Schema: employment_timesheet; Owner: -
--

GRANT SELECT ON TABLE employment_timesheet.sheet TO cella_app;
GRANT SELECT ON TABLE employment_timesheet.sheet TO cella_rules;


--
-- Name: TABLE claim; Type: ACL; Schema: expense_membership; Owner: -
--

GRANT SELECT ON TABLE expense_membership.claim TO cella_app;
GRANT SELECT ON TABLE expense_membership.claim TO cella_rules;


--
-- Name: TABLE contract; Type: ACL; Schema: file; Owner: -
--

GRANT SELECT ON TABLE file.contract TO cella_rules;


--
-- Name: TABLE receipt; Type: ACL; Schema: file; Owner: -
--

GRANT SELECT ON TABLE file.receipt TO cella_rules;


--
-- Name: TABLE record; Type: ACL; Schema: file; Owner: -
--

GRANT SELECT ON TABLE file.record TO cella_rules;


--
-- Name: TABLE shared; Type: ACL; Schema: file; Owner: -
--

GRANT SELECT ON TABLE file.shared TO cella_rules;


--
-- Name: TABLE line; Type: ACL; Schema: invoice; Owner: -
--

GRANT SELECT,INSERT ON TABLE invoice.line TO cella_app;
GRANT SELECT ON TABLE invoice.line TO cella_rules;


--
-- Name: TABLE item; Type: ACL; Schema: meeting; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE meeting.item TO cella_app;
GRANT SELECT ON TABLE meeting.item TO cella_rules;


--
-- Name: TABLE assignment; Type: ACL; Schema: membership_task; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE membership_task.assignment TO cella_app;
GRANT SELECT ON TABLE membership_task.assignment TO cella_rules;


--
-- Name: TABLE work_share; Type: ACL; Schema: patronage_payslip; Owner: -
--

GRANT SELECT ON TABLE patronage_payslip.work_share TO cella_app;
GRANT SELECT ON TABLE patronage_payslip.work_share TO cella_rules;


--
-- Name: TABLE time_share; Type: ACL; Schema: patronage_timesheet; Owner: -
--

GRANT SELECT ON TABLE patronage_timesheet.time_share TO cella_app;
GRANT SELECT ON TABLE patronage_timesheet.time_share TO cella_rules;


--
-- Name: TABLE filing; Type: ACL; Schema: project_task; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE project_task.filing TO cella_app;
GRANT SELECT ON TABLE project_task.filing TO cella_rules;


--
-- Name: SEQUENCE number; Type: ACL; Schema: task; Owner: -
--

GRANT USAGE ON SEQUENCE task.number TO cella_app;


--
-- Name: TABLE task; Type: ACL; Schema: task; Owner: -
--

GRANT SELECT,INSERT,UPDATE ON TABLE task.task TO cella_app;
GRANT SELECT ON TABLE task.task TO cella_rules;


--
-- Name: TABLE count; Type: ACL; Schema: project_task; Owner: -
--

GRANT SELECT ON TABLE project_task.count TO cella_app;
GRANT SELECT ON TABLE project_task.count TO cella_rules;


--
-- Name: TABLE journal; Type: ACL; Schema: transaction; Owner: -
--

GRANT SELECT ON TABLE transaction.journal TO cella_app;
GRANT SELECT ON TABLE transaction.journal TO cella_rules;


--
-- PostgreSQL database dump complete
--

\unrestrict qk5MaGWnnMZyLzOwz0jTpc6RtuKCGdHGp6NRzhitNDPBc5iDHI5Eg8Kd1QH320a

